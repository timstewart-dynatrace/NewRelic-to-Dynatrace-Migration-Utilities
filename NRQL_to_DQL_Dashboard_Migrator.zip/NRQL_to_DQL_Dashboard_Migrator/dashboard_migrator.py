#!/usr/bin/env python3
"""
US Foods Dashboard Migration Tool - Complete Solution
=====================================================

Migrates dashboards from New Relic to Dynatrace with:
- NRQL to DQL conversion with built-in validation
- Automatic syntax fixing during conversion
- Layout/positioning preservation
- Comprehensive error handling and reporting

Usage:
    python3 dashboard_migrator.py --list                    # List NR dashboards
    python3 dashboard_migrator.py --dry-run                 # Preview without uploading
    python3 dashboard_migrator.py --migrate                 # Full migration
    python3 dashboard_migrator.py --migrate --dashboard "Name"  # Single dashboard
    python3 dashboard_migrator.py --validate-only           # Just validate existing DT dashboards
"""

import os
import re
import json
import base64
import time
import logging
import requests
import urllib.request
import urllib.error
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)
import argparse


# ============================================================================
# DQL SYNTAX VALIDATOR
# ============================================================================

@dataclass
class DQLValidationError:
    line: int
    column: int
    message: str
    severity: str  # ERROR, WARNING

@dataclass 
class DQLValidationResult:
    valid: bool
    errors: List[DQLValidationError]
    query: str

class DQLSyntaxValidator:
    """
    Validates DQL syntax based on Dynatrace's DQL grammar rules.
    Catches common NRQL->DQL conversion errors BEFORE upload.
    """
    
    # Case-INSENSITIVE patterns (things that are wrong regardless of case)
    INVALID_PATTERNS_ICASE = [
        # Single = for comparison (should be ==)
        (r'(?<![=!<>])\s*=\s*(?![=])"', "Single '=' used for comparison - use '==' instead"),
        (r'(?<![=!<>])\s*=\s*(?![=])\d', "Single '=' used for comparison - use '==' instead"),
        (r'(?<![=!<>])\s*=\s*(?![=])\$', "Single '=' used for comparison - use '==' instead"),
        
        # !== is not valid DQL (should be !=)
        (r'!==', "'!==' is not valid in DQL - use '!=' instead"),
        
        # Single quotes for strings (should be double quotes)
        (r"==\s*'[^']*'", "Single quotes used for string - use double quotes in DQL"),
        
        # LIKE keyword
        (r'\bLIKE\b', "'LIKE' is not valid in DQL - use contains(), startsWith(), or endsWith()"),
        
        # <> for not equal
        (r'<>', "'<>' should be '!=' in DQL"),
        
        # Double pipes
        (r'\|\|', "'||' is not valid in DQL - use 'or' for logical OR"),
        
        # Semicolons
        (r';(?!\s*$)', "Semicolons are not used in DQL"),
        
        # NR-specific functions
        (r'\bpercentage\s*\(', "'percentage()' is not a valid DQL function - use countIf()/count()"),
        (r'countIf\s*\([^)]*countIf\s*\(', "Nested aggregation: countIf() inside countIf() - DQL error NO_NESTED_AGGREGATIONS"),
        (r'countIf\s*\([^)]*\bcount\s*\(', "Nested aggregation: count() inside countIf() - DQL error NO_NESTED_AGGREGATIONS"),
        (r'\bsum\s*\([^)]*\bavg\s*\(', "Nested aggregation: avg() inside sum() - DQL error NO_NESTED_AGGREGATIONS"),
        (r'\bmax\s*\([^)]*\bcount\s*\(', "Nested aggregation: count() inside max() - DQL error NO_NESTED_AGGREGATIONS"),
        (r'\buniqueCount\s*\(', "'uniqueCount()' should be 'countDistinct()' in DQL"),
        (r'\bfunnel\s*\(', "'funnel()' is not available in DQL"),
        
        # Malformed contains/startsWith/endsWith - must have parentheses around them for negation
        # Wrong: not contains(x, y)  or  contains(not, y)
        # Right: not(contains(x, y))
        (r'\bnot\s+contains\s*\(', "'not contains()' is invalid - use 'not(contains(field, value))'"),
        (r'\bcontains\s*\(\s*not\s*,', "'contains(not, ...)' is invalid - use 'not(contains(field, value))'"),
        (r'\bnot\s+startsWith\s*\(', "'not startsWith()' is invalid - use 'not(startsWith(field, value))'"),
        (r'\bnot\s+endsWith\s*\(', "'not endsWith()' is invalid - use 'not(endsWith(field, value))'"),
        
        # takeLast/takeFirst in timeseries/makeTimeseries (only valid in summarize)
        (r'(?:make)?[Tt]imeseries\s+.*\btakeLast\s*\(', "'takeLast()' is not valid in timeseries/makeTimeseries - use avg(), max(), or sum()"),
        (r'(?:make)?[Tt]imeseries\s+.*\btakeFirst\s*\(', "'takeFirst()' is not valid in timeseries/makeTimeseries - use avg(), max(), or sum()"),
        (r'(?:make)?[Tt]imeseries\s+.*\btakeAny\s*\(', "'takeAny()' is not valid in timeseries/makeTimeseries - use avg(), max(), or sum()"),
    ]
    
    # Case-SENSITIVE patterns (where case matters)
    INVALID_PATTERNS_CASE = [
        # WHERE keyword (uppercase only - lowercase 'where' inside strings is fine)
        (r'\bWHERE\b', "'WHERE' is not valid in DQL - use 'filter' instead"),
        
        # AND/OR uppercase (lowercase is correct)
        (r'\bAND\b', "'AND' should be lowercase 'and' in DQL"),
        (r'\bOR\b', "'OR' should be lowercase 'or' in DQL"),
        (r'\bNOT\b', "'NOT' should be lowercase 'not' in DQL"),
        
        # IS NULL uppercase
        (r'\bIS\s+NULL\b', "'IS NULL' should be 'isNull(field)' in DQL"),
        (r'\bIS\s+NOT\s+NULL\b', "'IS NOT NULL' should be 'isNotNull(field)' in DQL"),
        
        # FACET keyword
        (r'\bFACET\b', "'FACET' is not valid in DQL - use 'by: {field}' instead"),
        
        # SELECT keyword
        (r'\bSELECT\b', "'SELECT' is not valid in DQL"),
        
        # FROM keyword (uppercase)
        (r'\bFROM\b', "'FROM' is not valid in DQL - use 'fetch <type>'"),
        
        # SINCE/UNTIL keywords
        (r'\bSINCE\b', "'SINCE' is not valid in DQL - use from: parameter"),
        (r'\bUNTIL\b', "'UNTIL' is not valid in DQL - use to: parameter"),
    ]
    
    def validate(self, dql: str) -> DQLValidationResult:
        """Validate a DQL query and return detailed results."""
        errors = []
        
        # Skip validation for comment-only or empty queries
        lines = dql.strip().split('\n')
        non_comment_lines = [l for l in lines if l.strip() and not l.strip().startswith('//')]
        
        if not non_comment_lines:
            return DQLValidationResult(valid=True, errors=[], query=dql)
        
        dql_only = '\n'.join(non_comment_lines)
        
        # Check case-insensitive patterns
        for pattern, message in self.INVALID_PATTERNS_ICASE:
            try:
                for match in re.finditer(pattern, dql_only, re.IGNORECASE):
                    line_num, col = self._get_position(dql_only, match.start())
                    errors.append(DQLValidationError(
                        line=line_num,
                        column=col,
                        message=message,
                        severity="ERROR"
                    ))
            except re.error:
                continue
        
        # Check case-sensitive patterns (NO re.IGNORECASE)
        for pattern, message in self.INVALID_PATTERNS_CASE:
            try:
                for match in re.finditer(pattern, dql_only):  # No IGNORECASE!
                    line_num, col = self._get_position(dql_only, match.start())
                    errors.append(DQLValidationError(
                        line=line_num,
                        column=col,
                        message=message,
                        severity="ERROR"
                    ))
            except re.error:
                continue
        
        # Check balanced parentheses
        paren_error = self._check_balanced_parens(dql_only)
        if paren_error:
            errors.append(paren_error)
        
        # Check balanced braces
        brace_error = self._check_balanced_braces(dql_only)
        if brace_error:
            errors.append(brace_error)
        
        # Check first command
        first_cmd_error = self._check_first_command(dql_only)
        if first_cmd_error:
            errors.append(first_cmd_error)
        
        return DQLValidationResult(
            valid=len([e for e in errors if e.severity == "ERROR"]) == 0,
            errors=errors,
            query=dql
        )
    
    def _get_position(self, text: str, index: int) -> Tuple[int, int]:
        """Get line number and column from character index"""
        lines = text[:index].split('\n')
        line_num = len(lines)
        col = len(lines[-1]) + 1 if lines else 1
        return line_num, col
    
    def _check_balanced_parens(self, dql: str) -> Optional[DQLValidationError]:
        """Check for balanced parentheses"""
        count = 0
        for i, char in enumerate(dql):
            if char == '(':
                count += 1
            elif char == ')':
                count -= 1
                if count < 0:
                    line, col = self._get_position(dql, i)
                    return DQLValidationError(
                        line=line, column=col,
                        message="Unbalanced parentheses - extra ')'",
                        severity="ERROR"
                    )
        if count > 0:
            return DQLValidationError(
                line=1, column=1,
                message=f"Unbalanced parentheses - missing {count} closing ')'",
                severity="ERROR"
            )
        return None
    
    def _check_balanced_braces(self, dql: str) -> Optional[DQLValidationError]:
        """Check for balanced braces"""
        count = 0
        for i, char in enumerate(dql):
            if char == '{':
                count += 1
            elif char == '}':
                count -= 1
                if count < 0:
                    line, col = self._get_position(dql, i)
                    return DQLValidationError(
                        line=line, column=col,
                        message="Unbalanced braces - extra '}'",
                        severity="ERROR"
                    )
        if count > 0:
            return DQLValidationError(
                line=1, column=1,
                message=f"Unbalanced braces - missing {count} closing '}}'",
                severity="ERROR"
            )
        return None
    
    def _check_first_command(self, dql: str) -> Optional[DQLValidationError]:
        """Check that query starts with valid DQL command"""
        valid_starts = {'fetch', 'timeseries', 'data'}
        
        for line in dql.split('\n'):
            line = line.strip()
            if line and not line.startswith('//'):
                first_word = line.split()[0].lower() if line.split() else ''
                if first_word not in valid_starts:
                    return DQLValidationError(
                        line=1, column=1,
                        message=f"DQL must start with 'fetch', 'timeseries', or 'data', not '{first_word}'",
                        severity="ERROR"
                    )
                break
        return None


# ============================================================================
# CONFIGURATION
# ============================================================================

NR_API_KEY = os.environ.get("NR_API_KEY", "")
NR_ACCOUNT_ID = os.environ.get("NR_ACCOUNT_ID", "")
NR_GRAPHQL_URL = "https://api.newrelic.com/graphql"

DT_ENV_URL = os.environ.get("DT_ENV_URL", "https://.apps.dynatrace.com")
DT_API_TOKEN = os.environ.get("DT_API_TOKEN", "")

# OAuth credentials for auto-token-refresh (no more manual token copying!)
DT_OAUTH_CLIENT_ID = ""
DT_OAUTH_CLIENT_SECRET = ""
DT_OAUTH_SCOPES = "document:documents:read document:documents:write document:documents:admin settings:objects:read settings:objects:write slo:slos:read slo:slos:write storage:logs:read storage:spans:read storage:events:read storage:metrics:read storage:buckets:read"

# SSL workaround for macOS certificate issues
import ssl
SSL_CONTEXT = ssl.create_default_context()
SSL_CONTEXT.check_hostname = False
SSL_CONTEXT.verify_mode = ssl.CERT_NONE

def _nrql_comment(nrql: str) -> str:
    """Format NRQL as a safe single-line DQL comment.
    
    Multi-line NRQL must be collapsed to one line so continuation lines
    don't leak raw NRQL code into the DQL body (DT would try to parse them).
    """
    return '// Original NRQL: ' + ' '.join(nrql.split())

def ms_to_dql_duration(ms: float) -> str:
    """Convert milliseconds to the most readable DQL duration literal.
    
    DQL duration type requires literals like 2s, 500ms, 1m â€” NOT raw nanosecond integers.
    Examples: 2000 â†’ '2s', 500 â†’ '500ms', 60000 â†’ '1m', 0.5 â†’ '500us'
    """
    if ms <= 0:
        return "0s"
    if ms >= 86_400_000 and ms % 86_400_000 == 0:
        return f"{int(ms // 86_400_000)}d"
    if ms >= 3_600_000 and ms % 3_600_000 == 0:
        return f"{int(ms // 3_600_000)}h"
    if ms >= 60_000 and ms % 60_000 == 0:
        return f"{int(ms // 60_000)}m"
    if ms >= 1000 and ms % 1000 == 0:
        return f"{int(ms // 1000)}s"
    if ms == int(ms):
        return f"{int(ms)}ms"
    us = ms * 1000
    if us == int(us):
        return f"{int(us)}us"
    return f"{ms}ms"

def get_auth_header(token: str) -> str:
    """Return correct Authorization header based on token type."""
    if token.startswith('dt0c01.'):
        return f"Api-Token {token}"
    else:
        return f"Bearer {token}"

def get_dt_oauth_token():
    """Automatically fetch OAuth token using client credentials."""
    import urllib.request
    import urllib.parse
    
    token_url = "https://sso.dynatrace.com/sso/oauth2/token"
    
    data = urllib.parse.urlencode({
        'grant_type': 'client_credentials',
        'client_id': DT_OAUTH_CLIENT_ID,
        'client_secret': DT_OAUTH_CLIENT_SECRET,
        'scope': DT_OAUTH_SCOPES
    }).encode('utf-8')
    
    req = urllib.request.Request(token_url, data=data, headers={
        'Content-Type': 'application/x-www-form-urlencoded'
    })
    
    try:
        with urllib.request.urlopen(req, timeout=30, context=SSL_CONTEXT) as response:
            result = json.loads(response.read().decode('utf-8'))
            return result.get('access_token')
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8') if hasattr(e, 'read') else ''
        print(f"OAuth Error: {e.code} - {error_body}")
        return None
    except Exception as e:
        print(f"Warning: Could not auto-fetch OAuth token: {e}")
        return None

# Dashboard schema version for Dynatrace
DT_DASHBOARD_VERSION = 19
DT_GRID_COLUMNS = 24  # DT uses 24-column grid, NR uses 12-column

# ============================================================================
# MVP DASHBOARDS (from Excel: Is MVP = Y)
# ============================================================================

MVP_DASHBOARDS = [
    {"name": "AEM_PROD", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6MTA5NzcxMA", "owner": "Digital"},
    {"name": "ECOM_R4_Search", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6MjIxNzA5NA", "owner": "Spotlight"},
    {"name": "Moxe - Product Discovery", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6NDI1MTYzMg", "owner": "Ordering"},
    {"name": "MOXe Shared Services", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6NDg2OTU4NQ", "owner": "Shared Services"},
    {"name": "Moxe_Prod_List_Domain", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6MzE0ODE2Ng", "owner": "List"},
    {"name": "Moxe_Prod_MPP_Domain", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6MTAxNjgyNjE", "owner": "Customer Tools"},
    {"name": "Moxe_Prod_Order", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6MTE3MzI4NDk", "owner": "Ordering"},
    {"name": "Moxe_Prod_Payment_Domain", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6MTE2MDM4NzM", "owner": "Payments"},
    {"name": "Moxe_Prod_Platform", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6NTcyODI5OA", "owner": "Platform"},
    {"name": "Price Domain API", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6ODIzNzgzOA", "owner": "List"},
    {"name": "Pricing Calls Data", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6MTg4NjQ1Mg", "owner": "List"},
    {"name": "Product Domain API", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6ODIzNzgzOQ", "owner": "Ordering"},
    {"name": "Search Domain", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6ODkxOTA2Ng", "owner": "Spotlight"},
    {"name": "ECOM_R4_SLO", "guid": "Mzk5MDk2fFZJWnxEQVNIQk9BUkR8ZGE6MjcwMDczNg", "owner": "Ecom"},
]

# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class ConversionResult:
    """Result of a single NRQL to DQL conversion"""
    original_nrql: str
    converted_dql: str
    fixes_applied: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    confidence: str = "HIGH"  # HIGH, MEDIUM, LOW
    success: bool = True

@dataclass 
class TileResult:
    """Result of converting a single tile/widget"""
    title: str
    tile_type: str
    conversion: Optional[ConversionResult] = None
    layout: Dict = field(default_factory=dict)
    success: bool = True
    error: str = ""

@dataclass
class DashboardResult:
    """Result of a full dashboard migration"""
    name: str
    nr_guid: str
    dt_id: str = ""
    total_tiles: int = 0
    successful_tiles: int = 0
    tiles_with_fixes: int = 0
    total_fixes: int = 0
    tile_results: List[TileResult] = field(default_factory=list)
    success: bool = True
    error: str = ""

# ============================================================================
# NRQL TO DQL MAPPINGS
# ============================================================================

# Event type to DT data source
EVENT_TYPE_MAP = {
    # APM/Transaction data
    'transaction': 'spans',
    'transactionerror': 'spans',
    'span': 'spans',
    
    # Metric data - use METRIC to trigger timeseries queries
    'metric': 'METRIC',
    'systemsample': 'METRIC',
    'processsample': 'METRIC',
    'networksample': 'METRIC',
    'storagesample': 'METRIC',
    
    # K8s samples - these are METRICS, not events
    'k8snodesample': 'K8S_NODE_METRIC',
    'k8scontainersample': 'K8S_WORKLOAD_METRIC',
    'k8spodsample': 'K8S_POD_METRIC',
    'k8sclustersample': 'K8S_CLUSTER_METRIC',
    'k8sdeploymentsample': 'K8S_WORKLOAD_METRIC',
    
    # Container metrics
    'containersample': 'METRIC',
    
    # Log data
    'log': 'logs',
    'logevent': 'logs',
    
    # Synthetic data
    'syntheticcheck': 'dt.synthetic.http.request',
    'syntheticsrequest': 'dt.synthetic.http.request',
    
    # Browser/RUM data
    'pageview': 'bizevents',
    'pageaction': 'bizevents',
    'browserinteraction': 'bizevents',
    'ajaxrequest': 'bizevents',
    'javascripterror': 'bizevents',
    
    # Lambda
    'awslambdainvocation': 'spans',
    
    # Custom events
    'nrcustomappevent': 'bizevents',
    
    # Infrastructure events
    'infrastructureevent': 'events',
}

# Metric field to DT metric key
# VERIFIED against official Dynatrace documentation:
#   - Service metrics: docs.dynatrace.com/docs/analyze-explore-automate/metrics/upgrade/service-metric-migration
#   - Host metrics: docs.dynatrace.com/docs/observe/infrastructure-observability/hosts/reference/metrics
#   - K8s metrics: docs.dynatrace.com/docs/analyze-explore-automate/metrics/upgrade/kubernetes-metric-migration
#   - Grail metrics: docs.dynatrace.com/docs/analyze-explore-automate/metrics/built-in-metrics-on-grail
#
# Uses Grail (dt.*) keys as primary â€” they're the current standard for DQL timeseries queries.
# Classic (builtin:*) keys still work in DQL but K8s classics are deprecated.
#
# Keys in this map are NR field names normalized: lowercased, dots/underscores stripped.
# e.g. NR "k8s.container.memoryUsedBytes" â†’ key "k8scontainermemoryusedbytes"

METRIC_MAP = {
    # =========================================================================
    # SERVICE / APM METRICS
    # Grail: dt.service.request.response_time, dt.service.request.count,
    #        dt.service.request.failure_count
    # Classic (still works): builtin:service.response.time, etc.
    # =========================================================================
    
    # Response time / duration
    'duration': 'dt.service.request.response_time',
    'durationms': 'dt.service.request.response_time',
    'webduration': 'dt.service.request.response_time',
    'totaltime': 'dt.service.request.response_time',
    'responsetime': 'dt.service.request.response_time',
    # NR FROM Metric dotted names (normalized)
    'apmservicetransactionduration': 'dt.service.request.response_time',
    'apmserviceoverviewresponsetime': 'dt.service.request.response_time',
    
    # External/database duration â€” NR-specific breakdown, DT doesn't split these
    # Map to response_time as closest equivalent; add warning in converter
    'externalduration': 'dt.service.request.response_time',
    'databaseduration': 'dt.service.request.response_time',
    'externalallweb': 'dt.service.request.response_time',
    
    # Error metrics
    'errorrate': 'dt.service.request.failure_count',      # NOTE: rate must be calculated from count+failure_count
    'errorcount': 'dt.service.request.failure_count',
    'apmserviceerrorcount': 'dt.service.request.failure_count',
    
    # Throughput / request count
    'throughput': 'dt.service.request.count',
    'requestsperminute': 'dt.service.request.count',
    'requestcount': 'dt.service.request.count',
    'apmservicetransactioncount': 'dt.service.request.count',
    'apmserviceoverviewthroughput': 'dt.service.request.count',
    
    # Apdex â€” Classic only, NOT available on Grail
    'apdex': 'builtin:service.apdex',
    
    # =========================================================================
    # HOST METRICS â€” CPU
    # Classic: builtin:host.cpu.*  |  Grail: dt.host.cpu.*
    # Ref: docs.dynatrace.com/docs/observe/infrastructure-observability/hosts/reference/metrics
    # =========================================================================
    'cpupercent': 'dt.host.cpu.usage',
    'cpuusagepercent': 'dt.host.cpu.usage',
    'cpusystempercent': 'dt.host.cpu.system',
    'cpuuserpercent': 'dt.host.cpu.user',
    'cpuidlepercent': 'dt.host.cpu.idle',
    'cpuiowaitpercent': 'dt.host.cpu.iowait',
    'cpustealpercent': 'dt.host.cpu.steal',
    'systemload': 'dt.host.cpu.load',
    'loadaverage1min': 'dt.host.cpu.load',
    'loadaverage5min': 'dt.host.cpu.load5m',
    'loadaverage15min': 'dt.host.cpu.load15m',
    # NR SystemSample normalized names
    'cpuutilization': 'dt.host.cpu.usage',
    
    # =========================================================================
    # HOST METRICS â€” MEMORY
    # Classic: builtin:host.mem.*  |  Grail: dt.host.memory.*
    # NOTE: Grail uses "memory" not "mem"
    # =========================================================================
    'memoryusedpercent': 'dt.host.memory.usage',
    'memoryutilization': 'dt.host.memory.usage',
    'memoryfreebytes': 'dt.host.memory.avail.bytes',
    'memoryfree': 'dt.host.memory.avail.bytes',
    'memoryfreepercent': 'dt.host.memory.avail.percent',
    'memoryused': 'dt.host.memory.used',
    'memoryusedbytes': 'dt.host.memory.used',       # Host context; K8s context handled separately
    'swapused': 'dt.host.memory.swap.used',
    'swapfree': 'dt.host.memory.swap.avail',
    'swaptotal': 'dt.host.memory.swap.total',
    'pagefaults': 'dt.host.memory.avail.pfps',
    
    # =========================================================================
    # HOST METRICS â€” DISK
    # Classic: builtin:host.disk.*  |  Grail: dt.host.disk.*
    # =========================================================================
    'diskusedpercent': 'dt.host.disk.used.percent',
    'diskutilization': 'dt.host.disk.used.percent',
    'diskfreepercent': 'dt.host.disk.free',
    'diskused': 'dt.host.disk.used',
    'diskusedbytes': 'dt.host.disk.used',
    'diskfree': 'dt.host.disk.avail',
    'diskreadbytespersecond': 'dt.host.disk.bytes_read',
    'diskwritebytespersecond': 'dt.host.disk.bytes_written',
    'diskreadops': 'dt.host.disk.read_ops',
    'diskwriteops': 'dt.host.disk.write_ops',
    'diskutiltime': 'dt.host.disk.util_time',
    'diskqueuelength': 'dt.host.disk.queue_length',
    'inodesused': 'dt.host.disk.inodes_used',
    'inodesavailpercent': 'dt.host.disk.inodes_avail',
    
    # =========================================================================
    # HOST METRICS â€” NETWORK
    # Classic: builtin:host.net.nic.*  |  Grail: dt.host.net.nic.*
    # =========================================================================
    'networkrxbytes': 'dt.host.net.nic.bytes_rx',
    'networktxbytes': 'dt.host.net.nic.bytes_tx',
    'networkreceivedpersecond': 'dt.host.net.nic.bytes_rx',
    'networksentpersecond': 'dt.host.net.nic.bytes_tx',
    'transmitbytespersecond': 'dt.host.net.nic.bytes_tx',
    'receivebytespersecond': 'dt.host.net.nic.bytes_rx',
    'networkreceiveerrors': 'dt.host.net.nic.packets.errors_rx',
    'networktransmiterrors': 'dt.host.net.nic.packets.errors_tx',
    'networkreceivedropped': 'dt.host.net.nic.packets.dropped_rx',
    'networktransmitdropped': 'dt.host.net.nic.packets.dropped_tx',
    
    # =========================================================================
    # KUBERNETES CONTAINER METRICS (Grail: dt.kubernetes.container.*)
    # These are the primary K8s metrics in Grail. Workload/node aggregation
    # is done via by:{k8s.workload.name} or by:{k8s.node.name} in the query.
    #
    # Ref: docs.dynatrace.com/docs/analyze-explore-automate/metrics/upgrade/kubernetes-metric-migration
    # Classic (DEPRECATED): builtin:kubernetes.workload.cpu_usage â†’ dt.kubernetes.container.cpu_usage
    # =========================================================================
    
    # CPU
    'k8scontainercpuusedcores': 'dt.kubernetes.container.cpu_usage',
    'k8scontainercpucoresutilization': 'dt.kubernetes.container.cpu_usage',
    'cpuusedcores': 'dt.kubernetes.container.cpu_usage',                      # NR K8sContainerSample field
    'containercpuusage': 'dt.kubernetes.container.cpu_usage',
    'cpucoresutilization': 'dt.kubernetes.container.cpu_usage',
    'cputhrottled': 'dt.kubernetes.container.cpu_throttled',
    
    # CPU Requests & Limits
    'cpurequestscores': 'dt.kubernetes.container.requests_cpu',
    'cpulimitscores': 'dt.kubernetes.container.limits_cpu',
    'requestscpu': 'dt.kubernetes.container.requests_cpu',
    'limitscpu': 'dt.kubernetes.container.limits_cpu',
    
    # Memory
    'k8scontainermemoryusedbytes': 'dt.kubernetes.container.memory_working_set',
    'k8scontainermemoryutilization': 'dt.kubernetes.container.memory_working_set',
    'containermemoryusedbytes': 'dt.kubernetes.container.memory_working_set',
    'memoryworkingsetbytes': 'dt.kubernetes.container.memory_working_set',     # NR K8sContainerSample
    
    # Memory Requests & Limits
    'memoryrequestsbytes': 'dt.kubernetes.container.requests_memory',
    'memorylimitsbytes': 'dt.kubernetes.container.limits_memory',
    'requestsmemory': 'dt.kubernetes.container.requests_memory',
    'limitsmemory': 'dt.kubernetes.container.limits_memory',
    
    # Container lifecycle
    'k8scontainerrestartcountdelta': 'dt.kubernetes.container.restarts',
    'k8scontainerrestartcount': 'dt.kubernetes.container.restarts',
    'restartcount': 'dt.kubernetes.container.restarts',
    'restartcountdelta': 'dt.kubernetes.container.restarts',
    'outofmemorykills': 'dt.kubernetes.container.oom_kills',
    'oomkills': 'dt.kubernetes.container.oom_kills',
    
    # Container readiness â€” DT uses workload conditions, not per-container isReady
    'k8scontainerisready': 'dt.kubernetes.workload.conditions',
    'isready': 'dt.kubernetes.workload.conditions',
    
    # =========================================================================
    # KUBERNETES NODE METRICS (Grail: dt.kubernetes.node.*)
    # Node-level resource usage = aggregate container metrics by node:
    #   timeseries sum(dt.kubernetes.container.cpu_usage), by:{k8s.node.name}
    # Node allocatable resources have dedicated metrics.
    # =========================================================================
    
    # Node allocatable (these ARE dedicated node metrics)
    'allocatablecpucores': 'dt.kubernetes.node.cpu_allocatable',
    'allocatablecpuutilization': 'dt.kubernetes.node.cpu_allocatable',        # NOTE: utilization = usage/allocatable, needs calc
    'allocatablecpucoresutilization': 'dt.kubernetes.node.cpu_allocatable',   # NR variant with "Cores" in name
    'cpuallocatable': 'dt.kubernetes.node.cpu_allocatable',
    'allocatablememorybytes': 'dt.kubernetes.node.memory_allocatable',
    'allocatablememoryutilization': 'dt.kubernetes.node.memory_allocatable',   # NOTE: utilization needs calc
    'memoryallocatable': 'dt.kubernetes.node.memory_allocatable',
    'allocatablepods': 'dt.kubernetes.node.pods_allocatable',
    
    # Node memory (usage) â€” In Grail, aggregate container metrics to node level
    # Map to container.memory_working_set; converter will add by:{k8s.node.name}
    'memoryavailablebytes': 'dt.kubernetes.container.memory_working_set',      # K8s context
    
    # =========================================================================
    # KUBERNETES POD METRICS
    # Pod-level = container metrics grouped by pod:
    #   timeseries sum(dt.kubernetes.container.cpu_usage), by:{k8s.pod.name}
    # =========================================================================
    'k8spodcpuusedbytes': 'dt.kubernetes.container.cpu_usage',
    'k8spodmemoryusedbytes': 'dt.kubernetes.container.memory_working_set',
    'podcpuusage': 'dt.kubernetes.container.cpu_usage',
    'podmemoryusage': 'dt.kubernetes.container.memory_working_set',
    
    # =========================================================================
    # KUBERNETES CLUSTER / WORKLOAD COUNTS
    # =========================================================================
    'podsrunning': 'dt.kubernetes.pods',
    'podsdesired': 'dt.kubernetes.workload.pods_desired',
    'containersrunning': 'dt.kubernetes.containers',
    
    # =========================================================================
    # KUBERNETES PERSISTENT VOLUME CLAIMS (Grail: dt.kubernetes.persistentvolumeclaim.*)
    # Maps NR filesystem metrics in K8s context
    # =========================================================================
    'fscapacitybytes': 'dt.kubernetes.persistentvolumeclaim.capacity',
    'fsusedbytes': 'dt.kubernetes.persistentvolumeclaim.used',
    'fsavailablebytes': 'dt.kubernetes.persistentvolumeclaim.available',
    'fscapacityutilization': 'dt.kubernetes.persistentvolumeclaim.used',      # NOTE: utilization needs calc
    # Inode metrics â€” K8s node filesystem inodes
    'fsinodesfree': 'dt.host.disk.inodes_avail',
    'fsinodesused': 'dt.host.disk.inodes_used',
    'fsinodes': 'dt.host.disk.inodes_total',
    'inodesused': 'dt.host.disk.inodes_used',
    'inodesavailpercent': 'dt.host.disk.inodes_avail',
    
    # =========================================================================
    # CONTAINER METRICS (non-K8s, from NR ContainerSample)
    # Classic: builtin:containers.*  |  Grail: dt.containers.*
    # =========================================================================
    'containercpupercent': 'dt.containers.cpu.usage_user_time',
    'containermemorypercent': 'dt.containers.memory.resident_set_bytes',
    
    # =========================================================================
    # NR `FROM Metric` DOTTED METRIC NAMES
    # These appear in queries like: FROM Metric SELECT latest(`apm.service.overview.responseTime`)
    # Normalized: dots and underscores stripped, lowercased
    # =========================================================================
    
    # APM dotted metrics
    'apmserviceoverviewresponsetime50': 'dt.service.request.response_time',
    'apmserviceoverviewresponsetime99': 'dt.service.request.response_time',
    'apmservicetransactiondurationaverage': 'dt.service.request.response_time',
    'apmserviceerrorrateerrorrate': 'dt.service.request.failure_count',
    
    # Host dotted metrics (NR agent)
    'hostsystemcpuutilization': 'dt.host.cpu.usage',
    'hostmemorytotal': 'dt.host.memory.used',
    'hostnettransmitbytes': 'dt.host.net.nic.bytes_tx',
    'hostnetreceivebytes': 'dt.host.net.nic.bytes_rx',
    
    # K8s dotted metrics (NR Kubernetes integration)
    # These come from queries like: FROM Metric SELECT latest(`k8s.container.memoryUsedBytes`)
    'k8scontainermemoryusedbytes': 'dt.kubernetes.container.memory_working_set',    # explicit duplicate for dotted form
    'k8scontainercpuusage': 'dt.kubernetes.container.cpu_usage',
    'k8snodecpuusage': 'dt.kubernetes.container.cpu_usage',                         # aggregate to node
    'k8snodememoryusage': 'dt.kubernetes.container.memory_working_set',              # aggregate to node
    'k8spodcpuusage': 'dt.kubernetes.container.cpu_usage',
    'k8spodmemoryusage': 'dt.kubernetes.container.memory_working_set',

    # =========================================================================
    # SERVICE METRICS â€” Extended (Verified: DT Service Metrics Migration Guide Dec 2025)
    # Key insight: Many NR service sub-metrics map to dt.service.request.count
    # with dimensional filters (failed, http.response.status_code, endpoint.name)
    # =========================================================================
    
    # External/backend call metrics â€” DT tracks via spans, not separate metrics
    # NR externalDuration, externalCallCount â†’ fetch spans with span.kind="client"
    'externalcallcount': 'dt.service.request.count',         # NOTE: needs filter span.kind="client"
    'externalthroughput': 'dt.service.request.count',
    'externalresponsetime': 'dt.service.request.response_time',
    
    # Database call metrics â€” DT tracks via spans with db.statement
    # NR databaseCallCount â†’ fetch spans | filter isNotNull(db.statement)
    'databasecallcount': 'dt.service.request.count',          # NOTE: needs filter on db spans
    'databaseresponsetime': 'dt.service.request.response_time',
    
    # Error rate breakdown â€” DT uses dimensional filters
    'http4xxerrorrate': 'dt.service.request.count',           # NOTE: needs filter http.response.status_code 400-499
    'http5xxerrorrate': 'dt.service.request.count',           # NOTE: needs filter http.response.status_code 500-599
    'httperrorcount': 'dt.service.request.failure_count',
    'failurerate': 'dt.service.request.failure_count',
    'failurecount': 'dt.service.request.failure_count',
    'successcount': 'dt.service.request.count',               # NOTE: needs filter failed==false
    'successrate': 'dt.service.request.count',
    
    # Key request / endpoint metrics
    'webtransactiontotaltime': 'dt.service.request.response_time',
    'webtransactioncount': 'dt.service.request.count',
    'webrequestcount': 'dt.service.request.count',
    
    # =========================================================================
    # PROCESS METRICS (Verified: DT Built-in Metrics on Grail Feb 2026)
    # NR ProcessSample fields â†’ dt.process.* on Grail
    # NOTE: builtin:process.cpu/memory NOT on Grail; use dt.process.* instead
    # Process metrics replace builtin:tech.generic prefix
    # =========================================================================
    
    # Process CPU â€” NR ProcessSample cpuPercent
    'processcpupercent': 'dt.process.cpu.usage',
    'processcpuuserpercent': 'dt.process.cpu.user',
    'processcpusystempercent': 'dt.process.cpu.system',
    
    # Process Memory
    'processmemoryrssbytes': 'dt.process.memory.rss',
    'processmemoryusedbytes': 'dt.process.memory.rss',
    'processmemoryvirtualsize': 'dt.process.memory.virtual',
    'memoryresidentsize': 'dt.process.memory.rss',
    'memoryvirtualsize': 'dt.process.memory.virtual',
    
    # Process Network
    'processnetreceivedpersecond': 'dt.process.network.bytes_rx',
    'processnetsentpersecond': 'dt.process.network.bytes_tx',
    'iototalreadbytes': 'dt.process.io.read_bytes',
    'iototalwritebytes': 'dt.process.io.write_bytes',
    'ioreadbytespersecond': 'dt.process.io.read_bytes',
    'iowritebytespersecond': 'dt.process.io.write_bytes',
    'ioreadcountpersecond': 'dt.process.io.read_ops',
    'iowritecountpersecond': 'dt.process.io.write_ops',
    
    # Process Threads/FD
    'threadcount': 'dt.process.threads',
    'filedescriptorcount': 'dt.process.open_file_descriptors',
    
    # Process Availability
    'processavailability': 'dt.process.availability',
    
    # Process network sessions
    'networksessionsestablished': 'dt.process.network.sessions.established',
    'networksessionsresetlocal': 'dt.process.network.sessions.reset_local',
    'networksessionsresetremote': 'dt.process.network.sessions.reset_remote',
    
    # =========================================================================
    # SYNTHETIC METRICS (Verified: DT HTTP Monitor Metrics in Synthetic on Grail)
    # NR SyntheticCheck fields â†’ dt.synthetic.* metrics
    # =========================================================================
    
    # HTTP monitor metrics
    'syntheticduration': 'dt.synthetic.http.request.duration',
    'syntheticresponsetime': 'dt.synthetic.http.request.duration',
    'monitorresponsetime': 'dt.synthetic.http.request.duration',
    'monitorduration': 'dt.synthetic.http.request.duration',
    'checkduration': 'dt.synthetic.http.request.duration',
    'syntheticavailability': 'dt.synthetic.http.availability',
    'monitoravailability': 'dt.synthetic.http.availability',
    'syntheticexecutions': 'dt.synthetic.http.executions',
    
    # Browser monitor metrics
    'browserduration': 'dt.synthetic.browser.duration',
    'browseravailability': 'dt.synthetic.browser.availability',
    
    # Multi-protocol / ICMP
    'icmproundtriptime': 'dt.synthetic.multi_protocol.icmp.round_trip_time',
    'icmpavailability': 'dt.synthetic.multi_protocol.icmp.success_rate',
    'icmppacketssent': 'dt.synthetic.multi_protocol.icmp.packets_sent',
    'icmppacketsreceived': 'dt.synthetic.multi_protocol.icmp.packets_received',
    'dnsresolutiontime': 'dt.synthetic.multi_protocol.dns.resolution_time',
    'tcpconnectiontime': 'dt.synthetic.multi_protocol.tcp.connection_time',
    
    # =========================================================================
    # BROWSER / RUM METRICS (NR PageView/BrowserInteraction â†’ DT RUM)
    # DT stores browser data differently â€” primarily in user sessions
    # These map to the closest Grail equivalents
    # =========================================================================
    
    'domprocessingtime': 'dt.rum.action.duration.dom_processing',
    'pageloadtime': 'dt.rum.action.duration',
    'firstcontentfulpaint': 'dt.rum.action.duration.first_contentful_paint',
    'firstpaint': 'dt.rum.action.duration.first_paint',
    'largestcontentfulpaint': 'dt.rum.action.duration.largest_contentful_paint',
    'cumulativelayoutshift': 'dt.rum.action.cumulative_layout_shift',
    'firstinputdelay': 'dt.rum.action.first_input_delay',
    'interactiontonextpaint': 'dt.rum.action.interaction_to_next_paint',
    'timetointeractive': 'dt.rum.action.duration.load_event_end',
    'backendtime': 'dt.rum.action.duration.server',
    'frontendtime': 'dt.rum.action.duration.frontend',
    'networktime': 'dt.rum.action.duration.network',
    'connectionsetuptime': 'dt.rum.action.duration.network',
    
    # AJAX/XHR
    'ajaxresponsetime': 'dt.rum.xhr.duration',
    'ajaxcallcount': 'dt.rum.xhr.count',
    
    # JavaScript errors
    'javascripterrorcount': 'dt.rum.jserror.count',
    'jserrorcount': 'dt.rum.jserror.count',
    
    # =========================================================================
    # AWS CLOUD METRICS (Verified: DT Built-in Metrics on Grail)
    # NR AWS integration â†’ dt.cloud.aws.*
    # =========================================================================
    
    # Lambda
    'awslambdaduration': 'dt.cloud.aws.lambda.duration',
    'awslambdainvocations': 'dt.cloud.aws.lambda.invocations',
    'awslambdaerrors': 'dt.cloud.aws.lambda.errors',
    'awslambdathrottles': 'dt.cloud.aws.lambda.throttlers',
    'awslambdaconcurrentexecutions': 'dt.cloud.aws.lambda.conc_executions',
    
    # RDS
    'awsrdscpuutilization': 'dt.cloud.aws.rds.cpu.usage',
    'awsrdsconnections': 'dt.cloud.aws.rds.connections',
    'awsrdsfreeablememory': 'dt.cloud.aws.rds.memory.freeable',
    'awsrdsreadlatency': 'dt.cloud.aws.rds.latency.read',
    'awsrdswritelatency': 'dt.cloud.aws.rds.latency.write',
    'awsrdsreadiops': 'dt.cloud.aws.rds.ops.read',
    'awsrdswriteiops': 'dt.cloud.aws.rds.ops.write',
    
    # ALB/ELB
    'awsalbhealthyhostcount': 'dt.cloud.aws.elb.hosts.healthy',
    'awsalbunhealthyhostcount': 'dt.cloud.aws.elb.hosts.unhealthy',
    'awsalbrequestcount': 'dt.cloud.aws.alb.requests',
    'awsalbresponsetime': 'dt.cloud.aws.alb.resp_time',
    'awsalb5xxcount': 'dt.cloud.aws.alb.errors.alb.http5xx',
    'awsalb4xxcount': 'dt.cloud.aws.alb.errors.alb.http4xx',
    'awsalbactiveconnections': 'dt.cloud.aws.alb.connections.active',
    
    # EC2
    'awsec2cpuutilization': 'dt.cloud.aws.ec2.cpu.usage',
    'awsec2networkrx': 'dt.cloud.aws.ec2.net.rx',
    'awsec2networktx': 'dt.cloud.aws.ec2.net.tx',
    'awsec2diskreadops': 'dt.cloud.aws.ec2.disk.read_ops',
    'awsec2diskwriteops': 'dt.cloud.aws.ec2.disk.write_ops',
    
    # DynamoDB
    'awsdynamodbconsumedreadrcu': 'dt.cloud.aws.dynamo.capacity_units.consumed.read',
    'awsdynamodbconsumedwritewcu': 'dt.cloud.aws.dynamo.capacity_units.consumed.write',
    'awsdynamodbthrottledrequests': 'dt.cloud.aws.dynamo.requests.throttled',
    'awsdynamodblatency': 'dt.cloud.aws.dynamo.requests.latency',
    
    # S3 â€” no dedicated Grail metrics for S3 (use extension metrics)
    
    # =========================================================================
    # HOST AVAILABILITY (Verified: DT Built-in Metrics on Grail)
    # =========================================================================
    'hostavailability': 'dt.host.availability',
    'hostuptime': 'dt.host.uptime',
}

# =============================================================================
# METRIC TRANSFORMS â€” Calculated Expressions
# =============================================================================
# Some NR fields map to CALCULATED expressions, not simple metric lookups.
# When the converter encounters these field names, it emits a multi-step DQL
# query instead of a simple `timeseries avg(metric)`.
#
# Each entry is:
#   'normalized_field_key': {
#       'type': 'calculated' | 'unit_convert' | 'multi_metric',
#       'dql':  the full DQL template (may contain {agg}, {by}, {filter} placeholders),
#       'note': human-readable explanation of what changed,
#       'confidence': override confidence level
#   }
#
# Fields NOT in this dict use the standard METRIC_MAP â†’ timeseries path.
# =============================================================================

METRIC_TRANSFORMS = {
    # -------------------------------------------------------------------------
    # ERROR RATE â€” NR has errorRate as first-class field; DT must calculate it
    # NR: SELECT latest(errorRate) FROM Transaction
    # DT: (failure_count / total_count) * 100
    # -------------------------------------------------------------------------
    'errorrate': {
        'type': 'calculated',
        'dql': (
            "timeseries {failures = sum(dt.service.request.failure_count), "
            "total = sum(dt.service.request.count)}{by}{filter}\n"
            "| fieldsAdd error_rate = else(toDouble(failures) / toDouble(total) * 100.0, 0.0)"
        ),
        'dql_single': (
            "timeseries {fail = sum(dt.service.request.failure_count), "
            "total = sum(dt.service.request.count)}{by}{filter}\n"
            "| fieldsAdd error_rate = else(toDouble(fail) / toDouble(total) * 100.0, 0.0)"
        ),
        'note': 'errorRate calculated: (failure_count / request_count) * 100',
        'confidence': 'HIGH',
    },

    # -------------------------------------------------------------------------
    # K8s NODE CPU UTILIZATION â€” NR has allocatableCpuUtilization as %;
    # DT requires: sum(container.cpu_usage by node) / node.cpu_allocatable * 100
    # -------------------------------------------------------------------------
    'allocatablecpuutilization': {
        'type': 'multi_metric',
        'dql': (
            "// CPU Utilization = (container CPU usage / node allocatable) * 100\n"
            "timeseries {usage = sum(dt.kubernetes.container.cpu_usage), "
            "allocatable = avg(dt.kubernetes.node.cpu_allocatable)}, by: {k8s.node.name}{filter}\n"
            "| fieldsAdd cpu_utilization_pct = (toDouble(usage) / toDouble(allocatable)) * 100.0"
        ),
        'note': 'Node CPU utilization calculated from container usage / node allocatable',
        'confidence': 'MEDIUM',
    },
    # Variant: NR also uses allocatableCpuCoresUtilization (with "Cores")
    'allocatablecpucoresutilization': {
        'type': 'multi_metric',
        'dql': (
            "// CPU Utilization = (container CPU usage / node allocatable) * 100\n"
            "timeseries {usage = sum(dt.kubernetes.container.cpu_usage), "
            "allocatable = avg(dt.kubernetes.node.cpu_allocatable)}, by: {k8s.node.name}{filter}\n"
            "| fieldsAdd cpu_utilization_pct = (toDouble(usage) / toDouble(allocatable)) * 100.0"
        ),
        'note': 'Node CPU utilization calculated from container usage / node allocatable',
        'confidence': 'MEDIUM',
    },

    # -------------------------------------------------------------------------
    # K8s NODE MEMORY UTILIZATION â€” same pattern as CPU
    # NR: latest(allocatableMemoryUtilization)
    # DT: sum(container.memory_working_set by node) / node.memory_allocatable * 100
    # -------------------------------------------------------------------------
    'allocatablememoryutilization': {
        'type': 'multi_metric',
        'dql': (
            "// Memory Utilization = (container memory working set / node allocatable) * 100\n"
            "timeseries {usage = sum(dt.kubernetes.container.memory_working_set), "
            "allocatable = avg(dt.kubernetes.node.memory_allocatable)}, by: {k8s.node.name}{filter}\n"
            "| fieldsAdd memory_utilization_pct = (toDouble(usage) / toDouble(allocatable)) * 100.0"
        ),
        'note': 'Node memory utilization calculated from container working set / node allocatable',
        'confidence': 'MEDIUM',
    },

    # -------------------------------------------------------------------------
    # K8s FILESYSTEM UTILIZATION â€” NR has fsCapacityUtilization as %;
    # DT: pvc.used / pvc.capacity * 100
    # -------------------------------------------------------------------------
    'fscapacityutilization': {
        'type': 'multi_metric',
        'dql': (
            "// Filesystem utilization = (PVC used / PVC capacity) * 100\n"
            "timeseries {used = sum(dt.kubernetes.persistentvolumeclaim.used), "
            "cap = sum(dt.kubernetes.persistentvolumeclaim.capacity)}{by}{filter}\n"
            "| fieldsAdd fs_utilization_pct = (toDouble(used) / toDouble(cap)) * 100.0"
        ),
        'note': 'PVC utilization calculated from used / capacity',
        'confidence': 'MEDIUM',
    },

    # -------------------------------------------------------------------------
    # K8s CONTAINER CPU â€” Unit conversion
    # NR reports in CORES (millicores). DT reports in NANOSECONDS per minute.
    # Conversion: DT_ns_per_min â†’ cores = value / (60 * 1e9)
    # We add a fieldsAdd to convert units after the timeseries query.
    # -------------------------------------------------------------------------
    'cpuusedcores': {
        'type': 'unit_convert',
        'metric': 'dt.kubernetes.container.cpu_usage',
        'post_calc': "| fieldsAdd cpu_cores = toDouble({alias}) / 60000000000.0",
        'note': 'DT reports CPU in ns/min; converted to cores: value / (60 * 1e9)',
        'confidence': 'HIGH',
    },
    'k8scontainercpuusedcores': {
        'type': 'unit_convert',
        'metric': 'dt.kubernetes.container.cpu_usage',
        'post_calc': "| fieldsAdd cpu_cores = toDouble({alias}) / 60000000000.0",
        'note': 'DT reports CPU in ns/min; converted to cores: value / (60 * 1e9)',
        'confidence': 'HIGH',
    },

    # -------------------------------------------------------------------------
    # K8s CONTAINER CPU UTILIZATION â€” Needs limits comparison
    # NR: cpuCoresUtilization = (cpuUsedCores / cpuLimitCores) * 100
    # DT: (cpu_usage / limits_cpu) * 100
    # -------------------------------------------------------------------------
    'cpucoresutilization': {
        'type': 'multi_metric',
        'dql': (
            "// Container CPU utilization = (usage / limit) * 100\n"
            "timeseries {usage = avg(dt.kubernetes.container.cpu_usage), "
            "lim = avg(dt.kubernetes.container.limits_cpu)}{by}{filter}\n"
            "| fieldsAdd cpu_utilization_pct = (toDouble(usage) / toDouble(lim)) * 100.0"
        ),
        'note': 'Container CPU utilization calculated from usage / limits',
        'confidence': 'MEDIUM',
    },
    'k8scontainercpucoresutilization': {
        'type': 'multi_metric',
        'dql': (
            "// Container CPU utilization = (usage / limit) * 100\n"
            "timeseries {usage = avg(dt.kubernetes.container.cpu_usage), "
            "lim = avg(dt.kubernetes.container.limits_cpu)}{by}{filter}\n"
            "| fieldsAdd cpu_utilization_pct = (toDouble(usage) / toDouble(lim)) * 100.0"
        ),
        'note': 'Container CPU utilization calculated from usage / limits',
        'confidence': 'MEDIUM',
    },

    # -------------------------------------------------------------------------
    # K8s CONTAINER MEMORY UTILIZATION â€” Needs limits comparison
    # NR: memoryUtilization = (memoryUsedBytes / memoryLimitBytes) * 100
    # -------------------------------------------------------------------------
    'k8scontainermemoryutilization': {
        'type': 'multi_metric',
        'dql': (
            "// Container memory utilization = (working_set / limit) * 100\n"
            "timeseries {usage = avg(dt.kubernetes.container.memory_working_set), "
            "lim = avg(dt.kubernetes.container.limits_memory)}{by}{filter}\n"
            "| fieldsAdd memory_utilization_pct = (toDouble(usage) / toDouble(lim)) * 100.0"
        ),
        'note': 'Container memory utilization calculated from working_set / limits',
        'confidence': 'MEDIUM',
    },
    'memoryutilization': {
        'type': 'multi_metric',
        'dql': (
            "// Container memory utilization = (working_set / limit) * 100\n"
            "timeseries {usage = avg(dt.kubernetes.container.memory_working_set), "
            "lim = avg(dt.kubernetes.container.limits_memory)}{by}{filter}\n"
            "| fieldsAdd memory_utilization_pct = (toDouble(usage) / toDouble(lim)) * 100.0"
        ),
        'note': 'Container memory utilization calculated from working_set / limits',
        'confidence': 'MEDIUM',
    },

    # -------------------------------------------------------------------------
    # NR externalDuration / databaseDuration â€” NR-specific breakdowns
    # DT doesn't separate external vs DB call time as a builtin metric.
    # Map to response_time with explanatory note.
    # -------------------------------------------------------------------------
    'externalduration': {
        'type': 'unit_convert',
        'metric': 'dt.service.request.response_time',
        'post_calc': '',
        'note': 'NR externalDuration has no DT equivalent; mapped to total response_time. Use span analytics for call breakdown.',
        'confidence': 'LOW',
    },
    'databaseduration': {
        'type': 'unit_convert',
        'metric': 'dt.service.request.response_time',
        'post_calc': '',
        'note': 'NR databaseDuration has no DT equivalent; mapped to total response_time. Use span analytics for DB call time.',
        'confidence': 'LOW',
    },
}

# Aggregation function mapping
AGG_MAP = {
    # Basic aggregations
    'count': 'count()',
    'sum': 'sum',
    'average': 'avg',
    'avg': 'avg',
    'max': 'max',
    'min': 'min',
    'percentile': 'percentile',
    'stddev': 'stddev',
    'rate': 'rate',
    
    # NR-specific -> DQL equivalents
    'latest': 'takeLast',      # DQL uses takeLast() for latest value
    'earliest': 'takeFirst',   # DQL uses takeFirst() for earliest value
    'last': 'takeLast',        # Alias
    'first': 'takeFirst',      # Alias
    'uniquecount': 'countDistinct',
    'uniques': 'collectDistinct',
    'median': 'percentile',  # Note: use percentile(field, 50)
    
    # String functions
    'concat': 'concat',
    'lower': 'lower',
    'upper': 'upper',
    'substring': 'substring',
    'length': 'stringLength',   # DQL uses stringLength() not strlen()
    'capture': 'extract',  # Regex capture
    'aparse': 'parse',     # Anchor parse
    
    # Math functions
    'abs': 'abs',
    'ceil': 'ceil',
    'floor': 'floor',
    'round': 'round',
    'sqrt': 'sqrt',
    'pow': 'power',        # DQL uses power() not pow()
    'log': 'log',          # Both use log() for natural log
    'log10': 'log10',
    'exp': 'exp',
    
    # Time functions
    'dateOf': 'formatTimestamp',
    'hourOf': 'getHour',
    'minuteOf': 'getMinute',
    'dayOfWeek': 'getDayOfWeek',
    'weekOf': 'getWeekOfYear',  # DQL uses getWeekOfYear() not getWeek()
    'monthOf': 'getMonth',
    'yearOf': 'getYear',
    
    # Type conversion
    'numeric': 'toDouble',
    'string': 'toString',
    
    # Post-preprocess aliases (preprocess may have already renamed)
    'countdistinct': 'countDistinct',
    'collectdistinct': 'collectDistinct',
}

# Attribute mapping NR -> DT
ATTR_MAP = {
    # K8s attributes (longer matches first)
    'k8s.containername': 'k8s.container.name',
    'k8s.podname': 'k8s.pod.name',
    'k8s.clustername': 'k8s.cluster.name',
    'k8s.deploymentname': 'k8s.deployment.name',
    'k8s.namespacename': 'k8s.namespace.name',
    'k8s.nodename': 'k8s.node.name',
    # NR K8s attributes without k8s. prefix
    'containername': 'k8s.container.name',
    'clustername': 'k8s.cluster.name',
    'clusterName': 'k8s.cluster.name',
    'namespace': 'k8s.namespace.name',
    'namespaceName': 'k8s.namespace.name',
    'podname': 'k8s.pod.name',
    'podName': 'k8s.pod.name',
    'nodename': 'k8s.node.name',
    'nodeName': 'k8s.node.name',
    'jobname': 'k8s.job.name',
    'jobName': 'k8s.job.name',
    'deploymentname': 'k8s.deployment.name',
    'deploymentName': 'k8s.deployment.name',
    
    # NOTE: K8s METRIC mappings (cpuUsedCores â†’ dt.kubernetes.*, memoryUsedBytes â†’ dt.host.memory.*)
    # are in the Grail metric section above (lines ~590-680). Do NOT duplicate here.
    # The deprecated builtin:kubernetes.* metrics do NOT work in Grail DQL queries.
    
    # APM/Transaction attributes
    'transactionname': 'span.name',
    'name': 'span.name',  # When used in Transaction context
    'appName': 'service.name',
    'appname': 'service.name',
    'duration': 'duration',
    'duration.ms': 'duration',  # Handle unit conversion context
    'databaseDuration': 'db.duration',
    'externalDuration': 'http.duration',
    'host': 'host.name',
    'httpResponseCode': 'http.response.status_code',
    # Note: 'error' field is intentionally NOT mapped here as it's too generic
    # and matches inside strings. Use error.message or check error == true explicitly.
    'error.message': 'error.message',
    'entityGuid': 'dt.entity.service',
    
    # HTTP/Service attributes
    'request.uri': 'http.request.path',
    'request.url': 'http.request.path',
    'request.method': 'http.request.method',
    'http.statuscode': 'http.response.status_code',
    'httpresponsecode': 'http.response.status_code',
    'response.status': 'http.response.status_code',
    'http.method': 'http.request.method',
    'httpmethod': 'http.request.method',
    'http.url': 'http.request.path',
    'httpurl': 'http.request.path',
    
    # Host/Infrastructure attributes
    'fullhostname': 'host.name',
    'hostname': 'host.name',
    'cpuPercent': 'host.cpu.usage',
    'memoryUsedPercent': 'host.memory.usage',
    'diskUsedPercent': 'host.disk.usage',
    
    # Entity attributes
    'entityname': 'entity.name',
    'entity.name': 'entity.name',
    
    # Error attributes
    'errormessage': 'error.message',
    'error.class': 'error.type',
    'errorclass': 'error.type',
    
    # Log attributes
    'logmessage': 'content',
    'log.message': 'content',
    'message': 'content',
    'loglevel': 'loglevel',
    'severity': 'loglevel',
    'log.level': 'loglevel',
    'level': 'loglevel',
    
    # Service/App attributes
    'servicename': 'service.name',
    'application': 'service.name',
    'service': 'service.name',
    
    # Cloud attributes
    'awsregion': 'cloud.region',
    'aws.region': 'cloud.region',
    'regionname': 'cloud.region',
    'provider.accountid': 'cloud.account.id',
    'environment': 'environment',
    'env': 'environment',
    
    # Browser/RUM attributes
    'session': 'session.id',
    'pageUrl': 'page.url',
    'userAgent': 'user_agent',
    'countryCode': 'geo.country',
    'city': 'geo.city',
}

# Visualization mapping NR -> DT
VIZ_MAP = {
    'viz.line': 'lineChart',
    'viz.area': 'areaChart',
    'viz.stacked-area': 'areaChart',
    'viz.bar': 'barChart',
    'viz.stacked-bar': 'barChart',
    'viz.billboard': 'singleValue',
    'viz.pie': 'pieChart',
    'viz.table': 'table',
    'viz.markdown': 'markdown',
    'viz.heatmap': 'honeycomb',
    'viz.histogram': 'histogram',
    'viz.json': 'table',
    'viz.bullet': 'gauge',
    'viz.funnel': 'table',  # No funnel in DT
    'viz.scatter': 'scatterPlot',
}

# =============================================================================
# ADVANCED NRQL CONVERTERS â€” DPL, rate(), COMPARE WITH, funnel, etc.
# =============================================================================

class RegexToDPLConverter:
    """
    Converts RE2 regex patterns to Dynatrace Pattern Language (DPL).
    
    Strategy:
    1. Extract named capture groups first, converting inner patterns
    2. Convert remaining regex to DPL matchers
    3. Wrap literal text in quotes
    4. Output format: MATCHER:export_name (no spaces around colon)
    """
    
    DPL_KEYWORDS = {'INT', 'LONG', 'WORD', 'ALPHA', 'ALNUM', 'DIGIT', 'SPACE', 'NSPACE',
                    'IPV4', 'IPV6', 'IPADDR', 'TIMESTAMP', 'ISO8601', 'LD', 'DATA',
                    'UPPER', 'LOWER', 'EOL', 'DQS', 'SQS', 'JSON', 'BOOLEAN',
                    'DOUBLE', 'FLOAT', 'HEXINT'}
    
    def convert(self, regex_pattern: str) -> Tuple[str, List[str]]:
        """Convert RE2 regex to DPL pattern. Returns (dpl_pattern, capture_names)."""
        capture_names = []
        segments = []  # list of (type, content) tuples: ('matcher', 'INT:name') or ('literal', 'text')
        
        pos = 0
        pattern = regex_pattern
        
        # Strip anchors
        if pattern.startswith('^'):
            pattern = pattern[1:]
        if pattern.endswith('$'):
            pattern = pattern[:-1]
        
        while pos < len(pattern):
            # Named capture group: (?P<name>inner)
            named_match = re.match(r'\(\?P<(\w+)>([^)]*)\)', pattern[pos:])
            if named_match:
                name = named_match.group(1)
                inner = named_match.group(2)
                capture_names.append(name)
                dpl_type = self._inner_to_dpl_type(inner)
                segments.append(('matcher', f'{dpl_type}:{name}'))
                pos += named_match.end()
                continue
            
            # Unnamed capture group: (inner)
            unnamed_match = re.match(r'\(([^?][^)]*)\)', pattern[pos:])
            if unnamed_match:
                inner = unnamed_match.group(1)
                group_name = f'group{len(capture_names) + 1}'
                capture_names.append(group_name)
                dpl_type = self._inner_to_dpl_type(inner)
                segments.append(('matcher', f'{dpl_type}:{group_name}'))
                pos += unnamed_match.end()
                continue
            
            # Whitespace shorthand with quantifier: \s+, \s*, \s
            ws_match = re.match(r'\\s([+*?]?)', pattern[pos:])
            if ws_match:
                q = ws_match.group(1) or ''
                segments.append(('matcher', f'SPACE{q}'))
                pos += ws_match.end()
                continue
            
            # Non-whitespace shorthand: \S+, \S*, \S
            nws_match = re.match(r'\\S([+*?]?)', pattern[pos:])
            if nws_match:
                q = nws_match.group(1) or ''
                segments.append(('matcher', f'NSPACE{q}'))
                pos += nws_match.end()
                continue
            
            # Word shorthand with quantifier: \w+, \w*
            word_match = re.match(r'\\w([+*?]?)', pattern[pos:])
            if word_match:
                q = word_match.group(1)
                if q == '+':
                    segments.append(('matcher', 'WORD'))
                elif q == '*':
                    segments.append(('matcher', 'WORD?'))
                else:
                    segments.append(('matcher', 'ALNUM'))
                pos += word_match.end()
                continue
            
            # Digit with quantifier: \d+, \d*, \d{n}, \d{n,m}
            digit_match = re.match(r'\\d(\{[^}]+\}|[+*?]?)', pattern[pos:])
            if digit_match:
                q = digit_match.group(1)
                if q in ('+', '{1,}', ''):
                    # \d+ or \d â†’ use INT for sequences
                    segments.append(('matcher', 'INT' if q == '+' else 'DIGIT'))
                elif q == '*':
                    segments.append(('matcher', 'INT?'))
                elif q.startswith('{'):
                    # \d{3} â†’ INT for fixed-width numeric
                    segments.append(('matcher', 'INT'))
                else:
                    segments.append(('matcher', 'DIGIT'))
                pos += digit_match.end()
                continue
            
            # Character class: [...]
            cc_match = re.match(r'\[([^\]]+)\]([+*?]?)', pattern[pos:])
            if cc_match:
                cc_inner = cc_match.group(1)
                q = cc_match.group(2) or ''
                dpl_cc = self._char_class_to_dpl(cc_inner, q)
                segments.append(('matcher', dpl_cc))
                pos += cc_match.end()
                continue
            
            # Dot with quantifier: .+, .*, .
            dot_match = re.match(r'\.([+*?])', pattern[pos:])
            if dot_match and pos > 0 and pattern[pos-1] != '\\':
                q = dot_match.group(1)
                if q == '+':
                    segments.append(('matcher', 'LD'))
                elif q == '*':
                    segments.append(('matcher', 'LD?'))
                else:
                    segments.append(('matcher', 'LD'))
                pos += dot_match.end()
                continue
            
            # Escaped characters
            if pattern[pos] == '\\' and pos + 1 < len(pattern):
                next_ch = pattern[pos + 1]
                if next_ch == 'b':
                    # Word boundary - skip in DPL
                    pos += 2
                    continue
                elif next_ch == 'W':
                    segments.append(('matcher', 'SPACE'))
                    pos += 2
                    continue
                elif next_ch == 'D':
                    segments.append(('matcher', 'ALPHA'))
                    pos += 2
                    continue
                else:
                    # Escaped literal: \. \/ \- \[ etc.
                    segments.append(('literal', next_ch))
                    pos += 2
                    continue
            
            # Alternation group: (A|B|C) â€” not a capture
            alt_match = re.match(r'\((\?:)?([^)]+)\)', pattern[pos:])
            if alt_match and '|' in alt_match.group(2):
                alts = alt_match.group(2).split('|')
                # In DPL: ('A' | 'B' | 'C')
                alt_strs = [f"'{a}'" for a in alts]
                segments.append(('matcher', f"({' | '.join(alt_strs)})"))
                pos += alt_match.end()
                continue
            
            # Regular literal character
            if pattern[pos] not in '()[]\\^$.*+?{}|':
                # Accumulate literal text
                lit_end = pos
                while lit_end < len(pattern) and pattern[lit_end] not in '()[]\\^$.*+?{}|':
                    lit_end += 1
                segments.append(('literal', pattern[pos:lit_end]))
                pos = lit_end
            else:
                # Skip unhandled metacharacter
                pos += 1
        
        # Build DPL string
        dpl_parts = []
        for stype, content in segments:
            if stype == 'literal':
                dpl_parts.append(f"'{content}'")
            else:
                dpl_parts.append(content)
        
        return ' '.join(dpl_parts), capture_names
    
    def _inner_to_dpl_type(self, inner: str) -> str:
        """Convert the inner pattern of a capture group to a DPL matcher type."""
        inner = inner.strip()
        
        # IP address patterns
        if re.match(r'\\d\{1,3\}.*\\d\{1,3\}.*\\d\{1,3\}.*\\d\{1,3\}', inner):
            return 'IPV4'
        
        # ISO timestamp
        if r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}' in inner:
            return 'ISO8601'
        if r'\d{4}-\d{2}-\d{2}' in inner and 'T' in inner:
            return 'ISO8601'
        if re.match(r'\\d\{4\}[-./]\\d\{2\}[-./]\\d\{2\}', inner):
            return 'TIMESTAMP'
        
        # Pure digit patterns
        if inner in (r'\d+', r'[0-9]+', r'\d{1,}'):
            return 'INT'
        if re.match(r'^\\d\{\d+(,\d+)?\}$', inner):
            return 'INT'
        if inner == r'\d':
            return 'DIGIT'
        
        # Word patterns
        if inner in (r'\w+', r'[a-zA-Z0-9_]+'):
            return 'WORD'
        if inner == r'\w':
            return 'ALNUM'
        
        # Alpha patterns
        if inner in (r'[a-zA-Z]+', r'[A-Za-z]+'):
            return 'ALPHA+'
        if inner in (r'[A-Z]+',):
            return 'UPPER+'
        if inner in (r'[a-z]+',):
            return 'LOWER+'
        
        # Non-whitespace (common for URLs, tokens)
        if inner in (r'\S+', r'[^ ]+', r'[^\s]+'):
            return 'NSPACE+'
        
        # Character classes with negation
        neg_match = re.match(r'^\[\^([^\]]+)\]\+?$', inner)
        if neg_match:
            excluded = neg_match.group(1)
            if excluded == '"':
                return 'DQS'  # Everything except double quote
            elif excluded == "'":
                return 'SQS'  # Everything except single quote
            elif '/' in excluded or ' ' in excluded:
                return 'NSPACE+'  # Non-space, non-slash
            else:
                return 'LD'
        
        # Character classes with specific chars
        cc_match = re.match(r'^\[([^\]]+)\]([+*?]?)$', inner)
        if cc_match:
            chars = cc_match.group(1)
            q = cc_match.group(2) or '+'
            return self._char_class_to_dpl(chars, q)
        
        # Alternation: INFO|WARN|ERROR|DEBUG
        if '|' in inner and not inner.startswith('('):
            alts = inner.split('|')
            return f"({' | '.join(repr(a) for a in alts)})"
        
        # Wildcard .+ or .*
        if inner in ('.+', '.*'):
            return 'LD'
        
        # Default: line data
        return 'LD'
    
    def _char_class_to_dpl(self, cc_inner: str, quantifier: str) -> str:
        """Convert a character class like [a-zA-Z0-9.-] to DPL matcher."""
        q = quantifier
        
        if cc_inner in ('a-zA-Z', 'A-Za-z'):
            return f'ALPHA{q}'
        if cc_inner in ('a-zA-Z0-9', 'A-Za-z0-9', '0-9a-zA-Z'):
            return f'ALNUM{q}'
        if cc_inner == '0-9':
            return 'INT' if q in ('+', '') else f'DIGIT{q}'
        if cc_inner == 'A-Z':
            return f'UPPER{q}'
        if cc_inner == 'a-z':
            return f'LOWER{q}'
        if cc_inner.startswith('^'):
            # Negated class
            excluded = cc_inner[1:]
            if ' ' in excluded or '\\s' in excluded:
                return f'NSPACE{q}'
            if '"' in excluded:
                return f'DQS'
            return f'LD{q}'
        
        # Complex character class with dots, dashes etc: keep as LD
        if '\\w' in cc_inner or 'a-z' in cc_inner:
            return f'WORD{q}' if q else 'WORD'
        
        return f'LD{q}'

class AparseConverter:
    """Converts NRQL aparse() anchor patterns (% delimiters) to DPL."""
    
    def convert(self, pattern: str) -> Tuple[str, List[str]]:
        """Convert aparse pattern to DPL. Returns (dpl_pattern, capture_names)."""
        capture_names = []
        dpl_parts = []
        parts = pattern.split('%')
        
        for i, part in enumerate(parts):
            if i % 2 == 0:
                if part: dpl_parts.append(f"'{part}'")
            else:
                capture_names.append(part)
                dpl_type = self._infer_type(part)
                dpl_parts.append(f'{dpl_type}:{part}')
        
        return ' '.join(dpl_parts), capture_names
    
    def _infer_type(self, name: str) -> str:
        name_lower = name.lower()
        if 'ip' in name_lower or 'addr' in name_lower: return 'IPADDR'
        elif 'port' in name_lower or 'code' in name_lower or 'num' in name_lower or 'count' in name_lower: return 'INT'
        elif 'time' in name_lower or 'date' in name_lower: return 'TIMESTAMP'
        elif 'user' in name_lower or 'name' in name_lower: return 'WORD'
        elif 'email' in name_lower: return 'NSPACE'
        elif 'url' in name_lower or 'path' in name_lower: return 'NSPACE'
        elif 'msg' in name_lower or 'message' in name_lower: return 'LD'
        else: return 'LD'


class RateDerivativeConverter:
    """Converts NRQL rate() and derivative() to DQL timeseries with rate: param."""
    
    UNIT_MAP = {
        'second': 's', 'seconds': 's', 'sec': 's',
        'minute': 'm', 'minutes': 'm', 'min': 'm',
        'hour': 'h', 'hours': 'h', 'hr': 'h',
        'day': 'd', 'days': 'd',
    }
    
    def convert_rate(self, rate_expr: str) -> Optional[Tuple[str, str]]:
        """
        Convert rate(agg(field), N unit) to DQL.
        Returns (dql_agg_expr, rate_param) or None.
        
        NRQL: rate(count(*), 1 minute) â†’ DQL: count(), rate:1m
        """
        match = re.match(
            r'rate\s*\(\s*(\w+)\s*\(\s*([^)]*)\s*\)\s*,\s*(\d+)\s*(\w+)\s*\)',
            rate_expr, re.IGNORECASE
        )
        if not match: return None
        
        agg, field, amount, unit = match.groups()
        agg_map = {'count': 'count', 'sum': 'sum', 'avg': 'avg',
                    'average': 'avg', 'min': 'min', 'max': 'max'}
        dql_agg = agg_map.get(agg.lower(), agg.lower())
        dql_unit = self.UNIT_MAP.get(unit.lower(), unit[0].lower())
        
        if field == '*' or not field:
            return f'{dql_agg}()', f'rate:{amount}{dql_unit}'
        else:
            return f'{dql_agg}({field})', f'rate:{amount}{dql_unit}'
    
    def convert_derivative(self, deriv_expr: str) -> Optional[Tuple[str, str]]:
        """Convert derivative(agg(field), N unit) â†’ DQL rate: param."""
        match = re.match(
            r'derivative\s*\(\s*(\w+)\s*\(\s*([^)]*)\s*\)\s*,\s*(\d+)\s*(\w+)\s*\)',
            deriv_expr, re.IGNORECASE
        )
        if not match: return None
        
        agg, field, amount, unit = match.groups()
        agg_map = {'count': 'count', 'sum': 'sum', 'avg': 'avg',
                    'average': 'avg', 'min': 'min', 'max': 'max'}
        dql_agg = agg_map.get(agg.lower(), agg.lower())
        dql_unit = self.UNIT_MAP.get(unit.lower(), unit[0].lower())
        
        if field == '*' or not field:
            return f'{dql_agg}()', f'rate:{amount}{dql_unit}'
        else:
            return f'{dql_agg}({field})', f'rate:{amount}{dql_unit}'


class CompareWithConverter:
    """Converts NRQL COMPARE WITH â†’ DQL timeseries shift: parameter."""
    
    def convert(self, nrql: str) -> Optional[Tuple[str, str]]:
        """
        Extract COMPARE WITH and return (cleaned_nrql, shift_param).
        NRQL: SELECT ... COMPARE WITH 1 day ago â†’ shift:-1d
        """
        match = re.search(
            r'\s*COMPARE\s+WITH\s+(\d+)\s+(second|minute|hour|day|week|month)s?\s+ago\s*',
            nrql, re.IGNORECASE
        )
        if not match: return None
        
        amount = int(match.group(1))
        unit = match.group(2).lower()
        
        unit_map = {'second': 's', 'minute': 'm', 'hour': 'h', 'day': 'd', 'week': 'd', 'month': 'd'}
        if unit == 'week': shift_amount, shift_unit = amount * 7, 'd'
        elif unit == 'month': shift_amount, shift_unit = amount * 30, 'd'
        else: shift_amount, shift_unit = amount, unit_map[unit]
        
        shift_param = f'shift:-{shift_amount}{shift_unit}'
        cleaned = re.sub(r'\s*COMPARE\s+WITH\s+\d+\s+\w+\s+ago\s*', '', nrql, flags=re.IGNORECASE)
        return cleaned.strip(), shift_param


class FunnelConverter:
    """Converts NRQL funnel() to Dynatrace USQL FUNNEL."""
    
    def convert(self, nrql: str) -> Optional[Dict[str, Any]]:
        """Returns dict with usql, steps, type='usql', note."""
        match = re.search(
            r'funnel\s*\(\s*(\w+)\s*,\s*(.+?)\s*\)\s*', nrql, re.IGNORECASE
        )
        if not match: return None
        
        conditions = re.findall(
            r"WHERE\s+(\w+)\s*(=|!=|LIKE)\s*['\"]([^'\"]+)['\"]",
            match.group(2), re.IGNORECASE
        )
        if not conditions: return None
        
        field_map = {'action': 'useraction.name', 'name': 'useraction.name',
                     'page': 'useraction.name', 'type': 'useraction.type',
                     'application': 'useraction.application', 'app': 'useraction.application'}
        
        usql_parts = []
        steps = []
        for field, op, value in conditions:
            usql_field = field_map.get(field.lower(), f'useraction.{field}')
            usql_op = '=' if op.upper() in ('=', 'LIKE') else '!='
            usql_parts.append(f'{usql_field}{usql_op}"{value}"')
            steps.append({'field': field, 'op': op, 'value': value})
        
        return {
            'usql': f"SELECT FUNNEL({', '.join(usql_parts)}) FROM usersession",
            'steps': steps, 'type': 'usql',
            'note': 'Requires User Sessions API, not DQL'
        }


class ExtrapolateHandler:
    """Handles NRQL EXTRAPOLATE keyword â†’ DT auto-sampling or extrapolate:true."""
    
    def handle(self, nrql: str, dql: str) -> Tuple[str, str, Optional[str]]:
        """Returns (cleaned_nrql, updated_dql, note)."""
        if 'EXTRAPOLATE' not in nrql.upper():
            return nrql, dql, None
        
        cleaned_nrql = re.sub(r'\s+EXTRAPOLATE\s*', ' ', nrql, flags=re.IGNORECASE).strip()
        
        if 'countDistinct' in dql:
            updated_dql = re.sub(
                r'countDistinct\(([^)]+)\)',
                r'countDistinct(\1, extrapolate:true)', dql
            )
            return cleaned_nrql, updated_dql, 'Added extrapolate:true to countDistinct'
        else:
            return cleaned_nrql, dql, 'EXTRAPOLATE removed - Dynatrace handles sampling automatically'


class BucketPercentileConverter:
    """Converts NRQL bucketPercentile() â†’ DQL multiple percentile() calls."""
    
    def convert(self, expr: str) -> Optional[str]:
        """
        NRQL: bucketPercentile(http_req_duration_bucket, 50, 95, 99)
        DQL:  percentile(http_req_duration, 50), percentile(..., 95), ...
        """
        match = re.match(
            r'bucketPercentile\s*\(\s*([^,]+)\s*,\s*(.+)\s*\)',
            expr, re.IGNORECASE
        )
        if not match: return None
        
        metric = re.sub(r'_bucket$', '', match.group(1).strip())
        percentiles = [p.strip() for p in match.group(2).split(',')]
        return ', '.join(f'percentile({metric}, {p})' for p in percentiles)


class WithAsConverter:
    """Handles NRQL WITH...AS (CTE) patterns â†’ DQL inline or append strategy."""
    
    def convert(self, nrql: str) -> Optional[Dict[str, Any]]:
        cte_match = re.match(
            r'WITH\s+((?:\w+\s+AS\s*\([^)]+\)\s*,?\s*)+)',
            nrql, re.IGNORECASE
        )
        if not cte_match: return None
        
        cte_defs = re.findall(r'(\w+)\s+AS\s*\(([^)]+)\)', cte_match.group(1), re.IGNORECASE)
        if not cte_defs: return None
        
        main_query = nrql[cte_match.end():]
        main_match = re.match(r'\s*SELECT\s+(.+)', main_query, re.IGNORECASE)
        if not main_match: return None
        
        ctes = []
        all_simple = True
        for name, query in cte_defs:
            agg_match = re.search(r'SELECT\s+(\w+)\s*\(\s*([^)]*)\s*\)', query, re.IGNORECASE)
            if agg_match:
                ctes.append({'name': name, 'query': query, 'agg': agg_match.group(1),
                             'field': agg_match.group(2) or '*', 'simple': True})
            else:
                ctes.append({'name': name, 'query': query, 'simple': False})
                all_simple = False
        
        if all_simple and len(ctes) <= 2:
            return self._inline_strategy(ctes, main_match.group(1))
        else:
            return self._append_strategy(ctes, main_match.group(1))
    
    def _inline_strategy(self, ctes, main_select):
        agg_map = {'count': 'count', 'sum': 'sum', 'avg': 'avg',
                    'average': 'avg', 'min': 'min', 'max': 'max',
                    'uniquecount': 'countDistinct'}
        agg_parts = []
        for cte in ctes:
            dql_agg = agg_map.get(cte['agg'].lower(), cte['agg'].lower())
            f = cte['field']
            agg_parts.append(f"{cte['name']} = {dql_agg}()" if f == '*' or not f
                             else f"{cte['name']} = {dql_agg}({f})")
        
        result_expr = main_select
        for cte in ctes:
            result_expr = re.sub(rf'{cte["name"]}\.(\w+)', cte['name'], result_expr)
        
        dql = f"fetch spans\n| summarize {', '.join(agg_parts)}\n| fieldsAdd result = {result_expr}"
        return {'dql': dql, 'strategy': 'inline', 'ctes': ctes}
    
    def _append_strategy(self, ctes, main_select):
        dql_parts = [f"// CTE: {c['name']}\n// {c['query']}" for c in ctes]
        dql = '\n'.join(dql_parts) + f"\n\n// Main query needs manual review:\n// SELECT {main_select}"
        return {'dql': dql, 'strategy': 'manual_review', 'ctes': ctes,
                'note': 'Complex CTE requires manual review - use append or join'}


# ============================================================================
# DQL SYNTAX VALIDATOR & FIXER
# ============================================================================

class DQLValidator:
    """Validates and fixes DQL syntax issues"""
    
    def __init__(self):
        self.fixes = []
    
    def validate_and_fix(self, dql: str, context: str = "") -> Tuple[str, List[str]]:
        """
        Validate DQL and fix any syntax issues.
        Returns (fixed_dql, list_of_fixes_applied)
        """
        self.fixes = []
        
        if not dql or not dql.strip():
            return dql, []
        
        # Apply fixes in order
        dql = self._fix_variables(dql)
        dql = self._fix_backticks(dql)
        dql = self._fix_quotes(dql)
        dql = self._fix_comparison_operators(dql)
        dql = self._fix_logical_operators(dql)
        dql = self._fix_null_checks(dql)
        dql = self._fix_like_patterns(dql)
        dql = self._fix_where_in_filter(dql)
        dql = self._fix_timeseries_count(dql, context)
        dql = self._fix_invalid_functions(dql)
        dql = self._fix_broken_by_clause(dql)
        dql = self._fix_field_names(dql)
        dql = self._fix_duplicate_aggregations(dql)
        dql = self._fix_percentile_naming(dql)
        dql = self._fix_as_aliases(dql)
        dql = self._fix_bare_field_in_summarize(dql)
        dql = self._fix_nrql_subqueries(dql)
        dql = self._fix_metric_names(dql)
        dql = self._fix_whitespace(dql)
        
        return dql, self.fixes
    
    def _fix_where_in_filter(self, dql: str) -> str:
        """Fix 'where' keyword inside filter clauses - should be 'and'"""
        # Pattern: | filter ... where ... (where should be and)
        # But don't replace 'where' inside strings
        lines = dql.split('\n')
        fixed_lines = []
        
        for line in lines:
            if '| filter' in line.lower() or line.strip().lower().startswith('filter'):
                # Replace 'where' with 'and' but preserve strings
                # Simple approach: split on 'where' (case insensitive) outside quotes
                result = []
                in_string = False
                quote_char = None
                i = 0
                line_lower = line.lower()
                
                while i < len(line):
                    # Track string boundaries
                    if line[i] in '"\'':
                        if not in_string:
                            in_string = True
                            quote_char = line[i]
                        elif line[i] == quote_char:
                            in_string = False
                        result.append(line[i])
                        i += 1
                    elif not in_string and line_lower[i:i+5] == 'where':
                        result.append('and')
                        i += 5
                        self.fixes.append("Changed 'where' to 'and' in filter clause")
                    else:
                        result.append(line[i])
                        i += 1
                
                fixed_lines.append(''.join(result))
            else:
                fixed_lines.append(line)
        
        return '\n'.join(fixed_lines)
    
    def _fix_duplicate_aggregations(self, dql: str) -> str:
        """Fix duplicate aggregation functions like count(), count(), count()"""
        
        # Match the aggregation list after makeTimeseries or summarize
        for cmd in ['makeTimeseries', 'summarize']:
            pattern = rf'({cmd}\s+)(.*?)(\s*,\s*by:\s*\{{|$)'
            match = re.search(pattern, dql, re.IGNORECASE | re.DOTALL)
            if not match:
                continue
            
            prefix = match.group(1)
            agg_section = match.group(2).strip()
            suffix = match.group(3)
            
            # Split aggregations on commas (but not commas inside parentheses)
            aggs = []
            depth = 0
            current = ''
            for ch in agg_section:
                if ch in ('(', '{', '['):
                    depth += 1
                    current += ch
                elif ch in (')', '}', ']'):
                    depth -= 1
                    current += ch
                elif ch == ',' and depth == 0:
                    aggs.append(current.strip())
                    current = ''
                else:
                    current += ch
            if current.strip():
                aggs.append(current.strip())
            
            if len(aggs) <= 1:
                continue
            
            # Deduplicate: keep unique aggregations only
            seen = {}
            unique_aggs = []
            for agg in aggs:
                # Normalize for comparison: strip alias prefix (e.g., "total = count()" â†’ "count()")
                normalized = re.sub(r'^\w+\s*=\s*', '', agg).strip().lower()
                if normalized not in seen:
                    seen[normalized] = agg
                    unique_aggs.append(agg)
            
            if len(unique_aggs) < len(aggs):
                removed = len(aggs) - len(unique_aggs)
                dql = dql[:match.start()] + prefix + ', '.join(unique_aggs) + suffix + dql[match.end():]
                self.fixes.append(f"Removed {removed} duplicate aggregation(s)")
        
        return dql
    
    def _fix_percentile_naming(self, dql: str) -> str:
        """
        Fix unnamed percentile() in makeTimeseries/summarize.
        
        DQL requires named aggregations when percentile has a second argument,
        because the comma is ambiguous to the parser.
        
        BAD:  makeTimeseries percentile(duration, 99), by: {...}
        GOOD: makeTimeseries p99=percentile(duration, 99), by: {...}
        """
        # Only process if there's a percentile in a makeTimeseries/summarize context
        has_context = False
        for cmd in ['makeTimeseries', 'summarize']:
            if cmd.lower() in dql.lower() and 'percentile(' in dql.lower():
                has_context = True
                break
        
        if not has_context:
            return dql
        
        # Match percentile(field, N) â€” we'll check for existing alias separately
        pattern = r'percentile\s*\(\s*([^,)]+?)\s*,\s*(\d+)\s*\)'
        
        def name_percentile(match):
            full = match.group(0)
            field = match.group(1).strip()
            pct = match.group(2).strip()
            
            # Check if already named: look for "alias=" immediately before
            # Use match.string (the current string being processed) for accurate offsets
            start = match.start()
            prefix = match.string[max(0, start - 30):start]
            if re.search(r'\w+\s*=\s*$', prefix):
                return full  # Already named, don't touch
            
            return f'p{pct}=percentile({field}, {pct})'
        
        new_dql = re.sub(pattern, name_percentile, dql)
        if new_dql != dql:
            self.fixes.append("Named percentile aggregation (DQL requires alias for positional params)")
            dql = new_dql
        
        # Defensive: clean up any double-alias like "p95=p95=expr" â†’ "p95=expr"
        dql = re.sub(r'(\b\w+)=\1=', r'\1=', dql)
        
        # Sanitize numeric-leading aliases: 95th=expr â†’ _95th=expr
        dql = re.sub(r'(?<=[\s,])(\d+\w*)=(?!=)', r'_\1=', dql)
        
        return dql

    def _fix_as_aliases(self, dql: str) -> str:
        """
        Fix 'expression as alias' syntax in by: clauses.
        
        DQL uses 'alias=expression' not 'expression as alias'.
        
        BAD:  by: {substring(logger, ...) as Logger, error.message as Message}
        GOOD: by: {Logger=substring(logger, ...), Message=error.message}
        """
        # Find by: {...} clauses
        by_pattern = r'(by:\s*\{)(.*?)(\})'
        
        def fix_by_aliases(match):
            prefix = match.group(1)
            content = match.group(2)
            suffix = match.group(3)
            
            if ' as ' not in content.lower():
                return match.group(0)
            
            # Split on commas respecting parentheses depth
            parts = []
            depth = 0
            current = ''
            for ch in content:
                if ch in ('(', '{', '['):
                    depth += 1
                    current += ch
                elif ch in (')', '}', ']'):
                    depth -= 1
                    current += ch
                elif ch == ',' and depth == 0:
                    parts.append(current.strip())
                    current = ''
                else:
                    current += ch
            if current.strip():
                parts.append(current.strip())
            
            fixed_parts = []
            changed = False
            for part in parts:
                # Match: expression as alias (case insensitive, respecting parens)
                as_match = re.match(r'^(.+?)\s+[Aa][Ss]\s+"?(\w+)"?$', part.strip())
                if as_match:
                    expr = as_match.group(1).strip()
                    alias = as_match.group(2).strip()
                    fixed_parts.append(f'{alias}={expr}')
                    changed = True
                else:
                    fixed_parts.append(part)
            
            if changed:
                self.fixes.append("Converted 'expr as alias' to 'alias=expr' in by: clause")
                return prefix + ', '.join(fixed_parts) + suffix
            
            return match.group(0)
        
        dql = re.sub(by_pattern, fix_by_aliases, dql, flags=re.DOTALL)
        return dql
    
    def _fix_bare_field_in_summarize(self, dql: str) -> str:
        """
        Fix bare fields in summarize/makeTimeseries that aren't aggregations.
        
        BAD:  summarize duration
        GOOD: summarize avg(duration)
        
        BAD:  makeTimeseries duration
        GOOD: makeTimeseries avg(duration)
        
        Also handles: summarize takeLast(field) â†’ summarize avg(field)
        (takeLast is not a valid DQL aggregation for summarize/makeTimeseries)
        """
        # Known DQL aggregation functions
        valid_aggs = {
            'count', 'sum', 'avg', 'min', 'max', 'percentile', 'median',
            'countif', 'sumif', 'avgif', 'countdistinct', 'collectarray',
            'collectdistinct', 'takefirst', 'takelast', 'takeany', 'stdev',
            'variance', 'delta', 'rate',
        }
        # These are NOT valid in makeTimeseries
        invalid_ts_aggs = {'takelast', 'takefirst', 'takeany', 'collectarray', 'collectdistinct'}
        
        for cmd in ['makeTimeseries', 'summarize']:
            pattern = re.compile(
                rf'(\|\s*{cmd}\s+)(.*?)(\s*(?:,\s*by:|$))',
                re.IGNORECASE | re.DOTALL
            )
            match = pattern.search(dql)
            if not match:
                continue
            
            prefix = match.group(1)
            agg_section = match.group(2).strip()
            suffix = match.group(3)
            
            # Parse individual aggregation expressions
            # Split by comma, but respect parentheses
            parts = []
            depth = 0
            current = ''
            for ch in agg_section:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
                elif ch == ',' and depth == 0:
                    parts.append(current.strip())
                    current = ''
                    continue
                current += ch
            if current.strip():
                parts.append(current.strip())
            
            fixed_parts = []
            changed = False
            for part in parts:
                # Check if this part starts with a known aggregation
                func_match = re.match(r'(\w+)\s*=\s*(\w+)\s*\(', part)
                if not func_match:
                    func_match = re.match(r'(\w+)\s*\(', part)
                
                if func_match:
                    func_name = func_match.group(func_match.lastindex).lower()
                    # Fix invalid timeseries aggs
                    if cmd.lower() == 'maketimeseries' and func_name in invalid_ts_aggs:
                        part = re.sub(rf'\b{func_name}\s*\(', 'avg(', part, flags=re.IGNORECASE)
                        self.fixes.append(f"{func_name}() â†’ avg() (not valid in makeTimeseries)")
                        changed = True
                    elif func_name in valid_aggs:
                        pass  # Valid, keep as is
                    else:
                        # Unknown function â€” might be OK, leave it
                        pass
                else:
                    # Bare field name with no aggregation â€” wrap in avg()
                    alias_match = re.match(r'(\w+)\s*=\s*(.+)', part)
                    if alias_match:
                        alias = alias_match.group(1)
                        field = alias_match.group(2).strip()
                        part = f"{alias}=avg({field})"
                    else:
                        part = f"avg({part})"
                    self.fixes.append(f"Wrapped bare field '{part}' in avg() for {cmd}")
                    changed = True
                
                fixed_parts.append(part)
            
            if changed:
                new_agg_section = ', '.join(fixed_parts)
                dql = dql[:match.start()] + prefix + new_agg_section + suffix + dql[match.end():]
        
        return dql

    def _fix_nrql_subqueries(self, dql: str) -> str:
        """
        Fix NRQL subqueries that were passed through literally.
        
        BAD:  filter ... and in(trace.id, FROM Span SELECT trace.id and ...)
        GOOD: lookup [fetch spans | filter ...] joined on trace.id
        """
        # Detect NRQL subquery remnants â€” by the time DQL reaches the validator,
        # WHERE has been converted to 'and', so we match both forms.
        # The key signature is: FROM <Type> SELECT <field> inside the DQL
        
        # Check if there's even a subquery remnant
        if 'FROM ' not in dql or 'SELECT ' not in dql:
            # Check non-comment lines only
            code_lines = [l for l in dql.split('\n') if not l.strip().startswith('//')]
            code = '\n'.join(code_lines)
            if 'FROM ' not in code and 'SELECT ' not in code:
                return dql
        
        # Pattern: in(field, FROM Type SELECT field and/WHERE conditions)
        pattern1 = r'in\s*\(\s*(\w[\w.]*)\s*,\s*FROM\s+(\w+)\s+SELECT\s+(\w[\w.]*)(?:\s+(?:WHERE|and)\s+(.+?))?\s*\)'
        # Pattern: field in (FROM Type SELECT field and/WHERE conditions)
        pattern2 = r'(\w[\w.]*)\s+in\s*\(\s*FROM\s+(\w+)\s+SELECT\s+(\w[\w.]*)(?:\s+(?:WHERE|and)\s+(.+?))?\s*\)'
        
        def convert_subquery(match, is_in_func=False):
            if is_in_func:
                field = match.group(1).strip()
                source_type = match.group(2).strip()
                select_field = match.group(3).strip()
                conditions = (match.group(4) or '').strip()
            else:
                field = match.group(1).strip()
                source_type = match.group(2).strip()
                select_field = match.group(3).strip()
                conditions = (match.group(4) or '').strip()
            
            # Map NR source to DQL
            source_map = {
                'Span': 'spans', 'Transaction': 'spans',
                'Log': 'logs', 'SystemSample': 'dt.entity.host',
            }
            dt_source = source_map.get(source_type, 'spans')
            
            # Clean conditions
            if conditions:
                w = conditions
                w = re.sub(r"(\w)\s*=\s*(?!=)", r'\1 == ', w)
                w = re.sub(r'\bAND\b', 'and', w, flags=re.IGNORECASE)
                w = re.sub(r'\bappName\b', 'service.name', w)
                sub_filter = f' | filter {w}'
            else:
                sub_filter = ''
            
            lookup_dql = (f'lookup [fetch {dt_source}{sub_filter} '
                         f'| fields {select_field}], '
                         f'sourceField:{field}, lookupField:{select_field}, prefix:"sub."')
            
            self.fixes.append(f"Converted NRQL subquery to DQL lookup on {field}")
            return lookup_dql
        
        new_dql = dql
        new_dql = re.sub(pattern1, lambda m: convert_subquery(m, True), new_dql, flags=re.IGNORECASE | re.DOTALL)
        new_dql = re.sub(pattern2, lambda m: convert_subquery(m, False), new_dql, flags=re.IGNORECASE | re.DOTALL)
        
        if new_dql != dql:
            # Restructure: lookup can't be inside a filter â€” move to separate pipeline step
            lines = new_dql.split('\n')
            fixed_lines = []
            for line in lines:
                stripped = line.strip()
                if 'lookup [' in stripped and ('| filter' in stripped or stripped.startswith('filter')):
                    lookup_match = re.search(
                        r'(lookup\s+\[fetch\s+.+?\]\s*,\s*sourceField:\s*(\w[\w.]*)\s*,\s*lookupField:\s*\w[\w.]*\s*,\s*prefix:\s*"(\w+)\.?")',
                        stripped
                    )
                    if lookup_match:
                        lookup_stmt = lookup_match.group(1)
                        source_field = lookup_match.group(2)
                        prefix = lookup_match.group(3)
                        
                        # Remove the lookup from the filter
                        filter_clean = stripped[:lookup_match.start()].rstrip()
                        # Clean trailing 'and'
                        filter_clean = re.sub(r'\s+and\s*$', '', filter_clean)
                        
                        if filter_clean.strip():
                            fixed_lines.append(filter_clean)
                        fixed_lines.append(f'| {lookup_stmt}')
                        fixed_lines.append(f'| filter isNotNull({prefix}.{source_field})')
                    else:
                        fixed_lines.append(line)
                else:
                    fixed_lines.append(line)
            
            new_dql = '\n'.join(fixed_lines)
        
        return new_dql

    def _fix_metric_names(self, dql: str) -> str:
        """Fix metric names with colons that get misinterpreted as parameters"""
        # Pattern: builtin:something.something - needs to be quoted
        # Match metric names in aggregation functions and quote them
        
        def quote_metric(match):
            func = match.group(1)
            metric = match.group(2)
            self.fixes.append(f"Quoted metric name: {metric}")
            return f'{func}("{metric}"'
        
        # Match unquoted metric names with colons in aggregation functions
        # Pattern: max(builtin:... or avg(builtin:...
        dql = re.sub(
            r'\b(max|min|avg|sum|count)\(\s*(builtin:[a-zA-Z0-9_.]+)',
            quote_metric,
            dql
        )
        
        return dql
    
    def _fix_broken_by_clause(self, dql: str) -> str:
        """Fix broken by: clauses that have WHERE mixed in"""
        # Pattern: by: {field WHERE ...} - this is invalid
        match = re.search(r'by:\s*\{([^}]*)\s+WHERE\s+[^}]*\}', dql, re.IGNORECASE)
        if match:
            # Extract just the field names before WHERE
            fields_part = match.group(1).strip()
            # Clean up the by clause to just have fields
            old_by = match.group(0)
            new_by = f"by: {{{fields_part}}}"
            dql = dql.replace(old_by, new_by)
            self.fixes.append("Removed invalid WHERE from by: clause")
        
        return dql
    
    def _fix_quotes(self, dql: str) -> str:
        """DQL uses double quotes for strings, not single quotes"""
        # Find single-quoted strings (not inside double quotes)
        # Pattern: 'something' but not already "something"
        
        def replace_single_quotes(match):
            content = match.group(1)
            # Don't replace if it contains double quotes
            if '"' in content:
                return match.group(0)
            self.fixes.append(f"Changed single quotes to double quotes: '{content}'")
            return f'"{content}"'
        
        # Match single-quoted strings
        result = re.sub(r"'([^']*)'", replace_single_quotes, dql)
        return result
    
    def _fix_variables(self, dql: str) -> str:
        """Convert NR template variables {{var}} to DT format $var"""
        def replace_var(match):
            var_name = match.group(1)
            self.fixes.append(f"Converted variable {{{{{{var_name}}}}}} to ${var_name}")
            return f"${var_name}"
        
        result = re.sub(r'\{\{(\w+)\}\}', replace_var, dql)
        return result
    
    def _fix_backticks(self, dql: str) -> str:
        """Fix backtick-quoted field names, but preserve backticks where needed.
        
        Preserves backticks for:
        - DQL reserved/type words (duration, timestamp, string, etc.)
        - Identifiers starting with digits (4XX, 5XX)
        - Identifiers with special characters (/, $, spaces, hyphens)
        - fieldsRename lines (always need backticks for display names)
        """
        DQL_RESERVED = {
            'duration', 'timestamp', 'timeframe', 'string', 'long', 'double',
            'boolean', 'ip', 'record', 'array', 'true', 'false', 'null',
            'fetch', 'filter', 'summarize', 'fields', 'sort', 'limit',
            'lookup', 'join', 'append', 'parse', 'from', 'to', 'by',
            'asc', 'desc', 'not', 'and', 'or', 'in', 'is',
        }
        
        def needs_backticks(field: str) -> bool:
            """Check if a field name needs backtick escaping in DQL."""
            if not field:
                return False
            # Starts with digit
            if field[0].isdigit():
                return True
            # Is a DQL reserved word
            if field.lower() in DQL_RESERVED:
                return True
            # Contains special characters (not just alphanumeric, dots, underscores)
            if re.search(r'[^a-zA-Z0-9._]', field):
                return True
            return False
        
        def clean_backtick(match):
            field = match.group(1)
            # Convert NR k8s field names to DT format
            field_map = {
                'k8s.podName': 'k8s.pod.name',
                'k8s.containerName': 'k8s.container.name',
                'k8s.clusterName': 'k8s.cluster.name',
                'k8s.namespaceName': 'k8s.namespace.name',
                'k8s.deploymentName': 'k8s.deployment.name',
                'k8s.nodeName': 'k8s.node.name',
            }
            if field in field_map:
                self.fixes.append(f"Converted `{field}` to {field_map[field]}")
                return field_map[field]
            # Keep backticks if the field needs them
            if needs_backticks(field):
                return f'`{field}`'
            return field
        
        # Process line by line to skip fieldsRename lines
        lines = dql.split('\n')
        result_lines = []
        for line in lines:
            stripped = line.strip().lstrip('| ')
            if stripped.startswith('fieldsRename'):
                # Preserve backticks in fieldsRename - they're intentional
                result_lines.append(line)
            else:
                result_lines.append(re.sub(r'`([^`]+)`', clean_backtick, line))
        
        return '\n'.join(result_lines)
    
    def _fix_comparison_operators(self, dql: str) -> str:
        """Fix comparison operator syntax for DQL"""
        # <> is not valid in DQL, use !=
        if '<>' in dql:
            dql = dql.replace('<>', '!=')
            self.fixes.append("Changed '<>' to '!='")
        
        # CRITICAL: DQL uses == for equality, not =
        # But we need to be careful not to change:
        # - != (not equal)
        # - >= (greater than or equal)
        # - <= (less than or equal)
        # - == (already correct)
        # - Variable assignments in comments
        
        # Pattern: single = surrounded by spaces with value on right side
        # Match: field = "value" or field = $var or field = number
        # Don't match: !=, >=, <=, ==
        def fix_single_equals(match):
            before = match.group(1)
            after = match.group(2)
            self.fixes.append(f"Changed '=' to '==' for equality comparison")
            return f"{before}=={after}"
        
        # Don't convert = to == in fieldsAdd statements (those are assignments)
        # Split DQL by lines and only fix lines that aren't fieldsAdd
        lines = dql.split('\n')
        fixed_lines = []
        for line in lines:
            # Skip fieldsAdd lines - they use = for assignment
            if 'fieldsAdd' in line or 'fieldsRemove' in line or 'fieldsRename' in line:
                fixed_lines.append(line)
                continue
            
            # Match single = that's not part of !=, >=, <=, ==
            # Look for: word/field = "value" or word/field = $var or word/field = number
            line = re.sub(
                r'(\s)=(\s*")',  # = "string"
                fix_single_equals,
                line
            )
            line = re.sub(
                r'(\s)=(\s*\$)',  # = $variable
                fix_single_equals,
                line
            )
            line = re.sub(
                r'(\s)=(\s*\d)',  # = number
                fix_single_equals,
                line
            )
            # Also handle field=value without spaces
            line = re.sub(
                r'([a-zA-Z_][\w.]*)=(")',  # field="value" without spaces
                lambda m: f'{m.group(1)}=={m.group(2)}',
                line
            )
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines)
    
    def _fix_logical_operators(self, dql: str) -> str:
        """DQL uses lowercase and/or"""
        # AND -> and (case insensitive, word boundary)
        if re.search(r'\bAND\b', dql):
            dql = re.sub(r'\bAND\b', 'and', dql)
            self.fixes.append("Changed 'AND' to 'and'")
        
        # OR -> or
        if re.search(r'\bOR\b', dql):
            dql = re.sub(r'\bOR\b', 'or', dql)
            self.fixes.append("Changed 'OR' to 'or'")
        
        # NOT -> not (but be careful with isNotNull)
        if re.search(r'\bNOT\b(?!\s*[Nn]ull)', dql):
            dql = re.sub(r'\bNOT\b(?!\s*[Nn]ull)', 'not', dql)
            self.fixes.append("Changed 'NOT' to 'not'")
        
        return dql
    
    def _fix_null_checks(self, dql: str) -> str:
        """Fix NULL check syntax"""
        # IS NOT NULL -> isNotNull(field)
        # Handle regular fields, backtick-quoted fields, and hyphenated fields (like correlation-id)
        # Pattern: field IS NOT NULL or `field` IS NOT NULL or hyphen-field IS NOT NULL
        match = re.search(r'(`[^`]+`|[\w.-]+)\s+IS\s+NOT\s+NULL', dql, re.IGNORECASE)
        if match:
            field = match.group(1).strip('`')  # Remove backticks if present
            dql = re.sub(
                r'(`[^`]+`|[\w.-]+)\s+IS\s+NOT\s+NULL',
                lambda m: f'isNotNull({m.group(1).strip("`")})',
                dql,
                flags=re.IGNORECASE
            )
            self.fixes.append(f"Changed 'IS NOT NULL' to 'isNotNull()'")
        
        # IS NULL -> isNull(field)
        match = re.search(r'(`[^`]+`|[\w.-]+)\s+IS\s+NULL\b', dql, re.IGNORECASE)
        if match:
            field = match.group(1).strip('`')
            dql = re.sub(
                r'(`[^`]+`|[\w.-]+)\s+IS\s+NULL\b',
                lambda m: f'isNull({m.group(1).strip("`")})',
                dql,
                flags=re.IGNORECASE
            )
            self.fixes.append(f"Changed 'IS NULL' to 'isNull()'")
        
        return dql
    
    def _fix_like_patterns(self, dql: str) -> str:
        """Convert LIKE patterns to DQL functions"""
        # LIKE '%value%' -> contains("value")
        def convert_like(match):
            field = match.group(1)
            pattern = match.group(2)
            
            # Determine pattern type
            starts_with_wildcard = pattern.startswith('%')
            ends_with_wildcard = pattern.endswith('%')
            
            # Remove wildcards
            value = pattern.strip('%')
            
            if starts_with_wildcard and ends_with_wildcard:
                self.fixes.append(f"Changed '{field} LIKE' to 'contains()'")
                return f'contains({field}, "{value}")'
            elif starts_with_wildcard:
                self.fixes.append(f"Changed '{field} LIKE' to 'endsWith()'")
                return f'endsWith({field}, "{value}")'
            elif ends_with_wildcard:
                self.fixes.append(f"Changed '{field} LIKE' to 'startsWith()'")
                return f'startsWith({field}, "{value}")'
            else:
                self.fixes.append(f"Changed '{field} LIKE' to '=='")
                return f'{field} == "{value}"'
        
        # Match LIKE patterns with single or double quotes
        dql = re.sub(
            r"(\w+[\w.]*)\s+LIKE\s+['\"]([^'\"]+)['\"]",
            convert_like,
            dql,
            flags=re.IGNORECASE
        )
        
        # Also handle NOT LIKE - DQL syntax: not(contains(field, "value"))
        def convert_not_like(match):
            field = match.group(1)
            pattern = match.group(2)
            value = pattern.strip('%')
            
            self.fixes.append(f"Changed '{field} NOT LIKE' to 'not(contains())'")
            return f'not(contains({field}, "{value}"))'
        
        dql = re.sub(
            r"(\w+[\w.]*)\s+NOT\s+LIKE\s+['\"]([^'\"]+)['\"]",
            convert_not_like,
            dql,
            flags=re.IGNORECASE
        )
        
        return dql
    
    def _fix_timeseries_count(self, dql: str, context: str = "") -> str:
        """
        Fix timeseries count() - this is the most critical fix.
        timeseries requires a metric key, count() alone is invalid.
        NOTE: Don't match makeTimeseries which is valid!
        """
        # Check for standalone timeseries count() (not makeTimeseries)
        # Use negative lookbehind to exclude makeTimeseries
        if re.search(r'(?<!make)timeseries\s+count\(\s*\)', dql, re.IGNORECASE):
            # This is invalid - need to convert to fetch + summarize
            self.fixes.append("Converted invalid 'timeseries count()' to 'fetch + summarize'")
            dql = self._convert_timeseries_count_to_fetch(dql, context)
        
        return dql
    
    def _convert_timeseries_count_to_fetch(self, dql: str, context: str = "") -> str:
        """Convert timeseries count() to proper fetch + summarize"""
        # Extract any existing clauses
        by_match = re.search(r',\s*by:\s*\{([^}]*)\}', dql)
        filter_match = re.search(r',\s*filter:\s*(.+?)(?:,\s*by:|$)', dql)
        
        by_clause = by_match.group(1).strip() if by_match else ""
        filter_clause = filter_match.group(1).strip().rstrip(',') if filter_match else ""
        
        # Determine data source from context
        context_lower = context.lower()
        if 'log' in context_lower:
            source = 'logs'
        elif 'synthetic' in context_lower or 'monitor' in context_lower:
            source = 'dt.synthetic.http.request'
        elif 'error' in context_lower:
            source = 'spans'
        else:
            source = 'spans'
        
        # Build new query
        parts = [f"fetch {source}"]
        
        if filter_clause:
            parts.append(f"filter {filter_clause}")
        
        if by_clause:
            parts.append(f"summarize count(), by: {{{by_clause}}}")
        else:
            parts.append("summarize count()")
        
        return '\n| '.join(parts)
    
    def _fix_invalid_functions(self, dql: str) -> str:
        """Fix invalid or unsupported functions"""
        # uniqueCount -> countDistinct
        if 'uniqueCount(' in dql or 'uniquecount(' in dql:
            dql = re.sub(r'uniqueCount\(', 'countDistinct(', dql, flags=re.IGNORECASE)
            self.fixes.append("Changed 'uniqueCount()' to 'countDistinct()'")
        
        # average -> avg
        if re.search(r'\baverage\(', dql, re.IGNORECASE):
            dql = re.sub(r'\baverage\(', 'avg(', dql, flags=re.IGNORECASE)
            self.fixes.append("Changed 'average()' to 'avg()'")
        
        # latest -> takeAny
        if 'latest(' in dql:
            dql = re.sub(r'latest\(', 'takeAny(', dql, flags=re.IGNORECASE)
            self.fixes.append("Changed 'latest()' to 'takeAny()'")
        
        # Handle NR-specific SLI metrics - add warning comment
        # Check in both the original NRQL comment and the DQL itself
        # Skip if already has the new format comment
        if 'newrelic.sli.' in dql.lower() or 'sli.good' in dql.lower() or 'sli.valid' in dql.lower():
            if '// NOTE: NR SLI metrics' not in dql and 'fetch slo' not in dql.lower():
                pass  # Let the converter handle this with the better message
        
        # Handle clamp_max/clamp_min - these are now preprocessed to if()
        # Only add note if unconverted ones remain
        if 'clamp_max(' in dql.lower() or 'clamp_min(' in dql.lower():
            if '// NOTE: clamp' not in dql.lower():
                dql = "// NOTE: clamp_max/clamp_min converted to if() - verify logic\n" + dql
                self.fixes.append("Added note about clamp function conversion")
        
        # Handle histogram - convert to count() + bin() for categoricalBarChart visualization
        # NRQL: histogram(field, ceiling, numBars, width) 
        # DQL: summarize count(), by:{bin(field, width)}
        histogram_match = re.search(r'\bhistogram\s*\(\s*([^,]+)(?:\s*,\s*(\d+(?:\.\d+)?)(?:\s*,\s*(\d+(?:\.\d+)?)(?:\s*,\s*(\d+(?:\.\d+)?))?)?)?\s*\)', dql, re.IGNORECASE)
        if histogram_match:
            field = histogram_match.group(1).strip()
            if field == 'duration.ms':
                field = 'duration'
            
            # Calculate bin width
            ceiling = histogram_match.group(2)
            num_bars = histogram_match.group(3)
            explicit_w = histogram_match.group(4)
            if explicit_w:
                bin_w = int(float(explicit_w))
            elif ceiling and num_bars:
                bin_w = int(float(ceiling) / float(num_bars))
            else:
                bin_w = 1000
            
            # Use DQL duration literal for duration field
            if field == 'duration':
                bin_expr = ms_to_dql_duration(bin_w)
            else:
                bin_expr = str(bin_w)
            
            # Replace histogram() call with count(), by:{bin(field, width)}
            dql = re.sub(
                r'\bhistogram\s*\(\s*[^)]+\)',
                f'count(), by: {{bin({field}, {bin_expr})}}',
                dql,
                flags=re.IGNORECASE
            )
            
            # Fix "| summarize count(), by:..." (correct) or "| makeTimeseries count(), by:..." 
            # No further fixup needed since the replacement is valid DQL
            
            if '// NOTE: histogram' not in dql.lower():
                self.fixes.append("histogram() â†’ count() + bin() for categoricalBarChart")
        
        # Handle cdfPercentage - not available
        if 'cdfpercentage(' in dql.lower():
            if '// NOTE: cdfPercentage' not in dql:
                dql = "// NOTE: cdfPercentage() not available in DQL\n" + dql
                self.fixes.append("Added note about cdfPercentage not available")
        
        # aparse() is now handled by AparseConverter in NRQLtoDQLConverter with real DPL conversion
        # (no longer converting to extract() here)
        
        # Handle percentage() - NR-specific function
        # percentage(count(field), where condition) -> need to calculate manually
        # This is complex and can't be directly converted
        if 'percentage(' in dql.lower():
            if '// NOTE: percentage()' not in dql:
                dql = "// NOTE: NR percentage() function needs manual conversion in DQL\n// Use: (countIf(condition) / count()) * 100\n" + dql
                self.fixes.append("Added note about percentage() needing manual conversion")
        
        return dql
    
    def _fix_field_names(self, dql: str) -> str:
        """Fix common field name issues"""
        # Fields with hyphens need backticks in DQL
        # e.g., some-field -> `some-field`
        # But only if not already backticked
        
        # This is a complex fix - for now just note if there are potential issues
        if re.search(r'(?<![`])\b\w+-\w+\b(?![`])', dql):
            # Has hyphenated field not in backticks
            # For safety, we'll just note this as a warning
            pass
        
        return dql
    
    def _fix_whitespace(self, dql: str) -> str:
        """Clean up whitespace issues"""
        # Remove trailing whitespace from lines
        lines = [line.rstrip() for line in dql.split('\n')]
        
        # Remove empty lines at start/end
        while lines and not lines[0].strip():
            lines.pop(0)
        while lines and not lines[-1].strip():
            lines.pop()
        
        result = '\n'.join(lines)
        
        # Fix double pipes (| |) - often caused by joining issues
        result = re.sub(r'\|\s*\|', '|', result)
        
        # Fix pipe at start of line following another pipe
        result = re.sub(r'\|\s*\n\s*\|', '\n|', result)
        
        return result


# ============================================================================
# NRQL TO DQL CONVERTER
# ============================================================================

class NRQLtoDQLConverter:
    """Converts NRQL queries to DQL with built-in validation and SLO migration"""
    
    def __init__(self, registry: 'DTEnvironmentRegistry' = None):
        self.validator = DQLValidator()
        self._guid_cache = {}  # Maps GUID -> entity name/details
        self._guid_types = {}  # Maps GUID -> entity type (SERVICE_LEVEL, APM_APPLICATION, etc)
        self._detected_slos = set()  # Track all SERVICE_LEVEL GUIDs we've seen
        
        # Shared environment registry for live metric + entity validation
        self._registry = registry
        
        # AST compiler â€” primary conversion path (replaces regex for supported patterns)
        try:
            from nrql_compiler import NRQLCompiler
            self._ast_compiler = NRQLCompiler(
                field_map=ATTR_MAP, metric_map=METRIC_MAP,
                metric_transforms=METRIC_TRANSFORMS,
                metric_resolver=self._live_metric_resolver
            )
        except ImportError:
            self._ast_compiler = None
        
        # Advanced converters â€” DPL, rate, COMPARE WITH, funnel, etc.
        self._regex_to_dpl = RegexToDPLConverter()
        self._aparse_converter = AparseConverter()
        self._rate_converter = RateDerivativeConverter()
        self._compare_converter = CompareWithConverter()
        self._funnel_converter = FunnelConverter()
        self._with_as_converter = WithAsConverter()
        self._extrapolate_handler = ExtrapolateHandler()
        self._bucket_percentile_converter = BucketPercentileConverter()
        
        # SLO migration config
        self._nr_api_key = os.environ.get('NR_API_KEY', None)  # Auto-pickup for GUID resolution
        self._dt_url = None
        self._dt_token = None
        self._auto_create_slos = False
        self._created_slos = {}  # Track SLOs we've created: GUID -> DT SLO ID
        self._slo_details_cache = {}  # Cache full SLO details from NR
    
    def set_registry(self, registry: 'DTEnvironmentRegistry'):
        """Set or update the environment registry for live validation."""
        self._registry = registry
    
    def _validate_dql_live(self, dql: str, result: 'ConversionResult', max_retries: int = 2) -> str:
        """
        Validate DQL against the live Dynatrace Grail API.
        
        If syntax errors are detected:
        1. Parse the error message for hints
        2. Attempt targeted auto-fix
        3. Re-validate
        4. Repeat up to max_retries times
        5. If still invalid, attach the DT error message to warnings
        
        Returns the (possibly fixed) DQL string.
        """
        if not self._registry:
            return dql
        
        current_dql = dql
        
        for attempt in range(max_retries + 1):
            is_valid, error_msg, error_details = self._registry.validate_dql_syntax(current_dql)
            
            if is_valid is None:
                # API unavailable â€” skip validation silently
                return current_dql
            
            if is_valid:
                if attempt > 0:
                    result.fixes_applied.append(
                        f"DQL live-validated after {attempt} auto-fix(es)"
                    )
                return current_dql
            
            # Invalid â€” try to auto-fix
            if attempt < max_retries:
                parsed = self._registry.parse_dql_error(error_msg)
                fixed_dql = self._attempt_dql_fix(current_dql, parsed, error_msg)
                
                if fixed_dql and fixed_dql != current_dql:
                    result.fixes_applied.append(
                        f"Live validation fix (attempt {attempt + 1}): {parsed['error_type']} â€” {parsed.get('suggestion', error_msg[:80])}"
                    )
                    current_dql = fixed_dql
                    continue
            
            # Exhausted retries or no fix found â€” report the error
            result.warnings.append(f"DT API syntax error: {error_msg}")
            result.confidence = "LOW"
            # Add the error as a DQL comment so it's visible
            error_comment = f"// âš  DT VALIDATION ERROR: {error_msg[:120]}"
            if error_comment not in current_dql:
                current_dql = error_comment + '\n' + current_dql
            break
        
        return current_dql
    
    def _attempt_dql_fix(self, dql: str, parsed_error: Dict, raw_error: str) -> Optional[str]:
        """
        Attempt to fix DQL based on parsed error from the DT API.
        
        This is the auto-repair loop â€” each error type has targeted fixes.
        Returns fixed DQL or None if no fix is possible.
        """
        error_type = parsed_error.get('error_type', '')
        bad_token = parsed_error.get('bad_token', '')
        suggestion = parsed_error.get('suggestion', '')
        
        fixed = dql
        
        if error_type == 'syntax' and bad_token.lower() == 'as':
            # expr as alias â†’ alias=expr in by: clauses
            # Re-run the validator's as-alias fixer
            validator = DQLValidator()
            fixed = validator._fix_as_aliases(fixed)
            # Also check in summarize (not just by:)
            fixed = re.sub(
                r'(\w+\([^)]*\))\s+as\s+"?(\w+)"?',
                lambda m: f'{m.group(2)}={m.group(1)}',
                fixed, flags=re.IGNORECASE
            )
        
        elif error_type == 'parameter':
            # "Too many positional parameters" â€” name the aggregations
            validator = DQLValidator()
            fixed = validator._fix_percentile_naming(fixed)
            # Also try naming any unnamed aggregations in makeTimeseries
            # Pattern: makeTimeseries func(field, arg) â†’ name=func(field, arg)
            def name_agg(match):
                func = match.group(1)
                args = match.group(2)
                # Generate a name from the function
                name = func.lower()
                if ',' in args:
                    # e.g., percentile(duration, 99) â†’ p99
                    parts = args.split(',')
                    if len(parts) == 2 and parts[1].strip().isdigit():
                        name = f"p{parts[1].strip()}"
                return f"{name}={func}({args})"
            
            # Only fix unnamed aggregations (not already preceded by name=)
            lines = fixed.split('\n')
            new_lines = []
            for line in lines:
                if ('makeTimeseries' in line or 'summarize' in line) and '(' in line:
                    # Find aggregations that aren't named
                    def safe_name_agg(m):
                        inner = re.match(r'(\w+)\((.+)\)', m.group(1))
                        if inner:
                            return name_agg(inner)
                        return m.group(0)  # No match, return unchanged
                    
                    line = re.sub(
                        r'(?<!=)((?:avg|sum|min|max|count|percentile|countIf|countDistinct)\s*\([^)]+,[^)]+\))',
                        safe_name_agg,
                        line
                    )
                new_lines.append(line)
            fixed = '\n'.join(new_lines)
        
        elif error_type == 'function' and bad_token:
            # Unknown function â€” try to map it
            func_map = {
                'takeLast': 'last',
                'takeFirst': 'first',
                'countif': 'countIf',
                'avgif': 'avgIf',
                'sumif': 'sumIf',
                'isnull': 'isNull',
                'isnotnull': 'isNotNull',
                'tostring': 'toString',
                'toint': 'toInt',
                'todouble': 'toDouble',
            }
            replacement = func_map.get(bad_token.lower(), '')
            if replacement:
                fixed = re.sub(
                    rf'\b{re.escape(bad_token)}\s*\(',
                    f'{replacement}(',
                    fixed, flags=re.IGNORECASE
                )
        
        elif error_type == 'column' and bad_token:
            # Column doesn't exist â€” try comprehensive field mapping first,
            # then fall back to registry fuzzy search
            
            # Extended NRâ†’DT field map for fields that show up in DT API errors
            column_fix_map = {
                # Span/Trace IDs
                'parentId': 'span.parent_id', 'parentid': 'span.parent_id',
                'id': 'span.id', 'guid': 'span.id',
                'traceId': 'trace_id', 'traceid': 'trace_id',
                # Duration variants
                'Duration.Seconds': 'duration', 'duration.seconds': 'duration',
                'Duration.Ms': 'duration', 'duration.ms': 'duration',
                'durationMs': 'duration',
                # Name variants
                'name': 'span.name', 'transactionName': 'span.name',
                'transactionname': 'span.name',
                # Service/App
                'appName': 'service.name', 'appname': 'service.name',
                'entityName': 'entity.name', 'entityname': 'entity.name',
                'entityGuid': 'dt.entity.service',
                # HTTP
                'httpResponseCode': 'http.response.status_code',
                'httpresponsecode': 'http.response.status_code',
                'http.statusCode': 'http.response.status_code',
                'http.statuscode': 'http.response.status_code',
                'httpMethod': 'http.request.method',
                'httpmethod': 'http.request.method',
                'request.uri': 'http.request.path',
                'request.url': 'http.request.path',
                # Host
                'host': 'host.name', 'hostname': 'host.name',
                'fullHostname': 'host.name',
                # K8s
                'k8s.containerName': 'k8s.container.name',
                'k8s.podName': 'k8s.pod.name',
                'k8s.clusterName': 'k8s.cluster.name',
                'k8s.namespaceName': 'k8s.namespace.name',
                'clusterName': 'k8s.cluster.name',
                'podName': 'k8s.pod.name',
                # Logs
                'message': 'content', 'level': 'loglevel',
                'log.level': 'loglevel',
                # Browser/RUM
                'pageUrl': 'page.url', 'userAgentName': 'browser.name',
                'userAgentOS': 'os.name',
                'city': 'geo.city', 'countryCode': 'geo.country',
                'deviceType': 'device.type',
            }
            
            replacement = column_fix_map.get(bad_token)
            if not replacement:
                # Case-insensitive lookup
                replacement = column_fix_map.get(bad_token.lower())
            
            if replacement:
                fixed = re.sub(
                    r'(?<![.\w])' + re.escape(bad_token) + r'(?![.\w])',
                    replacement, fixed
                )
            elif self._registry:
                # Try registry fuzzy-find for metric keys
                entity = self._registry.find_metric(bad_token)
                if entity:
                    fixed = fixed.replace(bad_token, entity)
        
        # Generic fixes for common patterns in error messages
        if 'SELECT' in raw_error or 'FROM' in raw_error.split("'")[0:1]:
            # NRQL remnants â€” try subquery fix
            validator = DQLValidator()
            fixed = validator._fix_nrql_subqueries(fixed)
        
        return fixed if fixed != dql else None
    
    def _validate_dt_metric(self, metric_key: str, source_field: str = '') -> Tuple[str, Optional[str]]:
        """
        Validate a DT metric key against the live environment registry.
        
        Returns:
            (validated_metric, warning_or_none)
            - If metric exists: (metric_key, None)
            - If metric doesn't exist but correction found: (corrected_key, warning_string)
            - If no registry: (metric_key, None) â€” pass through unchanged
        """
        if not self._registry:
            return metric_key, None
        
        if self._registry.metric_exists(metric_key):
            return metric_key, None
        
        # Metric doesn't exist â€” try to find the correct one
        corrected = self._registry.find_metric(metric_key)
        if corrected:
            info = self._registry.get_metric_info(corrected)
            display = info['displayName'] if info else ''
            source_hint = f" (from NR field '{source_field}')" if source_field else ''
            warning = (f"Metric '{metric_key}' not found in environment{source_hint} â†’ "
                      f"auto-corrected to '{corrected}' ({display})")
            return corrected, warning
        else:
            source_hint = f" (from NR field '{source_field}')" if source_field else ''
            warning = f"Metric '{metric_key}' not found in environment{source_hint} â€” no close match"
            return metric_key, warning
    
    def _validate_entity_name(self, name: str, entity_type: str = 'SERVICE') -> Tuple[str, Optional[str]]:
        """
        Validate an entity name against the live environment registry.
        
        Returns:
            (validated_name, warning_or_none)
            - If entity found exactly: (name, None)
            - If entity found fuzzy: (dt_name, warning_string)
            - If no registry or not found: (name, warning_string)
        """
        if not self._registry:
            return name, None
        
        entity = self._registry.find_entity(name, entity_type)
        if entity:
            dt_name = entity['name']
            if dt_name.lower() == name.lower():
                return dt_name, None
            else:
                warning = f"Entity '{name}' matched to DT entity '{dt_name}' (fuzzy match)"
                return dt_name, warning
        else:
            warning = f"Entity '{name}' not found in DT environment as {entity_type}"
            return name, warning
    
    def _live_metric_resolver(self, field_key: str, raw_field: str, 
                               static_mapped: str = None) -> Tuple[str, Optional[str]]:
        """Bridge method: called by the AST compiler's DQLEmitter to resolve metrics.
        
        Uses the converter's full resolution chain:
        1. If static_mapped provided (from METRIC_MAP), validate it exists via registry
        2. If no static mapping, try registry fuzzy-find from raw_field
        3. Returns (dt_metric, warning_or_none)
        
        This gives the AST compiler access to the live DTEnvironmentRegistry
        without the compiler needing to know about the registry directly.
        """
        if static_mapped:
            # Validate the static mapping exists in the live environment
            validated, warning = self._validate_dt_metric(static_mapped, raw_field)
            return validated, warning
        
        # No static mapping â€” try live registry fuzzy-find
        if self._registry:
            # Try to find a matching metric by tokenizing the NR field name
            corrected = self._registry.find_metric(raw_field)
            if corrected:
                info = self._registry.get_metric_info(corrected)
                display = info['displayName'] if info else ''
                warning = (f"No METRIC_MAP entry for '{raw_field}' â†’ "
                          f"live-resolved to '{corrected}' ({display})")
                return corrected, warning
        
        # Nothing found
        return None, None
    
    def _resolve_metric(self, field_key: str, raw_field: str = '') -> Tuple[Optional[str], Optional[str]]:
        """
        Resolve an NR field to a validated DT metric.
        
        1. Look up in METRIC_MAP (static NRâ†’DT mapping)
        2. If registry available, validate the mapped metric exists
        3. If mapped metric doesn't exist, try registry fuzzy-find
        4. If field already looks like a DT metric (dt.* or builtin:*), validate directly
        
        Returns:
            (dt_metric_key_or_none, warning_or_none)
        """
        dt_metric = METRIC_MAP.get(field_key)
        
        if dt_metric:
            # METRIC_MAP gave us a target â€” validate it exists
            validated, warning = self._validate_dt_metric(dt_metric, raw_field)
            return validated, warning
        
        # Not in METRIC_MAP â€” check if raw field is already a DT metric
        if raw_field and (raw_field.startswith('dt.') or raw_field.startswith('builtin:')):
            validated, warning = self._validate_dt_metric(raw_field, raw_field)
            return validated, warning
        
        return None, None
    
    def configure_slo_migration(self, nr_api_key: str = None, dt_url: str = None, 
                                 dt_token: str = None, auto_create: bool = False):
        """
        Configure automatic SLO migration when SERVICE_LEVEL GUIDs are detected.
        
        Args:
            nr_api_key: New Relic API key for fetching SLO definitions
            dt_url: Dynatrace environment URL (e.g., https://xyz.apps.dynatrace.com)
            dt_token: Dynatrace API token with slo.write permission
            auto_create: If True, automatically create SLOs in DT when detected
        
        Example:
            converter.configure_slo_migration(
                nr_api_key=os.environ['NR_API_KEY'],
                dt_url='https://cwt03869.apps.dynatrace.com',
                dt_token=os.environ['DT_API_TOKEN'],
                auto_create=True
            )
        """
        self._nr_api_key = nr_api_key
        self._dt_url = dt_url.rstrip('/') if dt_url else None
        self._dt_token = dt_token
        self._auto_create_slos = auto_create
    
    def _fetch_slo_details_from_nr(self, guid: str) -> Optional[Dict]:
        """Fetch full SLO definition from New Relic for a specific GUID."""
        if not self._nr_api_key:
            print(f"  DEBUG: No NR API key configured, cannot fetch SLO details for {guid[:30]}...")
            return None
        
        print(f"  Fetching SLO details from NR for {guid[:30]}...")
        
        if guid in self._slo_details_cache:
            return self._slo_details_cache[guid]
        
        # Step 1: Get basic SLI entity info and the associated service GUID
        query = '''
        {
          actor {
            entity(guid: "%s") {
              guid
              name
              entityType
              tags { key values }
            }
          }
        }
        ''' % guid
        
        try:
            payload = json.dumps({"query": query}).encode('utf-8')
            headers = {"Content-Type": "application/json", "API-Key": self._nr_api_key}
            
            req = urllib.request.Request("https://api.newrelic.com/graphql", data=payload, headers=headers)
            with urllib.request.urlopen(req, timeout=30, context=SSL_CONTEXT) as response:
                data = json.loads(response.read().decode('utf-8'))
                
                # Debug: show what NR returned
                if 'errors' in data:
                    print(f"  DEBUG: NR API returned errors: {data['errors'][:200] if len(str(data['errors'])) > 200 else data['errors']}")
                
                # Print the raw response for debugging
                actor_data = data.get('data', {}).get('actor', {})
                print(f"  DEBUG: NR actor response keys: {list(actor_data.keys())}")
                
                entity = actor_data.get('entity')
                print(f"  DEBUG: Entity data: {entity}")
                
                if entity:
                    slo_name = entity.get('name', '')
                    print(f"  DEBUG: SLO Name: {slo_name}")
                    
                    # Parse tags into a dict
                    tags = {t['key']: t['values'][0] for t in entity.get('tags', []) if t.get('values')}
                    
                    # Extract target from nr.sloTarget tag (e.g., "97.0%")
                    target_str = tags.get('nr.sloTarget', '99.9%')
                    try:
                        target = float(target_str.replace('%', ''))
                    except:
                        target = 99.9
                    
                    # Extract period from nr.sloPeriod tag (e.g., "7d")
                    period_str = tags.get('nr.sloPeriod', '7d')
                    try:
                        time_window_days = int(period_str.replace('d', ''))
                    except:
                        time_window_days = 7
                    
                    # Extract associated service name and GUID from tags
                    associated_entity_name = tags.get('nr.associatedEntityName', '')
                    associated_entity_guid = tags.get('nr.associatedEntityGuid', '')
                    
                    # Build basic slo_info first
                    slo_info = {
                        'guid': guid,
                        'name': slo_name,
                        'tags': tags,
                        'target': target,
                        'time_window_days': time_window_days,
                        'description': f"Migrated from New Relic: {slo_name}",
                        'service_name': associated_entity_name,
                        'associated_entity_guid': associated_entity_guid,
                    }
                    
                    # Step 2: Try to get the actual NRQL queries from the associated entity
                    if associated_entity_guid:
                        sli_details = self._fetch_sli_nrql_from_associated_entity(associated_entity_guid, slo_name)
                        if sli_details:
                            slo_info.update(sli_details)
                            print(f"  DEBUG: Got SLI NRQL - good: {slo_info.get('good_events_from', 'N/A')}, valid: {slo_info.get('valid_events_from', 'N/A')}")
                    
                    # Infer SLO type from NRQL queries or name
                    slo_type, latency_ms = self._infer_slo_type(slo_info)
                    slo_info['slo_type'] = slo_type
                    if latency_ms:
                        slo_info['latency_threshold_ms'] = latency_ms
                    
                    print(f"  DEBUG: Inferred SLO type: {slo_type}")
                    print(f"  DEBUG: Target: {target}%, Period: {time_window_days}d, Service: {associated_entity_name}")
                    
                    self._slo_details_cache[guid] = slo_info
                    return slo_info
                else:
                    print(f"  DEBUG: Entity not found in NR response")
                    
        except Exception as e:
            import traceback
            print(f"  DEBUG: Exception fetching SLO: {type(e).__name__}: {e}")
            traceback.print_exc()
        
        return None
    
    def _fetch_sli_nrql_from_associated_entity(self, service_guid: str, sli_name: str) -> Dict:
        """
        Fetch the actual NRQL queries for an SLI from its associated service entity.
        
        Returns dict with good_events_from, good_events_where, valid_events_from, valid_events_where
        """
        # Query the associated service to get its service level indicators
        query = '''
        {
          actor {
            entity(guid: "%s") {
              ... on ApmExternalServiceEntity {
                serviceLevel {
                  indicators {
                    name
                    guid
                    events {
                      validEvents { from where }
                      goodEvents { from where }
                    }
                  }
                }
              }
              ... on ExternalServiceEntity {
                serviceLevel {
                  indicators {
                    name
                    guid
                    events {
                      validEvents { from where }
                      goodEvents { from where }
                    }
                  }
                }
              }
              ... on ApmServiceEntity {
                serviceLevel {
                  indicators {
                    name
                    guid
                    events {
                      validEvents { from where }
                      goodEvents { from where }
                    }
                  }
                }
              }
              ... on BrowserApplicationEntity {
                serviceLevel {
                  indicators {
                    name
                    guid
                    events {
                      validEvents { from where }
                      goodEvents { from where }
                    }
                  }
                }
              }
              ... on MobileApplicationEntity {
                serviceLevel {
                  indicators {
                    name
                    guid
                    events {
                      validEvents { from where }
                      goodEvents { from where }
                    }
                  }
                }
              }
              ... on SyntheticMonitorEntity {
                serviceLevel {
                  indicators {
                    name
                    guid
                    events {
                      validEvents { from where }
                      goodEvents { from where }
                    }
                  }
                }
              }
              ... on WorkloadEntity {
                serviceLevel {
                  indicators {
                    name
                    guid
                    events {
                      validEvents { from where }
                      goodEvents { from where }
                    }
                  }
                }
              }
              ... on GenericServiceEntity {
                serviceLevel {
                  indicators {
                    name
                    guid
                    events {
                      validEvents { from where }
                      goodEvents { from where }
                    }
                  }
                }
              }
              ... on GenericEntity {
                serviceLevel {
                  indicators {
                    name
                    guid
                    events {
                      validEvents { from where }
                      goodEvents { from where }
                    }
                  }
                }
              }
            }
          }
        }
        ''' % service_guid
        
        try:
            payload = json.dumps({"query": query}).encode('utf-8')
            headers = {"Content-Type": "application/json", "API-Key": self._nr_api_key}
            
            req = urllib.request.Request("https://api.newrelic.com/graphql", data=payload, headers=headers)
            with urllib.request.urlopen(req, timeout=30, context=SSL_CONTEXT) as response:
                data = json.loads(response.read().decode('utf-8'))
                
                if 'errors' in data:
                    print(f"  DEBUG: NR SLI query errors (may be expected for some entity types): {str(data['errors'])[:200]}")
                
                entity = data.get('data', {}).get('actor', {}).get('entity', {})
                service_level = entity.get('serviceLevel', {})
                indicators = service_level.get('indicators', [])
                
                print(f"  DEBUG: Found {len(indicators)} SLIs on associated entity")
                
                # Find the indicator matching our SLI name
                for indicator in indicators:
                    if indicator.get('name') == sli_name:
                        events = indicator.get('events', {})
                        good_events = events.get('goodEvents', {}) or {}
                        valid_events = events.get('validEvents', {}) or {}
                        
                        result = {
                            'good_events_from': good_events.get('from', ''),
                            'good_events_where': good_events.get('where', ''),
                            'valid_events_from': valid_events.get('from', ''),
                            'valid_events_where': valid_events.get('where', ''),
                        }
                        
                        print(f"  DEBUG: SLI NRQL queries found:")
                        print(f"    Good Events: FROM {result['good_events_from']} WHERE {result['good_events_where'][:100] if result['good_events_where'] else 'N/A'}...")
                        print(f"    Valid Events: FROM {result['valid_events_from']} WHERE {result['valid_events_where'][:100] if result['valid_events_where'] else 'N/A'}...")
                        
                        return result
                
                print(f"  DEBUG: SLI '{sli_name}' not found in associated entity's indicators")
                        
        except Exception as e:
            print(f"  DEBUG: Error fetching SLI NRQL: {type(e).__name__}: {e}")
        
        return {}
    
    def _infer_slo_type(self, slo_info: Dict) -> Tuple[str, Optional[int]]:
        """
        Infer SLO type (latency vs availability) from NRQL queries or name.
        
        Returns: (slo_type, latency_threshold_ms or None)
        """
        # Check NRQL where clauses for latency indicators
        good_where = slo_info.get('good_events_where', '').lower()
        valid_where = slo_info.get('valid_events_where', '').lower()
        all_nrql = f"{good_where} {valid_where}"
        
        # Look for latency patterns in NRQL
        latency_match = re.search(r'(?:duration|responsetime|latency)\s*[<>=]+\s*(\d+(?:\.\d+)?)', all_nrql, re.IGNORECASE)
        if latency_match:
            threshold_value = float(latency_match.group(1))
            # Determine if seconds or milliseconds based on value
            if threshold_value < 100:
                latency_ms = int(threshold_value * 1000)  # Assume seconds
            else:
                latency_ms = int(threshold_value)  # Assume milliseconds
            return ('latency', latency_ms)
        
        # Check name for latency indicators
        name_lower = slo_info.get('name', '').lower()
        if 'latency' in name_lower or 'response' in name_lower or 'duration' in name_lower or 'performance' in name_lower:
            return ('latency', 4000)  # Default 4s threshold
        
        # Default to availability
        return ('availability', None)
    
    def _analyze_slo_type(self, slo_info: Dict) -> str:
        """Determine SLO type and extract thresholds from NRQL content."""
        all_nrql = f"{slo_info.get('good_events_nrql', '')} {slo_info.get('valid_events_nrql', '')}".lower()
        
        # Extract latency threshold if present (e.g., duration < 4, responseTime < 2000)
        latency_match = re.search(r'(?:duration|responsetime|latency)\s*[<>=]+\s*(\d+(?:\.\d+)?)', all_nrql, re.IGNORECASE)
        if latency_match:
            threshold_value = float(latency_match.group(1))
            # Determine if it's seconds or milliseconds based on value
            # Values > 100 are likely ms, values < 100 are likely seconds
            if threshold_value > 100:
                slo_info['latency_threshold_ms'] = threshold_value
            else:
                slo_info['latency_threshold_ms'] = threshold_value * 1000
            return 'latency'
        
        # Check for duration-based without explicit threshold
        if 'duration' in all_nrql or 'latency' in all_nrql:
            slo_info['latency_threshold_ms'] = 4000  # Default 4s
            return 'latency'
        
        # Extract status code threshold (e.g., http.statusCode < 400)
        status_match = re.search(r'(?:statuscode|http\.status)\s*[<>=!]+\s*(\d+)', all_nrql, re.IGNORECASE)
        if status_match:
            status_threshold = int(status_match.group(1))
            slo_info['status_threshold'] = status_threshold
            if status_threshold >= 400:
                return 'error_rate'
            else:
                return 'availability'
        
        if 'error' in all_nrql or 'http.status' in all_nrql:
            return 'error_rate'
        elif 'count' in all_nrql:
            return 'availability'
        else:
            return 'custom'
    
    def _extract_service_name(self, slo_info: Dict) -> str:
        """Extract service name from SLO NRQL or name."""
        all_nrql = f"{slo_info.get('good_events_nrql', '')} {slo_info.get('valid_events_nrql', '')}"
        
        # Look for entity.name or appName in NRQL
        patterns = [
            r"entity\.name\s*=\s*['\"]([^'\"]+)['\"]",
            r"appName\s*=\s*['\"]([^'\"]+)['\"]",
            r"service\.name\s*=\s*['\"]([^'\"]+)['\"]",
        ]
        
        for pattern in patterns:
            match = re.search(pattern, all_nrql, re.IGNORECASE)
            if match:
                return match.group(1)
        
        # Fall back to extracting from SLO name
        slo_name = slo_info.get('name', '')
        if ' - ' in slo_name:
            return slo_name.split(' - ')[0].strip()
        
        return ''
    
    def _check_existing_slo_in_dt(self, slo_name: str) -> Optional[str]:
        """
        Check if an SLO with this name already exists in Dynatrace.
        
        Queries GET /platform/slo/v1/slos and searches by name.
        Returns the SLO objectId if found, None otherwise.
        """
        if not self._dt_url or not self._dt_token:
            return None
        
        try:
            base_url = self._dt_url.replace('.live.', '.apps.')
            url = f"{base_url}/platform/slo/v1/slos?pageSize=500"
            
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._dt_token}"
            }
            
            req = urllib.request.Request(url, headers=headers, method='GET')
            with urllib.request.urlopen(req, timeout=30, context=SSL_CONTEXT) as response:
                data = json.loads(response.read().decode('utf-8'))
                
                slos = data.get('slos', data.get('items', []))
                if isinstance(data, list):
                    slos = data
                
                for slo in slos:
                    existing_name = slo.get('name', '')
                    if existing_name.strip().lower() == slo_name.strip().lower():
                        slo_object_id = slo.get('objectId', slo.get('id', ''))
                        print(f"  âœ“ SLO already exists in DT: '{existing_name}' â†’ {slo_object_id[:50]}...")
                        return slo_object_id
                
                # Check for pagination
                next_page = data.get('nextPageKey')
                while next_page:
                    page_url = f"{base_url}/platform/slo/v1/slos?nextPageKey={next_page}"
                    req = urllib.request.Request(page_url, headers=headers, method='GET')
                    with urllib.request.urlopen(req, timeout=30, context=SSL_CONTEXT) as response:
                        data = json.loads(response.read().decode('utf-8'))
                        slos = data.get('slos', data.get('items', []))
                        if isinstance(data, list):
                            slos = data
                        for slo in slos:
                            existing_name = slo.get('name', '')
                            if existing_name.strip().lower() == slo_name.strip().lower():
                                slo_object_id = slo.get('objectId', slo.get('id', ''))
                                print(f"  âœ“ SLO already exists in DT: '{existing_name}' â†’ {slo_object_id[:50]}...")
                                return slo_object_id
                        next_page = data.get('nextPageKey')
                        
        except urllib.error.HTTPError as e:
            error_body = e.read().decode('utf-8') if hasattr(e, 'read') else ''
            print(f"  DEBUG: SLO existence check HTTP error {e.code}: {error_body[:200]}")
        except Exception as e:
            print(f"  DEBUG: SLO existence check error: {e}")
        
        return None
    
    def _create_slo_in_dt(self, slo_info: Dict) -> Tuple[bool, str, str]:
        """
        Create an SLO in Dynatrace using the NEW Platform SLO API (Grail-based).
        Skips creation if SLO with same name already exists, but still returns
        the existing SLO ID so it can be applied to dashboard tiles.
        
        API: /platform/slo/v1/slos on .apps.dynatrace.com
        Auth: OAuth Bearer token with scopes slo:slos:read, slo:slos:write
        
        Returns: (success, slo_id, message)
        """
        if not self._dt_url or not self._dt_token:
            return False, '', 'DT credentials not configured'
        
        guid = slo_info.get('guid', '')
        slo_name = slo_info.get('name', 'Migrated SLO')
        
        # Check if already attempted in this run (success or failure)
        if guid in self._created_slos:
            cached = self._created_slos[guid]
            if cached.startswith('FAILED:'):
                return False, '', f'Already attempted (cached failure): {cached}'
            return True, cached, 'Already created (cached)'
        
        # CHECK IF SLO ALREADY EXISTS IN DT before creating
        existing_id = self._check_existing_slo_in_dt(slo_name)
        if existing_id:
            # Cache it so we don't check again for this GUID
            self._created_slos[guid] = existing_id
            self._guid_cache[guid] = slo_name
            self._guid_types[guid] = 'SERVICE_LEVEL'
            print(f"  â­ Skipping SLO creation (already exists): {slo_name} â†’ {existing_id[:50]}...")
            return True, existing_id, f"SLO already exists in DT: {existing_id}"
            return True, cached, 'Already created'
        
        # Get target from NR tags or default
        target = slo_info.get('target', 99.9)
        warning = min(target + (100 - target) / 2, 99.99)
        
        # Determine timeframe from NR SLO period
        days = slo_info.get('time_window_days', 7)
        timeframe_from = f"now-{days}d"
        
        # Map SLO type and build DQL indicator
        slo_type = slo_info.get('slo_type', 'availability')
        service_name = slo_info.get('service_name', '')
        
        # Build DQL filter for service name
        # entityName must be resolved via fieldsAdd BEFORE it can be used in a filter
        entity_name_step = '\n| fieldsAdd entityName = entityName(dt.entity.service)'
        service_filter = ''
        if service_name:
            # Validate service name against DT entity registry
            validated_name, entity_warn = self._validate_entity_name(service_name, 'SERVICE')
            if entity_warn:
                print(f"  âš  {entity_warn}")
            if validated_name != service_name:
                print(f"  ðŸ”§ Service name corrected: '{service_name}' â†’ '{validated_name}'")
                service_name = validated_name
            
            # Escape quotes in service name
            escaped_name = service_name.replace('"', '\\"')
            service_filter = f'\n| filter contains(entityName, "{escaped_name}")'
        
        if slo_type == 'latency':
            # Latency SLO - measure response time against threshold
            # Official DT SLO template: per-bucket pass/fail using iCollectArray
            # dt.service.request.response_time is in MICROSECONDS (Âµs)
            # Source: https://docs.dynatrace.com/docs/deliver/service-level-objectives/service-level-objective-examples
            # Official example uses (1000 * 500) = 500000Âµs = 500ms threshold
            threshold_ms = slo_info.get('latency_threshold_ms', 4000)
            threshold_us = threshold_ms * 1000  # Convert ms â†’ microseconds
            
            print(f"  DEBUG: Latency SLO with threshold: {threshold_ms}ms ({threshold_us}Âµs)")
            
            # Uses official DT SLO template pattern from docs.dynatrace.com
            # entityName MUST be resolved before filter (fieldsAdd before filter)
            dql_indicator = f'''timeseries total=avg(dt.service.request.response_time), default:0, by: {{ dt.entity.service }}{entity_name_step}{service_filter}
| fieldsAdd high=iCollectArray(if(total[] > {threshold_us}, total[]))
| fieldsAdd low=iCollectArray(if(total[] <= {threshold_us}, total[]))
| fieldsAdd highRespTimes=iCollectArray(if(isNull(high[]), 0, else: 1))
| fieldsAdd lowRespTimes=iCollectArray(if(isNull(low[]), 0, else: 1))
| fieldsAdd sli=100*(lowRespTimes[]/(lowRespTimes[]+highRespTimes[]))
| fieldsRemove total, high, low, highRespTimes, lowRespTimes'''
        else:
            # Availability/Success SLO - measure success rate
            # Official DT SLO template: (total-failures)/total * 100
            # Uses dt.service.request.count and dt.service.request.failure_count (verified Grail metrics)
            # Source: https://docs.dynatrace.com/docs/deliver/service-level-objectives/service-level-objective-examples
            print(f"  DEBUG: Availability SLO (success rate)")
            
            dql_indicator = f'''timeseries {{
  total=sum(dt.service.request.count),
  failures=sum(dt.service.request.failure_count)
}}, by: {{ dt.entity.service }}{entity_name_step}{service_filter}
| fieldsAdd sli=(((total[]-failures[])/total[])*(100))
| fieldsRemove total, failures'''
        
        # Print NRQL queries if available
        if slo_info.get('good_events_from'):
            print(f"  DEBUG: NR Good Events: FROM {slo_info.get('good_events_from')} WHERE {slo_info.get('good_events_where', 'N/A')[:80]}...")
            print(f"  DEBUG: NR Valid Events: FROM {slo_info.get('valid_events_from')} WHERE {slo_info.get('valid_events_where', 'N/A')[:80]}...")
        
        # Build description with NRQL queries for reference
        description = slo_info.get('description', '')
        if not description:
            description = f"Migrated from New Relic: {slo_name}"
        
        # Add NRQL queries to description for reference
        good_from = slo_info.get('good_events_from', '')
        good_where = slo_info.get('good_events_where', '')
        valid_from = slo_info.get('valid_events_from', '')
        valid_where = slo_info.get('valid_events_where', '')
        
        if good_from or valid_from:
            description += "\n\n--- Original NR SLI NRQL ---"
            if good_from:
                description += f"\nGood Events: FROM {good_from} WHERE {good_where[:200] if good_where else 'N/A'}"
            if valid_from:
                description += f"\nValid Events: FROM {valid_from} WHERE {valid_where[:200] if valid_where else 'N/A'}"
        
        description = f"{description}\n\n[Migrated from NR GUID: {guid[:40]}...]"
        
        # Create payload for NEW Platform SLO API
        # Note: criteria is a direct ARRAY (not wrapped in criteriaDetails)
        payload = {
            "name": slo_name,
            "description": description[:1000],
            "criteria": [{
                "target": target,
                "warning": round(warning, 2),
                "timeframeFrom": timeframe_from,
                "timeframeTo": "now"
            }],
            "customSli": {
                "indicator": dql_indicator
            },
            "tags": ["MigratedFromNR:true"]
        }
        
        try:
            # Platform SLO API is on .apps. domain (NOT .live.)
            base_url = self._dt_url.replace('.live.', '.apps.')
            if not '.apps.' in base_url:
                # If URL doesn't have either, assume it's the base environment ID
                base_url = self._dt_url
            
            url = f"{base_url}/platform/slo/v1/slos"
            json_payload = json.dumps(payload)
            data = json_payload.encode('utf-8')
            
            # Platform API requires Bearer OAuth token
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._dt_token}"
            }
            
            print(f"  DEBUG: Creating Platform SLO at {url}")
            print(f"  DEBUG: Payload: {slo_name}, target={target}%, timeframe={timeframe_from}")
            print(f"  DEBUG: Full DQL indicator:\n{dql_indicator}")
            print(f"  DEBUG: JSON payload: {json_payload[:800]}...")
            
            req = urllib.request.Request(url, data=data, headers=headers, method='POST')
            with urllib.request.urlopen(req, timeout=30, context=SSL_CONTEXT) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                # Platform SLO API returns 'id' as UUID
                # But dashboard tiles need 'objectId' (the encoded entity ID)
                slo_uuid = result.get('id', '')
                slo_object_id = result.get('objectId', '')
                
                print(f"  DEBUG: SLO creation response keys: {list(result.keys())}")
                print(f"  DEBUG: UUID (id): {slo_uuid}")
                print(f"  DEBUG: ObjectId: {slo_object_id[:50]}..." if slo_object_id else "  DEBUG: ObjectId: None")
                
                # Prefer objectId for dashboard tiles, fall back to UUID
                slo_id_for_tiles = slo_object_id if slo_object_id else slo_uuid
                
                # Cache the created SLO - store objectId for dashboard tiles
                self._created_slos[guid] = slo_id_for_tiles
                self._guid_cache[guid] = slo_name
                self._guid_types[guid] = 'SERVICE_LEVEL'
                
                print(f"  âœ“ Platform SLO created: {slo_uuid}")
                print(f"  âœ“ Entity ID for tiles: {slo_id_for_tiles[:50]}..." if len(slo_id_for_tiles) > 50 else f"  âœ“ Entity ID for tiles: {slo_id_for_tiles}")
                return True, slo_id_for_tiles, f"Created Platform SLO: {slo_uuid}"
                
        except urllib.error.HTTPError as e:
            error_body = e.read().decode('utf-8') if hasattr(e, 'read') else ''
            print(f"  DEBUG: Platform SLO creation HTTP error {e.code}: {error_body[:500]}")
            # Cache the failure so we don't retry for this GUID
            self._created_slos[guid] = f"FAILED:{e.code}"
            return False, '', f"HTTP {e.code}: {error_body[:200]}"
        except Exception as e:
            print(f"  DEBUG: Platform SLO creation exception: {e}")
            # Cache the failure
            self._created_slos[guid] = f"FAILED:{str(e)[:50]}"
            return False, '', str(e)
    
    def _handle_slo_guid(self, guid: str) -> Tuple[str, str]:
        """
        Handle a SERVICE_LEVEL GUID - fetch details, optionally create in DT.
        
        Returns: (replacement_filter, warning_message)
        """
        print(f"  DEBUG: _handle_slo_guid called for {guid[:30]}..., auto_create={self._auto_create_slos}")
        
        # Try to get SLO details from NR
        slo_info = self._fetch_slo_details_from_nr(guid)
        
        if slo_info:
            slo_name = slo_info.get('name', '')
            print(f"  DEBUG: Got SLO info: {slo_name}")
            
            # Auto-create in DT if configured
            if self._auto_create_slos:
                print(f"  DEBUG: Attempting to create SLO in DT...")
                success, slo_id, msg = self._create_slo_in_dt(slo_info)
                if success:
                    return (
                        f'slo.name == "{slo_name}"',
                        f"SLO auto-created in DT (ID: {slo_id}): {slo_name}"
                    )
                else:
                    print(f"  DEBUG: SLO creation failed: {msg}")
                    return (
                        f'slo.name == "{slo_name}"',
                        f"SLO creation failed ({msg}), using name: {slo_name}"
                    )
            else:
                # Just resolve the name
                return (
                    f'slo.name == "{slo_name}"',
                    f"SLO resolved: {slo_name} (not auto-created, use --auto-create-slos)"
                )
        
        print(f"  DEBUG: Could not fetch SLO details from NR")
        # Couldn't get details - return placeholder
        return (
            '/* REPLACE: This is an SLO. Use: fetch slo | filter slo.name == "your-slo-name" */',
            "SLO GUID detected but could not fetch details from NR API"
        )
    
    def load_guid_mappings(self, mappings: Dict[str, str], types: Dict[str, str] = None):
        """
        Load pre-resolved GUID to entity name mappings.
        
        Args:
            mappings: Dict mapping GUID -> entity name (or other identifier)
            types: Optional dict mapping GUID -> entity type (SERVICE_LEVEL, APM_APPLICATION, etc)
        
        Example:
            converter.load_guid_mappings(
                {'Mzk5MDk2fEVYVHx...': 'prod-order-api-availability'},
                {'Mzk5MDk2fEVYVHx...': 'SERVICE_LEVEL'}
            )
        """
        self._guid_cache.update(mappings)
        if types:
            self._guid_types.update(types)
    
    def resolve_guids_from_api(self, api_key: str, guids: List[str] = None):
        """
        Resolve GUIDs by querying New Relic NerdGraph API.
        
        If guids is None, will use any GUIDs seen during conversion.
        Results are cached for use in subsequent conversions.
        """
        import urllib.request
        import urllib.error
        
        if not guids:
            return
        
        query = '''
        query ($guids: [EntityGuid]!) {
          actor {
            entities(guids: $guids) {
              guid
              name
              entityType
              domain
            }
          }
        }
        '''
        
        # Process in batches of 25
        for i in range(0, len(guids), 25):
            batch = guids[i:i + 25]
            payload = json.dumps({"query": query, "variables": {"guids": batch}}).encode('utf-8')
            headers = {"Content-Type": "application/json", "API-Key": api_key}
            
            try:
                req = urllib.request.Request("https://api.newrelic.com/graphql", data=payload, headers=headers)
                with urllib.request.urlopen(req, timeout=30, context=SSL_CONTEXT) as response:
                    data = json.loads(response.read().decode('utf-8'))
                    if 'data' in data and 'actor' in data['data']:
                        for entity in data['data']['actor'].get('entities', []):
                            if entity and entity.get('name'):
                                self._guid_cache[entity['guid']] = entity['name']
            except Exception as e:
                print(f"Warning: Could not resolve GUIDs from API: {e}")
    
    def convert(self, nrql: str, title: str = "") -> ConversionResult:
        """
        Convert NRQL to DQL with automatic validation and fixing.
        Returns ConversionResult with all details.
        """
        # Initialize warnings list for this conversion
        self._current_warnings = []
        # Store original NRQL for SLI detection (before preprocessing)
        self._current_original_nrql = nrql
        
        result = ConversionResult(
            original_nrql=nrql,
            converted_dql="",
            fixes_applied=[],
            warnings=[],
            confidence="HIGH",
            success=True
        )
        
        if not nrql or not nrql.strip():
            result.converted_dql = "// Empty query"
            result.confidence = "LOW"
            return result
        
        # Keep original for comment
        original_nrql = nrql
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # PRIMARY (AND ONLY) PATH: AST Compiler
        # ALL queries go through the AST compiler which has been given
        # METRIC_MAP, METRIC_TRANSFORMS, ATTR_MAP, and the live metric
        # resolver. There is no regex fallback â€” a single code path
        # means a single set of bugs to fix.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        
        nrql_clean = ' '.join(nrql.split())
        nrql_upper = nrql_clean.upper()
        
        if self._ast_compiler:
            ast_result = self._ast_compiler.compile(nrql_clean, title)
            
            if ast_result.success:
                result.converted_dql = ast_result.dql
                result.confidence = ast_result.confidence
                result.warnings = list(ast_result.warnings)
                result.fixes_applied = list(ast_result.fixes)
                
                # POST-AST: Apply features the emitter doesn't handle inline
                dql = ast_result.dql
                
                # COMPARE WITH â†’ shift: param or extended timeframe
                if 'COMPARE WITH' in nrql_upper:
                    compare_result = self._compare_converter.convert(nrql_clean)
                    if compare_result:
                        _, shift_param = compare_result
                        if 'timeseries' in dql.lower() and 'maketimeseries' not in dql.lower():
                            dql = re.sub(
                                r'(timeseries\s+[^\n]+)',
                                lambda m: f"{m.group(1)}, {shift_param}",
                                dql, count=1
                            )
                            result.warnings.append(f"COMPARE WITH â†’ {shift_param}")
                        else:
                            # makeTimeseries can't use shift: â€” expand fetch timeframe 
                            # to cover the comparison period (e.g. 7d for "COMPARE WITH 1 week ago")
                            # Extract the shift amount from shift_param like "shift:-7d" â†’ "7d"
                            shift_match = re.search(r'shift:-?(\d+\w+)', shift_param)
                            if shift_match:
                                period = shift_match.group(1)
                            else:
                                period = '7d'
                            # Add from: to the fetch line
                            dql = re.sub(
                                r'(fetch\s+\w+)',
                                lambda m: f"{m.group(1)}, from:now()-{period}",
                                dql, count=1
                            )
                            result.warnings.append(f"COMPARE WITH â†’ tile timeframe extended to {period} (makeTimeseries does not support shift:)")
                
                # EXTRAPOLATE â†’ extrapolate:true on countDistinct
                if 'EXTRAPOLATE' in nrql_upper:
                    _, dql, extrap_note = self._extrapolate_handler.handle(nrql, dql)
                    if extrap_note:
                        result.warnings.append(extrap_note)
                
                result.converted_dql = dql
                
                # Collect any warnings from sub-methods
                if hasattr(self, '_current_warnings') and self._current_warnings:
                    result.warnings.extend(self._current_warnings)
                
                # PHASE 0: GUID Resolution
                # NR entity GUIDs (base64 strings) must be resolved to 
                # entity names BEFORE they reach DT. This uses the _guid_cache,
                # NerdGraph API resolution, and base64 decoding.
                if result.converted_dql:
                    result.converted_dql = self._resolve_guids_in_dql(result.converted_dql, result)
                
                # PHASE 1: Minimal post-AST processing
                # The AST emitter produces correct DQL. We only need a few
                # legitimate post-processing steps that aren't the AST's job:
                #   - Dashboard tile timeframe cleanup (from:now() removal)
                #   - builtin: prefix stripping for non-metric queries  
                #   - Boolean operator case normalization (ANDâ†’and)
                # We do NOT run the full 24-check regex sanitizer here.
                # That sanitizer exists for the regex fallback path.
                if result.converted_dql:
                    result.converted_dql, post_fixes = self._post_ast_cleanup(result.converted_dql)
                    if post_fixes:
                        result.fixes_applied.extend(post_fixes)
                
                # PHASE 2: Live DT Grail API validation (verify against real API)
                if self._registry and result.converted_dql:
                    result.converted_dql = self._validate_dql_live(result.converted_dql, result)
                
                return result
            
            # AST compilation failed â€” DO NOT silently fall through to regex.
            # Mark the query for manual review so we know exactly which queries
            # the AST can't handle, rather than producing silently broken DQL.
            _ast_error = ast_result.error or 'Unknown AST error'
            result.warnings.append(f"AST compiler failed: {_ast_error}")
            result.confidence = "LOW"
            
            # Log the failure for debugging â€” we need to fix the AST, not patch regex
            logger.warning(f"AST FAILURE â€” needs compiler fix: {_ast_error} | NRQL: {nrql[:300]}")
            print(f"  âš  AST FAILURE: {_ast_error}")
            print(f"    Full NRQL: {nrql}")
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # FALLBACK: Regex-based conversion (DEPRECATED â€” USE IS TRACKED)
        # Every query that reaches this path is a bug in the AST compiler.
        # We still convert them so dashboards aren't empty, but the output
        # is marked LOW confidence and logged for AST compiler fixes.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        result.confidence = "LOW"
        if "AST compiler failed" not in str(result.warnings):
            result.warnings.append("No AST compiler available â€” regex fallback used")
        
        # PRE-CHECK: Handle NR-specific complex functions
        # Instead of bailing out, we now convert them!
        converted_complex = []
        
        # Convert percentage(count(*), WHERE condition) â†’ 100.0 * countIf(condition) / count()
        if re.search(r'\bpercentage\s*\(', nrql_clean, re.IGNORECASE):
            nrql_clean = self._convert_percentage_function(nrql_clean)
            converted_complex.append('percentage() â†’ countIf()/count()*100')
        
        # Convert filter(func, WHERE condition) â†’ funcIf(field, condition)
        if re.search(r'\bfilter\s*\(', nrql_clean, re.IGNORECASE):
            nrql_clean = self._convert_filter_function(nrql_clean)
            converted_complex.append('filter() â†’ funcIf()')
        
        # Convert apdex(t:threshold) â†’ use builtin or calculate
        if re.search(r'\bapdex\s*\(', nrql_clean, re.IGNORECASE):
            nrql_clean = self._convert_apdex_function(nrql_clean)
            converted_complex.append('apdex() â†’ calculated formula')
        
        # Convert cdfPercentage(field, t1, t2, t3, t4) â†’ multiple countIf() buckets
        if re.search(r'\bcdfPercentage\s*\(', nrql_clean, re.IGNORECASE):
            nrql_clean = self._convert_cdf_percentage_function(nrql_clean)
            converted_complex.append('cdfPercentage() â†’ countIf() buckets')
        
        # SPECIAL CASE: histogram() queries
        # NR histogram(field, ceiling, numBars, width) â†’ DQL summarize count(), by:{bin(field, width)}
        # DT barChart visualization renders this as a visual histogram.
        histogram_match = re.search(r'\bhistogram\s*\(\s*([^,\)]+)(?:\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)(?:\s*,\s*(\d+(?:\.\d+)?))?)?\s*\)', nrql_clean, re.IGNORECASE)
        if histogram_match:
            hist_field = histogram_match.group(1).strip()
            # Convert duration.ms to duration
            if hist_field.lower() == 'duration.ms':
                hist_field = 'duration'
            
            # Calculate bin width from histogram args
            ceiling = histogram_match.group(2)
            num_bars = histogram_match.group(3)
            explicit_width = histogram_match.group(4)
            
            if explicit_width:
                bin_width = int(float(explicit_width))
            elif ceiling and num_bars:
                bin_width = int(float(ceiling) / float(num_bars))
            else:
                bin_width = 1000  # default 1s bins
            
            # Convert to DQL duration literal if this is a duration field
            if hist_field == 'duration':
                bin_expr = ms_to_dql_duration(bin_width)
            else:
                bin_expr = str(bin_width)
            
            # Extract WHERE clause for the histogram query
            where_match = re.search(r'\bWHERE\s+(.+?)(?:\s+(?:SINCE|UNTIL|TIMESERIES|FACET|LIMIT|ORDER|COMPARE)|\s*$)', nrql_clean, re.IGNORECASE)
            where_clause = where_match.group(1) if where_match else ''
            
            # Convert WHERE clause
            converted_where = self._convert_where(where_clause) if where_clause else ''
            
            # Convert duration comparisons in WHERE to DQL duration literals
            if hist_field == 'duration' and converted_where:
                def _dur_lit(m):
                    op, val = m.group(1), float(m.group(2))
                    return f"duration {op} {ms_to_dql_duration(val)}"
                converted_where = re.sub(
                    r'(?<![.\w])duration\s*(>=|<=|>|<|==|!=)\s*(\d+(?:\.\d+)?)',
                    _dur_lit, converted_where)
            
            # Get event type
            event_type = self._extract_from(nrql_clean)
            dt_source = self._map_event_type(event_type) if event_type else 'spans'
            
            # Build histogram query with count() + bin()
            dql_parts = [f"fetch {dt_source}"]
            if converted_where:
                dql_parts.append(f"| filter {converted_where}")
            dql_parts.append(f"| summarize count(), by: {{bin({hist_field}, {bin_expr})}}")
            
            dql = '\n'.join(dql_parts)
            result.converted_dql = f"{_nrql_comment(original_nrql)}\n{dql}"
            result.confidence = "HIGH"
            result.warnings.append("histogram() â†’ count() + bin() as categoricalBarChart visualization")
            return result
        
        if converted_complex:
            result.warnings.extend(converted_complex)
        
        try:
            # PREPROCESS: Convert NR-specific syntax before parsing
            nrql_clean = self._preprocess_nrql(nrql_clean)
            
            # Parse NRQL components
            event_type = self._extract_from(nrql_clean)
            select_clause = self._extract_select(nrql_clean)
            where_clause = self._extract_where(nrql_clean)
            facet_clause = self._extract_facet(nrql_clean)
            limit_value = self._extract_limit(nrql_clean)
            has_timeseries = bool(re.search(r'\bTIMESERIES\b', nrql_clean, re.IGNORECASE))
            has_compare = bool(re.search(r'\bCOMPARE\s+WITH\b', nrql_clean, re.IGNORECASE))
            
            # === ADVANCED PRE-PROCESSING ===
            # Reset per-query state
            self._current_rate_params = []
            self._current_shift_param = None
            self._current_funnel_result = None
            
            # 1. Handle COMPARE WITH â†’ extract shift: param and clean NRQL
            if has_compare:
                compare_result = self._compare_converter.convert(nrql_clean)
                if compare_result:
                    nrql_clean, self._current_shift_param = compare_result
                    # Re-extract clauses from cleaned NRQL
                    select_clause = self._extract_select(nrql_clean)
                    where_clause = self._extract_where(nrql_clean)
                    facet_clause = self._extract_facet(nrql_clean)
                    has_timeseries = True  # COMPARE WITH implies timeseries
            
            # 2. Handle EXTRAPOLATE â€” strip from NRQL, will apply to DQL post-build
            has_extrapolate = 'EXTRAPOLATE' in nrql_clean.upper()
            if has_extrapolate:
                nrql_clean = re.sub(r'\s+EXTRAPOLATE\s*', ' ', nrql_clean, flags=re.IGNORECASE).strip()
                select_clause = self._extract_select(nrql_clean)
            
            # 3. Handle funnel() â†’ USQL (completely different output)
            if 'funnel(' in nrql_clean.lower():
                funnel_result = self._funnel_converter.convert(nrql_clean)
                if funnel_result:
                    result.converted_dql = f"{_nrql_comment(original_nrql)}\n// {funnel_result['note']}\n{funnel_result['usql']}"
                    result.confidence = "MEDIUM"
                    result.warnings.append(f"funnel() â†’ USQL: {funnel_result['note']}")
                    return result
            
            # 4. Handle WITH...AS (CTEs) â†’ inline or manual review
            if re.match(r'\s*WITH\s+', nrql_clean, re.IGNORECASE):
                cte_result = self._with_as_converter.convert(nrql_clean)
                if cte_result:
                    result.converted_dql = f"{_nrql_comment(original_nrql)}\n{cte_result['dql']}"
                    result.confidence = "MEDIUM" if cte_result['strategy'] == 'inline' else "LOW"
                    if cte_result.get('note'):
                        result.warnings.append(cte_result['note'])
                    result.warnings.append(f"WITH...AS converted via {cte_result['strategy']} strategy")
                    return result
            
            if not event_type:
                result.converted_dql = f"// Could not parse event type from: {original_nrql}"
                result.confidence = "LOW"
                result.warnings.append("Could not determine event type")
                return result
            
            # Map event type to DT source
            dt_source = self._map_event_type(event_type)
            
            # Build DQL based on query type
            if dt_source == "METRIC":
                dql, confidence = self._build_metric_query(
                    select_clause, where_clause, facet_clause, has_timeseries, title
                )
            elif dt_source.startswith("K8S_"):
                # K8s-specific metrics
                dql, confidence = self._build_k8s_metric_query(
                    dt_source, select_clause, where_clause, facet_clause, has_timeseries, title
                )
            elif dt_source == "events":
                # Infrastructure events
                dql, confidence = self._build_events_query(
                    select_clause, where_clause, facet_clause, limit_value, title
                )
            else:
                dql, confidence = self._build_fetch_query(
                    dt_source, select_clause, where_clause, facet_clause, 
                    limit_value, has_timeseries, title, nrql_clean
                )
            
            result.confidence = confidence
            
            # Validate and fix DQL syntax issues
            dql, fixes = self.validator.validate_and_fix(dql, title)
            result.fixes_applied = fixes
            
            # Check original NRQL for NR-specific features that need manual conversion
            nrql_lower = nrql.lower()
            warnings_to_add = []
            
            if 'newrelic.sli.' in nrql_lower or 'sli.good' in nrql_lower or 'sli.valid' in nrql_lower:
                warnings_to_add.append("// NOTE: NR SLI metrics converted to DT SLO query - verify slo.name filter")
                result.warnings.append("NR SLI metrics converted to DT SLO query")
            
            if 'clamp_max(' in nrql_lower or 'clamp_min(' in nrql_lower:
                warnings_to_add.append("// NOTE: clamp_max/clamp_min converted to if() - verify logic")
                result.warnings.append("clamp functions converted to if() expressions")
            
            if 'compare with' in nrql_lower:
                if self._current_shift_param:
                    # shift: is ONLY valid on the metrics 'timeseries' command, NOT makeTimeseries
                    if 'timeseries' in dql.lower() and 'maketimeseries' not in dql.lower():
                        dql = re.sub(
                            r'(timeseries\s+[^\n]+)',
                            lambda m: f"{m.group(1)}, {self._current_shift_param}",
                            dql, count=1
                        )
                        warnings_to_add.append(f"// NOTE: COMPARE WITH â†’ {self._current_shift_param}")
                        result.warnings.append(f"COMPARE WITH â†’ {self._current_shift_param} on timeseries")
                    else:
                        # makeTimeseries doesn't support shift: â€” extend fetch timeframe
                        shift_match = re.search(r'shift:-?(\d+\w+)', self._current_shift_param)
                        period = shift_match.group(1) if shift_match else '7d'
                        dql = re.sub(
                            r'(fetch\s+\w+)',
                            lambda m: f"{m.group(1)}, from:now()-{period}",
                            dql, count=1
                        )
                        warnings_to_add.append(f"// NOTE: COMPARE WITH â†’ tile timeframe extended to {period}")
                        result.warnings.append(f"COMPARE WITH â†’ tile timeframe extended to {period}")
                else:
                    # No shift param extracted, default to 7d
                    dql = re.sub(
                        r'(fetch\s+\w+)',
                        lambda m: f"{m.group(1)}, from:now()-7d",
                        dql, count=1
                    )
                    warnings_to_add.append("// NOTE: COMPARE WITH â†’ tile timeframe extended to 7d")
                    result.warnings.append("COMPARE WITH â†’ tile timeframe extended to 7d")
            
            # Apply rate: params if any were collected
            if hasattr(self, '_current_rate_params') and self._current_rate_params:
                for rate_param in self._current_rate_params:
                    # rate: is ONLY valid on the metrics 'timeseries' command, NOT makeTimeseries
                    if 'timeseries' in dql.lower() and 'maketimeseries' not in dql.lower():
                        dql = re.sub(
                            r'(timeseries\s+[^\n]+)',
                            lambda m, rp=rate_param: f"{m.group(1)}, {rp}",
                            dql, count=1
                        )
                    else:
                        warnings_to_add.append(f"// NOTE: rate: not supported on makeTimeseries. Original rate conversion: {rate_param}")
            
            # Apply EXTRAPOLATE post-processing
            if has_extrapolate:
                _, dql, extrap_note = self._extrapolate_handler.handle(nrql, dql)
                if extrap_note:
                    warnings_to_add.append(f"// NOTE: {extrap_note}")
                    result.warnings.append(extrap_note)
            
            # Add original NRQL as comment (after validation so it's not modified)
            if warnings_to_add:
                dql = '\n'.join(warnings_to_add) + f"\n{_nrql_comment(original_nrql)}\n{dql}"
            else:
                dql = f"{_nrql_comment(original_nrql)}\n{dql}"
            
            result.converted_dql = dql
            
            # VALIDATE the converted DQL â€” Phase 1: local regex-based checks
            validator = DQLSyntaxValidator()
            validation = validator.validate(dql)
            
            if not validation.valid:
                result.success = False
                result.confidence = "LOW"
                for err in validation.errors:
                    result.warnings.append(f"DQL Syntax Error: {err.message}")
            
        except Exception as e:
            result.converted_dql = f"// Conversion error: {str(e)}\n// Original: {original_nrql}"
            result.confidence = "LOW"
            result.warnings.append(f"Conversion error: {str(e)}")
            result.success = False
        
        # Collect any warnings from sub-methods
        if hasattr(self, '_current_warnings') and self._current_warnings:
            result.warnings.extend(self._current_warnings)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # PHASE 1: DQL Output Sanitizer (fix known bad patterns)
        # Runs on EVERY output from EVERY path (AST, regex, fallback)
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        if result.converted_dql:
            result.converted_dql, sanitize_fixes = self._sanitize_dql_output(result.converted_dql)
            if sanitize_fixes:
                result.fixes_applied.extend(sanitize_fixes)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # PHASE 2: Live DT Grail API validation (verify final clean DQL)
        # Last step â€” validates the sanitized output against the real API
        # Runs on ALL queries with DQL output, not just success=True,
        # because the sanitizer may have fixed a failed query into valid DQL
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        if self._registry and result.converted_dql:
            # Skip queries that are just error comments
            dql_clean = '\n'.join(
                l for l in result.converted_dql.split('\n') 
                if l.strip() and not l.strip().startswith('//')
            ).strip()
            if dql_clean:
                result.converted_dql = self._validate_dql_live(result.converted_dql, result)
        
        return result
    
    def _resolve_guids_in_dql(self, dql: str, result: 'ConversionResult') -> str:
        """
        Resolve NR entity GUIDs in DQL output to DT entity names.
        
        NR GUIDs are base64 strings like 'MXxBUE18QVBNfEFQUExJQ0FUSU9OfDUxOTY2NTc'.
        These have NO meaning in DT. We resolve them to entity names using:
          1. _guid_cache (pre-loaded or previously resolved)
          2. Base64 decoding to extract entity type
          3. NerdGraph API lookup (if NR API key configured)
        """
        import base64 as b64
        
        # Pattern: base64 GUID values in filter/where (20+ chars of A-Za-z0-9+/=)
        # They appear as:  dt.entity.service == "MXxBUE18..." or entity.guid == "MXxBUE18..."
        # or inside in() sets: in(dt.entity.service, {"MXxBUE18...", "MXxBUE18..."})
        guid_pattern = r'"([A-Za-z0-9+/]{20,}={0,2})"'
        guid_matches = re.findall(guid_pattern, dql)
        
        if not guid_matches:
            return dql
        
        for guid in guid_matches:
            # Skip if it looks like a normal string (has spaces, lowercase, etc)
            if ' ' in guid or guid.islower():
                continue
            
            # Try to decode as NR GUID (base64 encoded account|type|subtype|id)
            resolved_name = None
            entity_type = ''
            
            # 1. Check guid_cache first
            if guid in self._guid_cache:
                resolved_name = self._guid_cache[guid]
                entity_type = self._guid_types.get(guid, '')
            else:
                # 2. Try base64 decode to determine entity type
                try:
                    padded = guid + '=' * (4 - len(guid) % 4) if len(guid) % 4 else guid
                    decoded = b64.b64decode(padded).decode('utf-8')
                    parts = decoded.split('|')
                    if len(parts) >= 3:
                        # Valid NR GUID: account_id|type|subtype|id
                        entity_type = parts[1] if len(parts) > 1 else ''  # APM, BROWSER, VIZ, etc
                        entity_subtype = parts[2] if len(parts) > 2 else ''  # APPLICATION, SERVICE_LEVEL, etc
                        entity_id = parts[3] if len(parts) > 3 else ''
                        
                        if entity_subtype == 'SERVICE_LEVEL':
                            self._detected_slos.add(guid)
                            # Try SLO resolution
                            try:
                                slo_replacement, slo_warning = self._handle_slo_guid(guid)
                                if slo_replacement and '__GUID_PLACEHOLDER__' not in slo_replacement:
                                    resolved_name = None  # Will use slo_replacement directly
                                    dql = dql.replace(f'"{guid}"', f'"{slo_replacement}"' if '==' not in slo_replacement else slo_replacement)
                                    result.warnings.append(slo_warning)
                                    continue
                            except:
                                pass
                        
                        # For APM/APPLICATION entities, try NR API
                        if not resolved_name and hasattr(self, '_nr_api_key') and self._nr_api_key:
                            try:
                                self.resolve_guids_from_api(self._nr_api_key, [guid])
                                if guid in self._guid_cache:
                                    resolved_name = self._guid_cache[guid]
                            except:
                                pass
                    else:
                        continue  # Not an NR GUID format
                except:
                    continue  # Not valid base64 or not an NR GUID
            
            # Apply resolution
            if resolved_name:
                # Determine the right DT field based on entity type
                entity_type_lower = entity_type.lower() if entity_type else ''
                entity_subtype = self._guid_types.get(guid, '').upper()
                
                if entity_subtype in ('SERVICE_LEVEL',):
                    new_filter = f'slo.name == "{resolved_name}"'
                elif entity_subtype in ('APM_APPLICATION', 'APPLICATION', 'SERVICE'):
                    new_filter = f'service.name == "{resolved_name}"'
                else:
                    new_filter = f'dt.entity.name == "{resolved_name}"'
                
                # Replace the field == "GUID" pattern  
                # Handle: dt.entity.service == "GUID" â†’ service.name == "name"
                dql = re.sub(
                    rf'(dt\.entity\.service|dt\.entity\.name|entity\.guid|entityGuid)\s*==\s*"{re.escape(guid)}"',
                    new_filter,
                    dql
                )
                # Handle: in(dt.entity.service, {"GUID"...}) - replace just the value
                dql = dql.replace(f'"{guid}"', f'"{resolved_name}"')
                
                result.warnings.append(f"NR GUID resolved â†’ {new_filter}")
                result.fixes_applied.append(f"GUID {guid[:20]}... â†’ {resolved_name}")
            else:
                # Couldn't resolve - at minimum, add a clear warning
                # and replace with a comment so DQL doesn't error on the GUID
                result.warnings.append(
                    f"âš  NR GUID detected ({entity_type or 'unknown type'}): {guid[:30]}... "
                    f"Replace with dt.entity.name or service.name filter"
                )
        
        return dql
    
    def _post_ast_cleanup(self, dql: str) -> Tuple[str, List[str]]:
        """
        Minimal post-AST cleanup. Only handles things that are NOT the AST's job:
        
        1. Dashboard tile timeframe (from:now() added by COMPARE WITH handler)
        2. builtin: prefix in non-metric queries (metricâ†’record field translation)
        3. Boolean operator case (safety net â€” AST should handle, but costs nothing)
        
        This method intentionally does NOT:
        - Fix AS keywords (AST never produces them)
        - Fix curly braces (AST handles this in _format_agg_list)
        - Fix double-equals (AST alias handling prevents this)
        - Fix any NRQL leakage (AST never leaks NRQL syntax)
        
        If you're tempted to add a check here, FIX THE AST EMITTER INSTEAD.
        """
        fixes = []
        
        # Skip comment-only queries
        stripped = dql.strip()
        if not stripped or stripped.startswith('// Empty') or stripped.startswith('// ERROR'):
            return dql, fixes
        
        # 1. Dashboard tile timeframe: strip hardcoded from:now()-Xd
        #    Dashboard tiles get their timeframe from the time selector.
        #    The COMPARE WITH handler adds from:now() which overrides the picker.
        if re.search(r'fetch\s+\w+\s*,\s*from:now\(\)', dql):
            dql = re.sub(r'(fetch\s+\w+)\s*,\s*from:now\(\)-\w+', r'\1', dql)
            fixes.append("Removed hardcoded from:now()-Xd â€” dashboard tile uses time selector")
        
        # 2. builtin: prefix in non-metric record queries
        #    builtin:host.cpu.usage is metric-API syntax. In fetch/filter context,
        #    the field name without builtin: is needed.
        if 'builtin:' in dql and 'fetch ' in dql:
            lines = dql.split('\n')
            new_lines = []
            for line in lines:
                s = line.strip()
                if s.startswith('//'):
                    new_lines.append(line)
                    continue
                cmd = s.lstrip('| ')
                if cmd.startswith(('filter ', 'fields ', 'fieldsAdd ', 'summarize ')):
                    if 'builtin:' in line:
                        line = line.replace('builtin:', '')
                        fixes.append("Stripped builtin: prefix from record query")
                new_lines.append(line)
            dql = '\n'.join(new_lines)
        
        # 3. Boolean operators: ANDâ†’and, ORâ†’or, NOTâ†’not
        #    AST should handle this, but it's a one-liner safety net.
        if re.search(r'\bAND\b', dql):
            dql = re.sub(r'\bAND\b', 'and', dql)
        if re.search(r'\bOR\b', dql):
            dql = re.sub(r'\bOR\b', 'or', dql)
        if re.search(r'\bNOT\b(?!\s*[Nn]ull)', dql):
            dql = re.sub(r'\bNOT\b(?!\s*[Nn]ull)', 'not', dql)
        
        return dql, fixes
    
    def _sanitize_dql_output(self, dql: str) -> Tuple[str, List[str]]:
        """
        FINAL GATE: Comprehensive DQL output sanitizer.
        
        Runs on EVERY DQL output from EVERY conversion path (AST, regex, fallback).
        Catches known-invalid patterns and either fixes them or marks the query 
        as needing manual review.
        
        Returns (sanitized_dql, list_of_fixes_applied).
        """
        fixes = []
        
        # Skip comment-only queries
        stripped = dql.strip()
        if not stripped or stripped.startswith('// Empty') or stripped.startswith('// ERROR'):
            return dql, fixes
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 1: Embedded NRQL subqueries â€” DQL has NO subquery support
        # Pattern: "in (SELECT ..." or "IN (FROM ..." in NON-COMMENT lines
        # Note: DQL lookup [...] commands ARE valid â€” only match raw NRQL subquery syntax
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # Only check non-comment, non-lookup lines
        non_comment_dql = '\n'.join(
            line for line in dql.split('\n') 
            if line.strip() and not line.strip().startswith('//')
        )
        # Don't match inside lookup [...] commands (those are valid DQL)
        # Only match bare "in (SELECT" or "in (FROM" that aren't inside lookup brackets
        has_raw_subquery = bool(re.search(r'\b(?:in|IN)\s*\(\s*(?:SELECT|FROM)\b', non_comment_dql))
        has_lookup = 'lookup [' in non_comment_dql or 'lookup[' in non_comment_dql
        
        if has_raw_subquery and not has_lookup:
            # Extract the subquery for the comment
            sub_match = re.search(r'\b(?:in|IN)\s*\(\s*(SELECT|FROM)\s+[^\n|]{0,80}', non_comment_dql)
            sub_text = sub_match.group(0)[:80] if sub_match else 'subquery'
            
            # Remove "and fieldName in (SELECT ... to end of line/pipe" from non-comment lines only
            lines = dql.split('\n')
            cleaned_lines = []
            for line in lines:
                if line.strip().startswith('//'):
                    cleaned_lines.append(line)
                else:
                    cleaned_line = re.sub(
                        r'\s+and\s+\w+(?:\.\w+)*\s+in\s*\(\s*(?:SELECT|FROM)\s+[^\n|]*',
                        '', line, flags=re.IGNORECASE)
                    cleaned_line = re.sub(
                        r'\w+(?:\.\w+)*\s+in\s*\(\s*(?:SELECT|FROM)\s+[^\n|]*(?:\s*and\s+)?',
                        '', cleaned_line, flags=re.IGNORECASE)
                    cleaned_lines.append(cleaned_line)
            
            fixes.append(f"Removed unsupported NRQL subquery ({sub_text}...) â€” DQL has no subquery support")
            dql = '\n'.join(cleaned_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 2: Raw NRQL SELECT/FROM fragments leaked through
        # If we see "SELECT" or "FROM Span" mid-query (not in a comment),
        # the fallback produced garbage
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        lines = dql.split('\n')
        clean_lines = []
        for line in lines:
            stripped_line = line.strip()
            if stripped_line.startswith('//'):
                clean_lines.append(line)
                continue
            # Check for raw NRQL fragments
            if re.search(r'\bSELECT\b(?!\s*id)', stripped_line) and 'Original NRQL' not in line:
                fixes.append(f"Removed raw NRQL fragment: {stripped_line[:60]}...")
                continue  # Drop this line entirely
            # Check for garbage "| fields" lines that contain NRQL WHERE clauses
            if re.match(r'\|\s*fields\s+.*\bwhere\b', stripped_line, re.IGNORECASE):
                fixes.append(f"Removed garbage fields line: {stripped_line[:60]}...")
                continue
            # Check for raw "FROM Span" fragments (not in fetch command)
            if re.search(r'\bFROM\s+(?:Span|Transaction|Metric|Log|Event)\b', stripped_line) and not stripped_line.startswith('fetch'):
                fixes.append(f"Removed raw NRQL FROM fragment: {stripped_line[:60]}...")
                continue
            clean_lines.append(line)
        dql = '\n'.join(clean_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 3: Single = comparison operator (must be == in DQL)
        # Only in | filter lines, not in | fieldsAdd (where = is assignment)
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        lines = dql.split('\n')
        fixed_lines = []
        for line in lines:
            stripped_line = line.strip()
            if stripped_line.startswith('//'):
                fixed_lines.append(line)
                continue
            
            # Only fix = in filter/where contexts, NOT in fieldsAdd/summarize (where = is assignment)
            if '| filter' in line or stripped_line.startswith('| filter'):
                # Replace single = with == but not !=, >=, <=, ==
                original = line
                line = re.sub(r'(?<![!<>=])=(?!=)', '==', line)
                # Clean up any triple === that got created
                line = line.replace('===', '==')
                if line != original:
                    fixes.append("Fixed single = to == in filter clause")
            
            fixed_lines.append(line)
        dql = '\n'.join(fixed_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 4: Invalid field names
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        invalid_fields = {
            'Duration.Seconds': 'duration',
            'Duration.seconds': 'duration',
            'duration.Seconds': 'duration',
            'duration.seconds': 'duration', 
            'duration.ms': 'duration',
            'Duration.Ms': 'duration',
            'Duration.ms': 'duration',
            'Duration.Minutes': 'duration',
            'durationMs': 'duration',
            'name': 'span.name',  # In span context
            'parentId': 'trace.parent_span_id',
            'parent.id': 'trace.parent_span_id',
            'traceId': 'trace_id',
            'entity.name': 'dt.entity.name',
            'appName': 'service.name',
            'entityGuid': '/* NR entity.guid - replace with dt.entity filter */',
            'entity.guid': '/* NR entity.guid - replace with dt.entity filter */',
            'transactionType': 'span.kind',
            'errorType': 'error.type',
            'errorMessage': 'error.message',
            'response.status': 'http.response.status_code',
            'databaseCallCount': 'db.call_count',
            'externalCallCount': 'http.call_count',
            'deploymentName': 'k8s.deployment.name',
        }
        
        for bad_field, good_field in invalid_fields.items():
            # Only replace in non-comment lines, with word boundaries
            pattern = r'(?<![.\w])' + re.escape(bad_field) + r'(?![.\w])'
            if re.search(pattern, dql):
                # Don't replace inside comment lines
                lines = dql.split('\n')
                new_lines = []
                for line in lines:
                    if line.strip().startswith('//'):
                        new_lines.append(line)
                    else:
                        new_line = re.sub(pattern, good_field, line)
                        if new_line != line:
                            fixes.append(f"Fixed invalid field: {bad_field} â†’ {good_field}")
                        new_lines.append(new_line)
                dql = '\n'.join(new_lines)
        
        # Special case: bare `name` field should be `span.name` only in span queries
        if 'fetch spans' in dql:
            lines = dql.split('\n')
            new_lines = []
            for line in lines:
                if line.strip().startswith('//'):
                    new_lines.append(line)
                else:
                    # Replace bare `name` (not part of service.name, span.name, etc.)
                    new_line = re.sub(r'(?<![.\w])name(?![.\w])', 'span.name', line)
                    if new_line != line:
                        fixes.append("Fixed bare 'name' â†’ 'span.name' in span query")
                    new_lines.append(new_line)
            dql = '\n'.join(new_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 5: Raw NRQL arithmetic expressions
        # Pattern: (field)/1000 or (duration.ms)/1000
        # These need to be converted to DQL fieldsAdd expressions
        # IMPORTANT: Must NOT match inside function calls like toDouble(duration)/1000
        # The negative lookbehind (?<![a-zA-Z]) prevents matching when a letter
        # directly precedes the ( â€” this covers toDouble(, avg(, etc.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        arith_pattern = r'(?<![a-zA-Z])\((\w+(?:\.\w+)*)\)\s*/\s*(\d+)'
        if re.search(arith_pattern, dql):
            def _fix_arith(m):
                field = m.group(1)
                divisor = m.group(2)
                # Map known fields
                if field in ('duration.ms', 'Duration.ms', 'duration'):
                    fixes.append(f"Converted raw arithmetic ({field})/{divisor} â†’ duration field")
                    return 'duration'  # DT duration is already typed, no division needed
                fixes.append(f"Converted raw arithmetic ({field})/{divisor} â†’ toDouble({field})/{divisor}")
                return f"toDouble({field}) / {divisor}"
            dql = re.sub(arith_pattern, _fix_arith, dql)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 6: Empty filter/summarize lines (garbage from removed subqueries)
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        lines = dql.split('\n')
        clean_lines = []
        for line in lines:
            stripped_line = line.strip()
            # Remove empty pipe commands
            if stripped_line in ('| filter', '| filter ', '| summarize', '| fields'):
                fixes.append(f"Removed empty command: {stripped_line}")
                continue
            # Remove lines that are just whitespace
            if not stripped_line and clean_lines and not clean_lines[-1].strip():
                continue  # Skip consecutive blank lines
            clean_lines.append(line)
        dql = '\n'.join(clean_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 7: Trailing commas in filter clauses 
        # (left behind after removing subquery fragments)
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # "| filter service.name == "x" and " â†’ remove trailing "and"
        dql = re.sub(r'\band\s*$', '', dql, flags=re.MULTILINE)
        dql = re.sub(r'\bor\s*$', '', dql, flags=re.MULTILINE)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 8: NRQL LIKE operator â†’ DQL matchesPhrase/matchesPattern
        # DQL doesn't have LIKE - must use matchesPhrase or matchesPattern
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        def _fix_like(m):
            field = m.group(1)
            pattern_val = m.group(2)
            negation = 'NOT ' if m.group(0).strip().upper().startswith('NOT') else ''
            not_prefix = 'NOT ' if negation else ''
            
            if '%' in pattern_val:
                # LIKE '%value%' â†’ matchesPhrase(field, "value")
                clean_val = pattern_val.replace('%', '')
                if pattern_val.startswith('%') and pattern_val.endswith('%'):
                    fixes.append(f"Converted LIKE to matchesPhrase for {field}")
                    return f'{not_prefix}matchesPhrase({field}, "{clean_val}")'
                elif pattern_val.endswith('%'):
                    fixes.append(f"Converted LIKE to startsWith for {field}")
                    return f'{not_prefix}startsWith({field}, "{clean_val}")'
                elif pattern_val.startswith('%'):
                    fixes.append(f"Converted LIKE to endsWith for {field}")
                    return f'{not_prefix}endsWith({field}, "{clean_val}")'
            fixes.append(f"Converted LIKE to matchesPhrase for {field}")
            return f'{not_prefix}matchesPhrase({field}, "{pattern_val}")'
        
        # Match: field LIKE 'pattern' or field NOT LIKE 'pattern'
        dql = re.sub(
            r'(?:NOT\s+)?(\w+(?:\.\w+)*)\s+(?:NOT\s+)?LIKE\s+["\']([^"\']*)["\']',
            _fix_like, dql, flags=re.IGNORECASE)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 9: NR `limit max` â†’ DQL has no direct equivalent
        # Just remove it â€” DQL uses query limit settings
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        if re.search(r'\blimit\s+max\b', dql, re.IGNORECASE):
            dql = re.sub(r'\|\s*limit\s+max\b', '', dql, flags=re.IGNORECASE)
            dql = re.sub(r'\blimit\s+max\b', '', dql, flags=re.IGNORECASE)
            fixes.append("Removed NR 'limit max' (DQL uses query limit settings)")
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 10: Double pipes left from removals: "| |" â†’ "|"
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        dql = re.sub(r'\|\s*\|', '|', dql)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 11: NR shorthand metrics that weren't expanded pre-AST
        # averageduration â†’ avg(duration), maxduration â†’ max(duration), etc.
        # These may appear in | fields or | summarize lines
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        shorthand_map = {
            'averageduration': 'avg(duration)',
            'avgduration': 'avg(duration)',
            'averageresponsetime': 'avg(duration)',
            'maxduration': 'max(duration)',
            'minduration': 'min(duration)',
            'medianduration': 'percentile(duration, 50)',
        }
        dql_lower = dql.lower()
        for shorthand, replacement in shorthand_map.items():
            if shorthand in dql_lower:
                # Replace case-insensitively but only as whole word
                pattern = re.compile(r'\b' + re.escape(shorthand) + r'\b', re.IGNORECASE)
                if pattern.search(dql):
                    # Don't replace inside comment lines
                    lines = dql.split('\n')
                    new_lines = []
                    for line in lines:
                        if line.strip().startswith('//'):
                            new_lines.append(line)
                        else:
                            new_lines.append(pattern.sub(replacement, line))
                    dql = '\n'.join(new_lines)
                    fixes.append(f"Expanded NR shorthand {shorthand} â†’ {replacement}")
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 12: Concatenated/mangled function names
        # toDoubletoDouble, toDoubleduration, avgduration (without parens), etc.
        # These result from prior regex passes incorrectly merging tokens
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # Fix toDoubleXXX where XXX is not ( â€” means parens were eaten
        def _fix_mangled_toDouble(m):
            field = m.group(1)
            fixes.append(f"Fixed mangled toDouble{field} â†’ toDouble({field})")
            return f"toDouble({field})"
        dql = re.sub(r'\btoDouble([a-z]\w*)\b(?!\s*\()', _fix_mangled_toDouble, dql)
        # Fix toDoubletoDouble
        dql = re.sub(r'\btoDouble\s*\(\s*toDouble\s*\(', 'toDouble(', dql)
        if 'toDoubletoDouble' in dql:
            dql = dql.replace('toDoubletoDouble', 'toDouble')
            fixes.append("Fixed doubled toDoubletoDouble â†’ toDouble")
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 13: from:now()-Xd on fetch line for dashboard tiles
        # Dashboard tiles control their own timeframe via time selector.
        # Hardcoded from: overrides the user's time picker.
        # Strip it â€” the COMPARE WITH shift: is handled in viz settings.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        if re.search(r'fetch\s+\w+\s*,\s*from:now\(\)', dql):
            dql = re.sub(r'(fetch\s+\w+)\s*,\s*from:now\(\)-\w+', r'\1', dql)
            fixes.append("Removed hardcoded from:now()-Xd â€” dashboard tile uses time selector")
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 13b: Functions that don't exist in DQL
        # stddev() â€” DQL Grail has no native standard deviation function.
        # Replace with a comment/warning rather than emitting invalid DQL.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        if 'stddev(' in dql:
            lines = dql.split('\n')
            new_lines = []
            for line in lines:
                if line.strip().startswith('//'):
                    new_lines.append(line)
                    continue
                if 'stddev(' in line:
                    new_lines.append(line.replace('stddev(', '/* stddev unsupported in DQL */ avg('))
                    fixes.append("Replaced stddev() with avg() â€” DQL has no native stddev function")
                else:
                    new_lines.append(line)
            dql = '\n'.join(new_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 14: Backtick-escape unsafe aliases in summarize/fieldsAdd/fields
        # Aliases that are DQL reserved words, start with digits, contain
        # spaces, or contain special characters ($, /, etc.) need backtick escaping.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        DQL_RESERVED = {
            'duration', 'timestamp', 'timeframe', 'string', 'long', 'double',
            'boolean', 'ip', 'record', 'array', 'true', 'false', 'null',
            'fetch', 'filter', 'summarize', 'fields', 'sort', 'limit',
            'lookup', 'join', 'append', 'parse', 'from', 'to', 'by',
            'asc', 'desc', 'not', 'and', 'or', 'in', 'is',
        }
        
        def _needs_backtick_escape(name: str) -> bool:
            """Check if an identifier needs backtick escaping in DQL."""
            if not name or name.startswith('`'):
                return False
            if name[0].isdigit():
                return True
            if name.lower() in DQL_RESERVED:
                return True
            if re.search(r'[^a-zA-Z0-9_.]', name):
                return True
            return False
        
        def _escape_alias(name: str) -> str:
            """Backtick-escape an alias if needed."""
            if _needs_backtick_escape(name):
                return f'`{name}`'
            return name
        
        # Scan for aliases in summarize and fieldsAdd lines
        lines = dql.split('\n')
        new_lines = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('//'):
                new_lines.append(line)
                continue
            
            cmd_stripped = stripped.lstrip('| ')
            
            # Identify the command and extract content after it
            cmd_keyword = None
            for kw in ('summarize ', 'fieldsAdd ', 'makeTimeseries ', 'timeseries '):
                if cmd_stripped.startswith(kw):
                    cmd_keyword = kw
                    break
            
            if cmd_keyword:
                # Find the position of the content after the command keyword
                kw_idx = line.find(cmd_keyword)
                prefix = line[:kw_idx + len(cmd_keyword)]
                content = line[kw_idx + len(cmd_keyword):]
                
                # Fix aliases in content: alias=expr patterns
                # Match: identifier followed by = (not ==)
                # Identifiers can be: word, word.word, `word`, or special chars
                def _fix_alias_in_content(m):
                    alias = m.group(1)
                    eq_and_rest = m.group(2)
                    if _needs_backtick_escape(alias):
                        fixes.append(f"Backtick-escaped alias: {alias} â†’ `{alias}`")
                        return f'`{alias}`{eq_and_rest}'
                    return m.group(0)
                
                # Pattern: non-backticked identifier before = (not ==)
                # Must handle: p99=percentile(...), 4XX = 100.0 * ..., $/Month=count()
                content = re.sub(
                    r'(?<![`a-zA-Z])([A-Za-z$_/\d][A-Za-z0-9$_/. ]*?)\s*(=(?!=))',
                    _fix_alias_in_content,
                    content
                )
                line = prefix + content
            
            new_lines.append(line)
        dql = '\n'.join(new_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 15: Fix substring() positional parameters
        # DQL: substring(str, from:start, to:end) â€” NOT substring(str, start, end)
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        if 'substring(' in dql:
            def _fix_substring(m):
                expr = m.group(1)
                start = m.group(2)
                end = m.group(3)
                fixes.append(f"Fixed substring positional params â†’ named from:/to:")
                return f'substring({expr}, from:{start}, to:{end})'
            dql = re.sub(
                r'substring\(([^,]+),\s*(\w+)\s*,\s*(\w+)\s*\)',
                _fix_substring,
                dql
            )
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 16: Strip builtin: prefix in non-metric queries
        # builtin:kubernetes.pod.phase is metric-API syntax, invalid in DQL fetch/filter.
        # In fetch queries, use the entity/record field name without builtin: prefix.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        if 'builtin:' in dql and ('fetch ' in dql or '| filter' in dql):
            lines = dql.split('\n')
            new_lines = []
            for line in lines:
                stripped = line.strip()
                if stripped.startswith('//'):
                    new_lines.append(line)
                    continue
                cmd = stripped.lstrip('| ')
                # Only strip builtin: in filter/fields/fieldsAdd lines, not in timeseries
                if cmd.startswith(('filter ', 'fields ', 'fieldsAdd ', 'summarize ')):
                    if 'builtin:' in line:
                        line = line.replace('builtin:', '')
                        fixes.append("Stripped builtin: prefix from record query (metric-API syntax)")
                new_lines.append(line)
            dql = '\n'.join(new_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 17: Aggregations in non-aggregation context
        # sum(), avg(), count(), min(), max() inside fieldsAdd are invalid.
        # Move the aggregation into the preceding timeseries/summarize line.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        lines = dql.split('\n')
        new_lines = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('//'):
                new_lines.append(line)
                continue
            
            cmd = stripped.lstrip('| ')
            if cmd.startswith('fieldsAdd '):
                content = cmd[len('fieldsAdd '):]
                # Check if the value side of alias=expr contains a bare aggregation function
                alias_match = re.match(r'(\S+)\s*=\s*(sum|avg|count|min|max)\s*\(', content, re.IGNORECASE)
                if alias_match:
                    alias = alias_match.group(1)
                    # Try to merge into preceding timeseries/summarize line
                    merged = False
                    for i in range(len(new_lines) - 1, -1, -1):
                        prev_cmd = new_lines[i].strip().lstrip('| ')
                        if prev_cmd.startswith(('timeseries ', 'makeTimeseries ', 'summarize ')):
                            # Extract the full fieldsAdd expression: alias=agg(metric)
                            full_expr = content.strip()
                            new_lines[i] = new_lines[i].rstrip() + f", {full_expr}"
                            fixes.append(f"Moved aggregation '{alias}' from fieldsAdd into timeseries/summarize")
                            merged = True
                            break
                        elif prev_cmd.startswith(('fieldsAdd ', '//')):
                            continue  # Skip other fieldsAdd and comments
                        else:
                            break  # Stop at non-matching lines
                    if merged:
                        continue  # Don't add the original fieldsAdd line
                    else:
                        # Can't merge â€” comment it out with guidance
                        new_lines.append(f"// TODO: {stripped} â€” aggregation not valid in fieldsAdd")
                        fixes.append(f"Flagged aggregation in fieldsAdd: {alias}")
                        continue
            new_lines.append(line)
        dql = '\n'.join(new_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 18: Duplicate aliases in same command
        # "The field p99 would be created twice in the same command"
        # Detect duplicate alias names and suffix with _2, _3, etc.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        lines = dql.split('\n')
        new_lines = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('//'):
                new_lines.append(line)
                continue
            cmd = stripped.lstrip('| ')
            if cmd.startswith(('summarize ', 'makeTimeseries ', 'timeseries ', 'fieldsAdd ')):
                # Extract all alias=expr patterns
                alias_pattern = re.compile(r'(?<![a-zA-Z`])(`?[\w.]+`?)\s*=(?!=)')
                aliases = alias_pattern.findall(cmd)
                seen_aliases = {}
                for alias in aliases:
                    clean = alias.strip('`')
                    if clean in seen_aliases:
                        seen_aliases[clean] += 1
                        # Find and rename the duplicate
                        new_alias = f"{alias}_{seen_aliases[clean]}"
                        # Replace only the Nth occurrence
                        count = 0
                        def _replace_nth(m):
                            nonlocal count
                            if m.group(1).strip('`') == clean:
                                count += 1
                                if count == seen_aliases[clean]:
                                    fixes.append(f"Renamed duplicate alias {clean} â†’ {clean}_{seen_aliases[clean]}")
                                    return f"{new_alias}="
                            return m.group(0)
                        line = re.sub(r'(?<![a-zA-Z`])(`?[\w.]+`?)\s*=(?!=)', _replace_nth, line)
                    else:
                        seen_aliases[clean] = 1
            new_lines.append(line)
        dql = '\n'.join(new_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 19: Backtick-escape field names containing / in paths
        # labels.app.kubernetes.io/span.name â†’ `labels.app.kubernetes.io/span.name`
        # These are valid field paths but / is parsed as division without backticks
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # Match: word.word.word/word patterns (typical k8s label paths) not already backticked
        slash_field_pattern = re.compile(r'(?<!`)(\b[a-zA-Z][\w.]*(?:/[\w.]+)+\b)(?!`)')
        if slash_field_pattern.search(dql):
            lines = dql.split('\n')
            new_lines = []
            for line in lines:
                if line.strip().startswith('//'):
                    new_lines.append(line)
                    continue
                # Split line into quoted-string and non-quoted segments.
                # Only apply backtick escaping to non-quoted segments to avoid
                # mangling URLs inside contains("..."), filter field == "..." etc.
                segments = re.split(r'("(?:[^"\\]|\\.)*")', line)
                new_segments = []
                for seg in segments:
                    if seg.startswith('"') and seg.endswith('"'):
                        # Inside a quoted string â€” leave it alone
                        new_segments.append(seg)
                    else:
                        # Outside quotes â€” safe to backtick-escape slash-fields
                        def _fix_slash_field(m):
                            field = m.group(1)
                            if field.startswith('http') or field.startswith('ftp'):
                                return field
                            fixes.append(f"Backtick-escaped field with /: {field}")
                            return f'`{field}`'
                        new_segments.append(slash_field_pattern.sub(_fix_slash_field, seg))
                new_lines.append(''.join(new_segments))
            dql = '\n'.join(new_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 20: Fix bare NR field names that aren't valid in DQL context
        # Fields like `Item`, `Items`, `Group`, `Log`, `MS` from NR custom events
        # get used bare in DQL where they clash with DQL parser expectations.
        # If they appear in filter/summarize/fields contexts as lone identifiers
        # (not part of a dotted path), backtick-escape them.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # Common NR custom event field names that clash with DQL parsing
        # (uppercase single words that DQL may interpret as keywords or types)
        nr_custom_fields = {
            'Item', 'Items', 'Group', 'Groups', 'Log', 'Logs',
            'MS', 'Action', 'Type', 'Status', 'Result', 'Value',
            'Message', 'Error', 'Name', 'Id', 'Key', 'Data',
        }
        for field in nr_custom_fields:
            # Only match as standalone identifier (not part of dotted path)
            pattern = re.compile(r'(?<![.\w`])' + re.escape(field) + r'(?![.\w`])')
            if pattern.search(dql):
                lines = dql.split('\n')
                new_lines = []
                for line in lines:
                    if line.strip().startswith('//'):
                        new_lines.append(line)
                        continue
                    cmd = line.strip().lstrip('| ')
                    # Only fix in filter/summarize/fieldsAdd/fields lines
                    if cmd.startswith(('filter ', 'summarize ', 'fieldsAdd ', 'fields ', 'sort ')):
                        new_line = pattern.sub(f'`{field}`', line)
                        if new_line != line:
                            fixes.append(f"Backtick-escaped NR field name: {field}")
                            line = new_line
                    new_lines.append(line)
                dql = '\n'.join(new_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 21: Strip ALL remaining NRQL `AS` keywords from DQL output
        # DQL uses alias=expr syntax, NOT expr AS alias.
        # _fix_as_aliases only handles by: clauses â€” this catches EVERYTHING.
        # Must run BEFORE curly-brace wrapping (CHECK 23) to avoid mangling.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        lines = dql.split('\n')
        as_fixed_lines = []
        for line in lines:
            stripped_line = line.strip()
            if stripped_line.startswith('//'):
                as_fixed_lines.append(line)
                continue
            
            # Only fix AS in command lines (summarize, makeTimeseries, fieldsAdd, fields)
            cmd = stripped_line.lstrip('| ')
            if any(cmd.startswith(kw) for kw in ('summarize ', 'makeTimeseries ', 'fieldsAdd ', 'fields ')):
                original_line = line
                
                # Use a robust approach: find ' AS ' (case-insensitive) in the line
                # and convert to alias=expr format. Must handle nested parens.
                def _fix_all_as_in_line(text):
                    """Convert all 'expr AS alias' patterns to 'alias=expr' in a line."""
                    # Find the command keyword and work on the rest
                    kw_match = re.match(r'^(\s*\|?\s*(?:summarize|makeTimeseries|fieldsAdd|fields)\s+)', text, re.IGNORECASE)
                    if not kw_match:
                        return text
                    prefix = kw_match.group(1)
                    body = text[len(prefix):]
                    
                    # Split body into top-level comma-separated parts (respecting parens)
                    parts = []
                    depth = 0
                    current = []
                    for ch in body:
                        if ch in ('(', '{', '['):
                            depth += 1
                        elif ch in (')', '}', ']'):
                            depth -= 1
                        elif ch == ',' and depth == 0:
                            parts.append(''.join(current))
                            current = []
                            continue
                        current.append(ch)
                    if current:
                        parts.append(''.join(current))
                    
                    fixed_parts = []
                    changed = False
                    for part in parts:
                        stripped_part = part.strip()
                        # Look for AS at the end of the part (case-insensitive)
                        # Pattern: <expression> AS <alias> or <expression> AS '<alias>'
                        as_match = re.search(r'\s+[Aa][Ss]\s+[\'"]?([^\'"]+?)[\'"]?\s*$', stripped_part)
                        if as_match and not stripped_part.startswith('by:'):
                            alias_raw = as_match.group(1).strip()
                            expr = stripped_part[:as_match.start()].strip()
                            # Preserve backtick-escaped aliases as-is
                            if alias_raw.startswith('`') and alias_raw.endswith('`'):
                                alias_clean = alias_raw
                            elif re.search(r'[^a-zA-Z0-9_]', alias_raw) or alias_raw[0:1].isdigit():
                                alias_clean = re.sub(r'[^a-zA-Z0-9_]', '_', alias_raw)
                                if alias_clean[0:1].isdigit():
                                    alias_clean = '_' + alias_clean
                            else:
                                alias_clean = alias_raw
                            fixed_parts.append(f' {alias_clean}={expr}')
                            changed = True
                        else:
                            fixed_parts.append(part)
                    
                    if changed:
                        return prefix + ','.join(fixed_parts)
                    return text
                
                line = _fix_all_as_in_line(line)
                
                if line != original_line:
                    fixes.append("Converted NRQL 'AS' alias to DQL 'alias=expr' syntax")
            
            as_fixed_lines.append(line)
        dql = '\n'.join(as_fixed_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 22: Fix double-equals in aliases (alias1=alias2=expr â†’ alias1=expr)
        # This happens when multi-percentile expansion creates p95=percentile(...)
        # AND an AS alias also creates Percentile=... on the same expression.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        lines = dql.split('\n')
        dedup_lines = []
        for line in lines:
            if line.strip().startswith('//'):
                dedup_lines.append(line)
                continue
            # Match: word=word=expr (double alias)
            original_line = line
            # Pattern: alias1=alias2=funcOrExpr  â†’  alias1=funcOrExpr
            line = re.sub(
                r'(\w+)=(\w+)=(\w+\s*\()',
                lambda m: f'{m.group(1)}={m.group(3)}',
                line
            )
            # Also fix: alias1=alias2=bareExpr (no function call)
            line = re.sub(
                r'(\w+)=(\w+)=([^,\s(]+)',
                lambda m: f'{m.group(1)}={m.group(3)}',
                line
            )
            if line != original_line:
                fixes.append("Fixed double-alias (alias1=alias2=expr â†’ alias1=expr)")
            dedup_lines.append(line)
        dql = '\n'.join(dedup_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 23: Wrap multi-aggregation summarize in curly braces
        # DQL REQUIRES: summarize {min(x), max(x)}, by:{field}
        # We output:    summarize min(x), max(x), by:{field}  â† WRONG
        # Only applies to summarize, NOT makeTimeseries (different syntax).
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        def _wrap_summarize_aggs(line: str) -> str:
            """Wrap multiple aggregations in summarize command with {}."""
            # Match: summarize <aggs> [, by:{...}]
            # We need to extract just the aggregation part (before by:)
            sum_match = re.match(r'^(\s*\|?\s*summarize\s+)(.*)', line, re.IGNORECASE)
            if not sum_match:
                return line
            
            prefix = sum_match.group(1)
            rest = sum_match.group(2).strip()
            
            # Already wrapped in {}
            if rest.startswith('{'):
                return line
            
            # Split off by: clause (respecting nesting)
            by_clause = ''
            agg_part = rest
            
            # Find ', by:' at top level (not inside parens)
            depth = 0
            for i, ch in enumerate(rest):
                if ch in ('(', '{', '['):
                    depth += 1
                elif ch in (')', '}', ']'):
                    depth -= 1
                elif depth == 0 and rest[i:].startswith(', by:'):
                    agg_part = rest[:i]
                    by_clause = rest[i:]  # includes ', by:{...}'
                    break
                elif depth == 0 and rest[i:].startswith(',by:'):
                    agg_part = rest[:i]
                    by_clause = rest[i:]
                    break
            
            # Count top-level aggregation expressions
            agg_count = 0
            depth = 0
            for ch in agg_part:
                if ch in ('(', '{', '['):
                    depth += 1
                elif ch in (')', '}', ']'):
                    depth -= 1
                elif ch == ',' and depth == 0:
                    agg_count += 1
            agg_count += 1  # N commas = N+1 expressions
            
            if agg_count > 1:
                return f"{prefix}{{{agg_part}}}{by_clause}"
            return line
        
        lines = dql.split('\n')
        brace_fixed_lines = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('//'):
                brace_fixed_lines.append(line)
                continue
            cmd = stripped.lstrip('| ')
            if cmd.lower().startswith('summarize ') and not cmd.lower().startswith('summarize {'):
                original = line
                line = _wrap_summarize_aggs(line)
                if line != original:
                    fixes.append("Wrapped multi-aggregation summarize in {} (DQL requirement)")
            brace_fixed_lines.append(line)
        dql = '\n'.join(brace_fixed_lines)
        
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        # CHECK 24: Fix makeTimeseries with multiple aggregation aliases
        # makeTimeseries does NOT support alias=expr syntax.
        # If multi-percentile expansion created p95=percentile(...), p99=percentile(...),
        # strip the aliases and they'll auto-generate column names.
        # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
        lines = dql.split('\n')
        mt_fixed_lines = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('//'):
                mt_fixed_lines.append(line)
                continue
            cmd = stripped.lstrip('| ')
            if cmd.lower().startswith('maketimeseries '):
                original = line
                # Find the makeTimeseries command portion (before by:, interval:, etc.)
                mt_match = re.match(r'^(\s*\|?\s*makeTimeseries\s+)(.*)', line, re.IGNORECASE)
                if mt_match:
                    mt_prefix = mt_match.group(1)
                    mt_rest = mt_match.group(2)
                    
                    # Split off named params (by:, interval:, from:, to:)
                    params_part = ''
                    agg_end = len(mt_rest)
                    depth = 0
                    for i, ch in enumerate(mt_rest):
                        if ch in ('(', '{', '['):
                            depth += 1
                        elif ch in (')', '}', ']'):
                            depth -= 1
                        elif depth == 0 and mt_rest[i:].startswith(', by:'):
                            agg_end = i
                            params_part = mt_rest[i:]
                            break
                        elif depth == 0 and mt_rest[i:].startswith(', interval:'):
                            agg_end = i
                            params_part = mt_rest[i:]
                            break
                    
                    agg_portion = mt_rest[:agg_end]
                    
                    # Strip alias= from each aggregation (makeTimeseries doesn't support aliases)
                    def _strip_mt_alias(part):
                        eq_match = re.match(r'^\s*`?(\w+)`?\s*=\s*(?!=)(.+)$', part.strip())
                        if eq_match:
                            return eq_match.group(2).strip()
                        return part.strip()
                    
                    # Split aggregations respecting parens
                    parts = []
                    depth = 0
                    current = []
                    for ch in agg_portion:
                        if ch in ('(', '{', '['):
                            depth += 1
                        elif ch in (')', '}', ']'):
                            depth -= 1
                        elif ch == ',' and depth == 0:
                            parts.append(''.join(current).strip())
                            current = []
                            continue
                        current.append(ch)
                    if current:
                        parts.append(''.join(current).strip())
                    
                    clean_parts = [_strip_mt_alias(p) for p in parts if p.strip()]
                    line = mt_prefix + ', '.join(clean_parts) + params_part
                    
                    if line != original:
                        fixes.append("Stripped aliases from makeTimeseries (not supported, uses auto-column names)")
            mt_fixed_lines.append(line)
        dql = '\n'.join(mt_fixed_lines)
        
        # Final cleanup: remove trailing whitespace on each line
        lines = dql.split('\n')
        dql = '\n'.join(line.rstrip() for line in lines)
        
        return dql, fixes
    
    def _build_metric_query(self, select_clause: str, where_clause: str, 
                           facet_clause: str, has_timeseries: bool, title: str) -> Tuple[str, str]:
        """Build a DQL query for metric data"""
        confidence = "HIGH"
        
        # Parse aggregation - handle backtick-quoted fields like `k8s.container.cpuUsedCores`
        # Extended pattern to include latest, earliest, first, last
        agg_match = re.search(
            r'(count|sum|average|avg|max|min|percentile|latest|earliest|first|last)\s*\(\s*`?([^)`]*)`?\s*\)',
            select_clause or '',
            re.IGNORECASE
        )
        
        if agg_match:
            func = agg_match.group(1).lower()
            field = agg_match.group(2).strip().strip('`') if agg_match.group(2) else ''
            
            # Handle latest/earliest/first/last
            # For METRIC sources: latest() just means "current value" â†’ use avg() on timeseries
            # For non-metric sources (spans, logs): use fetch + summarize with takeLast/takeFirst
            if func in ['latest', 'last', 'earliest', 'first']:
                # Check if the field maps to a known DT metric - if so, use timeseries path
                field_key = field.lower().replace('.', '').replace('_', '').replace('`', '') if field else ''
                dt_metric, _metric_warn = self._resolve_metric(field_key, field) if field_key else (None, None)
                if _metric_warn:
                    self._current_warnings.append(_metric_warn)
                
                # === METRIC_TRANSFORMS INTERCEPT ===
                # Check if this field needs a calculated expression instead of simple lookup
                if field_key:
                    transform_result = self._apply_metric_transform(
                        field_key, func, where_clause, facet_clause
                    )
                    if transform_result:
                        return transform_result[0], transform_result[1]
                
                if dt_metric or (field and (field.startswith('builtin:') or field.startswith('dt.'))):
                    # This is a METRIC query with latest() - route to timeseries with avg()
                    # latest() on metrics = "most recent aggregated value" = avg() in timeseries
                    metric_name = dt_metric if dt_metric else field
                    
                    # Handle multiple aggregations in same SELECT
                    all_aggs = re.findall(
                        r'(latest|earliest|first|last|average|avg|sum|max|min)\s*\(\s*`?([^)`]*)`?\s*\)',
                        select_clause, re.IGNORECASE
                    )
                    
                    # Build timeseries with first metric
                    dql = f"timeseries avg({metric_name})"
                    
                    # Add grouping (facet)
                    if facet_clause:
                        dt_facets = self._convert_facet(facet_clause)
                        if dt_facets:
                            dql += f", by: {{{dt_facets}}}"
                    
                    # Add filter
                    if where_clause:
                        dt_filter = self._convert_where(where_clause)
                        if dt_filter:
                            dql += f", filter: {dt_filter}"
                    
                    # Note if multiple metrics were in SELECT
                    if len(all_aggs) > 1:
                        unmapped = []
                        for _, fld in all_aggs[1:]:
                            fld_clean = fld.strip().strip('`')
                            fld_key = fld_clean.lower().replace('.', '').replace('_', '')
                            m, _mw = self._resolve_metric(fld_key, fld_clean)
                            if _mw:
                                self._current_warnings.append(_mw)
                            unmapped.append(m or fld_clean)
                        dql = f"// NOTE: Multiple metrics - additional: {', '.join(unmapped)}\n{dql}"
                    
                    return dql, "HIGH"
                
                # Non-metric: use fetch + summarize with takeLast/takeFirst
                dt_func = 'takeLast' if func in ['latest', 'last'] else 'takeFirst'
                dt_field = self._map_attribute(field) if field else 'timestamp'
                
                # Check for multiple aggregations
                all_aggs = re.findall(
                    r'(latest|earliest|first|last)\s*\(\s*`?([^)`]*)`?\s*\)',
                    select_clause, re.IGNORECASE
                )
                
                agg_exprs = []
                for f, fld in all_aggs:
                    f_lower = f.lower()
                    dt_f = 'takeLast' if f_lower in ['latest', 'last'] else 'takeFirst'
                    dt_fld = self._map_attribute(fld.strip('`')) if fld else 'timestamp'
                    agg_exprs.append(f'{dt_f}({dt_fld})')
                
                parts = ["fetch spans"]
                if where_clause:
                    dt_filter = self._convert_where(where_clause)
                    parts.append(f"filter {dt_filter}")
                
                if facet_clause:
                    dt_facets = self._convert_facet(facet_clause)
                    if dt_facets:
                        parts.append(f"summarize {', '.join(agg_exprs)}, by: {{{dt_facets}}}")
                    else:
                        parts.append(f"summarize {', '.join(agg_exprs)}")
                else:
                    parts.append(f"summarize {', '.join(agg_exprs)}")
                
                return '\n| '.join(parts), "HIGH"
            
            # count() without field should use fetch + summarize, not timeseries
            if func == 'count' and (not field or field == '*'):
                return self._build_count_query(where_clause, facet_clause, 'spans', title)
            
            # Check for NR-specific SLI metrics - need to convert to DT SLO queries
            if field and 'newrelic.sli' in field.lower():
                return self._convert_sli_query(select_clause, where_clause, title)
            
            # Map to DT function
            dt_func = AGG_MAP.get(func, func)
            if dt_func == 'count()':
                dt_func = 'count'
            
            # CRITICAL: timeseries only supports sum, avg, min, max, count, percentile, countDistinct
            # takeLast/takeFirst are NOT valid timeseries aggregations
            if dt_func in ('takeLast', 'takeFirst', 'takeAny'):
                dt_func = 'avg'
            
            # Map field to metric
            if field:
                # Remove backticks and normalize
                field_key = field.lower().replace('.', '').replace('_', '').replace('`', '')
                
                # === METRIC_TRANSFORMS INTERCEPT ===
                transform_result = self._apply_metric_transform(
                    field_key, func, where_clause, facet_clause
                )
                if transform_result:
                    return transform_result[0], transform_result[1]
                
                dt_metric, _metric_warn = self._resolve_metric(field_key, field)
                if _metric_warn:
                    self._current_warnings.append(_metric_warn)
                
                if dt_metric:
                    dql = f"timeseries {dt_func}({dt_metric})"
                elif field.startswith('builtin:') or field.startswith('dt.'):
                    # Passthrough â€” already validated by _resolve_metric above
                    dql = f"timeseries {dt_func}({field})"
                else:
                    # Unknown field - fall back to fetch with note
                    parts = [f"// NOTE: Unknown metric field '{field}' - may need manual mapping"]
                    parts.append("fetch spans")
                    if where_clause:
                        dt_filter = self._convert_where(where_clause)
                        parts.append(f"| filter {dt_filter}")
                    if facet_clause:
                        dt_facets = self._convert_facet(facet_clause)
                        if dt_facets:  # Skip if CASES() couldn't be converted
                            parts.append(f"| summarize count(), by: {{{dt_facets}}}")
                        else:
                            parts.append("| summarize count()")
                    else:
                        parts.append("| summarize count()")
                    return '\n'.join(parts), "MEDIUM"
            else:
                # Default metric for common functions
                if func in ['avg', 'average']:
                    dql = "timeseries avg(builtin:service.response.time)"
                elif func == 'sum':
                    dql = "timeseries sum(builtin:service.requestCount.total)"
                else:
                    return self._build_count_query(where_clause, facet_clause, 'spans', title)
            
            # Add grouping
            if facet_clause:
                dt_facets = self._convert_facet(facet_clause)
                if dt_facets:  # Skip if CASES() couldn't be converted
                    dql += f", by: {{{dt_facets}}}"
            
            # Add filter
            if where_clause:
                dt_filter = self._convert_where(where_clause)
                dql += f", filter: {dt_filter}"
            
            return dql, confidence
        
        # No recognizable aggregation - fall back to fetch
        return self._build_count_query(where_clause, facet_clause, 'spans', title)
    
    @staticmethod
    def _strip_maketimeseries_aliases(expr: str) -> Tuple[str, List[Tuple[str, str]]]:
        """
        Strip alias=agg() patterns from an expression for makeTimeseries.
        makeTimeseries does NOT support alias=agg() syntax (only 'timeseries' does).
        Returns (clean_expr, [(auto_name, alias), ...]) for fieldsRename.
        """
        rename_pairs = []
        clean_parts = []
        
        # Split by comma, respecting parentheses depth
        parts = []
        depth = 0
        current = []
        for ch in expr:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            elif ch == ',' and depth == 0:
                parts.append(''.join(current).strip())
                current = []
                continue
            current.append(ch)
        if current:
            parts.append(''.join(current).strip())
        
        for part in parts:
            # Match alias=expr pattern (but not ==)
            eq_match = re.match(r'^(\w+)\s*=\s*(?!=)(.+)$', part.strip())
            if eq_match:
                alias_name = eq_match.group(1)
                raw_expr = eq_match.group(2).strip()
                clean_parts.append(raw_expr)
                rename_pairs.append((raw_expr, alias_name))
            else:
                clean_parts.append(part.strip())
        
        return ', '.join(clean_parts), rename_pairs

    def _build_fetch_query(self, dt_source: str, select_clause: str, where_clause: str,
                          facet_clause: str, limit_value: int, has_timeseries: bool,
                          title: str, original_nrql: str = "") -> Tuple[str, str]:
        """Build a DQL fetch query for non-metric data"""
        confidence = "HIGH"
        parts = [f"fetch {dt_source}"]
        
        # Detect and handle subqueries: WHERE x IN (SELECT x FROM ...)
        # NR supports SQL-style subqueries; DQL needs join/lookup instead
        subquery_pattern = r"(\w[\w.]*)\s+(?:NOT\s+)?IN\s*\(\s*SELECT\s+(.+?)\s+FROM\s+(\w+)(?:\s+WHERE\s+(.+?))?\s*\)"
        subquery_match = re.search(subquery_pattern, where_clause or '', re.IGNORECASE)
        if subquery_match:
            join_field = subquery_match.group(1)  # e.g., trace.id
            sub_select = subquery_match.group(2)  # e.g., trace.id
            sub_from = subquery_match.group(3)    # e.g., Span
            sub_where = subquery_match.group(4)   # e.g., service.name = 'xxx'
            
            # Map the subquery source
            sub_dt_source = self._map_event_type(sub_from) or 'spans'
            
            # Map join field to DT attribute
            dt_join_field = self._map_attribute(join_field)
            
            # Build the subquery filter
            sub_filter = ''
            if sub_where:
                # Remove the subquery from where_clause to get remaining conditions
                sub_filter_converted = self._convert_where(sub_where)
                if sub_filter_converted:
                    sub_filter = f" | filter {sub_filter_converted}"
            
            # Remove the subquery clause from the main WHERE
            is_not_in = 'NOT IN' in where_clause.upper()
            remaining_where = re.sub(subquery_pattern, '', where_clause or '', flags=re.IGNORECASE).strip()
            # Clean up leftover AND/OR
            remaining_where = re.sub(r'^\s*(AND|OR)\s+', '', remaining_where, flags=re.IGNORECASE).strip()
            remaining_where = re.sub(r'\s+(AND|OR)\s*$', '', remaining_where, flags=re.IGNORECASE).strip()
            
            # Build join-based query
            join_kind = 'leftOuter' if is_not_in else 'inner'
            parts.append(f"join [fetch {sub_dt_source}{sub_filter} | fields {dt_join_field}], on: {{{dt_join_field}}}, kind: {join_kind}")
            
            if is_not_in:
                parts.append(f"filter isNull(lookup.{dt_join_field})")
            
            # Add remaining WHERE conditions
            if remaining_where:
                dt_filter = self._convert_where(remaining_where)
                if dt_filter and dt_filter.strip():
                    parts.append(f"filter {dt_filter}")
            
            # Add comment about subquery conversion
            if hasattr(self, '_current_warnings'):
                self._current_warnings.append(f"Subquery converted to DQL join on {dt_join_field}")
            
            # Continue to aggregation section below (skip the normal filter block)
            where_clause = None  # Prevent double-filtering
        
        # Add filter
        if where_clause:
            dt_filter = self._convert_where(where_clause)
            if dt_filter and dt_filter.strip():
                parts.append(f"filter {dt_filter}")
        
        # Check for CDF percentage expressions (special handling needed)
        if select_clause and '__cdf_' in select_clause:
            # Extract all the __cdf_ fields
            # Format: __cdf_total__=count(), __cdf_under_1000ms__=countIf(duration < 1000000000), ...
            agg_expr = select_clause.strip()
            
            # Clean field names for DQL (remove __cdf_ prefix and __ suffix)
            clean_expr = re.sub(r'__cdf_([^_]+(?:_\d+m?s)?)__', r'\1', agg_expr)
            
            # Build the aggregation part
            # For TIMESERIES, we can only return raw counts - percentage calculation 
            # on arrays requires complex arrayMap syntax
            # The visualization layer can show percentages
            if has_timeseries:
                # Strip aliases for makeTimeseries (doesn't support alias=agg() syntax)
                mt_clean, mt_renames = self._strip_maketimeseries_aliases(clean_expr)
                if facet_clause:
                    dt_facets = self._convert_facet(facet_clause)
                    if dt_facets:
                        parts.append(f"makeTimeseries {mt_clean}, by: {{{dt_facets}}}")
                    else:
                        parts.append(f"makeTimeseries {mt_clean}")
                else:
                    parts.append(f"makeTimeseries {mt_clean}")
                # Note: makeTimeseries doesn't support aliases or fieldsRename after it
                # Auto-generated column names (e.g. percentile(duration, 95)) are used in charts
                # Note: For timeseries, percentages must be calculated in visualization
                # or use arrayMap which is complex
            else:
                # For non-timeseries (summarize), we CAN calculate percentages
                if facet_clause:
                    dt_facets = self._convert_facet(facet_clause)
                    if dt_facets:
                        parts.append(f"summarize {clean_expr}, by: {{{dt_facets}}}")
                    else:
                        parts.append(f"summarize {clean_expr}")
                else:
                    parts.append(f"summarize {clean_expr}")
                
                # Add fieldsAdd to calculate percentages (only for non-timeseries)
                bucket_names = re.findall(r'(under_\d+m?s)', clean_expr)
                if bucket_names:
                    pct_fields = [f"pct_{name} = 100.0 * {name} / total" for name in bucket_names]
                    parts.append(f"fieldsAdd {', '.join(pct_fields)}")
                    # Remove the raw count fields, keep only percentages
                    fields_to_remove = ['total'] + bucket_names
                    parts.append(f"fieldsRemove {', '.join(fields_to_remove)}")
            
            if limit_value:
                parts.append(f"limit {limit_value}")
            
            return '\n| '.join(parts), "HIGH"
        
        # Check for pre-converted DQL expressions (countIf, avgIf, math expressions)
        # These were converted from NR functions like percentage(), filter()
        if select_clause and re.search(r'\b(countIf|avgIf|sumIf|maxIf|minIf)\s*\(', select_clause, re.IGNORECASE):
            # Extract the expression, preserving math
            # Look for pattern: (expression) AS 'alias' or just expression
            expr_match = re.search(r'^\s*(.+?)(?:\s+AS\s+[\'"]?[\w\s]+[\'"]?)?\s*$', select_clause, re.IGNORECASE)
            if expr_match:
                agg_expr = expr_match.group(1).strip()
                # Clean up any remaining NR syntax
                agg_expr = re.sub(r"'([^']+)'", r'"\1"', agg_expr)  # Single to double quotes
                
                if has_timeseries:
                    # Strip aliases for makeTimeseries
                    mt_clean, mt_renames = self._strip_maketimeseries_aliases(agg_expr)
                    if facet_clause:
                        dt_facets = self._convert_facet(facet_clause)
                        if dt_facets:
                            parts.append(f"makeTimeseries {mt_clean}, by: {{{dt_facets}}}")
                        else:
                            parts.append(f"makeTimeseries {mt_clean}")
                    else:
                        parts.append(f"makeTimeseries {mt_clean}")
                else:
                    if facet_clause:
                        dt_facets = self._convert_facet(facet_clause)
                        if dt_facets:
                            parts.append(f"summarize {agg_expr}, by: {{{dt_facets}}}")
                        else:
                            parts.append(f"summarize {agg_expr}")
                    else:
                        parts.append(f"summarize {agg_expr}")
                
                if limit_value:
                    parts.append(f"limit {limit_value}")
                
                return '\n| '.join(parts), "HIGH"
        
        # Parse ALL aggregations (not just the first one)
        # Enhanced pattern to capture:
        # - alias=func(args)
        # - func(args) AS alias
        # - func(args) as 'alias with spaces'
        # - func(args)
        # Also handles: rate(func(), interval), latest(), earliest(), uniqueCount()
        
        # First, extract any AS aliases and normalize them
        # Pattern: func(args) AS 'alias' or func(args) AS alias
        select_normalized = select_clause or ''
        
        # Convert "AS 'alias'" and 'AS alias' to "AS_alias" format for easier parsing
        def normalize_as_alias(match):
            full_expr = match.group(1)
            alias = match.group(2).strip("'\"")
            # If alias needs escaping (spaces, special chars, reserved words, digit-prefix),
            # backtick-escape it; otherwise clean it
            if (alias[0:1].isdigit() or 
                re.search(r'[^a-zA-Z0-9_]', alias) or
                alias.lower() in {'duration', 'timestamp', 'timeframe', 'string', 'long',
                                   'double', 'boolean', 'ip', 'record', 'array'}):
                clean_alias = f'`{alias}`'
            else:
                clean_alias = re.sub(r'[^a-zA-Z0-9_]', '_', alias)
            return f'{clean_alias}={full_expr}'
        
        # Handle: expr AS 'alias' or expr AS alias
        # Fixed regex: handles nested parens in func calls AND quoted aliases with spaces
        # Pattern 1: func(...) AS 'quoted alias with spaces'
        select_normalized = re.sub(
            r'(\w+\s*\([^)]*(?:\([^)]*\)[^)]*)*\))\s+[Aa][Ss]\s+[\'"]([^\'"]+)[\'"]',
            normalize_as_alias,
            select_normalized
        )
        # Pattern 2: func(...) AS unquoted_alias (single word)
        select_normalized = re.sub(
            r'(\w+\s*\([^)]*(?:\([^)]*\)[^)]*)*\))\s+[Aa][Ss]\s+(\w+)',
            normalize_as_alias,
            select_normalized
        )
        
        # Extended aggregation pattern including rate, latest, earliest, etc.
        # NOTE: preprocess converts latestâ†’last and earliestâ†’first, so we match both forms
        agg_pattern = r'(?:(\w+)\s*=\s*)?(count|sum|average|avg|max|min|uniquecount|percentile|countDistinct|collectDistinct|rate|latest|earliest|last|first|stddev|median)\s*\(\s*([^)]*)\s*\)'
        all_aggs = re.findall(agg_pattern, select_normalized, re.IGNORECASE)
        
        # Filter out inner functions that are part of rate() or derivative()
        # e.g. rate(count(*), 1 minute) matches both 'rate' and 'count' - skip the inner one
        has_rate = any(f.lower() in ('rate', 'derivative') for _, f, _ in all_aggs)
        if has_rate:
            filtered = []
            for alias, func, args in all_aggs:
                fl = func.lower()
                if fl in ('rate', 'derivative'):
                    filtered.append((alias, func, args))
                elif fl in ('count', 'sum', 'avg', 'average', 'min', 'max') and not alias:
                    # Skip inner aggs that are part of rate() â€” only if no alias
                    # Check if this func appears inside a rate/derivative in the original select
                    inner_check = re.search(
                        rf'(?:rate|derivative)\s*\([^)]*{func}\s*\(', 
                        select_normalized, re.IGNORECASE
                    )
                    if inner_check:
                        continue  # Skip - it's the inner function of rate()
                    filtered.append((alias, func, args))
                else:
                    filtered.append((alias, func, args))
            all_aggs = filtered
        
        if all_aggs:
            agg_expressions = []
            warnings = []
            
            for alias, func, args in all_aggs:
                func_lower = func.lower()
                dt_func = AGG_MAP.get(func_lower, func_lower)
                
                # Handle special functions
                if func_lower == 'rate':
                    # The agg_pattern regex truncates nested parens, so re-extract from select
                    rate_match = re.search(r'rate\s*\((.+)\)', select_normalized, re.IGNORECASE)
                    if rate_match:
                        rate_full = f'rate({rate_match.group(1).strip()})'
                    else:
                        rate_full = f'rate({args})' if args else 'rate(count(*))'
                    rate_result = self._rate_converter.convert_rate(rate_full)
                    if rate_result:
                        expr, rate_param = rate_result
                        if not hasattr(self, '_current_rate_params'):
                            self._current_rate_params = []
                        self._current_rate_params.append(rate_param)
                        warnings.append(f"rate() â†’ {expr}, {rate_param}")
                    else:
                        inner_match = re.search(r'(count|sum|avg)\s*\([^)]*\)', args, re.IGNORECASE)
                        if inner_match:
                            expr = 'count()' if 'count' in inner_match.group(0).lower() else inner_match.group(0)
                        else:
                            expr = 'count()'
                        warnings.append(f"rate() â†’ {expr} (rate: param needs manual addition)")
                elif func_lower == 'derivative':
                    # Use RateDerivativeConverter
                    deriv_full = f'derivative({args})' if args else 'derivative(count(*))'
                    deriv_result = self._rate_converter.convert_derivative(deriv_full)
                    if deriv_result:
                        expr, rate_param = deriv_result
                        if not hasattr(self, '_current_rate_params'):
                            self._current_rate_params = []
                        self._current_rate_params.append(rate_param)
                        warnings.append(f"derivative() â†’ {expr}, {rate_param}")
                    else:
                        expr = f'avg({args})' if args else 'count()'
                        warnings.append("derivative() approximated - review rate calculation")
                elif func_lower == 'latest':
                    field = args.strip() if args else '*'
                    if field == '*':
                        # takeLast/takeFirst only valid in summarize, NOT timeseries/makeTimeseries
                        expr = 'count()' if has_timeseries else 'takeLast(timestamp)'
                    else:
                        dt_field = self._map_attribute(field.replace('duration.ms', 'duration'))
                        if has_timeseries:
                            # timeseries/makeTimeseries only supports: avg, sum, min, max, count, percentile
                            expr = f'avg({dt_field})'
                            warnings.append(f"latest({field}) â†’ avg({dt_field}) for timeseries (takeLast not supported)")
                        else:
                            expr = f'takeLast({dt_field})'
                elif func_lower == 'last':
                    # Already converted from latest() by preprocess
                    field = args.strip() if args else '*'
                    if field == '*':
                        expr = 'count()' if has_timeseries else 'takeLast(timestamp)'
                    else:
                        dt_field = self._map_attribute(field.replace('duration.ms', 'duration'))
                        if has_timeseries:
                            expr = f'avg({dt_field})'
                            warnings.append(f"last({field}) â†’ avg({dt_field}) for timeseries (takeLast not supported)")
                        else:
                            expr = f'takeLast({dt_field})'
                elif func_lower == 'earliest':
                    field = args.strip() if args else '*'
                    if field == '*':
                        expr = 'count()' if has_timeseries else 'takeFirst(timestamp)'
                    else:
                        dt_field = self._map_attribute(field.replace('duration.ms', 'duration'))
                        if has_timeseries:
                            expr = f'avg({dt_field})'
                            warnings.append(f"earliest({field}) â†’ avg({dt_field}) for timeseries (takeFirst not supported)")
                        else:
                            expr = f'takeFirst({dt_field})'
                elif func_lower == 'first':
                    # Already converted from earliest() by preprocess
                    field = args.strip() if args else '*'
                    if field == '*':
                        expr = 'count()' if has_timeseries else 'takeFirst(timestamp)'
                    else:
                        dt_field = self._map_attribute(field.replace('duration.ms', 'duration'))
                        if has_timeseries:
                            expr = f'avg({dt_field})'
                            warnings.append(f"first({field}) â†’ avg({dt_field}) for timeseries (takeFirst not supported)")
                        else:
                            expr = f'takeFirst({dt_field})'
                elif func_lower == 'median':
                    field = args.strip() if args else 'duration'
                    dt_field = self._map_attribute(field.replace('duration.ms', 'duration'))
                    expr = f'percentile({dt_field}, 50)'
                elif func_lower == 'count' or not args or args == '*':
                    expr = 'count()'
                elif func_lower == 'percentile':
                    # percentile(field, value) - keep both args
                    args_clean = args.replace('duration.ms', 'duration')
                    expr = f'percentile({args_clean})'
                elif func_lower == 'uniquecount':
                    field = args.split(',')[0].strip()
                    dt_field = self._map_attribute(field)
                    expr = f'countDistinct({dt_field})'
                elif func_lower == 'collectdistinct':
                    # Already preprocessed from uniques() with maxLength param
                    expr = f'collectDistinct({args.strip()})'
                else:
                    # Map field name
                    field = args.split(',')[0].strip()  # First arg is the field
                    # Convert duration.ms to duration
                    if field == 'duration.ms':
                        field = 'duration'
                    dt_field = self._map_attribute(field)
                    expr = f'{dt_func}({dt_field})'
                
                # Add alias if present
                if alias:
                    agg_expressions.append(f'{alias}={expr}')
                else:
                    agg_expressions.append(expr)
            
            # Check for math operations after aggregations (e.g., / 1000)
            # Look for patterns like "avg(...) / 1000" or "* 100"
            math_match = re.search(r'\)\s*([*/+-])\s*(\d+(?:\.\d+)?)', select_clause or '')
            math_suffix = ''
            if math_match:
                operator = math_match.group(1)
                operand = math_match.group(2)
                # We'll need to add this as a fieldsAdd after summarize
                math_suffix = f' {operator} {operand}'
                warnings.append(f"Math operation ({operator} {operand}) - add fieldsAdd if needed")
            
            # Add any warnings to current_warnings
            if hasattr(self, '_current_warnings'):
                self._current_warnings.extend(warnings)
            
            # Join all aggregations
            agg_expr = ', '.join(agg_expressions)
            
            # Use makeTimeseries if TIMESERIES was specified, otherwise summarize
            # IMPORTANT: makeTimeseries does NOT support alias=agg() syntax or shift:/rate: params
            # Only the metrics 'timeseries' command supports those. For makeTimeseries,
            # we strip aliases and add fieldsRename after if needed.
            if has_timeseries:
                # Separate aliases from expressions for makeTimeseries
                rename_pairs = []  # (auto_name, alias) pairs
                clean_agg_parts = []
                for agg_part in agg_expressions:
                    eq_match = re.match(r'^(\w+)\s*=\s*(.+)$', agg_part.strip())
                    if eq_match:
                        alias_name = eq_match.group(1)
                        raw_expr = eq_match.group(2)
                        clean_agg_parts.append(raw_expr)
                        rename_pairs.append((raw_expr, alias_name))
                    else:
                        clean_agg_parts.append(agg_part)
                
                clean_agg_expr = ', '.join(clean_agg_parts)
                
                if facet_clause:
                    dt_facets = self._convert_facet(facet_clause)
                    if dt_facets:
                        parts.append(f"makeTimeseries {clean_agg_expr}, by: {{{dt_facets}}}")
                    else:
                        parts.append(f"makeTimeseries {clean_agg_expr}")
                else:
                    parts.append(f"makeTimeseries {clean_agg_expr}")
                
                # Note: makeTimeseries doesn't support fieldsRename after it
                # Auto-generated column names are used directly in chart legends
            else:
                if facet_clause:
                    dt_facets = self._convert_facet(facet_clause)
                    if dt_facets:
                        parts.append(f"summarize {agg_expr}, by: {{{dt_facets}}}")
                    else:
                        parts.append(f"summarize {agg_expr}")
                else:
                    parts.append(f"summarize {agg_expr}")
        
        elif select_clause:
            # Check for string/transformation/scalar functions that need fieldsAdd
            # This covers ALL functions preprocessed in _preprocess_nrql
            scalar_funcs = [
                # String functions
                'concat', 'capture', 'aparse', 'substring', 'lower', 'upper', 'if',
                'stringlength', 'indexof', 'trim',
                # Math functions  
                'power', 'log', 'log10', 'abs', 'ceil', 'floor', 'round', 'sqrt', 'exp',
                # Date/time extraction
                'getdayofmonth', 'getmonth', 'getyear', 'gethour', 'getminute',
                'getweekofyear', 'formattimestamp', 'getsecond', 'getdayofweek',
                # Type casting
                'todouble', 'tostring', 'toboolean', 'totimestamp',
                # Bucketing
                'bin',
            ]
            has_scalar_func = any(f'{func}(' in select_clause.lower() for func in scalar_funcs)
            
            if has_scalar_func:
                # Handle string/transformation functions
                fields_add_exprs = []
                confidence = "MEDIUM"
                
                # Handle concat(a, b, c) as alias
                concat_match = re.search(
                    r'concat\s*\(([^)]+)\)\s*(?:[Aa][Ss]\s+[\'"]?(\w+)[\'"]?)?',
                    select_clause, re.IGNORECASE
                )
                if concat_match:
                    args = concat_match.group(1)
                    alias = concat_match.group(2) or 'concatenated'
                    # Map attribute names in args, keep string literals quoted
                    mapped_args = []
                    for arg in args.split(','):
                        arg = arg.strip()
                        # Check if it's a string literal (quoted)
                        if (arg.startswith('"') and arg.endswith('"')) or (arg.startswith("'") and arg.endswith("'")):
                            # It's a string literal - keep it quoted (convert to double quotes)
                            mapped_args.append(f'"{arg.strip("\"\'")}"')
                        else:
                            # It's a field name - map it
                            mapped_args.append(self._map_attribute(arg))
                    fields_add_exprs.append(f'{alias} = concat({", ".join(mapped_args)})')
                
                # Handle capture(field, regex) -> parse field, "DPL_PATTERN"
                # Uses RegexToDPLConverter for actual RE2 â†’ DPL conversion
                capture_match = re.search(
                    r'capture\s*\(([^,]+),\s*[r]?[\'"]([^\'"]+)[\'"]\)\s*(?:[Aa][Ss]\s+[\'"]?(\w+)[\'"]?)?',
                    select_clause, re.IGNORECASE
                )
                if capture_match:
                    field = self._map_attribute(capture_match.group(1).strip())
                    regex_pattern = capture_match.group(2)
                    alias = capture_match.group(3) or 'extracted'
                    # Convert RE2 regex to DPL
                    dpl_pattern, capture_names = self._regex_to_dpl.convert(regex_pattern)
                    parse_cmd = f'parse {field}, "{dpl_pattern}"'
                    fields_add_exprs.append(f'// capture() â†’ | {parse_cmd}')
                    if hasattr(self, '_current_warnings'):
                        if capture_names:
                            self._current_warnings.append(
                                f"capture() â†’ DPL parse with fields: {', '.join(capture_names)}")
                        else:
                            self._current_warnings.append(
                                f"capture() â†’ DPL parse (verify pattern: {dpl_pattern[:40]}...)")
                
                # Handle aparse(field, 'pattern') -> parse with DPL
                # Uses AparseConverter for % delimiter â†’ DPL conversion
                aparse_match = re.search(
                    r'aparse\s*\(([^,]+),\s*[\'"]([^\'"]+)[\'"]\)\s*(?:[Aa][Ss]\s+[\'"]?(\w+)[\'"]?)?',
                    select_clause, re.IGNORECASE
                )
                if aparse_match:
                    field = self._map_attribute(aparse_match.group(1).strip())
                    anchor_pattern = aparse_match.group(2)
                    alias = aparse_match.group(3) or 'parsed'
                    # Convert aparse % pattern to DPL
                    dpl_pattern, capture_names = self._aparse_converter.convert(anchor_pattern)
                    parse_cmd = f'parse {field}, "{dpl_pattern}"'
                    fields_add_exprs.append(f'// aparse() â†’ | {parse_cmd}')
                    if hasattr(self, '_current_warnings'):
                        self._current_warnings.append(
                            f"aparse() â†’ DPL parse, captures: {', '.join(capture_names)}")
                
                # Handle if(condition, true_val, false_val)
                if_match = re.search(
                    r'if\s*\(([^,]+),\s*[\'"]?([^\'"]+)[\'"]?,\s*[\'"]?([^\'"]+)[\'"]?\)\s*(?:[Aa][Ss]\s+[\'"]?(\w+)[\'"]?)?',
                    select_clause, re.IGNORECASE
                )
                if if_match:
                    condition = if_match.group(1).strip()
                    true_val = if_match.group(2).strip()
                    false_val = if_match.group(3).strip()
                    alias = if_match.group(4) or 'result'
                    # Convert condition
                    condition = self._convert_where_condition_only(condition)
                    fields_add_exprs.append(f'{alias} = if({condition}, "{true_val}", "{false_val}")')
                
                if fields_add_exprs:
                    parts.append(f"fieldsAdd {', '.join(fields_add_exprs)}")
                else:
                    # Generic scalar function fallback: pass through any function(args) as fieldsAdd
                    # This handles preprocessed functions like power(), getDayOfMonth(), toDouble(), etc.
                    func_match = re.search(
                        r'(?:(\w+)\s*=\s*)?(\w+)\s*\((.+)\)',
                        select_clause, re.IGNORECASE
                    )
                    if func_match:
                        alias = func_match.group(1)
                        func_name = func_match.group(2)
                        func_args = func_match.group(3)
                        # Map field names in args (skip string literals and numbers)
                        mapped_args = []
                        for arg in func_args.split(','):
                            arg = arg.strip()
                            if (arg.startswith('"') or arg.startswith("'") or 
                                re.match(r'^-?\d+\.?\d*$', arg) or
                                '(' in arg):  # nested function, leave as-is
                                mapped_args.append(arg)
                            else:
                                mapped_args.append(self._map_attribute(arg))
                        result_expr = f'{func_name}({", ".join(mapped_args)})'
                        if alias:
                            parts.append(f"fieldsAdd {alias} = {result_expr}")
                        else:
                            parts.append(f"fieldsAdd {result_expr}")
                    else:
                        # Fallback - just pass through with warning
                        parts.append(f"// Scalar function not fully converted: {select_clause[:80]}")
                        if hasattr(self, '_current_warnings'):
                            self._current_warnings.append("Scalar function requires manual review")
            else:
                # SELECT specific fields without aggregation
                fields = self._parse_select_fields(select_clause)
                if fields:
                    dt_fields = [self._map_attribute(f) for f in fields]
                    parts.append(f"fields {', '.join(dt_fields)}")
        
        # Add limit
        if limit_value:
            parts.append(f"limit {limit_value}")
        
        return '\n| '.join(parts), confidence
    
    def _convert_sli_query(self, select_clause: str, where_clause: str, title: str) -> Tuple[str, str]:
        """
        Convert NR SLI metric queries to DT SLO queries.
        
        NR SLI queries use metrics like:
        - newrelic.sli.good - count of good events
        - newrelic.sli.valid - count of valid/total events
        
        Common patterns:
        - Status: sum(newrelic.sli.good) / sum(newrelic.sli.valid) * 100
        - Error budget: (clamp_min(clamp_max(sum(good)/sum(valid)*100, 100) - target, 0) / (100 - target)) * 100
        """
        confidence = "MEDIUM"
        
        # Extract SLO GUID from WHERE clause
        slo_guid = None
        guid_match = re.search(r"entity\.guid\s*=\s*['\"]([^'\"]+)['\"]", where_clause, re.IGNORECASE)
        if guid_match:
            slo_guid = guid_match.group(1)
        
        # Resolve GUID to SLO name
        slo_name = None
        if slo_guid:
            if slo_guid in self._guid_cache:
                slo_name = self._guid_cache[slo_guid]
            elif self._auto_create_slos:
                # Try to fetch from NR
                slo_info = self._fetch_slo_details_from_nr(slo_guid)
                if slo_info:
                    slo_name = slo_info.get('name', '')
        
        # Analyze SELECT clause to determine what's being calculated
        # Use ORIGINAL NRQL if available (before preprocessing), otherwise use select_clause
        original_nrql = getattr(self, '_current_original_nrql', '') or ''
        query_to_analyze = original_nrql.lower() if original_nrql else select_clause.lower() if select_clause else ''
        title_lower = title.lower() if title else ''
        
        print(f"  DEBUG: SLI query analysis - title: '{title}'")
        
        # Determine SLO metric type based on multiple signals
        slo_metric = 'slo.status'  # Default
        
        # Signal 1: Title contains clear indicator
        if 'error budget' in title_lower or 'budget' in title_lower:
            slo_metric = 'slo.errorBudget'
            print(f"  DEBUG: Detected error budget from title")
        elif 'burn' in title_lower and 'rate' in title_lower:
            slo_metric = 'slo.burnRate'
            print(f"  DEBUG: Detected burn rate from title")
        elif 'target' in title_lower:
            slo_metric = 'slo.target'
            print(f"  DEBUG: Detected target from title")
        
        # Signal 2: Original NRQL has clamp_min/clamp_max (error budget formula)
        elif 'clamp_min' in query_to_analyze or 'clamp_max' in query_to_analyze:
            slo_metric = 'slo.errorBudget'
            print(f"  DEBUG: Detected error budget from clamp functions")
            
            # Try to extract target from the formula (e.g., "- 97" or "100 - 97")
            target_match = re.search(r'(?:[-â€“]\s*(\d+(?:\.\d+)?)|100\s*[-â€“]\s*(\d+(?:\.\d+)?))', query_to_analyze)
            if target_match:
                target = target_match.group(1) or target_match.group(2)
                print(f"  DEBUG: Extracted target from formula: {target}%")
        
        # Signal 3: Converted if() pattern from preprocessing (error budget)
        # Pattern: if(...) / (100 - target) * 100
        elif re.search(r'if\s*\([^)]+\)\s*/\s*\(\s*100\s*-\s*\d+', query_to_analyze):
            slo_metric = 'slo.errorBudget'
            print(f"  DEBUG: Detected error budget from converted if() pattern")
        
        # Signal 4: Simple status calculation (good/valid ratio without the error budget math)
        elif 'newrelic.sli.good' in query_to_analyze and 'newrelic.sli.valid' in query_to_analyze:
            # If it has division but no complex math, it's status
            if '/' in query_to_analyze and 'if(' not in query_to_analyze:
                slo_metric = 'slo.status'
                print(f"  DEBUG: Detected status from good/valid ratio")
            elif '/' not in query_to_analyze:
                # Just counting, not ratio
                slo_metric = 'count'
                print(f"  DEBUG: Detected raw count query")
            else:
                # Has if() but check if it's simple
                slo_metric = 'slo.status'
        
        # Signal 5: Check for just good or just valid
        elif 'newrelic.sli.good' in query_to_analyze:
            slo_metric = 'goodCount'
            print(f"  DEBUG: Detected good events count")
        elif 'newrelic.sli.valid' in query_to_analyze:
            slo_metric = 'validCount'
            print(f"  DEBUG: Detected valid events count")
        
        # Build DQL filter
        if slo_name:
            slo_filter = f'slo.name == "{slo_name}"'
            confidence = "HIGH"
        elif slo_guid:
            slo_filter = f'/* REPLACE with slo.name: NR GUID was {slo_guid[:30]}... */'
            confidence = "LOW"
        else:
            slo_filter = '/* REPLACE: Add slo.name == "Your SLO Name" */'
            confidence = "LOW"
        
        print(f"  DEBUG: SLO metric type: {slo_metric}, filter: {slo_filter[:50]}...")
        
        # Generate appropriate DQL/guidance based on metric type
        # NOTE: In DT, SLO data is typically displayed via the dedicated SLO tile widget,
        # not via DQL queries. But we provide DQL for custom visualizations.
        
        # Build SLO name reference for comments
        slo_ref = slo_name if slo_name else f"(NR GUID: {slo_guid[:30]}...)" if slo_guid else "Your SLO Name"
        
        if slo_metric == 'slo.status':
            dql = f'''// SLO STATUS: "{slo_ref}"
// RECOMMENDED: Use the dedicated SLO tile widget in Dashboards
// which displays Status, Error Budget, and Target automatically.
// 
// To add: Dashboard > Add tile > Service-Level Objective > Select "{slo_ref}"
//
// If you need a custom DQL visualization, the SLO's underlying query is in the SLO definition.'''
        
        elif slo_metric == 'slo.errorBudget':
            dql = f'''// ERROR BUDGET: "{slo_ref}"
// RECOMMENDED: Use the dedicated SLO tile widget in Dashboards
// The SLO widget includes Error Budget display by default.
// 
// To add: Dashboard > Add tile > Service-Level Objective > Select "{slo_ref}"
// Then enable "Error budget" in the tile's Data mapping columns.
//
// Error Budget = (Current Status - Target) / (100 - Target) * 100'''
        
        elif slo_metric == 'slo.burnRate':
            dql = f'''// BURN RATE: "{slo_ref}"
// RECOMMENDED: Use the dedicated SLO tile widget in Dashboards
// Burn rate visualization is included when burn rate alerting is configured.
// 
// To add: Dashboard > Add tile > Service-Level Objective > Select "{slo_ref}"
//
// Burn Rate = rate at which error budget is being consumed'''
        
        elif slo_metric == 'slo.target':
            dql = f'''// SLO TARGET: "{slo_ref}"
// RECOMMENDED: Use the dedicated SLO tile widget in Dashboards
// which displays the Target value.
// 
// To add: Dashboard > Add tile > Service-Level Objective > Select "{slo_ref}"
// Then enable "Target" in the tile's Data mapping columns.'''
        
        elif slo_metric in ('goodCount', 'validCount', 'count'):
            # These don't have direct DT equivalents
            dql = f'''// RAW SLI COUNTS: "{slo_ref}"
// NOTE: Raw good/valid event counts aren't exposed in DT SLO tiles.
// The SLO widget shows Status (percentage) and Error Budget instead.
//
// If you need raw counts, query the underlying data directly:
// fetch spans
// | filter dt.entity.service == "SERVICE-..." // Replace with your service
// | summarize total = count(), good = countIf(duration <= 4s)
// | fieldsAdd sli = 100.0 * good / total'''
            confidence = "LOW"
        
        else:
            dql = f'''// SLO: "{slo_ref}"
// RECOMMENDED: Use the dedicated SLO tile widget in Dashboards
// To add: Dashboard > Add tile > Service-Level Objective > Select your SLO'''
        
        return dql, confidence
    
    def _build_count_query(self, where_clause: str, facet_clause: str, 
                          source: str, title: str) -> Tuple[str, str]:
        """Build a simple count query using fetch + summarize"""
        parts = [f"fetch {source}"]
        
        if where_clause:
            dt_filter = self._convert_where(where_clause)
            parts.append(f"filter {dt_filter}")
        
        if facet_clause:
            dt_facets = self._convert_facet(facet_clause)
            if dt_facets:
                parts.append(f"summarize count(), by: {{{dt_facets}}}")
            else:
                parts.append("summarize count()")
        else:
            parts.append("summarize count()")
        
        return '\n| '.join(parts), "HIGH"
    
    def _build_k8s_metric_query(self, k8s_source: str, select_clause: str, where_clause: str,
                                facet_clause: str, has_timeseries: bool, title: str) -> Tuple[str, str]:
        """Build DQL query for Kubernetes metrics (K8sNodeSample, K8sContainerSample, etc.)"""
        confidence = "MEDIUM"  # K8s queries often need manual adjustment
        notes = []
        
        # â”€â”€ K8s context-specific metric overrides â”€â”€
        # Some NR fields like memoryUsedBytes appear in both host and K8s contexts.
        # When we KNOW we're in K8s context (FROM K8sContainerSample/K8sNodeSample),
        # these must map to dt.kubernetes.* metrics, not dt.host.* metrics.
        K8S_METRIC_OVERRIDES = {
            'memoryusedbytes': 'dt.kubernetes.container.memory_working_set',
            'memoryused': 'dt.kubernetes.container.memory_working_set',
            'cpuusedbytes': 'dt.kubernetes.container.cpu_usage',
            'cpupercent': 'dt.kubernetes.container.cpu_usage',
            'diskused': 'dt.kubernetes.persistentvolumeclaim.used',
            'diskusedbytes': 'dt.kubernetes.persistentvolumeclaim.used',
        }
        
        # K8s fields that are entity properties, not timeseries metrics.
        # These get redirected to entity fetch queries or readiness-comparison timeseries.
        K8S_ENTITY_FIELDS = {
            'isready': {
                # Show readiness as desired vs ready comparison
                'dql': 'timeseries avg(dt.kubernetes.workload.pods_ready), avg(dt.kubernetes.workload.pods_desired)',
                'note': '// isReady â†’ DT readiness = pods_ready vs pods_desired comparison',
                'confidence': 'MEDIUM',
            },
            'status': {
                'dql': (
                    'fetch dt.entity.cloud_application'
                    '\n| fields entity.name, status = cloudApplicationStatus'
                ),
                'note': '// status â†’ DT entity property (not a timeseries metric)',
                'confidence': 'MEDIUM',
            },
            'isscheduled': {
                'dql': (
                    'fetch dt.entity.cloud_application_instance'
                    '\n| fields entity.name, phase = cloudApplicationInstancePhase'
                ),
                'note': '// isScheduled â†’ DT entity phase property',
                'confidence': 'MEDIUM',
            },
        }
        
        # Check if WHERE clause contains metric-based filtering (e.g., allocatableMemoryUtilization < 90)
        metric_filter_patterns = [
            'allocatablememoryutilization', 'memoryusedbytes', 'memoryavailablebytes',
            'fscapacityutilization', 'fsavailablebytes', 'fsinodesused', 'fsinodes',
            'cpuusedbytes', 'allocatablecpuutilization'
        ]
        where_lower = (where_clause or '').lower()
        has_metric_filter = any(p in where_lower for p in metric_filter_patterns)
        
        if has_metric_filter:
            notes.append("// NOTE: Metric-based filtering (e.g., memoryUtilization < 90) works differently in DT")
            notes.append("// Consider using DT's threshold alerts or post-aggregation filtering")
            confidence = "LOW"
        
        # Parse the select clause to find what metrics are being queried
        # NR K8s queries: SELECT latest(memoryUsedBytes), latest(allocatableMemoryUtilization)...
        agg_matches = re.findall(
            r'(latest|last|earliest|first|average|avg|sum|max|min)\s*\(\s*([^)]+)\s*\)',
            select_clause or '',
            re.IGNORECASE
        )
        
        if not agg_matches:
            # No aggregation, might be just field selection
            result = self._build_count_query(where_clause, facet_clause, 'dt.entity.cloud_application', title)
            if notes:
                return '\n'.join(notes) + '\n' + result[0], "LOW"
            return result
        
        # â”€â”€ K8s entity field interception â”€â”€
        # Some K8s fields (isReady, status, isScheduled) are entity properties, not
        # timeseries metrics. Detect them and emit entity/comparison queries instead.
        first_field_key = agg_matches[0][1].strip().strip('`').lower().replace('.', '').replace('_', '')
        entity_info = K8S_ENTITY_FIELDS.get(first_field_key)
        if entity_info:
            dql = entity_info['dql']
            # Append cluster/namespace filter from WHERE clause if present
            if where_clause:
                dt_filter = self._convert_where(where_clause)
                if dt_filter:
                    if 'timeseries' in dql:
                        dql += f", filter: {dt_filter}"
                    else:
                        dql += f"\n| filter {dt_filter}"
            # Append grouping from FACET if present
            if facet_clause and 'timeseries' in dql:
                dt_facets = self._convert_facet(facet_clause)
                if dt_facets:
                    dql += f", by: {{{dt_facets}}}"
            if notes:
                dql = '\n'.join(notes) + '\n' + entity_info['note'] + '\n' + dql
            else:
                dql = entity_info['note'] + '\n' + dql
            return dql, entity_info['confidence']
        
        # Map each metric
        dt_metrics = []
        unmapped_metrics = []
        transform_used = False
        
        for func, field in agg_matches:
            field = field.strip().strip('`')
            field_key = field.lower().replace('.', '').replace('_', '')
            
            # === METRIC_TRANSFORMS INTERCEPT ===
            # If the FIRST metric has a transform, use it directly (calculated expressions
            # are full queries and can't be combined with other metrics easily)
            if not transform_used and not dt_metrics:
                transform_result = self._apply_metric_transform(
                    field_key, func.lower(), where_clause, facet_clause
                )
                if transform_result:
                    dql, conf, note_text = transform_result
                    # Prepend any existing notes
                    if notes:
                        dql = '\n'.join(notes) + '\n' + dql
                    # Note remaining metrics that couldn't be included
                    remaining = [f.strip().strip('`') for _, f in agg_matches[1:]]
                    if remaining:
                        dql = f"// NOTE: Additional metrics in original query: {', '.join(remaining)}\n{dql}"
                    return dql, conf
            
            # === K8S CONTEXT OVERRIDE ===
            # Check K8s-specific overrides BEFORE generic METRIC_MAP 
            # (e.g. memoryUsedBytes â†’ container.memory_working_set in K8s, host.memory.used in host)
            k8s_override = K8S_METRIC_OVERRIDES.get(field_key)
            if k8s_override:
                dt_func = 'avg' if func.lower() in ['latest', 'last', 'first', 'earliest', 'average', 'avg'] else func.lower()
                dt_metrics.append((dt_func, k8s_override, field))
                continue
            
            dt_metric, _metric_warn = self._resolve_metric(field_key, field)
            if _metric_warn:
                self._current_warnings.append(_metric_warn)
            if dt_metric:
                dt_func = 'avg' if func.lower() in ['latest', 'last', 'first', 'earliest', 'average', 'avg'] else func.lower()
                dt_metrics.append((dt_func, dt_metric, field))
            else:
                unmapped_metrics.append(field)
        
        # If no metrics mapped, provide a placeholder with note
        if not dt_metrics:
            parts = notes.copy()
            parts.append(f"// NOTE: Unknown K8s metrics: {', '.join(unmapped_metrics)} - need manual mapping")
            parts.append("// Suggested: Check builtin:cloud.kubernetes.* metrics in DT Metrics browser")
            parts.append("fetch dt.entity.kubernetes_node")
            if where_clause:
                dt_filter = self._convert_where(where_clause)
                # Remove metric-based conditions from filter (they won't work on entities)
                for pattern in metric_filter_patterns:
                    dt_filter = re.sub(rf'\s*and\s+{pattern}\s*[<>=!]+\s*[\d.]+', '', dt_filter, flags=re.IGNORECASE)
                    dt_filter = re.sub(rf'{pattern}\s*[<>=!]+\s*[\d.]+\s*and\s*', '', dt_filter, flags=re.IGNORECASE)
                dt_filter = dt_filter.strip()
                if dt_filter:
                    parts.append(f"| filter {dt_filter}")
            if facet_clause:
                dt_facets = self._convert_facet(facet_clause)
                if dt_facets:
                    parts.append(f"| summarize count(), by: {{{dt_facets}}}")
                else:
                    parts.append("| summarize count()")
            else:
                parts.append("| summarize count()")
            return '\n'.join(parts), "LOW"
        
        # Build timeseries query with the first mapped metric
        dt_func, dt_metric, original_field = dt_metrics[0]
        
        dql = f"timeseries {dt_func}({dt_metric})"
        
        # Add grouping (facet)
        if facet_clause:
            dt_facets = self._convert_facet(facet_clause)
            if dt_facets:
                dql += f", by: {{{dt_facets}}}"
        
        # Add filter - but remove metric-based conditions
        if where_clause:
            dt_filter = self._convert_where(where_clause)
            # Remove metric-based conditions from filter
            for pattern in metric_filter_patterns:
                dt_filter = re.sub(rf'\s*and\s+{pattern}\s*[<>=!]+\s*[\d.]+', '', dt_filter, flags=re.IGNORECASE)
                dt_filter = re.sub(rf'{pattern}\s*[<>=!]+\s*[\d.]+\s*and\s*', '', dt_filter, flags=re.IGNORECASE)
                dt_filter = re.sub(rf'{pattern}\s*[<>=!]+\s*[\d.]+', '', dt_filter, flags=re.IGNORECASE)
            dt_filter = dt_filter.strip()
            if dt_filter:
                dql += f", filter: {dt_filter}"
        
        # Add note if there were unmapped metrics
        if unmapped_metrics:
            notes.append(f"// NOTE: Unmapped metrics: {', '.join(unmapped_metrics)}")
        
        # If multiple metrics, add a note
        if len(dt_metrics) > 1:
            notes.append(f"// NOTE: Multiple metrics in original - only using first. Others: {[m[2] for m in dt_metrics[1:]]}")
        
        # Prepend notes
        if notes:
            dql = '\n'.join(notes) + '\n' + dql
        
        return dql, confidence
    
    def _apply_metric_transform(self, field_key: str, agg_func: str,
                                 where_clause: str, facet_clause: str) -> Optional[Tuple[str, str, str]]:
        """
        Check if a field needs a calculated expression instead of simple metric lookup.
        
        Returns: (dql, confidence, note) if transform applies, None otherwise.
        
        This intercepts fields like errorRate, allocatableCpuUtilization, etc.
        that can't be expressed as a simple `timeseries avg(metric)`.
        """
        transform = METRIC_TRANSFORMS.get(field_key)
        if not transform:
            return None
        
        ttype = transform['type']
        confidence = transform.get('confidence', 'MEDIUM')
        note = transform.get('note', '')
        
        # Build the {by} and {filter} placeholders
        by_str = ''
        filter_str = ''
        
        if facet_clause:
            dt_facets = self._convert_facet(facet_clause)
            if dt_facets:
                by_str = f", by: {{{dt_facets}}}"
        
        if where_clause:
            dt_filter = self._convert_where(where_clause)
            if dt_filter and dt_filter.strip():
                filter_str = f", filter: {dt_filter}"
        
        if ttype == 'calculated':
            # Use the single-timeseries form for dashboard tiles (cleaner output)
            dql_template = transform.get('dql_single', transform['dql'])
            dql = dql_template.replace('{by}', by_str).replace('{filter}', filter_str)
            if note:
                dql = f"// {note}\n{dql}"
            return dql, confidence, note
        
        elif ttype == 'multi_metric':
            dql = transform['dql'].replace('{by}', by_str).replace('{filter}', filter_str)
            return dql, confidence, note
        
        elif ttype == 'unit_convert':
            metric = transform['metric']
            post_calc = transform.get('post_calc', '')
            
            # Build standard timeseries
            dt_func = AGG_MAP.get(agg_func, agg_func) if agg_func else 'avg'
            if dt_func == 'count()':
                dt_func = 'count'
            
            # CRITICAL: timeseries only supports sum, avg, min, max, count, percentile, countDistinct
            # takeLast/takeFirst are NOT valid timeseries aggregations
            if dt_func in ('takeLast', 'takeFirst', 'takeAny'):
                dt_func = 'avg'
            
            alias = field_key[:12]  # Short alias for the fieldsAdd reference
            dql = f"timeseries {alias} = {dt_func}({metric}){by_str}{filter_str}"
            
            if post_calc:
                post_calc_resolved = post_calc.replace('{alias}', alias)
                dql = f"{dql}\n{post_calc_resolved}"
            
            if note:
                dql = f"// {note}\n{dql}"
            
            return dql, confidence, note
        
        return None
    
    def _build_events_query(self, select_clause: str, where_clause: str,
                           facet_clause: str, limit_value: int, title: str) -> Tuple[str, str]:
        """Build DQL query for infrastructure events (InfrastructureEvent)"""
        parts = ["fetch events"]
        
        if where_clause:
            dt_filter = self._convert_where(where_clause)
            parts.append(f"filter {dt_filter}")
        
        # Parse fields from SELECT
        if select_clause:
            fields = self._parse_select_fields(select_clause)
            if fields:
                dt_fields = [self._map_attribute(f) for f in fields]
                parts.append(f"fields {', '.join(dt_fields)}")
        
        if limit_value:
            parts.append(f"limit {limit_value}")
        
        return '\n| '.join(parts), "MEDIUM"
    
    def _map_event_type(self, event_type: str) -> str:
        """Map NR event type to DT data source"""
        event_key = event_type.lower().replace('_', '').replace('-', '')
        
        if event_key in EVENT_TYPE_MAP:
            return EVENT_TYPE_MAP[event_key]
        
        # Heuristics
        if 'log' in event_key:
            return 'logs'
        elif 'metric' in event_key or 'sample' in event_key:
            return 'METRIC'
        elif 'span' in event_key or 'transaction' in event_key:
            return 'spans'
        elif 'synthetic' in event_key:
            return 'dt.synthetic.http.request'
        else:
            return 'spans'  # Default
    
    def _is_metric_query(self, nrql: str) -> bool:
        """Check if this NRQL targets a metric/K8s event type that needs
        the specialized _build_metric_query or _build_k8s_metric_query paths.
        The AST compiler doesn't handle these yet â€” they require METRIC_MAP
        lookups and timeseries (not makeTimeseries) commands."""
        from_match = re.search(r'\bFROM\s+(\w+)', nrql, re.IGNORECASE)
        if not from_match:
            return False
        event_type = from_match.group(1).lower().replace('_', '').replace('-', '')
        mapped = EVENT_TYPE_MAP.get(event_type, '')
        if not mapped:
            # Heuristic
            return 'metric' in event_type or 'sample' in event_type
        return mapped == 'METRIC' or mapped.startswith('K8S_')
    
    def _preprocess_nrql(self, nrql: str) -> str:
        """
        Preprocess NRQL to convert NR-specific syntax before parsing.
        Handles: clamp_max, clamp_min, latest, median, rate, variables, backticks
        """
        result = nrql
        
        # 1. Convert clamp_max(x, max) â†’ if(x > max, max, x)
        def convert_clamp_max(match):
            expr = match.group(1).strip()
            max_val = match.group(2).strip()
            return f'if({expr} > {max_val}, {max_val}, else:{expr})'
        
        result = re.sub(
            r'clamp_max\s*\(\s*(.+?)\s*,\s*(\d+(?:\.\d+)?)\s*\)',
            convert_clamp_max,
            result,
            flags=re.IGNORECASE
        )
        
        # 2. Convert clamp_min(x, min) â†’ if(x < min, min, x)
        def convert_clamp_min(match):
            expr = match.group(1).strip()
            min_val = match.group(2).strip()
            return f'if({expr} < {min_val}, {min_val}, else:{expr})'
        
        result = re.sub(
            r'clamp_min\s*\(\s*(.+?)\s*,\s*(\d+(?:\.\d+)?)\s*\)',
            convert_clamp_min,
            result,
            flags=re.IGNORECASE
        )
        
        # 3. Convert latest(field) â†’ last(field)
        result = re.sub(r'\blatest\s*\(', 'last(', result, flags=re.IGNORECASE)
        
        # 4. Convert median(field) â†’ percentile(field, 50)
        def convert_median(match):
            field = match.group(1).strip()
            return f'percentile({field}, 50)'
        
        result = re.sub(
            r'\bmedian\s*\(\s*([^)]+)\s*\)',
            convert_median,
            result,
            flags=re.IGNORECASE
        )
        
        # 5. Convert {{variable}} â†’ $variable (DT variable syntax)
        result = re.sub(r'\{\{(\w+)\}\}', r'$\1', result)
        
        # 6. Remove backticks from field names (DQL doesn't use them)
        result = re.sub(r'`([^`]+)`', r'\1', result)
        
        # 7. Convert uniqueCount() â†’ countDistinct()
        result = re.sub(r'\buniqueCount\s*\(', 'countDistinct(', result, flags=re.IGNORECASE)
        
        # 8. Convert percentile(field, p1, p2, ...) â†’ p1=percentile(field, p1), p2=percentile(field, p2), ...
        # NR allows multiple percentile values, DQL only allows one per call
        # ALSO: Strip any trailing AS alias (e.g., "percentile(x, 95, 99) AS 'Perc'")
        # because each expanded percentile gets its own p-prefixed alias.
        # Without this, we'd get "Perc=p95=percentile(...)" (double-equals).
        def convert_multi_percentile(match):
            field = match.group(1).strip()
            percentiles_str = match.group(2).strip()
            percentiles = [p.strip() for p in percentiles_str.split(',') if p.strip()]
            
            if len(percentiles) <= 1:
                # Single percentile, no change needed
                return match.group(0)
            
            # Multiple percentiles - create separate calls
            calls = []
            for p in percentiles:
                calls.append(f"p{p}=percentile({field}, {p})")
            return ', '.join(calls)
        
        # Use a broader regex that also captures and discards trailing AS alias
        result = re.sub(
            r'\bpercentile\s*\(\s*([^,]+?)\s*,\s*(\d+(?:\s*,\s*\d+)+)\s*\)\s*(?:[Aa][Ss]\s+[\'"]?[\w\s]+[\'"]?)?',
            convert_multi_percentile,
            result,
            flags=re.IGNORECASE
        )
        
        # 9. Convert bucketPercentile(metric_bucket, p1, p2, ...) â†’ percentile(metric, p1), ...
        def convert_bucket_percentile(match):
            converted = self._bucket_percentile_converter.convert(match.group(0))
            return converted if converted else match.group(0)
        
        result = re.sub(
            r'\bbucketPercentile\s*\([^)]+\)',
            convert_bucket_percentile,
            result,
            flags=re.IGNORECASE
        )
        
        # =====================================================================
        # 10. MATH FUNCTION CONVERSIONS (verified against DQL docs 2025)
        # =====================================================================
        # NRQL pow(base, exp) â†’ DQL power(base, exp)
        result = re.sub(r'\bpow\s*\(', 'power(', result, flags=re.IGNORECASE)
        
        # NRQL log(x) â†’ DQL log(x)  [Both use log() for natural log - NO conversion needed]
        # (pass through - identical function name)
        
        # NRQL log2(x) â†’ DQL (log(x) / log(2))  [DQL has no native log2]
        def convert_log2(match):
            expr = match.group(1).strip()
            return f'(log({expr}) / log(2))'
        result = re.sub(
            r'\blog2\s*\(\s*([^)]+)\s*\)',
            convert_log2,
            result,
            flags=re.IGNORECASE
        )
        
        # NRQL log10(x) â†’ DQL log10(x)  [both are base-10, same name]
        # (no conversion needed, pass through)
        
        # abs, ceil, floor, round, sqrt, exp â†’ same names in DQL (pass through)
        # (no conversion needed, DQL has identical function names)
        
        # =====================================================================
        # 11. TYPE CASTING CONVERSIONS (verified against DQL docs 2025)
        # =====================================================================
        # NRQL numeric(x) â†’ DQL toDouble(x)
        result = re.sub(r'\bnumeric\s*\(', 'toDouble(', result, flags=re.IGNORECASE)
        
        # NRQL string(x) â†’ DQL toString(x)
        # Be careful: only match standalone string() function, not substring()
        result = re.sub(r'(?<!\w)string\s*\(', 'toString(', result, flags=re.IGNORECASE)
        
        # NRQL boolean(x) â†’ DQL toBoolean(x)
        result = re.sub(r'\bboolean\s*\(', 'toBoolean(', result, flags=re.IGNORECASE)
        
        # NRQL toDatetime(x) â†’ DQL toTimestamp(x)
        result = re.sub(r'\btoDatetime\s*\(', 'toTimestamp(', result, flags=re.IGNORECASE)
        
        # =====================================================================
        # 12. STRING FUNCTION CONVERSIONS (verified against DQL docs 2025)
        # =====================================================================
        # NRQL position(str, substr) â†’ DQL indexOf(str, substr)
        result = re.sub(r'\bposition\s*\(', 'indexOf(', result, flags=re.IGNORECASE)
        
        # NRQL trim(x) â†’ DQL trim(x)  [same name, pass through]
        
        # NRQL ltrim(x) â†’ DQL trim(x) [degraded: DQL has no ltrim, trim() removes both sides]
        result = re.sub(r'\bltrim\s*\(', 'trim(', result, flags=re.IGNORECASE)
        
        # NRQL rtrim(x) â†’ DQL trim(x) [degraded: DQL has no rtrim, trim() removes both sides]
        result = re.sub(r'\brtrim\s*\(', 'trim(', result, flags=re.IGNORECASE)
        
        # =====================================================================
        # 12a. NRQL length(x) â†’ DQL stringLength(x) [confirmed DQL docs Dec 2025]
        # Be careful not to match stringLength() itself (already converted)
        # =====================================================================
        result = re.sub(r'(?<!\w)length\s*\(', 'stringLength(', result, flags=re.IGNORECASE)
        
        # =====================================================================
        # 13. DATE/TIME EXTRACTION CONVERSIONS (verified against DQL docs 2025)
        # DQL uses: getDayOfMonth(), getDayOfWeek(), getMonth(), getYear(),
        #           getHour(), getMinute(), getSecond(), getWeekOfYear()
        # =====================================================================
        # NRQL dayOfMonth(ts) â†’ DQL getDayOfMonth(ts)
        result = re.sub(r'\bdayOfMonth\s*\(', 'getDayOfMonth(', result, flags=re.IGNORECASE)
        
        # NRQL monthOf(ts) â†’ DQL getMonth(ts)
        result = re.sub(r'\bmonthOf\s*\(', 'getMonth(', result, flags=re.IGNORECASE)
        
        # NRQL yearOf(ts) â†’ DQL getYear(ts)
        result = re.sub(r'\byearOf\s*\(', 'getYear(', result, flags=re.IGNORECASE)
        
        # NRQL hourOf(ts) â†’ DQL getHour(ts)
        result = re.sub(r'\bhourOf\s*\(', 'getHour(', result, flags=re.IGNORECASE)
        
        # NRQL minuteOf(ts) â†’ DQL getMinute(ts)
        result = re.sub(r'\bminuteOf\s*\(', 'getMinute(', result, flags=re.IGNORECASE)
        
        # NRQL weekOf(ts) â†’ DQL getWeekOfYear(ts)
        result = re.sub(r'\bweekOf\s*\(', 'getWeekOfYear(', result, flags=re.IGNORECASE)
        
        # NRQL dateOf(ts) â†’ DQL formatTimestamp(ts, format:"yyyy-MM-dd")
        def convert_dateOf(match):
            expr = match.group(1).strip()
            return f'formatTimestamp({expr}, format:"yyyy-MM-dd")'
        result = re.sub(
            r'\bdateOf\s*\(\s*([^)]+)\s*\)',
            convert_dateOf,
            result,
            flags=re.IGNORECASE
        )
        
        # =====================================================================
        # 14. AGGREGATION FUNCTION CONVERSIONS (verified against DQL docs 2025)
        # =====================================================================
        # NRQL uniques(field, N) â†’ DQL collectDistinct(field, maxLength:N)
        def convert_uniques(match):
            field = match.group(1).strip()
            limit = match.group(2)
            if limit:
                return f'collectDistinct({field}, maxLength:{limit.strip()})'
            return f'collectDistinct({field})'
        result = re.sub(
            r'\buniques\s*\(\s*([^,)]+)(?:\s*,\s*(\d+))?\s*\)',
            convert_uniques,
            result,
            flags=re.IGNORECASE
        )
        
        # NRQL buckets(field, N) â†’ DQL bin(field, N)  [approximate]
        result = re.sub(r'\bbuckets\s*\(', 'bin(', result, flags=re.IGNORECASE)
        
        # =====================================================================
        # 15. WINDOW FUNCTION CONVERSIONS (partial - DQL has no direct equiv)
        # NRQL windowSum/Avg/Count/Max/Min work on timeseries data
        # DQL requires array functions on timeseries output
        # We convert to comments with the closest DQL approach
        # =====================================================================
        window_funcs = {
            'windowSum': 'sum',
            'windowAvg': 'avg',
            'windowCount': 'count',
            'windowMax': 'max',
            'windowMin': 'min',
        }
        for nrql_func, dql_agg in window_funcs.items():
            pattern = rf'\b{nrql_func}\s*\(\s*([^,]+?)\s*,\s*(\d+)\s+(\w+)\s*\)'
            def make_window_converter(agg_fn):
                def convert_window(match):
                    inner_expr = match.group(1).strip()
                    window_size = match.group(2)
                    window_unit = match.group(3)
                    # DQL approach: use timeseries with rollup or post-process with array functions
                    return f'{inner_expr} /* TODO: NR {nrql_func}({window_size} {window_unit}) - use DQL: timeseries ... | fieldsAdd rolling=arrayCumulativeSum(val) or rollup parameter */'
                return convert_window
            result = re.sub(pattern, make_window_converter(dql_agg), result, flags=re.IGNORECASE)
        
        # =====================================================================
        # 16. HARD/IMPOSSIBLE CONVERSIONS (add actionable comments)
        # =====================================================================
        # NRQL histogram() â†’ DQL: summarize count(), by:{bin(field, width)}
        # Main handler at line ~3832 intercepts most cases; this is a safety net
        def convert_histogram(match):
            args = match.group(1).strip()
            parts = [a.strip() for a in args.split(',')]
            field = parts[0] if parts else 'duration'
            if field == 'duration.ms':
                field = 'duration'
            # Calculate bin width
            if len(parts) >= 4:
                width = parts[3]
            elif len(parts) >= 3:
                try:
                    width = str(int(float(parts[1]) / float(parts[2])))
                except (ValueError, ZeroDivisionError):
                    width = '1000'
            else:
                width = '1000'
            # Use DQL duration literal for duration field
            if field == 'duration':
                try:
                    width = ms_to_dql_duration(float(width))
                except ValueError:
                    width = '1s'
            return f'count(), by: {{bin({field}, {width})}}'
        result = re.sub(
            r'\bhistogram\s*\(\s*([^)]+)\s*\)',
            convert_histogram,
            result,
            flags=re.IGNORECASE
        )
        
        # NRQL predictLinear() â†’ No DQL equiv (Davis AI handles predictions)
        def convert_predictLinear(match):
            args = match.group(1).strip()
            return f'/* NR predictLinear({args}) - No DQL equiv. Use Davis AI anomaly detection or forecast APIs */'
        result = re.sub(
            r'\bpredictLinear\s*\(\s*([^)]+)\s*\)',
            convert_predictLinear,
            result,
            flags=re.IGNORECASE
        )
        
        # NRQL eventType() â†’ Not needed in DQL (data source specified in fetch)
        result = re.sub(
            r'\beventType\s*\(\s*\)',
            '/* NR eventType() - DQL: data source is specified in fetch command */',
            result,
            flags=re.IGNORECASE
        )
        
        return result
    
    def _convert_percentage_function(self, nrql: str) -> str:
        """
        Convert NR percentage() function to DQL equivalent.
        
        NR: percentage(count(*), WHERE duration > 1)
        DQL: 100.0 * countIf(duration > 1000000000) / count()
        
        NR: percentage(count(*), WHERE error IS NOT NULL)
        DQL: 100.0 * countIf(isNotNull(error)) / count()
        """
        result = nrql
        
        # Pattern: percentage(count(*), WHERE condition)
        pattern = r'\bpercentage\s*\(\s*count\s*\(\s*\*?\s*\)\s*,\s*WHERE\s+(.+?)\s*\)'
        
        def convert_pct(match):
            condition = match.group(1).strip()
            # Convert the condition to DQL syntax
            condition = self._convert_where_condition_only(condition)
            return f'(100.0 * countIf({condition}) / count())'
        
        result = re.sub(pattern, convert_pct, result, flags=re.IGNORECASE)
        
        return result
    
    def _convert_filter_function(self, nrql: str) -> str:
        """
        Convert NR filter() function to DQL funcIf() equivalent.
        
        NR: filter(average(duration), WHERE error IS NULL)
        DQL: avgIf(duration, isNull(error))
        
        NR: filter(sum(amount), WHERE status = 'completed')
        DQL: sumIf(amount, status == "completed")
        """
        result = nrql
        
        # Pattern: filter(func(field), WHERE condition)
        pattern = r'\bfilter\s*\(\s*(average|avg|sum|count|max|min)\s*\(\s*([^)]*)\s*\)\s*,\s*WHERE\s+(.+?)\s*\)'
        
        def convert_filter(match):
            func = match.group(1).lower()
            field = match.group(2).strip() or '*'
            condition = match.group(3).strip()
            
            # Map function names
            func_map = {
                'average': 'avgIf',
                'avg': 'avgIf',
                'sum': 'sumIf',
                'count': 'countIf',
                'max': 'maxIf',
                'min': 'minIf'
            }
            dt_func = func_map.get(func, f'{func}If')
            
            # Convert condition
            condition = self._convert_where_condition_only(condition)
            
            if field == '*' or not field:
                return f'{dt_func}({condition})'
            else:
                return f'{dt_func}({field}, {condition})'
        
        result = re.sub(pattern, convert_filter, result, flags=re.IGNORECASE)
        
        return result
    
    def _convert_apdex_function(self, nrql: str) -> str:
        """
        Convert NR apdex() function to DQL.
        
        NR: apdex(t:0.5)  â†’ Apdex with 0.5s threshold
        
        DQL approach 1: Use builtin metric
          builtin:service.apdex
        
        DQL approach 2: Calculate manually
          (countIf(duration < threshold) + countIf(duration >= threshold and duration < 4*threshold) / 2) / count()
        """
        result = nrql
        
        # Pattern: apdex(t:threshold) or apdex(duration, t:threshold)
        pattern = r'\bapdex\s*\(\s*(?:duration\s*,\s*)?t\s*:\s*(\d+(?:\.\d+)?)\s*\)'
        
        def convert_apdex(match):
            threshold_sec = float(match.group(1))
            threshold_ns = int(threshold_sec * 1000000000)  # Convert to nanoseconds
            tolerating_ns = threshold_ns * 4
            
            # Return a calculated Apdex formula
            return f'((countIf(duration < {threshold_ns}) + 0.5 * countIf(duration >= {threshold_ns} and duration < {tolerating_ns})) / count())'
        
        result = re.sub(pattern, convert_apdex, result, flags=re.IGNORECASE)
        
        return result
    
    def _convert_cdf_percentage_function(self, nrql: str) -> str:
        """
        Convert NR cdfPercentage() function to DQL.
        
        NR: cdfPercentage(duration.ms, 1000, 2000, 4000, 6000)
        
        DQL approach: Use summarize with countIf, then calculate percentages
        For TIMESERIES queries, this needs special handling in the query builder.
        
        We mark the query with a special token that the builder will expand.
        """
        result = nrql
        
        # Pattern: cdfPercentage(field, threshold1, threshold2, ...)
        pattern = r'\bcdfPercentage\s*\(\s*([^,]+)\s*,\s*([^)]+)\s*\)'
        
        def convert_cdf(match):
            field = match.group(1).strip()
            thresholds_str = match.group(2).strip()
            
            # Parse thresholds (comma-separated numbers)
            thresholds = [float(t.strip()) for t in thresholds_str.split(',') if t.strip()]
            
            # Determine if field is in ms (duration.ms) or already ns
            is_ms = '.ms' in field.lower()
            field_clean = re.sub(r'\.ms$', '', field, flags=re.IGNORECASE)
            
            # Map field name
            if field_clean.lower() == 'duration':
                dt_field = 'duration'
            else:
                dt_field = field_clean
            
            # Build countIf expressions for each threshold
            # These are simple aggregations that makeTimeseries can handle
            bucket_exprs = ['__cdf_total__=count()']
            for t in thresholds:
                # Convert threshold to nanoseconds for DT
                if is_ms:
                    threshold_ns = int(t * 1000000)  # ms to ns
                    label = f"under_{int(t)}ms"
                else:
                    threshold_ns = int(t * 1000000000)  # seconds to ns
                    label = f"under_{t}s"
                
                bucket_exprs.append(f'__cdf_{label}__=countIf({dt_field} < {threshold_ns})')
            
            return ', '.join(bucket_exprs)
        
        result = re.sub(pattern, convert_cdf, result, flags=re.IGNORECASE)
        
        return result
    
    def _convert_where_condition_only(self, condition: str) -> str:
        """
        Convert just a WHERE condition (not the whole clause) to DQL syntax.
        Used by percentage() and filter() converters.
        """
        result = condition
        
        # IS NULL â†’ isNull()
        result = re.sub(r'(\w+)\s+IS\s+NULL', r'isNull(\1)', result, flags=re.IGNORECASE)
        
        # IS NOT NULL â†’ isNotNull()
        result = re.sub(r'(\w+)\s+IS\s+NOT\s+NULL', r'isNotNull(\1)', result, flags=re.IGNORECASE)
        
        # Single = to ==
        result = re.sub(r"(\w+)\s*=\s*'([^']+)'", r'\1 == "\2"', result)
        result = re.sub(r'(\w+)\s*=\s*"([^"]+)"', r'\1 == "\2"', result)
        result = re.sub(r'(\w+)\s*=\s*(\d+)', r'\1 == \2', result)
        
        # != stays as !=
        # >, <, >=, <= stay as is
        
        # AND/OR to lowercase
        result = re.sub(r'\bAND\b', 'and', result, flags=re.IGNORECASE)
        result = re.sub(r'\bOR\b', 'or', result, flags=re.IGNORECASE)
        result = re.sub(r'\bNOT\b', 'not', result, flags=re.IGNORECASE)
        
        return result
    
    def _map_attribute(self, attr: str) -> str:
        """Map NR attribute to DT attribute"""
        attr_clean = attr.strip()
        attr_lower = attr_clean.lower()
        
        # Direct lookup first (exact match)
        if attr_lower in ATTR_MAP:
            return ATTR_MAP[attr_lower]
        
        # Try without dots/underscores for normalized lookup
        attr_key = attr_lower.replace('.', '').replace('_', '')
        if attr_key in ATTR_MAP:
            return ATTR_MAP[attr_key]
        
        # Return as-is if no mapping found
        return attr_clean
    
    def _convert_facet(self, facet_clause: str) -> str:
        """Convert FACET clause to DQL by clause. Returns empty string for unconvertible CASES()."""
        
        # Handle NRQL CASES() - convert to DQL if() expressions
        # CASES(WHERE condition1 AS 'label1', WHERE condition2 AS 'label2')
        # DT equivalent: if(condition1, "label1", if(condition2, "label2", "other"))
        if re.search(r'\bCASES\s*\(', facet_clause, re.IGNORECASE):
            
            # Try to extract and convert CASES to if() chain
            cases_match = re.search(
                r'CASES\s*\((.+)\)',
                facet_clause,
                re.IGNORECASE | re.DOTALL
            )
            
            if cases_match:
                cases_content = cases_match.group(1)
                
                # Parse individual CASE conditions: WHERE condition AS 'label'
                case_pattern = r"WHERE\s+(.+?)\s+AS\s+['\"]([^'\"]+)['\"]"
                cases = re.findall(case_pattern, cases_content, re.IGNORECASE)
                
                if cases:
                    # Build DQL if() chain
                    # if(condition1, "label1", if(condition2, "label2", "other"))
                    if_expr = self._build_if_chain(cases)
                    return if_expr
            
            # If we couldn't parse it, return empty - caller should skip by: clause
            return ""
        
        fields = [f.strip() for f in facet_clause.split(',')]
        converted = [self._map_attribute(f) for f in fields]
        return ', '.join(converted)
    
    def _build_if_chain(self, cases: list) -> str:
        """Build nested if() expression from CASES conditions"""
        if not cases:
            return '"other"'
        
        # Convert conditions to DQL syntax
        converted_cases = []
        for condition, label in cases:
            # Convert the condition to DQL
            dql_condition = self._convert_condition_to_dql(condition)
            converted_cases.append((dql_condition, label))
        
        # Build nested if: if(cond1, "label1", if(cond2, "label2", "other"))
        result = '"other"'
        for condition, label in reversed(converted_cases):
            result = f'if({condition}, "{label}", else:{result})'
        
        return result
    
    def _convert_condition_to_dql(self, condition: str) -> str:
        """Convert a single NRQL condition to DQL syntax"""
        result = condition.strip()
        
        # Handle common operators
        # = to ==
        result = re.sub(r'(?<![!<>=])\s*=\s*(?![=])', ' == ', result)
        # Single quotes to double quotes
        result = re.sub(r"'([^']*)'", r'"\1"', result)
        # Map common attributes
        result = self._map_attribute(result)
        
        return result
    
    def _convert_where(self, where_clause: str) -> str:
        """Convert WHERE clause to DQL filter"""
        result = where_clause
        
        # CRITICAL: Handle entity.guid - these are NR-specific and won't work in DT
        # Detect base64-looking GUIDs (NR format)
        guid_pattern = r"entity\.guid\s*=+\s*['\"]([A-Za-z0-9+/=]{20,})['\"]"
        guid_matches = re.findall(guid_pattern, result, re.IGNORECASE)
        
        for guid in guid_matches:
            # Check if we have a cached name for this GUID
            if guid in self._guid_cache:
                entity_name = self._guid_cache[guid]
                entity_type = self._guid_types.get(guid, '')
                
                # Generate appropriate DT replacement based on entity type
                if entity_type == 'SERVICE_LEVEL':
                    self._detected_slos.add(guid)  # Track detection
                    replacement = f'slo.name == "{entity_name}"'
                    self._current_warnings.append(f"SLO GUID resolved to: {entity_name} â†’ Use: fetch slo | filter slo.name == \"{entity_name}\"")
                elif entity_type in ('APM_APPLICATION', 'APPLICATION', 'SERVICE'):
                    replacement = f'service.name == "{entity_name}"'
                    self._current_warnings.append(f"Service GUID resolved to: {entity_name}")
                else:
                    replacement = f'dt.entity.name == "{entity_name}"'
                    self._current_warnings.append(f"GUID resolved to: {entity_name}")
            else:
                # Try to decode GUID to get entity type
                try:
                    import base64
                    padded = guid + '=' * (4 - len(guid) % 4) if len(guid) % 4 else guid
                    decoded = base64.b64decode(padded).decode('utf-8')
                    parts = decoded.split('|')
                    entity_type = parts[2] if len(parts) > 2 else ''
                    
                    if entity_type == 'SERVICE_LEVEL':
                        # Track this SLO detection
                        self._detected_slos.add(guid)
                        # This is an SLO - use the integrated handler
                        replacement, warning = self._handle_slo_guid(guid)
                        self._current_warnings.append(warning)
                    else:
                        replacement = '__GUID_PLACEHOLDER__'
                        self._current_warnings.append(f"GUID filter detected ({entity_type}) - replace with dt.entity filter. Example: dt.entity.name == \"your-svc-name\"")
                except:
                    replacement = '__GUID_PLACEHOLDER__'
                    self._current_warnings.append(f"GUID filter detected - replace with dt.entity filter. Example: dt.entity.name == \"your-svc-name\"")
            
            # Replace this specific GUID
            result = re.sub(
                rf"entity\.guid\s*=+\s*['\"]" + re.escape(guid) + r"['\"]",
                replacement,
                result,
                flags=re.IGNORECASE
            )
        
        # Also catch entityGuid (camelCase variant)
        entity_guid_pattern = r"entityGuid\s*=+\s*['\"]([A-Za-z0-9+/=]{20,})['\"]"
        guid_matches2 = re.findall(entity_guid_pattern, result, re.IGNORECASE)
        
        for guid in guid_matches2:
            if guid in self._guid_cache:
                entity_name = self._guid_cache[guid]
                entity_type = self._guid_types.get(guid, '')
                
                if entity_type == 'SERVICE_LEVEL':
                    self._detected_slos.add(guid)  # Track detection
                    replacement = f'slo.name == "{entity_name}"'
                    self._current_warnings.append(f"SLO GUID resolved: {entity_name}")
                else:
                    replacement = f'service.name == "{entity_name}"'
                    self._current_warnings.append(f"GUID resolved to: {entity_name}")
            else:
                # Try to decode and check if SLO
                try:
                    import base64
                    padded = guid + '=' * (4 - len(guid) % 4) if len(guid) % 4 else guid
                    decoded = base64.b64decode(padded).decode('utf-8')
                    parts = decoded.split('|')
                    entity_type = parts[2] if len(parts) > 2 else ''
                    
                    if entity_type == 'SERVICE_LEVEL':
                        self._detected_slos.add(guid)  # Track detection
                        replacement, warning = self._handle_slo_guid(guid)
                        self._current_warnings.append(warning)
                    else:
                        replacement = '__GUID_PLACEHOLDER__'
                        self._current_warnings.append("entityGuid filter detected - replace with dt.entity filter")
                except:
                    replacement = '__GUID_PLACEHOLDER__'
                    self._current_warnings.append("entityGuid filter detected - replace with dt.entity filter")
            
            result = re.sub(
                rf"entityGuid\s*=+\s*['\"]" + re.escape(guid) + r"['\"]",
                replacement,
                result,
                flags=re.IGNORECASE
            )
        
        # Handle NOT LIKE first (before LIKE to avoid partial matches)
        # NOT LIKE '%value%' -> not(contains(field, "value"))
        def convert_not_like(match):
            field = match.group(1)
            pattern = match.group(2)
            value = pattern.strip('%')
            return f'not(contains({field}, "{value}"))'
        
        result = re.sub(
            r"(\w+[\w.]*)\s+NOT\s+LIKE\s+['\"]([^'\"]+)['\"]",
            convert_not_like,
            result,
            flags=re.IGNORECASE
        )
        
        # Handle LIKE
        # LIKE '%value%' -> contains(field, "value")
        # LIKE 'value%' -> startsWith(field, "value")
        # LIKE '%value' -> endsWith(field, "value")
        def convert_like(match):
            field = match.group(1)
            pattern = match.group(2)
            starts_wild = pattern.startswith('%')
            ends_wild = pattern.endswith('%')
            value = pattern.strip('%')
            
            if starts_wild and ends_wild:
                return f'contains({field}, "{value}")'
            elif starts_wild:
                return f'endsWith({field}, "{value}")'
            elif ends_wild:
                return f'startsWith({field}, "{value}")'
            else:
                return f'{field} == "{value}"'
        
        result = re.sub(
            r"(\w+[\w.]*)\s+LIKE\s+['\"]([^'\"]+)['\"]",
            convert_like,
            result,
            flags=re.IGNORECASE
        )
        
        # Handle RLIKE (regex): field RLIKE 'pattern' -> matchesPhrase(field, "pattern")
        # Also handles: field NOT RLIKE 'pattern' -> not(matchesPhrase(field, "pattern"))
        # Note: DQL has limited regex support via matchesPhrase
        def convert_rlike(match):
            field = match.group(1)
            negated = match.group(2) is not None
            pattern = match.group(3)
            func = f'matchesPhrase({field}, "{pattern}")'
            if negated:
                func = f'not({func})'
            return func
        
        result = re.sub(
            r"(\w+[\w.]*)\s+(NOT\s+)?RLIKE\s+['\"]([^'\"]+)['\"]",
            convert_rlike,
            result,
            flags=re.IGNORECASE
        )
        
        # Handle IN clauses: field IN ('a', 'b', 'c') -> in(field, "a", "b", "c")
        # Also handles: field NOT IN ('a', 'b') -> not(in(field, "a", "b"))
        def convert_in_clause(match):
            field = match.group(1)
            negated = match.group(2) is not None
            values_str = match.group(3)
            # Convert single quotes to double quotes and clean up
            values_str = values_str.replace("'", '"')
            func = f'in({field}, {values_str})'
            if negated:
                func = f'not({func})'
            return func
        
        result = re.sub(
            r"(\w+[\w.]*)\s+(NOT\s+)?IN\s*\(([^)]+)\)",
            convert_in_clause,
            result,
            flags=re.IGNORECASE
        )
        
        # Handle BETWEEN: field BETWEEN x AND y -> field >= x and field <= y
        # Also handles: field NOT BETWEEN x AND y -> (field < x or field > y)
        def convert_between(match):
            field = match.group(1)
            negated = match.group(2) is not None
            low = match.group(3)
            high = match.group(4)
            if negated:
                return f'({field} < {low} or {field} > {high})'
            return f'({field} >= {low} and {field} <= {high})'
        
        result = re.sub(
            r"(\w+[\w.]*)\s+(NOT\s+)?BETWEEN\s+([^\s]+)\s+AND\s+([^\s]+)",
            convert_between,
            result,
            flags=re.IGNORECASE
        )
        
        # Handle IS NOT NULL -> isNotNull()
        result = re.sub(
            r"(\w+[\w.]*)\s+IS\s+NOT\s+NULL",
            r'isNotNull(\1)',
            result,
            flags=re.IGNORECASE
        )
        
        # Handle IS NULL -> isNull()
        result = re.sub(
            r"(\w+[\w.]*)\s+IS\s+NULL\b",
            r'isNull(\1)',
            result,
            flags=re.IGNORECASE
        )
        
        # Handle IS true/false -> == true/false
        result = re.sub(r'\bIS\s+true\b', '== true', result, flags=re.IGNORECASE)
        result = re.sub(r'\bIS\s+false\b', '== false', result, flags=re.IGNORECASE)
        
        # Handle AND/OR - convert to lowercase
        result = re.sub(r'\bAND\b', 'and', result)
        result = re.sub(r'\bOR\b', 'or', result)
        result = re.sub(r'\bNOT\b', 'not', result)
        
        # Handle single quotes -> double quotes for string values
        # But be careful not to change != to !==
        # Pattern: only change = 'value' when = is not preceded by ! < >
        result = re.sub(r"(?<![!<>])=\s*'([^']*)'", r'== "\1"', result)
        
        # Also handle != 'value' -> != "value" (just quote change, keep !=)
        result = re.sub(r"!=\s*'([^']*)'", r'!= "\1"', result)
        
        # Handle single = for comparison (not part of != >= <= ==)
        # Only convert standalone = to == when followed by a value (not another =)
        result = re.sub(r'(?<![!<>=])\s*=\s*(?![=])', ' == ', result)
        
        # Sort by length descending to replace longer matches first
        sorted_attrs = sorted(ATTR_MAP.items(), key=lambda x: len(x[0]), reverse=True)
        
        for nr_attr, dt_attr in sorted_attrs:
            # Match attribute names that are NOT preceded by a dot (to avoid matching parts of DT paths like service.name)
            # Also require word boundary at end
            pattern = r'(?<![.\w])' + re.escape(nr_attr) + r'(?![.\w])'
            result = re.sub(pattern, dt_attr, result, flags=re.IGNORECASE)
        
        # Also handle NR metric fields that might appear in WHERE clauses
        # These are typically used as filter conditions for K8s metrics
        metric_in_filter = {
            'allocatableMemoryUtilization': 'dt.kubernetes.node.memory_allocatable_utilization',
            'memoryUsedBytes': 'dt.kubernetes.node.memory_used',
            'memoryAvailableBytes': 'dt.kubernetes.node.memory_available',
            'fsCapacityUtilization': 'dt.kubernetes.node.filesystem_utilization',
            'fsAvailableBytes': 'dt.kubernetes.node.filesystem_available',
            'fsInodesUsed': 'dt.kubernetes.node.filesystem_inodes_used',
            'fsInodes': 'dt.kubernetes.node.filesystem_inodes_total',
        }
        
        for nr_field, dt_field in metric_in_filter.items():
            if nr_field in result:
                # These fields in WHERE clauses won't work the same way in DT
                # Add a comment but leave as-is for manual fixing
                pass  # We'll handle this via notes in the query builder
        
        # Replace GUID placeholder with actual comment (after attribute mapping is done)
        result = result.replace(
            '__GUID_PLACEHOLDER__',
            '/* REPLACE WITH: service.name == "your-service-name" OR dt.entity.service == "SERVICE-XXXXX" */'
        )
        
        # Convert duration values with units to nanoseconds (DT native unit)
        # Handles: 500ms, 1s, 5m, 1h, 2d
        def convert_duration_unit(match):
            value = float(match.group(1))
            unit = match.group(2).lower()
            
            # Convert to nanoseconds
            multipliers = {
                'ns': 1,
                'us': 1000,
                'ms': 1000000,
                's': 1000000000,
                'm': 60000000000,
                'h': 3600000000000,
                'd': 86400000000000,
            }
            multiplier = multipliers.get(unit, 1000000)  # default to ms
            ns_value = int(value * multiplier)
            return str(ns_value)
        
        # Match duration values with units (only when following comparison operators)
        result = re.sub(
            r'(>=|<=|>|<|==|!=)\s*(\d+(?:\.\d+)?)(ns|us|ms|s|m|h|d)\b',
            lambda m: f'{m.group(1)} {convert_duration_unit(type("", (), {"group": lambda s, i: m.group(i+1)})())}',
            result,
            flags=re.IGNORECASE
        )
        
        # Simpler pattern for duration units after operators
        def replace_duration_with_unit(match):
            operator = match.group(1)
            value = float(match.group(2))
            unit = match.group(3).lower()
            multipliers = {'ns': 1, 'us': 1000, 'ms': 1000000, 's': 1000000000, 'm': 60000000000, 'h': 3600000000000}
            ns_value = int(value * multipliers.get(unit, 1000000))
            return f'{operator} {ns_value}'
        
        result = re.sub(
            r'(>=|<=|>|<|==|!=)\s*(\d+(?:\.\d+)?)(ns|us|ms|s|m|h|d)\b',
            replace_duration_with_unit,
            result,
            flags=re.IGNORECASE
        )
        
        # Convert duration.ms to duration (DT uses nanoseconds natively)
        # Values need to be multiplied by 1000000 when comparing to ms
        def convert_duration_ms(match):
            operator = match.group(1)  # >= <= > < == !=
            value = match.group(2)  # numeric value
            # Convert ms to nanoseconds (multiply by 1,000,000)
            try:
                ns_value = int(float(value) * 1000000)
                return f'duration {operator} {ns_value}'
            except:
                return f'duration {operator} {value}000000'
        
        result = re.sub(
            r'\bduration\.ms\s*(>=|<=|>|<|==|!=)\s*(\d+(?:\.\d+)?)',
            convert_duration_ms,
            result,
            flags=re.IGNORECASE
        )
        
        # Also handle standalone duration.ms (without operator, e.g., in select)
        result = re.sub(r'\bduration\.ms\b', 'duration', result, flags=re.IGNORECASE)
        
        return result
    
    def _parse_select_fields(self, select_clause: str) -> List[str]:
        """Parse field names from SELECT clause"""
        # Remove aggregation functions
        cleaned = re.sub(r'\w+\s*\([^)]*\)', '', select_clause)
        # Split by comma and clean
        fields = [f.strip() for f in cleaned.split(',') if f.strip()]
        # Remove aliases (AS ...)
        fields = [re.sub(r'\s+AS\s+\w+', '', f, flags=re.IGNORECASE).strip() for f in fields]
        return [f for f in fields if f and f != '*']
    
    # NRQL Parsing helpers
    def _extract_from(self, nrql: str) -> Optional[str]:
        match = re.search(r'\bFROM\s+(\w+)', nrql, re.IGNORECASE)
        return match.group(1).lower() if match else None
    
    def _extract_select(self, nrql: str) -> Optional[str]:
        # Handle both orderings: SELECT...FROM and FROM...SELECT
        # Must be quote-aware to avoid matching FROM inside string literals
        
        # Find SELECT keyword
        select_match = re.search(r'\bSELECT\s+', nrql, re.IGNORECASE)
        if not select_match:
            return None
        
        start = select_match.end()
        
        # Walk forward tracking quote state to find the real FROM keyword
        in_single_quote = False
        in_double_quote = False
        i = start
        while i < len(nrql):
            ch = nrql[i]
            if ch == "'" and not in_double_quote:
                in_single_quote = not in_single_quote
            elif ch == '"' and not in_single_quote:
                in_double_quote = not in_double_quote
            elif not in_single_quote and not in_double_quote:
                # Check for FROM keyword (word boundary)
                if nrql[i:i+4].upper() == 'FROM' and (i == 0 or not nrql[i-1].isalnum()):
                    after = i + 4
                    if after >= len(nrql) or not nrql[after].isalnum():
                        return nrql[start:i].strip()
            i += 1
        
        # No FROM found â€” return everything after SELECT
        return nrql[start:].strip()
    
    def _extract_where(self, nrql: str) -> Optional[str]:
        # NR allows WHERE after FACET, so handle both orders
        # IMPORTANT: Don't match 'where' inside function calls like percentage(count(x), where y)
        
        # First, temporarily replace 'where' inside function calls
        # Pattern: inside parentheses, replace 'where' with placeholder
        def protect_inner_where(s):
            result = []
            depth = 0
            i = 0
            while i < len(s):
                if s[i] == '(':
                    depth += 1
                    result.append(s[i])
                elif s[i] == ')':
                    depth -= 1
                    result.append(s[i])
                elif depth > 0 and s[i:i+5].upper() == 'WHERE':
                    result.append('__INNER_WHERE__')
                    i += 4  # skip rest of 'where'
                else:
                    result.append(s[i])
                i += 1
            return ''.join(result)
        
        protected_nrql = protect_inner_where(nrql)
        
        # Now extract WHERE from the protected string
        match = re.search(
            r'\bWHERE\s+(.+?)(?:\bFACET\b|\bSINCE\b|\bUNTIL\b|\bLIMIT\b|\bTIMESERIES\b|\bCOMPARE\b|$)',
            protected_nrql, re.IGNORECASE
        )
        if match:
            result = match.group(1).strip()
            # Restore any inner WHERE placeholders
            result = result.replace('__INNER_WHERE__', 'where')
            return result
        
        # Also try WHERE after FACET (NR flexible syntax)
        match = re.search(
            r'\bFACET\s+[^W]+\bWHERE\s+(.+?)(?:\bSINCE\b|\bUNTIL\b|\bLIMIT\b|\bTIMESERIES\b|\bCOMPARE\b|$)',
            protected_nrql, re.IGNORECASE
        )
        if match:
            result = match.group(1).strip()
            result = result.replace('__INNER_WHERE__', 'where')
            return result
        
        return None
    
    def _extract_facet(self, nrql: str) -> Optional[str]:
        # First check if we have CASES() - need special handling
        cases_match = re.search(r'\bFACET\s+(CASES\s*\(.+?\))\s*(?:TIMESERIES|SINCE|UNTIL|LIMIT|COMPARE|$)', nrql, re.IGNORECASE | re.DOTALL)
        if cases_match:
            # Found CASES() - need to properly match the parentheses
            facet_start = nrql.upper().find('FACET')
            if facet_start == -1:
                return None
            
            # Find the CASES( 
            cases_start = nrql.upper().find('CASES(', facet_start)
            if cases_start == -1:
                return None
            
            # Match the closing parenthesis
            paren_count = 0
            end_pos = cases_start
            for i, char in enumerate(nrql[cases_start:]):
                if char == '(':
                    paren_count += 1
                elif char == ')':
                    paren_count -= 1
                    if paren_count == 0:
                        end_pos = cases_start + i + 1
                        break
            
            facet = nrql[facet_start + 6:end_pos].strip()  # +6 for "FACET "
            return facet
        
        # Standard facet extraction
        match = re.search(
            r'\bFACET\s+(.+?)(?:\bWHERE\b|\bSINCE\b|\bUNTIL\b|\bLIMIT\b|\bTIMESERIES\b|\bCOMPARE\b|$)',
            nrql, re.IGNORECASE
        )
        if match:
            facet = match.group(1).strip()
            # Remove backticks and map field names
            facet = re.sub(r'`([^`]+)`', r'\1', facet)
            return facet
        return None
    
    def _extract_limit(self, nrql: str) -> Optional[int]:
        match = re.search(r'\bLIMIT\s+(\d+)', nrql, re.IGNORECASE)
        return int(match.group(1)) if match else None


# ============================================================================
# LAYOUT CONVERTER
# ============================================================================

class LayoutConverter:
    """Converts NR widget layout to DT tile positioning"""
    
    # NR uses a 12-column grid, DT uses a different system
    # NR: column (1-12), row, width, height
    # DT new dashboards: tiles are positioned in a grid layout
    
    def convert_layout(self, nr_layout: Dict) -> Dict:
        """Convert NR widget layout to DT tile layout"""
        if not nr_layout:
            return {}
        
        # Extract NR positioning
        nr_col = nr_layout.get('column', 1)
        nr_row = nr_layout.get('row', 1)
        nr_width = nr_layout.get('width', 4)
        nr_height = nr_layout.get('height', 3)
        
        # DT uses a similar grid system for new dashboards
        # Scale appropriately (NR is 12-col, DT varies)
        dt_layout = {
            "x": (nr_col - 1),  # Convert 1-indexed to 0-indexed
            "y": (nr_row - 1),
            "w": nr_width,
            "h": nr_height
        }
        
        return dt_layout


# ============================================================================
# NEW RELIC CLIENT
# ============================================================================

class NewRelicClient:
    """Client for New Relic NerdGraph API"""
    
    def __init__(self, api_key: str, account_id: str):
        self.api_key = api_key
        self.account_id = account_id
        self.headers = {
            "Content-Type": "application/json",
            "Api-Key": api_key
        }
    
    def _execute(self, query: str) -> Dict:
        payload = {"query": query}
        response = requests.post(NR_GRAPHQL_URL, headers=self.headers, json=payload)
        
        if response.status_code != 200:
            raise Exception(f"NerdGraph error: {response.status_code} - {response.text}")
        
        result = response.json()
        if "errors" in result:
            raise Exception(f"NerdGraph errors: {result['errors']}")
        
        return result.get("data", {})
    
    def get_dashboard(self, guid: str) -> Dict:
        """Fetch dashboard with full widget and layout details"""
        query = f"""
        {{
            actor {{
                entity(guid: "{guid}") {{
                    ... on DashboardEntity {{
                        guid
                        name
                        description
                        permissions
                        pages {{
                            guid
                            name
                            description
                            widgets {{
                                id
                                title
                                layout {{
                                    column
                                    row
                                    width
                                    height
                                }}
                                visualization {{
                                    id
                                }}
                                rawConfiguration
                            }}
                        }}
                    }}
                }}
            }}
        }}
        """
        
        data = self._execute(query)
        entity = data.get("actor", {}).get("entity", {})
        
        if not entity:
            raise Exception(f"Dashboard not found: {guid}")
        
        return entity
    
    def list_dashboards(self) -> List[Dict]:
        """List all dashboards in the account"""
        query = f"""
        {{
            actor {{
                entitySearch(query: "type = 'DASHBOARD' AND accountId = '{self.account_id}'") {{
                    results {{
                        entities {{
                            ... on DashboardEntityOutline {{
                                guid
                                name
                                accountId
                            }}
                        }}
                    }}
                }}
            }}
        }}
        """
        
        data = self._execute(query)
        entities = data.get("actor", {}).get("entitySearch", {}).get("results", {}).get("entities", [])
        return entities


# ============================================================================
# DYNATRACE CLIENT
# ============================================================================

class DynatraceClient:
    """Client for Dynatrace Documents API (Platform APIs - require Bearer token)"""
    
    def __init__(self, env_url: str, api_token: str):
        self.env_url = env_url.rstrip('/')
        self.api_token = api_token
        # Platform APIs ALWAYS require Bearer token
        self.headers = {
            "Authorization": f"Bearer {api_token}"
        }
    
    def discover_schema_version(self) -> Optional[int]:
        """
        Query an existing dashboard to discover the current DT schema version.
        Returns the version int, or None if no dashboards exist / can't be read.
        """
        url = f"{self.env_url}/platform/document/v1/documents?filter=type%3D%3D'dashboard'&page-size=1"
        try:
            response = requests.get(url, headers=self.headers)
            if response.status_code != 200:
                return None
            data = response.json()
            documents = data.get('documents', [])
            if not documents:
                return None
            # Fetch the first dashboard's content
            doc_id = documents[0].get('id')
            if not doc_id:
                return None
            doc_url = f"{self.env_url}/platform/document/v1/documents/{doc_id}"
            doc_resp = requests.get(doc_url, headers=self.headers)
            if doc_resp.status_code != 200:
                return None
            # Content may come as multipart; try to extract version
            content_type = doc_resp.headers.get('Content-Type', '')
            if 'multipart' in content_type:
                match = re.search(r'"version"\s*:\s*(\d+)', doc_resp.text)
                if match:
                    return int(match.group(1))
            else:
                try:
                    content = doc_resp.json()
                    if isinstance(content, dict) and 'version' in content:
                        return int(content['version'])
                except:
                    pass
            return None
        except Exception as e:
            print(f"    âš  Could not discover schema version: {e}")
            return None

    def create_dashboard(self, name: str, content: Dict) -> str:
        """Create a new dashboard, returns document ID"""
        url = f"{self.env_url}/platform/document/v1/documents"
        
        content_json = json.dumps(content, indent=2)
        
        files = {
            'content': (f'{name}.json', content_json, 'application/json')
        }
        
        data = {
            'name': name,
            'type': 'dashboard',
            'isPrivate': 'false'
        }
        
        response = requests.post(url, headers=self.headers, files=files, data=data)
        
        if response.status_code not in [200, 201]:
            raise Exception(f"Failed to create dashboard: {response.status_code} - {response.text}")
        
        # Parse response to get ID
        doc_id = self._extract_id_from_response(response)
        
        # Share with everyone in the environment
        self._share_with_everyone(doc_id)
        
        return doc_id
    
    def _share_with_everyone(self, doc_id: str):
        """Make dashboard visible to everyone by setting isPrivate to false"""
        # First get the document to get its version for optimistic locking
        get_url = f"{self.env_url}/platform/document/v1/documents/{doc_id}"
        
        try:
            # Get current version
            response = requests.get(get_url, headers=self.headers)
            if response.status_code != 200:
                print(f"    âš  Could not get document for sharing: {response.status_code}")
                return
            
            # Extract version from response
            version = None
            content_type = response.headers.get('Content-Type', '')
            if 'multipart' in content_type:
                match = re.search(r'"version"\s*:\s*"([^"]+)"', response.text)
                if match:
                    version = match.group(1)
            else:
                try:
                    data = response.json()
                    version = data.get('version', '')
                except:
                    pass
            
            if not version:
                print(f"    âš  Could not get document version for sharing")
                return
            
            # Update document to make it public
            update_url = f"{self.env_url}/platform/document/v1/documents/{doc_id}"
            update_data = {
                'isPrivate': 'false',
                'optimisticLockingVersion': version
            }
            
            update_response = requests.patch(
                update_url,
                headers=self.headers,
                data=update_data
            )
            
            if update_response.status_code in [200, 204]:
                print(f"    âœ“ Dashboard visible to everyone")
            else:
                print(f"    âš  Could not share dashboard: {update_response.status_code} - {update_response.text[:200]}")
        except Exception as e:
            print(f"    âš  Could not share dashboard: {str(e)}")
    
    def _extract_id_from_response(self, response) -> str:
        """Extract document ID from multipart response"""
        content_type = response.headers.get('Content-Type', '')
        
        if 'multipart' in content_type:
            text = response.text
            match = re.search(r'"id"\s*:\s*"([^"]+)"', text)
            if match:
                return match.group(1)
        else:
            try:
                data = response.json()
                return data.get('id', '')
            except:
                pass
        
        return "unknown"


# ============================================================================
# DT ENVIRONMENT REGISTRY â€” Live validation against the real environment
# ============================================================================

class DTEnvironmentRegistry:
    """
    Central registry that lazy-loads live data from the Dynatrace environment.
    
    Provides:
      - Metric Registry:    Validate dt.* metric keys exist, fuzzy-find corrections
      - Entity Registry:    Resolve service/host/process names and IDs
      - Dashboard Registry: Check for existing dashboards before creating duplicates
      - Management Zone Registry: Map NR account/policy scope to DT zones
      - Synthetic Location Registry: Map NR locations to DT public/private locations
    
    All registries are lazy-loaded â€” only fetched when first accessed.
    Shared across SLOAuditor, NRQLtoDQLConverter, DashboardMigrator, etc.
    
    APIs used:
      Metrics v2:      GET /api/v2/metrics               (.live.)
      Entities v2:     GET /api/v2/entities               (.live.)
      Documents v1:    GET /platform/document/v1/documents (.apps.)
      Settings v2:     GET /api/v2/settings/objects        (.live.)
      Synthetic v2:    GET /api/v2/synthetic/locations      (.live.)
    """
    
    # Semantic synonyms for fuzzy matching (metrics + entities)
    SYNONYMS = {
        'error': {'failure', 'errors', 'failed'},
        'failure': {'error', 'errors', 'failed'},
        'errors': {'error', 'failure', 'failed'},
        'failed': {'error', 'failure', 'errors'},
        'response': {'response_time', 'responsetime', 'latency', 'duration'},
        'latency': {'response', 'response_time', 'duration'},
        'time': {'response_time', 'duration'},
        'success': {'successes', 'successcount'},
        'successes': {'success', 'successcount'},
        'total': {'count', 'all'},
        'bytes': {'bytes_rx', 'bytes_tx', 'bytesrx', 'bytestx'},
        'rx': {'bytes_rx', 'received'},
        'tx': {'bytes_tx', 'sent'},
        'memory': {'mem', 'ram'},
        'mem': {'memory', 'ram'},
        'cpu': {'processor', 'compute'},
        'disk': {'storage', 'volume'},
        'net': {'network', 'nic'},
        'network': {'net', 'nic'},
    }
    
    def __init__(self, dt_url: str, oauth_token: str = '', api_token: str = ''):
        """
        Args:
            dt_url: Base DT environment URL (either .apps. or .live.)
            oauth_token: OAuth Bearer token for Platform APIs
            api_token: Api-Token for Classic APIs (Metrics v2, Entities v2)
        """
        self.dt_url = dt_url.rstrip('/')
        self.platform_url = self.dt_url.replace('.live.', '.apps.')
        self.live_url = self.dt_url.replace('.apps.', '.live.')
        self.oauth_token = oauth_token
        self.api_token = api_token
        
        # Lazy-loaded registries
        self._metrics = None              # set of valid metric keys
        self._metric_display_names = {}   # key â†’ displayName
        self._metric_units = {}           # key â†’ unit
        self._metric_search_cache = {}    # bad_key â†’ best_match
        
        self._entities = None             # dict: entity_id â†’ {name, type, tags}
        self._entity_name_index = {}      # lowercase name â†’ [entity_ids]
        self._entity_type_index = {}      # type â†’ [entity_ids]
        
        self._dashboards = None           # dict: doc_id â†’ {name, owner, modified}
        self._dashboard_name_index = {}   # lowercase name â†’ [doc_ids]
        
        self._mgmt_zones = None           # dict: mz_id â†’ {name, rules}
        self._mgmt_zone_name_index = {}   # lowercase name â†’ mz_id
        
        self._synth_locations = None      # dict: location_id â†’ {name, type, city, ...}
        self._synth_location_name_index = {}  # lowercase city/name â†’ location_id
        
        self._load_errors = []            # Track API errors for reporting
        
        # DQL live validation cache
        self._dql_validation_cache = {}   # dql_hash â†’ (valid, error_msg)
    
    # â”€â”€â”€ HTTP helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def _api_get(self, url: str, domain: str = 'live') -> Optional[Dict]:
        """
        GET request to DT API.
        domain='live'     â†’ .live. domain, prefers Api-Token
        domain='platform' â†’ .apps. domain, requires Bearer OAuth
        """
        if domain == 'platform':
            if not self.oauth_token:
                return None
            auth = f'Bearer {self.oauth_token}'
        elif self.api_token:
            auth = f'Api-Token {self.api_token}'
        elif self.oauth_token:
            auth = f'Bearer {self.oauth_token}'
        else:
            return None
        
        headers = {'Authorization': auth, 'Accept': 'application/json'}
        try:
            req = urllib.request.Request(url, headers=headers, method='GET')
            with urllib.request.urlopen(req, timeout=30, context=SSL_CONTEXT) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            body = ''
            try:
                body = e.read().decode('utf-8')[:200]
            except:
                pass
            self._load_errors.append(f"HTTP {e.code} on {url[:80]}: {body}")
            # Retry with OAuth if Api-Token failed
            if domain == 'live' and self.api_token and self.oauth_token and e.code in (401, 403):
                headers['Authorization'] = f'Bearer {self.oauth_token}'
                try:
                    req = urllib.request.Request(url, headers=headers, method='GET')
                    with urllib.request.urlopen(req, timeout=30, context=SSL_CONTEXT) as resp:
                        return json.loads(resp.read().decode('utf-8'))
                except:
                    pass
            return None
        except Exception as e:
            self._load_errors.append(f"Error on {url[:80]}: {str(e)[:100]}")
            return None
    
    def _api_post(self, url: str, payload: Dict, domain: str = 'platform') -> Tuple[Optional[Dict], int]:
        """
        POST request to DT API.
        Returns (response_dict, status_code).
        """
        if domain == 'platform':
            if not self.oauth_token:
                return None, 0
            auth = f'Bearer {self.oauth_token}'
        elif self.api_token:
            auth = f'Api-Token {self.api_token}'
        elif self.oauth_token:
            auth = f'Bearer {self.oauth_token}'
        else:
            return None, 0
        
        headers = {
            'Authorization': auth,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        data = json.dumps(payload).encode('utf-8')
        try:
            req = urllib.request.Request(url, data=data, headers=headers, method='POST')
            with urllib.request.urlopen(req, timeout=15, context=SSL_CONTEXT) as resp:
                return json.loads(resp.read().decode('utf-8')), resp.status
        except urllib.error.HTTPError as e:
            body = ''
            try:
                body = e.read().decode('utf-8')
            except:
                pass
            try:
                return json.loads(body), e.code
            except:
                return {'error': {'message': body[:500]}}, e.code
        except Exception as e:
            return {'error': {'message': str(e)}}, 0
    
    # â”€â”€â”€ DQL Live Validation â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def validate_dql_syntax(self, dql: str) -> Tuple[bool, str, Optional[Dict]]:
        """
        Validate DQL syntax by submitting to the Grail query API with minimal execution.
        
        Uses a 1-second timeframe and maxResultRecords=1 to minimize cost.
        The API parses the DQL and returns syntax errors before execution,
        so even queries against missing data will validate syntax correctly.
        
        Returns:
            (is_valid, error_message, error_details)
            - (True, '', None)                     â€” valid DQL
            - (False, 'error text', {details})      â€” invalid DQL with error info
            - (None, 'unavailable', None)           â€” API not reachable (skip validation)
        """
        if not self.oauth_token:
            return None, 'No OAuth token â€” live validation unavailable', None
        
        # Strip comments from DQL for validation
        dql_clean = '\n'.join(
            line for line in dql.split('\n')
            if line.strip() and not line.strip().startswith('//')
        ).strip()
        
        if not dql_clean:
            return None, 'Empty DQL after stripping comments', None
        
        # Check cache
        cache_key = hash(dql_clean)
        if cache_key in self._dql_validation_cache:
            return self._dql_validation_cache[cache_key]
        
        # Submit to Grail query API
        url = f"{self.platform_url}/platform/storage/query/v1/query:execute"
        # Grail API requires ISO 8601 timestamps, not relative strings
        now = datetime.now(timezone.utc)
        two_hours_ago = now - timedelta(hours=2)
        payload = {
            "query": dql_clean,
            "defaultTimeframeStart": two_hours_ago.strftime("%Y-%m-%dT%H:%M:%S.000Z"),
            "defaultTimeframeEnd": now.strftime("%Y-%m-%dT%H:%M:%S.000Z"),
            "maxResultRecords": 1,
            "requestTimeoutMilliseconds": 5000,
            "locale": "en_US"
        }
        
        response, status = self._api_post(url, payload, domain='platform')
        
        if response is None:
            result = (None, 'API unreachable', None)
            self._dql_validation_cache[cache_key] = result
            return result
        
        # Parse response
        if status == 200:
            # Query executed successfully â€” DQL is valid
            result = (True, '', None)
            self._dql_validation_cache[cache_key] = result
            return result
        
        # Extract error details
        error_msg = ''
        error_details = None
        
        if isinstance(response, dict):
            error = response.get('error', {})
            if isinstance(error, dict):
                error_msg = error.get('message', '')
                error_details = error
                # DT error format often includes constraintViolations
                violations = error.get('constraintViolations', [])
                if violations:
                    error_msg = '; '.join(
                        v.get('message', '') for v in violations if v.get('message')
                    )
            elif isinstance(error, str):
                error_msg = error
            
            # Some errors come in 'errorMessage' field directly
            if not error_msg:
                error_msg = response.get('errorMessage', response.get('message', str(response)[:200]))
        
        # 400 = syntax/semantic error (what we want to catch)
        #        BUT some 400s are authorization errors, not syntax errors
        # 403 = missing scope (valid syntax but can't execute)
        # 429 = rate limited
        
        # Authorization / permissions errors â€” DQL parsed OK but token lacks table access
        auth_error_patterns = [
            'not_authorized_for_table',
            'not authorized',
            'permission',
            'scope',
            'access denied',
            'forbidden',
        ]
        error_lower = error_msg.lower()
        is_auth_error = any(p in error_lower for p in auth_error_patterns)
        
        if status == 403 or (status == 400 and is_auth_error):
            # DQL parsed OK but we lack permissions â€” syntax is valid
            result = (True, f'[AUTH] {error_msg}', None)
            self._dql_validation_cache[cache_key] = result
            return result
        
        if status == 429:
            # Rate limited â€” don't cache, skip validation
            return None, 'Rate limited â€” skipping validation', None
        
        result = (False, error_msg, error_details)
        self._dql_validation_cache[cache_key] = result
        return result
    
    def parse_dql_error(self, error_msg: str) -> Dict[str, str]:
        """
        Parse a DQL error message into structured hints for auto-fix.
        
        DT error messages follow patterns like:
        - "'X' isn't allowed here"
        - "Too many positional parameters"
        - "Unknown function 'X'"
        - "Column 'X' does not exist"
        - "Unexpected token 'X' at line N, column M"
        
        Returns dict with:
            error_type: 'syntax'|'function'|'column'|'parameter'|'unknown'
            bad_token: the problematic token if identifiable
            position: line:col if available
            suggestion: potential fix hint
        """
        result = {'error_type': 'unknown', 'bad_token': '', 'position': '', 'suggestion': ''}
        
        # "isn't allowed here" â€” wrong keyword/syntax
        m = re.search(r"[`'\"](.+?)[`'\"].*?isn't allowed here", error_msg, re.IGNORECASE)
        if m:
            result['error_type'] = 'syntax'
            result['bad_token'] = m.group(1)
            if m.group(1).lower() == 'as':
                result['suggestion'] = "Use 'alias=expr' instead of 'expr as alias'"
            elif m.group(1) == '(':
                result['suggestion'] = "Check for NRQL subqueries or function syntax"
            return result
        
        # "Too many positional parameters"
        if 'positional parameter' in error_msg.lower():
            result['error_type'] = 'parameter'
            result['suggestion'] = "Name aggregation parameters (e.g., p99=percentile(duration, 99))"
            return result
        
        # "Unknown function"
        m = re.search(r"[Uu]nknown function\s+[`'\"]?(\w+)[`'\"]?", error_msg)
        if m:
            result['error_type'] = 'function'
            result['bad_token'] = m.group(1)
            return result
        
        # "Column does not exist"
        m = re.search(r"[Cc]olumn\s+[`'\"]?(.+?)[`'\"]?\s+does not exist", error_msg)
        if m:
            result['error_type'] = 'column'
            result['bad_token'] = m.group(1)
            return result
        
        # Line/column position
        m = re.search(r'line\s+(\d+).*?column\s+(\d+)', error_msg, re.IGNORECASE)
        if m:
            result['position'] = f"{m.group(1)}:{m.group(2)}"
        
        return result
    
    def _paginate(self, base_url: str, items_key: str, domain: str = 'live',
                  max_pages: int = 20) -> List[Dict]:
        """Generic paginated fetch. Returns all items across pages."""
        all_items = []
        url = base_url
        pages = 0
        
        while url and pages < max_pages:
            data = self._api_get(url, domain=domain)
            if not data:
                break
            
            items = data.get(items_key, [])
            if isinstance(data, list):
                items = data
            all_items.extend(items)
            
            next_key = data.get('nextPageKey')
            if next_key:
                sep = '&' if '?' in base_url else '?'
                url = f"{base_url}{sep}nextPageKey={urllib.parse.quote(next_key)}"
            else:
                url = None
            pages += 1
        
        return all_items
    
    # â”€â”€â”€ Metric Registry â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def _load_metrics(self):
        """Fetch all dt.* and builtin:* metrics from the environment."""
        if self._metrics is not None:
            return
        
        self._metrics = set()
        self._metric_display_names = {}
        self._metric_units = {}
        
        for selector in ['dt.*', 'builtin:*']:
            encoded = urllib.parse.quote(selector, safe='*')
            url = f"{self.live_url}/api/v2/metrics?metricSelector={encoded}&fields=displayName,unit&pageSize=500"
            page = 0
            
            while url and page < 20:
                data = self._api_get(url)
                if not data:
                    break
                
                for m in data.get('metrics', []):
                    key = m.get('metricId', '')
                    if key:
                        self._metrics.add(key)
                        if m.get('displayName'):
                            self._metric_display_names[key] = m['displayName']
                        if m.get('unit'):
                            self._metric_units[key] = m['unit']
                
                next_key = data.get('nextPageKey')
                url = f"{self.live_url}/api/v2/metrics?nextPageKey={urllib.parse.quote(next_key)}" if next_key else None
                page += 1
    
    def metric_exists(self, key: str) -> bool:
        """Check if a metric key exists in the environment."""
        self._load_metrics()
        return key in self._metrics
    
    def get_metric_info(self, key: str) -> Optional[Dict]:
        """Get display name and unit for a metric."""
        self._load_metrics()
        if key not in self._metrics:
            return None
        return {
            'key': key,
            'displayName': self._metric_display_names.get(key, ''),
            'unit': self._metric_units.get(key, '')
        }
    
    def find_metric(self, bad_key: str) -> Optional[str]:
        """
        Fuzzy-find the correct metric key for a non-existent one.
        Uses token overlap + semantic synonyms + DT text search fallback.
        """
        if bad_key in self._metric_search_cache:
            return self._metric_search_cache[bad_key]
        
        self._load_metrics()
        
        bad_tokens = self._tokenize(bad_key)
        best_match = None
        best_score = 0
        
        for candidate in self._metrics:
            if not candidate.startswith('dt.'):
                continue
            cand_tokens = self._tokenize(candidate)
            score = self._token_similarity(bad_tokens, cand_tokens)
            
            # Prefix bonus
            if '.'.join(bad_key.split('.')[:2]) == '.'.join(candidate.split('.')[:2]):
                score += 0.3
            
            # Length similarity bonus
            len_ratio = min(len(bad_key), len(candidate)) / max(len(bad_key), len(candidate))
            score += len_ratio * 0.1
            
            if score > best_score:
                best_score = score
                best_match = candidate
        
        # DT text search fallback
        if best_score < 0.5:
            search_terms = ' '.join(bad_tokens - {'dt', 'builtin'})
            if search_terms:
                encoded = urllib.parse.quote(search_terms)
                url = f"{self.live_url}/api/v2/metrics?text={encoded}&fields=displayName&pageSize=5"
                data = self._api_get(url)
                if data:
                    for m in data.get('metrics', []):
                        key = m.get('metricId', '')
                        if key and key.startswith('dt.'):
                            cand_tokens = self._tokenize(key)
                            score = self._token_similarity(bad_tokens, cand_tokens)
                            if '.'.join(bad_key.split('.')[:2]) == '.'.join(key.split('.')[:2]):
                                score += 0.3
                            if score > best_score:
                                best_score = score
                                best_match = key
        
        result = best_match if best_score >= 0.4 else None
        self._metric_search_cache[bad_key] = result
        return result
    
    def validate_metric_map(self, metric_map: Dict[str, str]) -> Dict[str, Dict]:
        """
        Validate every target in a NRâ†’DT metric mapping dict.
        Returns dict of invalid entries: {nr_key: {target, exists, suggestion}}
        """
        self._load_metrics()
        invalid = {}
        
        for nr_key, dt_target in metric_map.items():
            if not dt_target.startswith('dt.'):
                continue
            if dt_target not in self._metrics:
                suggestion = self.find_metric(dt_target)
                invalid[nr_key] = {
                    'target': dt_target,
                    'exists': False,
                    'suggestion': suggestion,
                    'display_name': self._metric_display_names.get(suggestion, '') if suggestion else ''
                }
        
        return invalid
    
    def get_all_metrics(self, prefix: str = 'dt.') -> set:
        """Get all metric keys with given prefix."""
        self._load_metrics()
        return {k for k in self._metrics if k.startswith(prefix)}
    
    # â”€â”€â”€ Entity Registry â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def _load_entities(self, entity_type: str = None):
        """
        Fetch entities from the environment.
        entity_type: 'SERVICE', 'HOST', 'PROCESS_GROUP', etc. None = all common types.
        """
        if self._entities is not None and entity_type is None:
            return
        if entity_type and entity_type in self._entity_type_index:
            return
        
        if self._entities is None:
            self._entities = {}
            self._entity_name_index = {}
            self._entity_type_index = {}
        
        types_to_fetch = [entity_type] if entity_type else [
            'SERVICE', 'HOST', 'PROCESS_GROUP', 'APPLICATION',
            'SYNTHETIC_TEST', 'HTTP_CHECK'
        ]
        
        for etype in types_to_fetch:
            if etype in self._entity_type_index:
                continue
            
            selector = urllib.parse.quote(f'type("{etype}")')
            url = (f"{self.live_url}/api/v2/entities?entitySelector={selector}"
                   f"&fields=properties,tags&pageSize=500")
            
            entities = self._paginate(url, 'entities')
            self._entity_type_index[etype] = []
            
            for e in entities:
                eid = e.get('entityId', '')
                name = e.get('displayName', '')
                tags = {}
                for t in e.get('tags', []):
                    if t.get('value'):
                        tags[t['key']] = t['value']
                    else:
                        tags[t['key']] = True
                
                self._entities[eid] = {
                    'id': eid, 'name': name, 'type': etype,
                    'properties': e.get('properties', {}),
                    'tags': tags
                }
                self._entity_type_index[etype].append(eid)
                
                # Name index (lowercase, multiple entities can share names)
                lower_name = name.lower()
                if lower_name not in self._entity_name_index:
                    self._entity_name_index[lower_name] = []
                self._entity_name_index[lower_name].append(eid)
    
    def find_entity(self, name: str, entity_type: str = None) -> Optional[Dict]:
        """
        Find a DT entity by name (exact or fuzzy).
        Returns {id, name, type, properties, tags} or None.
        """
        self._load_entities(entity_type)
        
        lower = name.lower()
        
        # Exact match
        if lower in self._entity_name_index:
            ids = self._entity_name_index[lower]
            if entity_type:
                ids = [i for i in ids if self._entities[i]['type'] == entity_type]
            if ids:
                return self._entities[ids[0]]
        
        # Contains match (NR names often differ slightly)
        best = None
        best_score = 0
        for idx_name, ids in self._entity_name_index.items():
            if entity_type:
                ids = [i for i in ids if self._entities[i]['type'] == entity_type]
            if not ids:
                continue
            
            # Score: prefer contains match, then token overlap
            if lower in idx_name or idx_name in lower:
                score = 0.8
            else:
                name_tokens = self._tokenize(lower)
                idx_tokens = self._tokenize(idx_name)
                score = self._token_similarity(name_tokens, idx_tokens)
            
            if score > best_score:
                best_score = score
                best = self._entities[ids[0]]
        
        return best if best_score >= 0.5 else None
    
    def find_entities_by_type(self, entity_type: str) -> List[Dict]:
        """Get all entities of a type."""
        self._load_entities(entity_type)
        ids = self._entity_type_index.get(entity_type, [])
        return [self._entities[eid] for eid in ids]
    
    def entity_exists(self, name: str, entity_type: str = None) -> bool:
        """Quick check if an entity with this name exists."""
        return self.find_entity(name, entity_type) is not None
    
    def resolve_service_name(self, nr_name: str) -> Tuple[Optional[str], float]:
        """
        Given a New Relic service/app name, find the matching DT service.
        Returns (dt_entity_id, confidence) or (None, 0).
        
        NR names often look like: 'ecomr4-web', 'api-products-v1'
        DT names may differ:      'ecomr4-web', 'API Products V1'
        """
        entity = self.find_entity(nr_name, 'SERVICE')
        if entity:
            # Calculate confidence based on match quality
            lower_nr = nr_name.lower()
            lower_dt = entity['name'].lower()
            if lower_nr == lower_dt:
                return entity['id'], 1.0
            elif lower_nr in lower_dt or lower_dt in lower_nr:
                return entity['id'], 0.8
            else:
                return entity['id'], 0.5
        return None, 0.0
    
    # â”€â”€â”€ Dashboard Registry â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def _load_dashboards(self):
        """Fetch all existing dashboards from Documents API."""
        if self._dashboards is not None:
            return
        
        self._dashboards = {}
        self._dashboard_name_index = {}
        
        url = f"{self.platform_url}/platform/document/v1/documents?filter=type%3D%3D'dashboard'&page-size=500"
        data = self._api_get(url, domain='platform')
        if not data:
            return
        
        for doc in data.get('documents', []):
            doc_id = doc.get('id', '')
            name = doc.get('name', '')
            self._dashboards[doc_id] = {
                'id': doc_id, 'name': name,
                'owner': doc.get('owner', ''),
                'modificationInfo': doc.get('modificationInfo', {})
            }
            lower = name.lower()
            if lower not in self._dashboard_name_index:
                self._dashboard_name_index[lower] = []
            self._dashboard_name_index[lower].append(doc_id)
        
        # Handle pagination
        while data.get('nextPageKey'):
            next_key = data['nextPageKey']
            next_url = f"{self.platform_url}/platform/document/v1/documents?nextPageKey={urllib.parse.quote(next_key)}"
            data = self._api_get(next_url, domain='platform')
            if not data:
                break
            for doc in data.get('documents', []):
                doc_id = doc.get('id', '')
                name = doc.get('name', '')
                self._dashboards[doc_id] = {
                    'id': doc_id, 'name': name,
                    'owner': doc.get('owner', ''),
                    'modificationInfo': doc.get('modificationInfo', {})
                }
                lower = name.lower()
                if lower not in self._dashboard_name_index:
                    self._dashboard_name_index[lower] = []
                self._dashboard_name_index[lower].append(doc_id)
    
    def dashboard_exists(self, name: str) -> Optional[str]:
        """Check if a dashboard with this name exists. Returns doc_id or None."""
        self._load_dashboards()
        lower = name.lower()
        ids = self._dashboard_name_index.get(lower, [])
        return ids[0] if ids else None
    
    def find_dashboard(self, name: str) -> Optional[Dict]:
        """Find dashboard by exact or fuzzy name match."""
        self._load_dashboards()
        lower = name.lower()
        
        # Exact
        if lower in self._dashboard_name_index:
            return self._dashboards[self._dashboard_name_index[lower][0]]
        
        # Fuzzy
        best = None
        best_score = 0
        for dash_name, ids in self._dashboard_name_index.items():
            if lower in dash_name or dash_name in lower:
                score = 0.8
            else:
                score = self._token_similarity(self._tokenize(lower), self._tokenize(dash_name))
            if score > best_score:
                best_score = score
                best = self._dashboards[ids[0]]
        
        return best if best_score >= 0.6 else None
    
    def list_dashboards(self) -> List[Dict]:
        """List all dashboards."""
        self._load_dashboards()
        return list(self._dashboards.values())
    
    # â”€â”€â”€ Management Zone Registry â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def _load_management_zones(self):
        """Fetch management zones."""
        if self._mgmt_zones is not None:
            return
        
        self._mgmt_zones = {}
        self._mgmt_zone_name_index = {}
        
        # Settings v2 API for management zones
        url = f"{self.live_url}/api/v2/settings/objects?schemaIds=builtin:management-zones&pageSize=500"
        items = self._paginate(url, 'items')
        
        for item in items:
            obj_id = item.get('objectId', '')
            value = item.get('value', {})
            name = value.get('name', '')
            rules = value.get('rules', [])
            
            self._mgmt_zones[obj_id] = {
                'id': obj_id, 'name': name, 'rules': rules
            }
            self._mgmt_zone_name_index[name.lower()] = obj_id
    
    def find_management_zone(self, name: str) -> Optional[Dict]:
        """Find management zone by name (exact or fuzzy)."""
        self._load_management_zones()
        lower = name.lower()
        
        if lower in self._mgmt_zone_name_index:
            return self._mgmt_zones[self._mgmt_zone_name_index[lower]]
        
        # Fuzzy
        best = None
        best_score = 0
        for mz_name, mz_id in self._mgmt_zone_name_index.items():
            if lower in mz_name or mz_name in lower:
                score = 0.8
            else:
                score = self._token_similarity(self._tokenize(lower), self._tokenize(mz_name))
            if score > best_score:
                best_score = score
                best = self._mgmt_zones[mz_id]
        
        return best if best_score >= 0.5 else None
    
    def list_management_zones(self) -> List[Dict]:
        """List all management zones."""
        self._load_management_zones()
        return list(self._mgmt_zones.values())
    
    # â”€â”€â”€ Synthetic Location Registry â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def _load_synthetic_locations(self):
        """Fetch all synthetic locations (public + private)."""
        if self._synth_locations is not None:
            return
        
        self._synth_locations = {}
        self._synth_location_name_index = {}
        
        url = f"{self.live_url}/api/v2/synthetic/locations?type=PUBLIC"
        data = self._api_get(url)
        if data:
            for loc in data.get('locations', []):
                self._index_synth_location(loc)
        
        url = f"{self.live_url}/api/v2/synthetic/locations?type=PRIVATE"
        data = self._api_get(url)
        if data:
            for loc in data.get('locations', []):
                self._index_synth_location(loc)
    
    def _index_synth_location(self, loc: Dict):
        """Index a synthetic location for lookup."""
        loc_id = loc.get('entityId', '')
        name = loc.get('name', '')
        city = loc.get('city', '')
        loc_type = loc.get('type', '')
        
        self._synth_locations[loc_id] = {
            'id': loc_id, 'name': name, 'city': city,
            'type': loc_type,
            'countryCode': loc.get('countryCode', ''),
            'regionCode': loc.get('regionCode', ''),
            'cloudPlatform': loc.get('cloudPlatform', ''),
            'status': loc.get('status', '')
        }
        
        # Index by name, city, and various tokens
        for key in [name.lower(), city.lower()]:
            if key and key not in self._synth_location_name_index:
                self._synth_location_name_index[key] = loc_id
    
    def find_synthetic_location(self, nr_location: str) -> Optional[Dict]:
        """
        Map a New Relic location name to a DT synthetic location.
        NR: 'AWS_US_EAST_1', 'Columbus, OH, USA', 'Portland, OR, USA'
        DT: 'N. Virginia', 'Columbus', 'Portland'
        """
        self._load_synthetic_locations()
        lower = nr_location.lower()
        
        # Direct match
        if lower in self._synth_location_name_index:
            return self._synth_locations[self._synth_location_name_index[lower]]
        
        # Extract city from NR format: "Columbus, OH, USA" â†’ "columbus"
        city = lower.split(',')[0].strip()
        if city in self._synth_location_name_index:
            return self._synth_locations[self._synth_location_name_index[city]]
        
        # AWS region â†’ DT location: AWS_US_EAST_1 â†’ N. Virginia
        aws_to_city = {
            'us_east_1': 'n. virginia', 'us_east_2': 'ohio',
            'us_west_1': 'n. california', 'us_west_2': 'oregon',
            'eu_west_1': 'ireland', 'eu_west_2': 'london',
            'eu_central_1': 'frankfurt', 'ap_southeast_1': 'singapore',
            'ap_southeast_2': 'sydney', 'ap_northeast_1': 'tokyo',
            'ap_south_1': 'mumbai', 'sa_east_1': 'sÃ£o paulo',
        }
        nr_clean = lower.replace('aws_', '').replace('azure_', '').replace('gcp_', '')
        mapped_city = aws_to_city.get(nr_clean)
        if mapped_city and mapped_city in self._synth_location_name_index:
            return self._synth_locations[self._synth_location_name_index[mapped_city]]
        
        # Fuzzy token match
        best = None
        best_score = 0
        nr_tokens = self._tokenize(lower)
        for loc_name, loc_id in self._synth_location_name_index.items():
            loc_tokens = self._tokenize(loc_name)
            score = self._token_similarity(nr_tokens, loc_tokens)
            if score > best_score:
                best_score = score
                best = self._synth_locations.get(loc_id)
        
        return best if best_score >= 0.5 else None
    
    def list_synthetic_locations(self, loc_type: str = None) -> List[Dict]:
        """List synthetic locations, optionally filtered by type (PUBLIC/PRIVATE)."""
        self._load_synthetic_locations()
        locs = list(self._synth_locations.values())
        if loc_type:
            locs = [l for l in locs if l['type'] == loc_type]
        return locs
    
    # â”€â”€â”€ Shared utilities â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    @staticmethod
    def _tokenize(s: str) -> set:
        """Split a string into lowercase tokens on . _ and space."""
        tokens = set()
        for part in re.split(r'[._\s:]+', s):
            if part:
                tokens.add(part.lower())
        return tokens
    
    def _token_similarity(self, tokens_a: set, tokens_b: set) -> float:
        """Jaccard similarity with semantic synonym support."""
        if not tokens_a or not tokens_b:
            return 0.0
        
        direct_overlap = tokens_a & tokens_b
        
        synonym_overlap = set()
        for ta in tokens_a:
            if ta in direct_overlap:
                continue
            synonyms = self.SYNONYMS.get(ta, set())
            for tb in tokens_b:
                if tb in synonyms or ta in self.SYNONYMS.get(tb, set()):
                    synonym_overlap.add(ta)
                    break
        
        total = len(direct_overlap) + len(synonym_overlap) * 0.8
        union = tokens_a | tokens_b
        return total / len(union) if union else 0.0
    
    # â”€â”€â”€ Reporting â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def summary(self) -> Dict[str, int]:
        """Return counts of loaded registry items."""
        s = {}
        if self._metrics is not None:
            s['metrics'] = len(self._metrics)
            s['metrics_grail'] = sum(1 for k in self._metrics if k.startswith('dt.'))
            s['metrics_classic'] = sum(1 for k in self._metrics if k.startswith('builtin:'))
        if self._entities is not None:
            s['entities'] = len(self._entities)
            for etype, ids in self._entity_type_index.items():
                s[f'entities_{etype.lower()}'] = len(ids)
        if self._dashboards is not None:
            s['dashboards'] = len(self._dashboards)
        if self._mgmt_zones is not None:
            s['management_zones'] = len(self._mgmt_zones)
        if self._synth_locations is not None:
            s['synthetic_locations'] = len(self._synth_locations)
        if self._load_errors:
            s['load_errors'] = len(self._load_errors)
        return s
    
    def print_summary(self):
        """Print human-readable summary of loaded registries."""
        s = self.summary()
        if not s:
            print("  ðŸ“‹ Registry: nothing loaded yet")
            return
        
        print("  ðŸ“‹ DT Environment Registry:")
        if 'metrics' in s:
            print(f"     ðŸ“Š Metrics: {s['metrics']} ({s.get('metrics_grail', 0)} Grail, "
                  f"{s.get('metrics_classic', 0)} Classic)")
        if 'entities' in s:
            types_str = ', '.join(f"{v} {k.replace('entities_', '')}" 
                                  for k, v in s.items() if k.startswith('entities_'))
            print(f"     ðŸ¢ Entities: {s['entities']} ({types_str})")
        if 'dashboards' in s:
            print(f"     ðŸ“ˆ Dashboards: {s['dashboards']}")
        if 'management_zones' in s:
            print(f"     ðŸ—‚  Management Zones: {s['management_zones']}")
        if 'synthetic_locations' in s:
            print(f"     ðŸŒ Synthetic Locations: {s['synthetic_locations']}")
        if 'load_errors' in s:
            print(f"     âš  Load errors: {s['load_errors']}")


# ============================================================================
# SLO AUDITOR
# ============================================================================

class SLOAuditor:
    """
    Audits existing Dynatrace Gen3 Platform SLOs by evaluating their live status
    and dynamically validating every metric in their DQL against the environment's
    actual metric registry.
    
    Phase 1 - Evaluate: Fetch SLOs, check evaluation status (is it returning data?)
    Phase 2 - Discover: Build metric registry from GET /api/v2/metrics (all dt.* metrics)
    Phase 3 - Validate: Extract metric refs from DQL, check each against registry
    Phase 4 - Fix: For invalid metrics, search for correct match and replace
    
    APIs used:
      Platform SLO API: /platform/slo/v1/slos on .apps. domain (Bearer OAuth)
      Metrics v2 API:   /api/v2/metrics on .live. domain (Bearer OAuth or Api-Token)
    """
    
    # Aggregations NOT valid in timeseries/makeTimeseries
    INVALID_TIMESERIES_AGGS = {'takeLast', 'takeFirst', 'takeAny', 'collectArray', 'collectDistinct'}
    
    # Valid timeseries aggregations
    VALID_TIMESERIES_AGGS = {'sum', 'avg', 'min', 'max', 'count', 'percentile', 'countDistinct', 'countIf'}
    
    # Semantic synonyms for fuzzy metric matching
    # If a token in the bad metric matches a synonym of a token in the candidate, count it
    METRIC_SYNONYMS = {
        'error': {'failure', 'errors', 'failed'},
        'failure': {'error', 'errors', 'failed'},
        'errors': {'error', 'failure', 'failed'},
        'failed': {'error', 'failure', 'errors'},
        'response': {'response_time', 'responsetime', 'latency', 'duration'},
        'latency': {'response', 'response_time', 'duration'},
        'time': {'response_time', 'duration'},
        'success': {'successes', 'successcount'},
        'successes': {'success', 'successcount'},
        'total': {'count', 'all'},
        'bytes': {'bytes_rx', 'bytes_tx', 'bytesrx', 'bytestx'},
        'rx': {'bytes_rx', 'received'},
        'tx': {'bytes_tx', 'sent'},
        'memory': {'mem', 'ram'},
        'mem': {'memory', 'ram'},
        'cpu': {'processor', 'compute'},
        'disk': {'storage', 'volume'},
        'net': {'network', 'nic'},
        'network': {'net', 'nic'},
    }
    
    def __init__(self, dt_url: str, oauth_token: str, api_token: str = '',
                 registry: 'DTEnvironmentRegistry' = None):
        """
        Args:
            dt_url: Base DT environment URL (either .apps. or .live.)
            oauth_token: OAuth Bearer token for Platform SLO API
            api_token: Optional Api-Token for Metrics v2 API (falls back to OAuth)
            registry: Optional shared DTEnvironmentRegistry (avoids duplicate API calls)
        """
        self.dt_url = dt_url.rstrip('/')
        # Platform SLO API â†’ .apps.dynatrace.com
        self.platform_url = self.dt_url.replace('.live.', '.apps.')
        # Metrics v2 API â†’ .live.dynatrace.com
        self.live_url = self.dt_url.replace('.apps.', '.live.')
        self.oauth_token = oauth_token
        self.api_token = api_token
        
        # Use shared registry or create own
        self.registry = registry or DTEnvironmentRegistry(dt_url, oauth_token, api_token)
    
    # â”€â”€â”€ HTTP helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def _platform_request(self, url: str, method: str = 'GET', data: bytes = None) -> Optional[Dict]:
        """Request to Platform API (.apps. domain) with Bearer OAuth."""
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.oauth_token}',
            'Accept': 'application/json'
        }
        try:
            req = urllib.request.Request(url, data=data, headers=headers, method=method)
            with urllib.request.urlopen(req, timeout=30, context=SSL_CONTEXT) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            body = e.read().decode('utf-8') if hasattr(e, 'read') else ''
            print(f"  âš  Platform API HTTP {e.code}: {body[:300]}")
            return None
        except Exception as e:
            print(f"  âš  Platform API error: {e}")
            return None
    
    # â”€â”€â”€ Delegate to shared registry â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def metric_exists(self, metric_key: str) -> bool:
        return self.registry.metric_exists(metric_key)
    
    def find_correct_metric(self, bad_metric: str) -> Optional[str]:
        return self.registry.find_metric(bad_metric)
    
    # â”€â”€â”€ DQL parsing â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def extract_metrics_from_dql(self, dql: str) -> List[str]:
        """
        Extract all metric key references from a DQL query.
        
        Looks for patterns like:
          avg(dt.service.request.response_time)
          sum(dt.service.request.count)
          timeseries avg(dt.host.cpu.usage)
          countIf(dt.service.request.count > 0)
        """
        metrics = []
        if not dql:
            return metrics
        
        # Pattern 1: agg(metric_key) or agg(metric_key, ...)
        agg_pattern = r'(?:avg|sum|min|max|count|percentile|countIf|countDistinct)\s*\(\s*([a-zA-Z][a-zA-Z0-9._:]+)'
        for match in re.finditer(agg_pattern, dql):
            key = match.group(1).strip()
            # Filter out DQL keywords and known non-metrics
            if key not in ('duration', 'timestamp', 'start_time', 'true', 'false', 'null') \
               and not key.startswith('dt.entity.') \
               and ('.' in key):
                metrics.append(key)
        
        # Pattern 2: standalone metric in timeseries assignment: timeseries alias = agg(metric)
        # Already covered by agg_pattern
        
        # Pattern 3: default: in timeseries (metric is before the comma)
        # timeseries sum(dt.host.availability, default:0)
        # Already covered
        
        # Deduplicate while preserving order
        seen = set()
        unique = []
        for m in metrics:
            if m not in seen:
                seen.add(m)
                unique.append(m)
        
        return unique
    
    # â”€â”€â”€ SLO API â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def fetch_slos(self) -> List[Dict]:
        """Fetch all Gen3 Platform SLOs."""
        slos = []
        url = f"{self.platform_url}/platform/slo/v1/slos?pageSize=500"
        
        while url:
            data = self._platform_request(url)
            if not data:
                break
            
            items = data.get('slos', data.get('items', []))
            if isinstance(data, list):
                items = data
            slos.extend(items)
            
            next_key = data.get('nextPageKey')
            url = f"{self.platform_url}/platform/slo/v1/slos?nextPageKey={next_key}" if next_key else None
        
        return slos
    
    def fetch_slo_detail(self, slo_id: str) -> Optional[Dict]:
        """Fetch full Gen3 SLO definition including DQL."""
        url = f"{self.platform_url}/platform/slo/v1/slos/{slo_id}"
        return self._platform_request(url)
    
    def update_slo(self, slo_id: str, payload: Dict) -> bool:
        """Update a Gen3 Platform SLO via PUT."""
        url = f"{self.platform_url}/platform/slo/v1/slos/{slo_id}"
        data = json.dumps(payload).encode('utf-8')
        result = self._platform_request(url, method='PUT', data=data)
        return result is not None
    
    # â”€â”€â”€ Validation â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def validate_dql(self, dql: str) -> Tuple[List[str], List[str], str]:
        """
        Full DQL validation:
        1. Extract all metric references
        2. Validate each against live metric registry
        3. Check DQL syntax issues (bad aggs, NRQL leftovers, etc.)
        4. Build fixed DQL with correct metrics
        
        Returns: (errors, warnings, fixed_dql)
        """
        errors = []
        warnings = []
        fixed = dql
        
        if not dql or not dql.strip():
            return errors, warnings, fixed
        
        # â”€â”€â”€ Phase 1: Validate metric keys against live registry â”€â”€â”€
        metrics = self.extract_metrics_from_dql(dql)
        
        for metric_key in metrics:
            if metric_key.startswith('builtin:'):
                # Classic metric selector in DQL â€” definitely wrong
                correct = self.find_correct_metric(metric_key)
                if correct:
                    errors.append(f"Classic metric '{metric_key}' â†’ Grail: '{correct}'")
                    fixed = fixed.replace(metric_key, correct)
                else:
                    errors.append(f"Classic metric '{metric_key}' has no Grail equivalent â€” "
                                  f"check Built-in Metrics on Grail docs")
            
            elif metric_key.startswith('dt.'):
                if not self.metric_exists(metric_key):
                    # Metric doesn't exist â€” find the right one
                    correct = self.find_correct_metric(metric_key)
                    if correct:
                        info = self.registry.get_metric_info(correct)
                        display = info['displayName'] if info else ''
                        errors.append(f"Metric not found: '{metric_key}' â†’ "
                                      f"suggested: '{correct}' "
                                      f"({display})")
                        fixed = fixed.replace(metric_key, correct)
                    else:
                        errors.append(f"Metric not found: '{metric_key}' â€” "
                                      f"no close match in environment")
                # else: metric exists, all good
            
            elif '.' in metric_key and not metric_key.startswith(('calc:', 'ext:', 'legacy.')):
                # Unknown prefix â€” warn
                warnings.append(f"Unknown metric prefix: '{metric_key}' â€” "
                                f"expected dt.* for Grail metrics")
        
        # â”€â”€â”€ Phase 2: DQL syntax checks â”€â”€â”€
        is_timeseries = bool(re.search(r'\btimeseries\b', dql, re.IGNORECASE))
        is_maketimeseries = bool(re.search(r'\bmakeTimeseries\b', dql, re.IGNORECASE))
        
        # Invalid aggregations in timeseries context
        if is_timeseries or is_maketimeseries:
            for bad_agg in self.INVALID_TIMESERIES_AGGS:
                pattern = rf'\b{bad_agg}\s*\('
                if re.search(pattern, dql):
                    errors.append(f"'{bad_agg}()' not valid in timeseries â€” use avg(), sum(), or max()")
                    fixed = re.sub(rf'\b{bad_agg}\s*\(', 'avg(', fixed)
        
        # NRQL syntax leftovers
        nr_checks = [
            (r'\bFROM\s+\w+\s+SELECT\b', "Contains NRQL syntax (FROM ... SELECT)"),
            (r'\bSELECT\s+', "Contains NRQL SELECT keyword"),
            (r'\bFACET\s+', "Contains NRQL FACET â€” should be 'by:'"),
            (r'\bSINCE\s+\d', "Contains NRQL SINCE â€” should be 'from:'"),
        ]
        for pattern, message in nr_checks:
            if re.search(pattern, dql, re.IGNORECASE):
                errors.append(message)
        
        # Single quotes â†’ double quotes
        if re.search(r"==\s*'[^']*'", dql):
            warnings.append("Single quotes for string comparison â€” DQL uses double quotes")
            fixed = re.sub(r"==\s*'([^']*)'", r'== "\1"', fixed)
        
        # fieldsRename after makeTimeseries
        if is_maketimeseries and 'fieldsRename' in dql:
            mt_pos = dql.lower().find('maketimeseries')
            fr_pos = dql.lower().find('fieldsrename')
            if fr_pos > mt_pos:
                errors.append("fieldsRename cannot follow makeTimeseries")
                fixed = re.sub(r'\|\s*fieldsRename\s+[^\n]+', '', fixed)
        
        # Gen3 SLOs should produce an 'sli' field
        if 'sli' not in dql and (is_timeseries or is_maketimeseries):
            warnings.append("Gen3 SLO DQL should produce an 'sli' field")
        
        # Double dots in metric keys
        for metric in re.findall(r'dt\.[a-zA-Z0-9._]+', dql):
            if '..' in metric:
                errors.append(f"Double dot in metric name: '{metric}'")
        
        return errors, warnings, fixed
    
    # â”€â”€â”€ Main audit flow â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    def audit(self, fix: bool = False) -> Dict:
        """
        Full SLO audit:
        1. Fetch all Platform SLOs + their evaluation status
        2. Build metric registry from live environment
        3. For each SLO: extract DQL, validate every metric, check syntax
        4. Optionally fix broken SLOs
        
        Returns summary dict.
        """
        print("\n" + "=" * 80)
        print("  SLO DQL AUDIT (Gen3 Platform â€” Live Metric Validation)")
        print("=" * 80)
        
        # â”€â”€â”€ Phase 1: Fetch SLOs â”€â”€â”€
        print(f"\n  Fetching Platform SLOs from {self.platform_url}...")
        slos = self.fetch_slos()
        print(f"  Found {len(slos)} Gen3 Platform SLOs")
        
        if not slos:
            print("  âš  No SLOs found. Check:")
            print("    - OAuth token has slo:slos:read scope")
            print("    - URL resolves to .apps.dynatrace.com")
            return {'total': 0, 'valid': 0, 'warnings': 0, 'errors': 0, 'fixed': 0, 'details': []}
        
        # â”€â”€â”€ Phase 2: Build metric registry â”€â”€â”€
        print("  ðŸ“Š Loading metric registry from environment...")
        # Trigger lazy load via registry
        self.registry._load_metrics()
        
        if not self.registry._metrics:
            print("  âš  Could not load metric registry. Metric validation will be skipped.")
            print("    - Check Api-Token has metrics.read scope, or OAuth has metric read permissions")
        else:
            grail = sum(1 for k in self.registry._metrics if k.startswith('dt.'))
            classic = sum(1 for k in self.registry._metrics if k.startswith('builtin:'))
            print(f"  ðŸ“Š Registry: {len(self.registry._metrics)} metrics ({grail} Grail, {classic} Classic)")
        
        # â”€â”€â”€ Phase 3: Evaluate each SLO â”€â”€â”€
        results = {
            'total': len(slos),
            'valid': 0,
            'warnings': 0,
            'errors': 0,
            'fixed': 0,
            'skipped': 0,
            'metrics_checked': 0,
            'metrics_invalid': 0,
            'details': []
        }
        
        for slo in slos:
            slo_id = slo.get('id', slo.get('objectId', 'unknown'))
            slo_name = slo.get('name', 'Unnamed')
            
            # Check evaluation status from list response
            slo_status = slo.get('status', slo.get('evaluationStatus', ''))
            slo_eval_pct = slo.get('evaluatedPercentage', slo.get('sloStatus', None))
            
            # Get full SLO detail
            detail = self.fetch_slo_detail(slo_id)
            if not detail:
                results['skipped'] += 1
                results['details'].append({
                    'id': slo_id, 'name': slo_name, 'status': 'SKIP',
                    'errors': ['Could not fetch SLO detail']
                })
                continue
            
            # Extract DQL indicator
            custom_sli = detail.get('customSli', {})
            dql_indicator = ''
            if isinstance(custom_sli, dict):
                dql_indicator = custom_sli.get('indicator', '')
            
            template_sli = detail.get('templateSli', {})
            
            # Get target from criteria
            criteria = detail.get('criteria', [{}])
            target = criteria[0].get('target', 0) if criteria else 0
            
            # Get evaluation info from detail
            eval_status = detail.get('status', detail.get('evaluationStatus', slo_status))
            eval_error = detail.get('error', detail.get('evaluationError', ''))
            
            all_errors = []
            all_warnings = []
            fixed_dql = dql_indicator
            
            # Flag if SLO evaluation is erroring
            if eval_error:
                all_errors.append(f"SLO evaluation error: {str(eval_error)[:200]}")
            
            if eval_status and str(eval_status).upper() in ('ERROR', 'FAILURE', 'NO_DATA'):
                all_errors.append(f"SLO evaluation status: {eval_status}")
            
            if dql_indicator:
                # Full DQL validation with live metric checking
                errors, warnings, fixed = self.validate_dql(dql_indicator)
                
                # Track metrics stats
                metrics_in_slo = self.extract_metrics_from_dql(dql_indicator)
                results['metrics_checked'] += len(metrics_in_slo)
                for m in metrics_in_slo:
                    if m.startswith('dt.') and not self.metric_exists(m):
                        results['metrics_invalid'] += 1
                    elif m.startswith('builtin:'):
                        results['metrics_invalid'] += 1
                
                all_errors.extend(errors)
                all_warnings.extend(warnings)
                fixed_dql = fixed
            elif template_sli:
                template_id = template_sli.get('templateId', template_sli.get('id', 'unknown'))
                all_warnings.append(f"Template-based SLO (template: {template_id})")
            else:
                all_warnings.append("No DQL indicator found")
            
            # â”€â”€â”€ Determine status â”€â”€â”€
            if all_errors:
                status = 'ERROR'
                results['errors'] += 1
            elif all_warnings:
                status = 'WARNING'
                results['warnings'] += 1
            else:
                status = 'VALID'
                results['valid'] += 1
            
            # â”€â”€â”€ Print result â”€â”€â”€
            if status == 'ERROR':
                print(f"\n  âŒ [{slo_id[:30]}] {slo_name} (target: {target}%)")
                for e in all_errors:
                    print(f"     âŒ {e}")
                for w in all_warnings:
                    print(f"     âš ï¸  {w}")
                
                # Show which metrics were found in DQL
                if dql_indicator:
                    metrics_found = self.extract_metrics_from_dql(dql_indicator)
                    if metrics_found:
                        for m in metrics_found:
                            exists = self.metric_exists(m) if m.startswith('dt.') else False
                            icon = "âœ…" if exists else "âŒ"
                            info = self.registry.get_metric_info(m)
                            display = info['displayName'] if info else ''
                            suffix = f" ({display})" if display else ""
                            print(f"     {icon} metric: {m}{suffix}")
                
                # Auto-fix
                if fix and fixed_dql != dql_indicator and dql_indicator:
                    print(f"     ðŸ”§ Auto-fixing DQL indicator...")
                    
                    update_payload = {
                        'name': detail.get('name', slo_name),
                        'customSli': {'indicator': fixed_dql}
                    }
                    if detail.get('criteria'):
                        update_payload['criteria'] = detail['criteria']
                    if detail.get('description'):
                        update_payload['description'] = detail['description']
                    if detail.get('tags'):
                        update_payload['tags'] = detail['tags']
                    if detail.get('segments'):
                        update_payload['segments'] = detail['segments']
                    
                    if self.update_slo(slo_id, update_payload):
                        print(f"     âœ… Fixed!")
                        results['fixed'] += 1
                        
                        # Show what changed
                        old_metrics = set(self.extract_metrics_from_dql(dql_indicator))
                        new_metrics = set(self.extract_metrics_from_dql(fixed_dql))
                        for old_m in old_metrics - new_metrics:
                            new_m = [n for n in new_metrics - old_metrics 
                                     if n.split('.')[:2] == old_m.split('.')[:2]]
                            if new_m:
                                print(f"        {old_m} â†’ {new_m[0]}")
                    else:
                        print(f"     âŒ Fix failed â€” update manually in Service-Level Objectives app")
            
            elif status == 'WARNING':
                print(f"\n  âš ï¸  [{slo_id[:30]}] {slo_name}")
                for w in all_warnings:
                    print(f"     âš ï¸  {w}")
            
            results['details'].append({
                'id': slo_id, 'name': slo_name, 'status': status,
                'target': target,
                'eval_status': eval_status,
                'dql': dql_indicator[:300] if dql_indicator else None,
                'metrics': self.extract_metrics_from_dql(dql_indicator) if dql_indicator else [],
                'errors': all_errors, 'warnings': all_warnings,
                'fixed_dql': fixed_dql[:300] if fixed_dql != dql_indicator else None
            })
        
        # â”€â”€â”€ Summary â”€â”€â”€
        print("\n" + "=" * 80)
        print(f"  TOTAL: {results['total']} | âœ… Valid: {results['valid']} | "
              f"âš ï¸  Warnings: {results['warnings']} | âŒ Errors: {results['errors']}")
        if results['skipped']:
            print(f"  â­ Skipped: {results['skipped']}")
        print(f"  ðŸ“Š Metrics checked: {results['metrics_checked']} | "
              f"âŒ Invalid: {results['metrics_invalid']}")
        if fix:
            print(f"  ðŸ”§ Fixed: {results['fixed']}")
        print("=" * 80)
        
        if results['errors'] > 0 and not fix:
            print(f"\n  ðŸ’¡ Run with --fix-slos to auto-fix {results['errors']} SLO(s)")
        
        return results


class DashboardMigrator:
    """Main orchestrator for dashboard migration"""
    
    def __init__(self, nr_client: NewRelicClient, dt_client: Optional[DynatraceClient] = None,
                 registry: 'DTEnvironmentRegistry' = None):
        self.nr_client = nr_client
        self.dt_client = dt_client
        self.registry = registry
        self.converter = NRQLtoDQLConverter(registry=registry)
        self.layout_converter = LayoutConverter()
        self._schema_version = None  # Discovered from DT environment
    
    def configure_slo_migration(self, nr_api_key: str = None, dt_url: str = None,
                                 dt_token: str = None, auto_create: bool = False):
        """
        Configure automatic SLO creation during dashboard migration.
        
        When enabled, SERVICE_LEVEL GUIDs in NRQL will trigger:
        1. Fetch SLO definition from New Relic
        2. Create matching SLO in Dynatrace
        3. Use the SLO name in the converted DQL
        """
        self.converter.configure_slo_migration(
            nr_api_key=nr_api_key,
            dt_url=dt_url,
            dt_token=dt_token,
            auto_create=auto_create
        )
    
    def get_created_slos(self) -> Dict[str, str]:
        """Return dict of SLOs created during migration: GUID -> DT SLO ID"""
        return self.converter._created_slos.copy()
    
    def migrate_dashboard(self, guid: str, name: str, dry_run: bool = False) -> DashboardResult:
        """Migrate a single dashboard"""
        result = DashboardResult(name=name, nr_guid=guid)
        
        # Discover schema version from DT environment (once per session)
        if self._schema_version is None and self.dt_client:
            discovered = self.dt_client.discover_schema_version()
            if discovered:
                self._schema_version = discovered
                print(f"  âœ“ Discovered DT schema version: {discovered}")
            else:
                self._schema_version = DT_DASHBOARD_VERSION
                print(f"  â„¹ Using default schema version: {DT_DASHBOARD_VERSION}")
        
        try:
            # Fetch from New Relic
            nr_dashboard = self.nr_client.get_dashboard(guid)
            
            # Convert to Dynatrace format
            dt_dashboard, tile_results = self._convert_dashboard(nr_dashboard)
            
            result.tile_results = tile_results
            result.total_tiles = len(tile_results)
            result.successful_tiles = len([t for t in tile_results if t.success])
            result.tiles_with_fixes = len([t for t in tile_results if t.conversion and t.conversion.fixes_applied])
            result.total_fixes = sum(
                len(t.conversion.fixes_applied) 
                for t in tile_results 
                if t.conversion and t.conversion.fixes_applied
            )
            
            if not dry_run and self.dt_client:
                # Upload to Dynatrace
                dt_name = f"[Migrated] {name}"
                
                # Check for existing dashboard with same name (dedup via registry)
                if self.registry:
                    existing_id = self.registry.dashboard_exists(dt_name)
                    if existing_id:
                        print(f"  â­ Dashboard already exists in DT: '{dt_name}' â†’ {existing_id}")
                        print(f"    Skipping creation. Use --force to overwrite.")
                        result.dt_id = existing_id
                        result.success = True
                        return result
                
                result.dt_id = self.dt_client.create_dashboard(dt_name, dt_dashboard)
            
            result.success = True
            
        except Exception as e:
            result.success = False
            result.error = str(e)
            import traceback as _tb
            _tb.print_exc()  # Print full traceback for debugging
        
        return result
    
    def _convert_dashboard(self, nr_dashboard: Dict) -> Tuple[Dict, List[TileResult]]:
        """Convert NR dashboard to DT format with proper layout handling"""
        tiles = {}
        layouts = {}  # SEPARATE layouts object - this is key!
        tile_results = []
        tile_counter = 0
        
        pages = nr_dashboard.get("pages", [])
        
        # Track cumulative y-offset across pages
        # NR has separate pages with their own grids, DT flattens to one
        cumulative_y_offset = 0
        
        for page_idx, page in enumerate(pages):
            page_name = page.get("name", f"Page {page_idx + 1}")
            widgets = page.get("widgets", [])
            
            # Find the max y + height in this page to calculate next page offset
            page_max_y = 0
            for widget in widgets:
                layout = widget.get("layout", {})
                widget_bottom = layout.get("row", 0) + layout.get("height", 3)
                page_max_y = max(page_max_y, widget_bottom)
            
            # Add page header if multiple pages
            if len(pages) > 1:
                tile_id = str(tile_counter)
                tiles[tile_id] = {
                    "type": "markdown",
                    "content": f"## {page_name}"
                    # NO title field for markdown tiles per DT schema
                    # NO layout in tile - it goes in layouts object
                }
                layouts[tile_id] = {
                    "x": 0,
                    "y": cumulative_y_offset,
                    "w": DT_GRID_COLUMNS,  # Full width (24 columns)
                    "h": 1
                }
                tile_counter += 1
                cumulative_y_offset += 1  # Add space for the header
            
            # Convert each widget with adjusted y-position
            for widget in widgets:
                tile_id = str(tile_counter)
                tile_counter += 1
                
                tile, layout, tile_result = self._convert_widget(widget, cumulative_y_offset)
                tiles[tile_id] = tile
                layouts[tile_id] = layout
                tile_results.append(tile_result)
            
            # Add this page's height to cumulative offset for next page
            cumulative_y_offset += page_max_y
        
        # Build dashboard structure with SEPARATE layouts object
        # This matches the real DT schema
        # Use discovered version from environment, fall back to constant
        version = self._schema_version or DT_DASHBOARD_VERSION
        
        # â”€â”€ SLO Tile Deduplication â”€â”€
        # DT SLO tiles show Status + Error Budget + Target in one tile.
        # NR often splits these across 2-4 separate widgets for the same SLO:
        #   "Pricing Latency SLO target: 97%" + "Pricing Latency Error Budget"
        # Detect tiles referencing the same SLO GUID and merge into one.
        tiles, layouts = self._dedup_slo_tiles(tiles, layouts)
        
        dashboard = {
            "version": version,
            "variables": [],
            "tiles": tiles,
            "layouts": layouts,  # Layouts are SEPARATE, not embedded in tiles!
            "importedWithCode": False,
            "settings": {}
        }
        
        return dashboard, tile_results
    
    def _dedup_slo_tiles(self, tiles: Dict, layouts: Dict) -> Tuple[Dict, Dict]:
        """
        Deduplicate SLO tiles that reference the same SLO.
        
        NR dashboards often have 2-4 tiles per SLO:
          - "Pricing Latency SLO target: 97%" (status + target)
          - "Pricing Latency Error Budget"    (status + error budget)
          - "Pricing Latency SLI compliance over time (%)" (time series)
        
        DT's SLO tile shows ALL columns (Status, Error Budget, Target) in one widget.
        We keep the first tile for each SLO, enable all columns, and drop duplicates.
        
        Compliance "over time" tiles are kept as separate data tiles since they're
        time-series views, not the same as the summary SLO tile.
        """
        # Group SLO tiles by their sloId (or input)
        slo_groups = {}  # sloId â†’ list of (tile_id, tile, layout)
        non_slo_tiles = {}
        non_slo_layouts = {}
        
        for tile_id, tile in tiles.items():
            if tile.get('type') == 'slo':
                slo_id = tile.get('sloId') or tile.get('input')
                if slo_id:
                    if slo_id not in slo_groups:
                        slo_groups[slo_id] = []
                    slo_groups[slo_id].append((tile_id, tile, layouts.get(tile_id, {})))
                    continue
            # Also check data tiles that are SLO placeholders (no DT SLO ID yet)
            # Group by SLO GUID extracted from the query comment
            if tile.get('type') == 'data':
                query = tile.get('query', '')
                title_lower = (tile.get('title', '') or '').lower()
                # Check if it's an SLO placeholder
                guid_match = re.search(r'Original NR GUID:\s*(\S+)', query)
                if guid_match and ('slo' in title_lower or 'sli' in title_lower 
                                     or 'error budget' in title_lower or 'compliance' in title_lower):
                    guid = guid_match.group(1)
                    # Skip "over time" / compliance time-series tiles - those are different
                    if 'over time' in title_lower or 'compliance over time' in title_lower:
                        non_slo_tiles[tile_id] = tile
                        non_slo_layouts[tile_id] = layouts.get(tile_id, {})
                        continue
                    if guid not in slo_groups:
                        slo_groups[guid] = []
                    slo_groups[guid].append((tile_id, tile, layouts.get(tile_id, {})))
                    continue
            
            non_slo_tiles[tile_id] = tile
            non_slo_layouts[tile_id] = layouts.get(tile_id, {})
        
        # For each SLO group, keep one tile with all columns enabled
        merged_count = 0
        for slo_id, group in slo_groups.items():
            if len(group) <= 1:
                # Single tile â€” just enable all columns and keep it
                tile_id, tile, layout = group[0]
                self._enable_all_slo_columns(tile)
                non_slo_tiles[tile_id] = tile
                non_slo_layouts[tile_id] = layout
                continue
            
            # Multiple tiles for the same SLO â€” merge
            # Pick the tile with the best title (prefer one with SLO name, avoid "Error Budget")
            best_idx = 0
            for i, (tid, t, l) in enumerate(group):
                title = (t.get('title', '') or '').lower()
                if 'target' in title or 'slo' in title:
                    best_idx = i
                    break
            
            # Keep the best tile, enable all columns, use widest layout
            keep_id, keep_tile, keep_layout = group[best_idx]
            self._enable_all_slo_columns(keep_tile)
            
            # Use the widest layout from any of the tiles
            max_w = keep_layout.get('w', 6)
            for _, _, other_layout in group:
                max_w = max(max_w, other_layout.get('w', 6))
            keep_layout['w'] = max_w
            
            non_slo_tiles[keep_id] = keep_tile
            non_slo_layouts[keep_id] = keep_layout
            
            dropped = len(group) - 1
            merged_count += dropped
            titles = [g[1].get('title', '?') for g in group]
            print(f"    âœ“ Merged {len(group)} SLO tiles â†’ 1: {titles}")
        
        if merged_count > 0:
            print(f"    âœ“ Deduplicated {merged_count} redundant SLO tile(s)")
        
        return non_slo_tiles, non_slo_layouts
    
    def _enable_all_slo_columns(self, tile: Dict):
        """Enable all SLO columns (Status, Error Budget, Target) on a tile."""
        viz_settings = tile.get('visualizationSettings', {})
        viz_settings['columns'] = {
            'status': True,
            'errorBudget': True,
            'target': True,
            'evaluationPeriod': False
        }
        tile['visualizationSettings'] = viz_settings

    def _convert_widget(self, widget: Dict, y_offset: int = 0) -> Tuple[Dict, Dict, TileResult]:
        """Convert a single NR widget to DT tile and layout (separate objects)"""
        viz_raw = widget.get("visualization", {})
        if isinstance(viz_raw, str):
            viz = viz_raw
        elif isinstance(viz_raw, dict):
            viz = viz_raw.get("id", "viz.table")
        else:
            viz = "viz.table"
        raw_config = widget.get("rawConfiguration", {})
        # NR GraphQL returns rawConfiguration as a JSON string â€” parse it
        if isinstance(raw_config, str):
            try:
                raw_config = json.loads(raw_config)
            except (json.JSONDecodeError, TypeError):
                raw_config = {}
        title = widget.get("title", "")
        nr_layout = widget.get("layout", {})
        
        result = TileResult(
            title=title,
            tile_type=viz,
            layout=nr_layout,
            success=True
        )
        
        # Convert layout with y-offset for page accumulation
        # NR uses: column (1-12), row (1-based), width, height - 12 column grid
        # DT uses: x (0-based), y (0-based), w, h - 24 column grid
        # So we need to double the x and width values
        nr_col = nr_layout.get("column", 1) - 1  # Convert 1-indexed to 0-indexed
        nr_width = nr_layout.get("width", 4)
        
        dt_layout = {
            "x": nr_col * 2,  # NR 12-col -> DT 24-col (multiply by 2)
            "y": (nr_layout.get("row", 1) - 1) + y_offset,  # Add page offset
            "w": nr_width * 2,  # NR 12-col -> DT 24-col (multiply by 2)
            "h": nr_layout.get("height", 3)
        }
        
        # â”€â”€ Tile sizing: enforce readable minimums â”€â”€
        # NR height units are smaller than DT's; scale up and enforce per-viz minimums
        # Also ensure width isn't too narrow for content
        nr_h = nr_layout.get("height", 3)
        
        # Scale height: NR tiles are denser; DT needs more vertical space
        # A NR tile at h=3 is roughly equivalent to DT h=5-6
        scaled_h = max(nr_h, int(nr_h * 1.5))
        
        # Per-visualization minimum heights (DT grid units)
        VIZ_MIN_HEIGHTS = {
            'lineChart': 6, 'areaChart': 6,           # Charts need room for axes + legend
            'barChart': 6,                              # Bars need label space
            'pieChart': 5,                              # Pie needs room for labels
            'table': 6,                                 # Tables need header + rows
            'singleValue': 3,                           # Billboard can be compact
            'histogram': 6,                             # Histogram needs bin space
            'honeycomb': 5,                             # Honeycomb grid
            'graph': 8,                                 # Topology graphs need space
            'markdown': 2,                              # Markdown can be short
        }
        
        # Per-visualization minimum widths
        VIZ_MIN_WIDTHS = {
            'table': 8,                                 # Tables need column space
            'lineChart': 6, 'areaChart': 6,
            'barChart': 6,
            'pieChart': 6,
            'singleValue': 4,
        }
        
        # Apply minimum for this viz type (determined later, so use NR viz hint)
        nr_viz_lower = viz.lower() if viz else ''
        if 'table' in nr_viz_lower:
            min_h = VIZ_MIN_HEIGHTS.get('table', 5)
            min_w = VIZ_MIN_WIDTHS.get('table', 8)
        elif 'line' in nr_viz_lower or 'area' in nr_viz_lower or 'timeseries' in nr_viz_lower:
            min_h = VIZ_MIN_HEIGHTS.get('lineChart', 6)
            min_w = VIZ_MIN_WIDTHS.get('lineChart', 6)
        elif 'billboard' in nr_viz_lower:
            min_h = VIZ_MIN_HEIGHTS.get('singleValue', 3)
            min_w = VIZ_MIN_WIDTHS.get('singleValue', 4)
        elif 'pie' in nr_viz_lower:
            min_h = VIZ_MIN_HEIGHTS.get('pieChart', 5)
            min_w = VIZ_MIN_WIDTHS.get('pieChart', 6)
        elif 'bar' in nr_viz_lower:
            min_h = VIZ_MIN_HEIGHTS.get('barChart', 6)
            min_w = VIZ_MIN_WIDTHS.get('barChart', 6)
        elif 'markdown' in nr_viz_lower:
            min_h = VIZ_MIN_HEIGHTS.get('markdown', 2)
            min_w = 4
        else:
            min_h = 5
            min_w = 6
        
        dt_layout["h"] = max(scaled_h, min_h)
        dt_layout["w"] = max(dt_layout["w"], min_w)
        
        # Cap width to grid max â€” if tile would overflow, first try preserving width
        if dt_layout["x"] + dt_layout["w"] > DT_GRID_COLUMNS:
            overflow = (dt_layout["x"] + dt_layout["w"]) - DT_GRID_COLUMNS
            # If we can shift the tile left to fit, do that instead of squeezing
            if dt_layout["x"] >= overflow:
                dt_layout["x"] -= overflow
            else:
                # Must clamp width, but enforce a readable minimum
                dt_layout["w"] = max(DT_GRID_COLUMNS - dt_layout["x"], 4)
        
        # Handle markdown - no title field per DT schema
        if viz == "viz.markdown":
            tile = {
                "type": "markdown",
                "content": raw_config.get("text", "")
                # NO title field for markdown - DT schema doesn't have it
                # NO layout - it's in the layouts object
            }
            return tile, dt_layout, result
        
        # Get NRQL queries
        nrql_queries = raw_config.get("nrqlQueries", [])
        
        if not nrql_queries:
            tile = {
                "type": "data",
                "title": title or "Untitled",
                "query": "// No NRQL query found in source widget",
                "visualization": "table",
                "visualizationSettings": self._default_viz_settings(),
                "davis": {"enabled": False, "davisVisualization": {"isAvailable": True}}
                # NO layout - it's in the layouts object
            }
            result.conversion = ConversionResult(
                original_nrql="",
                converted_dql="// No NRQL query",
                confidence="LOW"
            )
            return tile, dt_layout, result
        
        # Get NRQL for analysis
        nrql = nrql_queries[0].get("query", "")
        nrql_lower = nrql.lower()
        
        # CHECK FOR SLI QUERY - create SLO tile instead of data tile
        if 'newrelic.sli.' in nrql_lower or 'sli.good' in nrql_lower or 'sli.valid' in nrql_lower:
            return self._create_slo_tile(nrql, title, dt_layout, result)
        
        # Convert NRQL to DQL for non-SLO tiles
        conversion = self.converter.convert(nrql, title)
        result.conversion = conversion
        
        # Smart visualization selection based on query structure and original viz
        dt_viz = self._select_best_visualization(viz, conversion.converted_dql, nrql)
        
        # Post-selection height adjustment â€” ensure tile fits the chosen DT viz
        POST_VIZ_MIN_HEIGHTS = {
            'lineChart': 6, 'areaChart': 6, 'barChart': 6,
            'categoricalBarChart': 6,
            'pieChart': 5, 'table': 6, 'singleValue': 3,
            'histogram': 6, 'honeycomb': 5, 'graph': 8, 'markdown': 2,
        }
        post_min = POST_VIZ_MIN_HEIGHTS.get(dt_viz, 5)
        if dt_layout["h"] < post_min:
            dt_layout["h"] = post_min
        
        # Build tile WITHOUT layout (layout goes in separate layouts object)
        tile = {
            "type": "data",
            "title": title or "Untitled",
            "query": conversion.converted_dql,
            "visualization": dt_viz,
            "visualizationSettings": self._get_viz_settings(
                dt_viz, nr_raw_config=raw_config, dql=conversion.converted_dql),
            "davis": {
                "enabled": False,
                "davisVisualization": {"isAvailable": True}
            }
            # NO layout here - it's in the layouts object
        }
        
        # Add explicit dataMapping if applicable
        data_mapping = self._build_data_mapping(dt_viz, conversion.converted_dql)
        if data_mapping:
            tile["dataMapping"] = data_mapping
        
        # Post-construction validation â€” auto-correct mismatches
        warnings = self._validate_tile_config(tile, conversion.converted_dql)
        if warnings:
            for w in warnings:
                logger.warning(f"Tile '{title}': {w}")
            # Auto-correct: if timeseries assigned to honeycomb, switch to lineChart
            schema = self._infer_all_output_fields(conversion.converted_dql)
            if schema['is_timeseries'] and dt_viz in ('honeycomb', 'categoricalBarChart'):
                tile['visualization'] = 'lineChart'
                tile['visualizationSettings'] = self._get_viz_settings(
                    'lineChart', nr_raw_config=raw_config, dql=conversion.converted_dql)
                tile['dataMapping'] = self._build_data_mapping(
                    'lineChart', conversion.converted_dql)
                logger.info(f"Tile '{title}': Auto-corrected {dt_viz} â†’ lineChart for timeseries")
            elif not schema['is_timeseries'] and dt_viz == 'barChart':
                tile['visualization'] = 'categoricalBarChart'
                tile['visualizationSettings'] = self._get_viz_settings(
                    'categoricalBarChart', nr_raw_config=raw_config, dql=conversion.converted_dql)
                tile['dataMapping'] = self._build_data_mapping(
                    'categoricalBarChart', conversion.converted_dql)
                logger.info(f"Tile '{title}': Auto-corrected barChart â†’ categoricalBarChart")
        
        return tile, dt_layout, result
    
    def _select_best_visualization(self, nr_viz: str, dql: str, nrql: str) -> str:
        """
        Select the best DT visualization based on query structure, metric type, and NR viz.
        
        DT visualization types:
          lineChart, areaChart, barChart, pieChart, singleValue,
          table, histogram, honeycomb, graph, categoricalBarChart
        
        Selection logic (priority order):
        1. Query structure (timeseries, summarize, facet count) 
        2. Metric semantics (utilizationâ†’gauge, countâ†’bar, rateâ†’line)
        3. NR visualization hint (preserve user intent)
        """
        dql_lower = dql.lower()
        nrql_lower = nrql.lower()
        
        # Strip comment lines before detecting query structure
        dql_code = '\n'.join(l for l in dql_lower.split('\n') if l.strip() and not l.strip().startswith('//'))
        is_timeseries = ('maketimeseries' in dql_code or 
                         dql_code.strip().startswith('timeseries') or
                         '\ntimeseries ' in dql_code)
        is_grouped = 'summarize' in dql_lower and 'by:' in dql_lower
        is_single_agg = 'summarize' in dql_lower and 'by:' not in dql_lower
        has_facet = 'facet' in nrql_lower
        has_multiple_aggs = dql_lower.count('count()') + dql_lower.count('avg(') + dql_lower.count('sum(') > 1
        
        # Count FACET items to determine grouping density
        facet_count = 0
        if has_facet:
            facet_match = re.search(r'facet\s+(.+?)(?:\s+(?:timeseries|since|until|limit|order|where)\b|$)', 
                                     nrql_lower, re.IGNORECASE)
            if facet_match:
                facet_count = facet_match.group(1).count(',') + 1
        
        # Detect metric semantics from query content
        is_utilization = any(kw in dql_lower for kw in ['utilization', 'percent', '_pct', 'usage'])
        is_error_rate = any(kw in dql_lower for kw in ['error_rate', 'failure', 'error'])
        is_throughput = any(kw in dql_lower for kw in ['request_count', 'count()', 'throughput'])
        is_latency = any(kw in dql_lower for kw in ['response.time', 'duration', 'latency', 'percentile'])
        is_status = any(kw in nrql_lower for kw in ['health', 'status', 'state', 'up', 'down'])
        
        # â”€â”€ TIMESERIES queries â”€â”€
        if is_timeseries:
            # Error rates and utilization â†’ area chart (filled shows severity)
            if is_error_rate or is_utilization:
                return 'areaChart'
            # Throughput/count â†’ bar chart (discrete intervals)
            if is_throughput and not is_latency:
                if nr_viz in ('viz.bar', 'viz.stacked-bar'):
                    return 'barChart'
            # Preserve NR area if specified
            if nr_viz in ('viz.area', 'viz.stacked-area'):
                return 'areaChart'
            # Default timeseries â†’ line chart
            return 'lineChart'
        
        # â”€â”€ HISTOGRAM (NRQL function â†’ categoricalBarChart, NOT DT histogram viz) â”€â”€
        # DT's "Histogram" viz expects pre-binned range data with start/end fields.
        # DT's "Bar" chart requires a Time dimension (timestamp column).
        # NR histogram() is a distribution: count()+bin() â†’ categoricalBarChart
        # which maps categories (bins) to values (counts) without needing time.
        if re.search(r'\bhistogram\s*\(', nrql_lower):
            return 'categoricalBarChart'
        
        # â”€â”€ Single value (billboard) â”€â”€
        if is_single_agg or nr_viz == 'viz.billboard':
            return 'singleValue'
        
        # â”€â”€ Status/health grids â†’ honeycomb â”€â”€
        if is_status and has_facet and facet_count <= 2:
            return 'honeycomb'
        
        # â”€â”€ Grouped aggregates (non-timeseries) â”€â”€
        # IMPORTANT: DT barChart expects a Time dimension (timeseries data).
        # Non-timeseries grouped data MUST use categoricalBarChart (Categories dimension).
        if is_grouped or (has_facet and 'timeseries' not in nrql_lower):
            # NR user chose pie â†’ respect it
            if nr_viz == 'viz.pie':
                return 'pieChart'
            # NR user chose table
            if nr_viz == 'viz.table':
                return 'table'
            # Count-only with few groups â†’ pie
            if is_throughput and facet_count <= 2 and nr_viz not in ('viz.bar', 'viz.stacked-bar'):
                return 'pieChart'
            # Default grouped â†’ categoricalBarChart (NOT barChart which needs Time)
            return 'categoricalBarChart'
        
        # â”€â”€ Table (raw data, multi-column) â”€â”€
        if nr_viz == 'viz.table' or 'fields' in dql_lower:
            return 'table'
        
        # â”€â”€ Markdown passthrough â”€â”€
        if nr_viz == 'viz.markdown':
            return 'markdown'
        
        # â”€â”€ Fallback: use NR viz mapping â”€â”€
        return VIZ_MAP.get(nr_viz, 'table')
    
    def _get_viz_settings(self, viz_type: str, nr_raw_config: Dict = None, 
                           dql: str = '') -> Dict:
        """Get visualization-specific settings, extracting NR config where available.
        
        Reads NR rawConfiguration for:
        - thresholds (billboard/single value critical/warning values)
        - colors (series color overrides)  
        - units (y-axis unit suffix)
        - legend position and visibility
        - chart type specific settings
        
        Computes recordField dynamically from DQL output field names.
        """
        nr_raw = nr_raw_config or {}
        if isinstance(nr_raw, str):
            try:
                nr_raw = json.loads(nr_raw)
            except (json.JSONDecodeError, TypeError):
                nr_raw = {}
        
        base_settings = {
            "thresholds": [],
            "chartSettings": {
                "gapPolicy": "connect",
                "legend": {
                    "hidden": False,
                    "position": "auto"
                }
            }
        }
        
        # â”€â”€ Extract NR thresholds â†’ DT thresholds â”€â”€
        # NR has two formats: list of alert thresholds, or dict of display settings
        nr_thresholds = nr_raw.get("thresholds", [])
        if isinstance(nr_thresholds, list) and nr_thresholds:
            dt_thresholds = self._convert_nr_thresholds(nr_thresholds)
            if dt_thresholds:
                base_settings["thresholds"] = dt_thresholds
        
        # â”€â”€ Extract NR units â”€â”€
        nr_y_axis = nr_raw.get("yAxisLeft", {})
        if not isinstance(nr_y_axis, dict):
            nr_y_axis = {}
        nr_unit = nr_y_axis.get("type") or nr_y_axis.get("unit") or ""
        
        # â”€â”€ Compute recordField from DQL output â”€â”€
        record_field = self._infer_record_field(dql)
        
        if viz_type == 'singleValue':
            # For faceted queries (FACET/by:), the dimension field is the "Single value"
            # display and the aggregation becomes the trend
            facet_field = self._infer_facet_field(dql)
            sv_record_field = facet_field if facet_field else record_field
            
            sv_settings = {
                "showLabel": True,
                "label": "",
                "autoscale": True,
                "alignment": "center",
                "recordField": sv_record_field,
                "colorThresholdTarget": "value"
            }
            
            # If faceted, set the trend to Custom with the aggregation field
            if facet_field:
                sv_settings["trend"] = {
                    "trendType": "custom",
                    "field": record_field  # e.g. "count()"
                }
            else:
                sv_settings["trend"] = {
                    "trendType": "auto",
                    "isVisible": True
                }
            
            base_settings["singleValue"] = sv_settings
            base_settings["chartSettings"]["legend"]["hidden"] = True
            
            # Apply unit formatting if detected
            if nr_unit:
                unit_config = self._map_nr_unit(nr_unit)
                if unit_config:
                    base_settings["unitsOverrides"] = [unit_config]
            
        elif viz_type == 'pieChart':
            base_settings["chartSettings"]["circleChartSettings"] = {
                "groupingThresholdType": "relative",
                "groupingThresholdValue": 2,
                "valueType": "relative"
            }
            base_settings["chartSettings"]["legend"] = {
                "hidden": False,
                "position": "right"
            }
            
        elif viz_type in ['lineChart', 'areaChart']:
            base_settings["chartSettings"]["legend"] = {
                "hidden": False,
                "position": "bottom"
            }
            base_settings["chartSettings"]["leftAxisCustomLabel"] = ""
            base_settings["chartSettings"]["rightAxisCustomLabel"] = ""
            if viz_type == 'areaChart':
                base_settings["chartSettings"]["areaOpacity"] = 0.3
            
            # Apply y-axis unit
            if nr_unit:
                unit_config = self._map_nr_unit(nr_unit)
                if unit_config:
                    base_settings["unitsOverrides"] = [unit_config]
            
            # Preserve NR y-axis range if set
            nr_y_min = nr_y_axis.get("min")
            nr_y_max = nr_y_axis.get("max")
            if nr_y_min is not None or nr_y_max is not None:
                axis_config = {}
                if nr_y_min is not None:
                    axis_config["min"] = nr_y_min
                if nr_y_max is not None:
                    axis_config["max"] = nr_y_max
                base_settings["chartSettings"]["leftYAxisSettings"] = axis_config
                
            # Extract NR series colors if present
            nr_colors = nr_raw.get("colors", {})
            if nr_colors and isinstance(nr_colors, dict):
                series_overrides = []
                for series_name, color_val in nr_colors.items():
                    if isinstance(color_val, str) and color_val.startswith('#'):
                        series_overrides.append({
                            "seriesName": series_name,
                            "color": color_val
                        })
                if series_overrides:
                    base_settings["chartSettings"]["seriesOverrides"] = series_overrides
                
        elif viz_type == 'barChart':
            # barChart is for TIMESERIES data (has Time dimension)
            base_settings["chartSettings"]["legend"] = {
                "hidden": False,
                "position": "bottom"
            }
            if nr_unit:
                unit_config = self._map_nr_unit(nr_unit)
                if unit_config:
                    base_settings["unitsOverrides"] = [unit_config]
            
        elif viz_type == 'categoricalBarChart':
            # categoricalBarChart is for non-timeseries GROUPED data (has Categories dimension)
            base_settings["chartSettings"]["categoricalBarChartSettings"] = {
                "layout": "vertical",
                "categoryAxis": "auto",
                "showLabels": True,
                "showValues": True
            }
            base_settings["chartSettings"]["legend"] = {
                "hidden": False,
                "position": "bottom"
            }
            
        elif viz_type == 'histogram':
            base_settings["chartSettings"]["histogram"] = {
                "dataMappings": [{
                    "valueAxis": "duration"
                }],
                "numberOfBuckets": 20
            }
            
        elif viz_type == 'table':
            base_settings["tableSettings"] = {
                "isThresholdBackgroundAppliedToCell": False,
                "hiddenColumns": [],
                "lineWrapIds": [],
                "firstVisibleRowIndex": 0
            }
            base_settings["chartSettings"]["legend"]["hidden"] = True
            
        elif viz_type == 'honeycomb':
            facet_field = self._infer_facet_field(dql)
            hc_mappings = {
                "value": record_field
            }
            if facet_field:
                hc_mappings["names"] = facet_field
            base_settings["honeycomb"] = {
                "shape": "hexagon",
                "legend": {
                    "hidden": False,
                    "position": "auto"
                },
                "dataMappings": hc_mappings,
                "colorPalette": "blue-red"
            }
        
        return base_settings
    
    def _infer_record_field(self, dql: str) -> str:
        """Infer the primary output field name from a DQL query.
        
        Used for singleValue recordField and honeycomb value mapping.
        DQL singleValue needs recordField to match what the query actually outputs:
        - summarize count() â†’ 'count()'
        - summarize avg(duration) â†’ 'avg(duration)'  
        - summarize myAlias=count() â†’ 'myAlias'
        - fieldsAdd result = ... â†’ 'result'
        - makeTimeseries count() â†’ 'count()' (array column)
        - makeTimeseries {avg=avg(dur), p90=percentile(dur,90)} â†’ 'avg'
        """
        if not dql:
            return 'result'
        
        import re
        
        # Strip comments for analysis
        code_lines = [l for l in dql.split('\n') if l.strip() and not l.strip().startswith('//')]
        dql_code = '\n'.join(code_lines)
        
        # Check for fieldsAdd with named output (last one wins)
        fields_add = re.findall(r'\|\s*fieldsAdd\s+(\w+)\s*=', dql_code)
        if fields_add:
            return fields_add[-1]
        
        # Check for makeTimeseries aggregations
        ts_match = re.search(r'\|\s*makeTimeseries\s+(.*?)(?:\s*,\s*(?:by:|interval:|from:|to:)|$)', 
                             dql_code, re.DOTALL)
        if ts_match:
            agg_part = ts_match.group(1).strip()
            # Strip braces
            if agg_part.startswith('{'):
                agg_part = agg_part.strip('{}').strip()
            # Get first aggregation
            first_agg = self._split_top_level(agg_part)[0].strip() if agg_part else ''
            if first_agg:
                alias_m = re.match(r'(\w+)\s*=\s*\w+\(', first_agg)
                if alias_m:
                    return alias_m.group(1)
                func_m = re.match(r'(\w+\([^)]*\))', first_agg)
                if func_m:
                    return func_m.group(1)
        
        # Check for metric timeseries: timeseries avg(dt.host.cpu.usage)
        if dql_code.strip().lower().startswith('timeseries'):
            metric_match = re.match(r'timeseries\s+(.*?)(?:\s*,\s*(?:by|filter):|$)', 
                                    dql_code.strip(), re.DOTALL | re.IGNORECASE)
            if metric_match:
                agg_part = metric_match.group(1).strip()
                first_agg = self._split_top_level(agg_part)[0].strip() if agg_part else ''
                if first_agg:
                    alias_m = re.match(r'(\w+)\s*=\s*\w+\(', first_agg)
                    if alias_m:
                        return alias_m.group(1)
                    func_m = re.match(r'(\w+\([^)]*\))', first_agg)
                    if func_m:
                        return func_m.group(1)
        
        # Check for summarize with alias
        summarize_match = re.search(r'\|\s*summarize\s+(.*?)(?:\s*,\s*by:|$)', dql_code, re.DOTALL)
        if summarize_match:
            agg_part = summarize_match.group(1).strip()
            if agg_part.startswith('{'):
                agg_part = agg_part.strip('{}').strip()
            first_agg = self._split_top_level(agg_part)[0].strip() if agg_part else ''
            if first_agg:
                alias_m = re.match(r'(\w+)\s*=\s*\w+\(', first_agg)
                if alias_m:
                    return alias_m.group(1)
                # No alias: return the raw expression
                func_m = re.match(r'(\w+\([^)]*\))', first_agg)
                if func_m:
                    return func_m.group(1)
                return first_agg
        
        return 'result'
    
    def _infer_facet_field(self, dql: str) -> Optional[str]:
        """Extract the dimension field from a faceted/grouped DQL query.
        
        For singleValue tiles with a by: clause, the dimension field should be
        the recordField (shown as "Single value") and the aggregation becomes
        the trend field.
        
        Returns the first dimension field name, or None if no by: clause.
        """
        if not dql:
            return None
        
        import re
        
        # Match by: {field} or by: {field1, field2}
        by_match = re.search(r'\bby:\s*\{([^}]+)\}', dql)
        if by_match:
            fields_str = by_match.group(1).strip()
            # Get first field, stripping any function wrapping like bin()
            first_field = fields_str.split(',')[0].strip()
            # If it's a function like bin(duration, 2s), skip â€” not a clean dimension
            if '(' in first_field:
                return None
            return first_field
        
        return None
    
    def _infer_all_output_fields(self, dql: str) -> Dict:
        """Analyze DQL to determine the output field schema.
        
        Returns a dict with:
          - 'agg_fields': list of aggregation output field names
          - 'dimension_fields': list of grouping/dimension field names
          - 'is_timeseries': bool
          - 'is_metric_timeseries': bool (starts with 'timeseries' command)
          - 'computed_fields': list of fieldsAdd output names
        """
        if not dql:
            return {'agg_fields': [], 'dimension_fields': [], 
                    'is_timeseries': False, 'is_metric_timeseries': False,
                    'computed_fields': []}
        
        import re
        
        # Strip comments for structure detection
        code_lines = [l for l in dql.split('\n') if l.strip() and not l.strip().startswith('//')]
        dql_code = '\n'.join(code_lines)
        dql_lower = dql_code.lower()
        
        is_ts = 'maketimeseries' in dql_lower
        is_metric_ts = dql_code.strip().lower().startswith('timeseries')
        
        agg_fields = []
        dimension_fields = []
        computed_fields = []
        
        # Extract fieldsAdd outputs
        for m in re.finditer(r'\|\s*fieldsAdd\s+(\w+)\s*=', dql_code):
            computed_fields.append(m.group(1))
        
        # Extract dimension fields from by: {field1, field2}
        by_match = re.search(r'\bby:\s*\{([^}]+)\}', dql_code)
        if by_match:
            for f in by_match.group(1).split(','):
                f = f.strip()
                # Handle alias: alias=expr
                alias_m = re.match(r'(\w+)\s*=\s*.+', f)
                if alias_m:
                    dimension_fields.append(alias_m.group(1))
                elif '(' not in f:
                    dimension_fields.append(f)
        
        # Extract aggregation fields
        # For makeTimeseries: look inside { } or bare aggregations
        if is_ts:
            ts_match = re.search(r'\|\s*makeTimeseries\s+(.*?)(?:\s*,\s*by:|$)', dql_code, re.DOTALL)
            if ts_match:
                agg_part = ts_match.group(1).strip()
                # Strip outer braces if present
                if agg_part.startswith('{'):
                    agg_part = agg_part.strip('{}').strip()
                # Parse each aggregation: alias=func() or just func()
                for agg in self._split_top_level(agg_part):
                    agg = agg.strip()
                    if not agg:
                        continue
                    alias_m = re.match(r'(\w+)\s*=\s*(\w+)\(', agg)
                    if alias_m:
                        agg_fields.append(alias_m.group(1))
                    else:
                        # Raw func like count() or avg(duration)
                        func_m = re.match(r'(\w+\([^)]*\))', agg)
                        if func_m:
                            agg_fields.append(func_m.group(1))
        elif 'summarize' in dql_lower:
            sum_match = re.search(r'\|\s*summarize\s+(.*?)(?:\s*,\s*by:|$)', dql_code, re.DOTALL)
            if sum_match:
                agg_part = sum_match.group(1).strip()
                if agg_part.startswith('{'):
                    agg_part = agg_part.strip('{}').strip()
                for agg in self._split_top_level(agg_part):
                    agg = agg.strip()
                    if not agg:
                        continue
                    alias_m = re.match(r'(\w+)\s*=\s*(\w+)\(', agg)
                    if alias_m:
                        agg_fields.append(alias_m.group(1))
                    else:
                        func_m = re.match(r'(\w+\([^)]*\))', agg)
                        if func_m:
                            agg_fields.append(func_m.group(1))
        
        # For metric timeseries: timeseries avg(dt.host.cpu.usage)
        if is_metric_ts:
            ts_match = re.match(r'timeseries\s+(.*?)(?:\s*,\s*(?:by|filter):|$)', 
                                dql_code.strip(), re.DOTALL | re.IGNORECASE)
            if ts_match:
                agg_part = ts_match.group(1).strip()
                for agg in self._split_top_level(agg_part):
                    agg = agg.strip()
                    if not agg:
                        continue
                    alias_m = re.match(r'(\w+)\s*=\s*(\w+)\(', agg)
                    if alias_m:
                        agg_fields.append(alias_m.group(1))
                    else:
                        func_m = re.match(r'(\w+\([^)]*\))', agg)
                        if func_m:
                            agg_fields.append(func_m.group(1))
        
        return {
            'agg_fields': agg_fields,
            'dimension_fields': dimension_fields,
            'is_timeseries': is_ts or is_metric_ts,
            'is_metric_timeseries': is_metric_ts,
            'computed_fields': computed_fields
        }
    
    def _split_top_level(self, s: str) -> list:
        """Split a string by commas, respecting nested parentheses."""
        parts = []
        depth = 0
        current = []
        for ch in s:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            elif ch == ',' and depth == 0:
                parts.append(''.join(current))
                current = []
                continue
            current.append(ch)
        if current:
            parts.append(''.join(current))
        return parts
    
    def _build_data_mapping(self, viz_type: str, dql: str) -> Optional[Dict]:
        """Build the explicit dataMapping object for a DT dashboard tile.
        
        Dynatrace tiles need explicit dataMapping to tell the visualization
        which DQL output columns map to which visual elements.
        Without it, auto-mapping fails when field names are non-standard,
        causing "No field available" errors.
        
        Covers ALL 21 DT visualization types:
        - Timeseries: lineChart, areaChart, barChart, bandChart
        - Categorical: categoricalBarChart, pieChart, donutChart
        - Scalar: singleValue, gauge, meterBar
        - Grid: honeycomb, heatmap
        - Distribution: histogram, scatterPlot
        - Table: table, recordList, raw
        - Maps: choroplethMap, dotMap, connectionMap, bubbleMap
        
        Returns None for viz types that auto-map (table, recordList, raw).
        """
        schema = self._infer_all_output_fields(dql)
        agg_fields = schema['agg_fields']
        dim_fields = schema['dimension_fields']
        computed = schema['computed_fields']
        is_ts = schema['is_timeseries']
        
        # Use computed fields if they exist (they're the "final" output)
        value_fields = computed if computed else agg_fields
        
        # â”€â”€ Timeseries visualizations â”€â”€
        if viz_type in ('lineChart', 'areaChart', 'barChart'):
            mapping = {}
            if is_ts:
                mapping['time'] = 'timeframe'
            if value_fields:
                mapping['values'] = value_fields
            if dim_fields:
                mapping['series'] = dim_fields
            return mapping if mapping else None
        
        # â”€â”€ Band chart (upper/lower bands around a central line) â”€â”€
        elif viz_type == 'bandChart':
            # bandChart needs: time, upperBound, lowerBound, and optionally a center value
            # Typically from queries producing min/max/avg or percentile bands
            mapping = {}
            if is_ts:
                mapping['time'] = 'timeframe'
            if len(value_fields) >= 3:
                # Assume: first=lower, second=center, third=upper
                mapping['lowerBound'] = value_fields[0]
                mapping['values'] = [value_fields[1]]
                mapping['upperBound'] = value_fields[2]
            elif len(value_fields) == 2:
                mapping['lowerBound'] = value_fields[0]
                mapping['upperBound'] = value_fields[1]
            elif value_fields:
                mapping['values'] = value_fields
            if dim_fields:
                mapping['series'] = dim_fields
            return mapping if mapping else None
            
        # â”€â”€ Single value â”€â”€
        elif viz_type == 'singleValue':
            if value_fields:
                return {'singleValue': value_fields[0]}
            return None
        
        # â”€â”€ Gauge (single numeric with min/max range) â”€â”€
        elif viz_type == 'gauge':
            if value_fields:
                return {'value': value_fields[0]}
            return None
        
        # â”€â”€ Meter bar (horizontal bar showing single value against range) â”€â”€
        elif viz_type == 'meterBar':
            if value_fields:
                return {'value': value_fields[0]}
            return None
            
        # â”€â”€ Honeycomb â”€â”€
        elif viz_type == 'honeycomb':
            mapping = {}
            if value_fields:
                mapping['value'] = value_fields[0]
            if dim_fields:
                mapping['names'] = dim_fields[0]
            return mapping if mapping else None
        
        # â”€â”€ Heatmap (x-axis, y-axis, color intensity) â”€â”€
        elif viz_type == 'heatmap':
            mapping = {}
            if is_ts:
                mapping['time'] = 'timeframe'
            if value_fields:
                mapping['value'] = value_fields[0]
            if dim_fields:
                mapping['categories'] = dim_fields[0]
            return mapping if mapping else None
            
        # â”€â”€ Categorical bar chart â”€â”€
        elif viz_type == 'categoricalBarChart':
            mapping = {}
            if value_fields:
                mapping['values'] = value_fields
            if dim_fields:
                mapping['categories'] = dim_fields[0]
            return mapping if mapping else None
            
        # â”€â”€ Pie / Donut chart â”€â”€
        elif viz_type in ('pieChart', 'donutChart'):
            mapping = {}
            if value_fields:
                mapping['value'] = value_fields[0]
            if dim_fields:
                mapping['names'] = dim_fields[0]
            return mapping if mapping else None
        
        # â”€â”€ Histogram (binned distribution) â”€â”€
        elif viz_type == 'histogram':
            # Histogram expects pre-binned data with start/end or bin edges
            # When coming from NR histogram(), we've converted to count() + bin()
            mapping = {}
            if value_fields:
                mapping['value'] = value_fields[0]
            if dim_fields:
                mapping['categories'] = dim_fields[0]
            return mapping if mapping else None
        
        # â”€â”€ Scatterplot (x vs y with optional size) â”€â”€
        elif viz_type == 'scatterPlot':
            mapping = {}
            if len(value_fields) >= 2:
                mapping['x'] = value_fields[0]
                mapping['y'] = value_fields[1]
                if len(value_fields) >= 3:
                    mapping['size'] = value_fields[2]
            elif value_fields:
                mapping['x'] = value_fields[0]
            if dim_fields:
                mapping['color'] = dim_fields[0]
            return mapping if mapping else None
        
        # â”€â”€ Map visualizations (choropleth, dot, connection, bubble) â”€â”€
        elif viz_type in ('choroplethMap', 'dotMap', 'connectionMap', 'bubbleMap'):
            # Maps need geographic data. If query has lat/lon fields, map them.
            # Otherwise, entity-based queries may auto-resolve location.
            mapping = {}
            all_fields = value_fields + dim_fields
            all_lower = {f.lower(): f for f in all_fields}
            
            # Try to find lat/lon fields
            lat_candidates = ['latitude', 'lat', 'geo.lat', 'location.lat']
            lon_candidates = ['longitude', 'lon', 'lng', 'geo.lon', 'location.lon']
            
            for lc in lat_candidates:
                if lc in all_lower:
                    mapping['latitude'] = all_lower[lc]
                    break
            for lc in lon_candidates:
                if lc in all_lower:
                    mapping['longitude'] = all_lower[lc]
                    break
            
            if value_fields:
                mapping['value'] = value_fields[0]
            if dim_fields:
                mapping['names'] = dim_fields[0]
            
            return mapping if mapping else None
            
        # â”€â”€ Table / Record list / Raw â†’ auto-map all columns â”€â”€
        elif viz_type in ('table', 'recordList', 'raw'):
            return None
            
        return None
    
    def _validate_tile_config(self, tile: Dict, dql: str) -> List[str]:
        """Post-construction validation of tile configuration.
        
        Returns a list of warning strings. Empty list = valid.
        Checks:
        - Visualization type matches query structure
        - Required data mapping fields present
        - Field names in settings match DQL output
        """
        warnings = []
        viz = tile.get('visualization', '')
        schema = self._infer_all_output_fields(dql)
        
        # Check: timeseries query should not use non-timeseries viz types
        ts_incompatible = {'honeycomb', 'categoricalBarChart', 'pieChart', 'donutChart',
                          'gauge', 'meterBar', 'scatterPlot'}
        if schema['is_timeseries'] and viz in ts_incompatible:
            warnings.append(
                f"Viz '{viz}' incompatible with timeseries query â€” should be lineChart/areaChart/barChart")
        
        # Check: non-timeseries query should not use barChart (needs Time dimension)
        if not schema['is_timeseries'] and viz == 'barChart':
            warnings.append(
                "barChart requires timeseries data (Time dimension) â€” use categoricalBarChart instead")
        
        # Check: honeycomb needs both value and names
        viz_settings = tile.get('visualizationSettings', {})
        hc = viz_settings.get('honeycomb', {})
        if viz == 'honeycomb' and hc:
            dm = hc.get('dataMappings', {})
            if not dm.get('value'):
                warnings.append("Honeycomb missing 'value' in dataMappings")
            if not dm.get('names') and schema['dimension_fields']:
                warnings.append("Honeycomb missing 'names' in dataMappings but query has dimensions")
        
        # Check: singleValue recordField matches a real output field
        sv = viz_settings.get('singleValue', {})
        if viz == 'singleValue' and sv:
            rf = sv.get('recordField', '')
            all_fields = schema['agg_fields'] + schema['dimension_fields'] + schema['computed_fields']
            if rf and all_fields and rf not in all_fields and rf != 'result':
                warnings.append(
                    f"singleValue recordField '{rf}' not found in DQL output: {all_fields}")
        
        # Check: gauge/meterBar need at least one value field
        if viz in ('gauge', 'meterBar'):
            value_fields = schema['computed_fields'] or schema['agg_fields']
            if not value_fields:
                warnings.append(f"{viz} requires at least one numeric value field")
        
        # Check: scatterPlot needs at least 2 value fields for x/y
        if viz == 'scatterPlot':
            value_fields = schema['computed_fields'] or schema['agg_fields']
            if len(value_fields) < 2:
                warnings.append("scatterPlot needs at least 2 numeric fields for x and y axes")
        
        # Check: map types need geographic context
        if viz in ('choroplethMap', 'dotMap', 'connectionMap', 'bubbleMap'):
            all_fields = schema['agg_fields'] + schema['dimension_fields'] + schema['computed_fields']
            all_lower = [f.lower() for f in all_fields]
            geo_fields = {'latitude', 'lat', 'longitude', 'lon', 'lng', 'geo.lat', 'geo.lon',
                         'location.lat', 'location.lon', 'countryCode', 'regionCode', 'city'}
            if not any(f in geo_fields for f in all_lower):
                warnings.append(f"{viz} requires geographic fields (lat/lon, countryCode, city, etc.)")
        
        return warnings

    def _convert_nr_thresholds(self, nr_thresholds: list) -> list:
        """Convert NR billboard thresholds to DT threshold format.
        
        NR format: [{"alertSeverity": "WARNING", "value": 0.5}, 
                     {"alertSeverity": "CRITICAL", "value": 1.0}]
        or newer: {"thresholds": [{"column": "count", "severity": "critical", "value": 100}]}
        
        DT format: [{"field": "count()", "title": "Critical", "isEnabled": true,
                      "rules": [{"value": 1.0, "color": {"Default": "#dc3545"}}]}]
        """
        dt_thresholds = []
        
        color_map = {
            'critical': '#dc3545',  # Red
            'warning': '#ffc107',   # Yellow/amber
            'not_alerting': '#28a745',  # Green
        }
        
        for t in nr_thresholds:
            severity = (t.get('alertSeverity', '') or t.get('severity', '')).lower()
            value = t.get('value')
            if value is not None and severity:
                dt_thresholds.append({
                    "field": "",  # Auto-detect
                    "title": severity.capitalize(),
                    "isEnabled": True,
                    "rules": [{
                        "value": value,
                        "color": {"Default": color_map.get(severity, '#ffc107')}
                    }]
                })
        
        return dt_thresholds
    
    def _map_nr_unit(self, nr_unit: str) -> Optional[Dict]:
        """Map NR y-axis unit types to DT unit override format.
        
        NR unit types: MILLISECONDS, SECONDS, BYTES, PERCENTAGE, COUNT, etc.
        DT units: ms, s, bytes, percent, count, etc.
        """
        unit_map = {
            'milliseconds': {"unit": "MilliSecond", "suffix": "ms"},
            'ms': {"unit": "MilliSecond", "suffix": "ms"},
            'seconds': {"unit": "Second", "suffix": "s"},
            's': {"unit": "Second", "suffix": "s"},
            'bytes': {"unit": "Byte", "suffix": "B"},
            'percentage': {"unit": "Percent", "suffix": "%"},
            'percent': {"unit": "Percent", "suffix": "%"},
            'count': {"unit": "Count", "suffix": ""},
            'requests_per_second': {"unit": "PerSecond", "suffix": "/s"},
            'apdex': {"unit": "Ratio", "suffix": ""},
        }
        
        mapped = unit_map.get(nr_unit.lower())
        if not mapped:
            return None
        
        return {
            "identifier": "general",
            "unitDefinition": mapped
        }
    
    def _create_slo_tile(self, nrql: str, title: str, dt_layout: Dict, result: TileResult) -> Tuple[Dict, Dict, TileResult]:
        """
        Create a proper DT SLO tile for NR SLI queries.
        
        Instead of a DQL code tile, we create an actual SLO widget tile
        that references the migrated SLO.
        """
        nrql_lower = nrql.lower()
        
        # Extract SLO GUID from WHERE clause
        slo_guid = None
        guid_match = re.search(r"entity\.guid\s*=\s*['\"]([^'\"]+)['\"]", nrql, re.IGNORECASE)
        if guid_match:
            slo_guid = guid_match.group(1)
        
        # Try to resolve GUID to SLO name and DT SLO ID
        slo_name = None
        dt_slo_id = None
        
        if slo_guid:
            # Debug: Check the auto_create flag
            print(f"    DEBUG: slo_guid={slo_guid[:30]}...")
            print(f"    DEBUG: converter._auto_create_slos={self.converter._auto_create_slos}")
            
            # IMPORTANT: Trigger SLO creation if auto-create is enabled
            # This ensures the SLO exists in DT before we try to reference it
            if self.converter._auto_create_slos:
                # This will create the SLO if it doesn't exist and cache the result
                replacement, warning = self.converter._handle_slo_guid(slo_guid)
                print(f"    DEBUG: SLO handle result: {replacement[:50]}...")
            
            # Now check our cache for the DT SLO ID (set during auto-create)
            if slo_guid in self.converter._created_slos:
                dt_slo_id = self.converter._created_slos[slo_guid]
                # Skip FAILED entries
                if dt_slo_id and isinstance(dt_slo_id, str) and dt_slo_id.startswith('FAILED:'):
                    dt_slo_id = None
            
            # Get the name from cache
            if slo_guid in self.converter._guid_cache:
                slo_name = self.converter._guid_cache[slo_guid]
        
        # SLO tiles always show all columns â€” dedup in _dedup_slo_tiles
        # handles merging multiple NR tiles into one DT tile
        show_status = True
        show_error_budget = True
        show_target = True
        
        # Build the SLO tile
        if dt_slo_id:
            # We have a DT SLO ID - create a proper SLO tile
            # Both 'input' and 'sloId' should be set to the entity ID
            tile = {
                "type": "slo",
                "title": title or slo_name or "SLO",
                "input": dt_slo_id,  # Required for SLO selection
                "sloId": dt_slo_id,  # Also required
                "visualizationSettings": {
                    "columns": {
                        "status": show_status,
                        "errorBudget": show_error_budget,
                        "target": show_target,
                        "evaluationPeriod": False
                    },
                    "showLabels": True,
                    "applyStatusThresholdColorTo": "value"
                }
            }
            
            result.conversion = ConversionResult(
                original_nrql=nrql,
                converted_dql=f"// SLO Tile: {slo_name or 'Unknown'}\n// DT SLO ID: {dt_slo_id}",
                confidence="HIGH"
            )
            result.success = True
            
            print(f"    âœ“ Created SLO tile for: {slo_name or dt_slo_id}")
        else:
            # No DT SLO ID - create a placeholder data tile with instructions
            tile = {
                "type": "data",
                "title": title or "SLO (needs configuration)",
                "query": f'''// SLO TILE REQUIRED
// This tile should display SLO data for: {slo_name or 'Unknown SLO'}
// 
// TO FIX: 
// 1. Delete this tile
// 2. Add a new Service-Level Objective tile
// 3. Select the SLO: "{slo_name or 'Your SLO'}"
//
// Original NR GUID: {slo_guid or 'Unknown'}
// Original NRQL: {' '.join((nrql[:200]).split())}...''',
                "visualization": "singleValue",
                "visualizationSettings": self._default_viz_settings(),
                "davis": {"enabled": False, "davisVisualization": {"isAvailable": True}}
            }
            
            result.conversion = ConversionResult(
                original_nrql=nrql,
                converted_dql="// SLO tile placeholder - needs manual configuration",
                confidence="LOW"
            )
            result.success = True
            
            print(f"    âš  Created placeholder for SLO: {slo_name or slo_guid or 'Unknown'} (no DT SLO ID available)")
        
        return tile, dt_layout, result
    
    def _default_viz_settings(self) -> Dict:
        return {
            "thresholds": [],
            "chartSettings": {
                "gapPolicy": "connect",
                "circleChartSettings": {
                    "groupingThresholdType": "relative",
                    "groupingThresholdValue": 0,
                    "valueType": "relative"
                }
            },
            "singleValue": {
                "showLabel": True,
                "label": "",
                "autoscale": True,
                "alignment": "center"
            },
            "table": {
                "rowDensity": "condensed",
                "enableSparklines": False,
                "hiddenColumns": [],
                "columnWidths": {}
            }
        }


# ============================================================================
# MAIN
# ============================================================================

def run_migration(dashboards: List[Dict], dry_run: bool = False, verbose: bool = False,
                  auto_create_slos: bool = False, nr_api_key: str = None,
                  dt_url: str = None, dt_token: str = None):
    """
    Run migration for selected dashboards.
    
    Args:
        dt_token: OAuth token for both dashboards and Platform SLOs
                  (needs document:documents:write AND slo:slos:write scopes)
    """
    """Run the migration for specified dashboards"""
    
    print("\n" + "="*70)
    print("US FOODS DASHBOARD MIGRATION TOOL")
    print("="*70)
    print(f"Mode: {'DRY RUN (preview only)' if dry_run else 'LIVE MIGRATION'}")
    if auto_create_slos:
        print(f"SLO Auto-Create: ENABLED (Platform SLO API)")
    print(f"Dashboards: {len(dashboards)}")
    print("="*70)
    
    # Use passed parameters or fall back to globals
    effective_dt_url = dt_url or DT_ENV_URL
    effective_dt_token = dt_token or DT_API_TOKEN  # OAuth token for both dashboards AND SLOs
    effective_nr_key = nr_api_key or NR_API_KEY
    
    # Debug: show token info
    if effective_dt_token:
        print(f"OAuth Token: {effective_dt_token[:20]}...{effective_dt_token[-10:]} (len={len(effective_dt_token)})")
    
    # Initialize clients - DynatraceClient uses OAuth token for dashboard creation
    nr_client = NewRelicClient(effective_nr_key, NR_ACCOUNT_ID)
    dt_client = DynatraceClient(effective_dt_url, effective_dt_token) if not dry_run and effective_dt_token else None
    
    # Create shared environment registry for live validation across all components
    registry = None
    if effective_dt_url and (effective_dt_token or DT_API_TOKEN):
        registry = DTEnvironmentRegistry(
            effective_dt_url,
            oauth_token=effective_dt_token or '',
            api_token=DT_API_TOKEN or ''
        )
        print(f"  âœ“ Environment registry initialized (live metric + entity validation)")
    
    migrator = DashboardMigrator(nr_client, dt_client, registry=registry)
    
    # Configure SLO migration - NEW Platform SLO API uses .apps. domain with OAuth
    if effective_nr_key:
        if auto_create_slos and effective_dt_token:
            # Platform SLO API is on .apps. domain (NOT .live.)
            # It requires OAuth with slo:slos:read, slo:slos:write scopes
            slo_url = effective_dt_url  # Keep .apps. domain
            if '.live.' in slo_url:
                slo_url = slo_url.replace('.live.', '.apps.')
            print(f"SLO auto-creation enabled - Platform SLOs will be created at {slo_url}/platform/slo/v1/slos")
            print(f"  Note: OAuth client needs slo:slos:read and slo:slos:write scopes")
            migrator.configure_slo_migration(
                nr_api_key=effective_nr_key,
                dt_url=slo_url,
                dt_token=effective_dt_token,  # Use OAuth token
                auto_create=True
            )
        else:
            # Just resolve SLO names, don't auto-create
            migrator.configure_slo_migration(
                nr_api_key=effective_nr_key,
                auto_create=False
            )
    
    results = []
    total_fixes = 0
    
    for idx, dash_info in enumerate(dashboards, 1):
        name = dash_info["name"]
        guid = dash_info["guid"]
        
        print(f"\n[{idx}/{len(dashboards)}] {name}")
        print(f"    GUID: {guid}")
        
        result = migrator.migrate_dashboard(guid, name, dry_run=dry_run)
        results.append(result)
        
        if result.success:
            print(f"    âœ“ Converted {result.successful_tiles}/{result.total_tiles} tiles")
            
            if result.tiles_with_fixes > 0:
                print(f"    âœ“ Applied {result.total_fixes} syntax fixes across {result.tiles_with_fixes} tiles")
                total_fixes += result.total_fixes
            
            if verbose and result.tile_results:
                # Show fix details
                for tile_result in result.tile_results:
                    if tile_result.conversion and tile_result.conversion.fixes_applied:
                        print(f"      - {tile_result.title}:")
                        for fix in tile_result.conversion.fixes_applied:
                            print(f"        â€¢ {fix}")
            
            if not dry_run and result.dt_id:
                print(f"    âœ“ Created in Dynatrace: {result.dt_id}")
        else:
            print(f"    âœ— Error: {result.error}")
    
    # Summary
    print("\n" + "="*70)
    print("MIGRATION SUMMARY")
    print("="*70)
    
    successful = len([r for r in results if r.success])
    failed = len([r for r in results if not r.success])
    total_tiles = sum(r.total_tiles for r in results)
    converted_tiles = sum(r.successful_tiles for r in results)
    
    print(f"\nDashboards: {successful} succeeded, {failed} failed")
    print(f"Tiles: {converted_tiles}/{total_tiles} converted")
    print(f"Syntax Fixes Applied: {total_fixes}")
    
    # Live DQL Validation Summary
    if registry:
        cache = getattr(registry, '_dql_validation_cache', {})
        live_valid = sum(1 for v in cache.values() if v[0] is True and not str(v[1]).startswith('[AUTH]'))
        live_auth = sum(1 for v in cache.values() if v[0] is True and str(v[1]).startswith('[AUTH]'))
        live_invalid = sum(1 for v in cache.values() if v[0] is False)
        live_total = live_valid + live_auth + live_invalid
        if live_total > 0:
            print(f"\nðŸ”¬ Live DQL Validation (Grail API):")
            print(f"   âœ… {live_valid}/{live_total} queries validated successfully")
            if live_auth > 0:
                print(f"   ðŸ” {live_auth} queries valid syntax but token lacks table access (NOT_AUTHORIZED_FOR_TABLE)")
            if live_invalid > 0:
                print(f"   âŒ {live_invalid} queries have DT syntax errors")
                # Show first few errors
                error_count = 0
                for cache_key, (is_valid, error_msg, _) in cache.items():
                    if not is_valid and error_count < 5:
                        print(f"      â†’ {error_msg[:100]}")
                        error_count += 1
            else:
                print(f"   ðŸŽ¯ ZERO DQL syntax errors â€” all queries will render in Dynatrace")
        else:
            print(f"\nâš  Live DQL validation: No queries validated (check OAuth scopes)")
    else:
        print(f"\nâš  Live DQL validation: DISABLED (no registry/credentials)")
    
    # SLO Summary
    created_slos = migrator.get_created_slos()
    detected_slos = getattr(migrator.converter, '_detected_slos', set())
    
    if created_slos:
        print(f"\nSLOs Created in Dynatrace: {len(created_slos)}")
        for nr_guid, dt_slo_id in created_slos.items():
            slo_name = migrator.converter._guid_cache.get(nr_guid, 'Unknown')
            print(f"  âœ“ {slo_name} (DT ID: {dt_slo_id})")
    
    if detected_slos and not created_slos:
        print(f"\nSLOs Detected: {len(detected_slos)} (not auto-created)")
        print("  Use --auto-create-slos with --nr-api-key and --dt-token to create them")
        for guid in list(detected_slos)[:5]:
            slo_name = migrator.converter._guid_cache.get(guid, guid[:30] + '...')
            print(f"  - {slo_name}")
    elif not detected_slos and auto_create_slos:
        print("\nNo SERVICE_LEVEL GUIDs were found in the dashboard queries")
    
    if failed > 0:
        print("\nFailed dashboards:")
        for r in results:
            if not r.success:
                print(f"  - {r.name}: {r.error}")
    
    # Save detailed report
    report = {
        "timestamp": datetime.now().isoformat(),
        "mode": "dry_run" if dry_run else "live",
        "summary": {
            "total_dashboards": len(results),
            "successful": successful,
            "failed": failed,
            "total_tiles": total_tiles,
            "converted_tiles": converted_tiles,
            "total_fixes": total_fixes
        },
        "results": [
            {
                "name": r.name,
                "nr_guid": r.nr_guid,
                "dt_id": r.dt_id,
                "success": r.success,
                "error": r.error,
                "total_tiles": r.total_tiles,
                "successful_tiles": r.successful_tiles,
                "tiles_with_fixes": r.tiles_with_fixes,
                "total_fixes": r.total_fixes
            }
            for r in results
        ]
    }
    
    report_file = f"migration_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(report_file, 'w') as f:
        json.dump(report, f, indent=2)
    print(f"\nDetailed report saved to: {report_file}")
    
    return results


def main():
    parser = argparse.ArgumentParser(
        description="US Foods Dashboard Migration Tool - NR to DT"
    )
    
    parser.add_argument(
        "--list", 
        action="store_true",
        help="List MVP dashboards to migrate"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true", 
        help="Preview migration without uploading to Dynatrace"
    )
    parser.add_argument(
        "--migrate",
        action="store_true",
        help="Run full migration to Dynatrace"
    )
    parser.add_argument(
        "--dashboard",
        type=str,
        help="Migrate a specific dashboard by name"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Show detailed fix information"
    )
    parser.add_argument(
        "--export",
        action="store_true",
        help="Export converted dashboards to JSON files"
    )
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Just validate existing DT dashboards (don't migrate)"
    )
    
    # SLO Migration options
    parser.add_argument(
        "--auto-create-slos",
        action="store_true",
        help="Automatically create SLOs in Dynatrace when SERVICE_LEVEL GUIDs are detected"
    )
    parser.add_argument(
        "--nr-api-key",
        type=str,
        default=os.environ.get('NR_API_KEY'),
        help="New Relic API key (or set NR_API_KEY env var)"
    )
    parser.add_argument(
        "--audit-slos",
        action="store_true",
        help="Audit existing Dynatrace SLOs for correct DQL syntax and metric names"
    )
    parser.add_argument(
        "--fix-slos",
        action="store_true",
        help="Auto-fix known bad metric names in DT SLOs (requires --audit-slos)"
    )
    parser.add_argument(
        "--validate-env",
        action="store_true",
        help="Pre-flight check: validate METRIC_MAP targets, discover entities, dashboards, and locations"
    )
    parser.add_argument(
        "--validate-dql",
        action="store_true",
        help="Convert all dashboards and validate every DQL query against the live DT Grail API"
    )
    
    args = parser.parse_args()
    
    if args.list:
        print("\nMVP DASHBOARDS TO MIGRATE:")
        print("="*60)
        for idx, d in enumerate(MVP_DASHBOARDS, 1):
            print(f"{idx:2}. {d['name']}")
            print(f"    GUID: {d['guid']}")
            print(f"    Owner: {d['owner']}")
        print(f"\nTotal: {len(MVP_DASHBOARDS)} dashboards")
        return
    
    # Validate-only mode: check existing DT dashboards
    if args.validate_only:
        if not DT_API_TOKEN:
            print("ERROR: DT_API_TOKEN not set")
            return
        
        print("\nValidating existing Dynatrace dashboards...")
        dt_client = DynatraceClient(DT_ENV_URL, DT_API_TOKEN)
        
        # List documents that are dashboards - Platform API requires Bearer
        url = f"{DT_ENV_URL}/platform/document/v1/documents?filter=type%3D%3D'dashboard'"
        headers = {"Authorization": f"Bearer {DT_API_TOKEN}"}
        
        import requests
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            print(f"Error listing dashboards: {response.status_code}")
            print(response.text)
            return
        
        # Parse the response (it's JSON with documents array)
        try:
            data = response.json()
            documents = data.get('documents', [])
            print(f"Found {len(documents)} dashboards")
            
            for doc in documents:
                doc_id = doc.get('id', 'unknown')
                doc_name = doc.get('name', 'Untitled')
                print(f"\n  {doc_name} ({doc_id})")
        except Exception as e:
            print(f"Error parsing response: {e}")
        return
    
    # Filter dashboards if specific one requested
    if args.dashboard:
        dashboards = [d for d in MVP_DASHBOARDS if args.dashboard.lower() in d['name'].lower()]
        if not dashboards:
            print(f"No dashboard found matching: {args.dashboard}")
            return
    else:
        dashboards = MVP_DASHBOARDS
    
    if args.export:
        # Export mode - save to files WITH live DQL validation
        print("\nExporting dashboards to JSON files...")
        nr_client = NewRelicClient(NR_API_KEY, NR_ACCOUNT_ID)
        
        # Get OAuth for live DQL validation during export
        oauth_token = get_dt_oauth_token()
        registry = None
        if oauth_token and DT_ENV_URL:
            registry = DTEnvironmentRegistry(DT_ENV_URL, oauth_token=oauth_token, api_token=DT_API_TOKEN or '')
            print("  âœ“ Live DQL validation enabled for export")
        else:
            print("  âš  No OAuth token â€” exporting without live DQL validation")
        
        migrator = DashboardMigrator(nr_client, None, registry=registry)
        
        total_queries = 0
        validated_queries = 0
        
        for dash_info in dashboards:
            name = dash_info["name"]
            guid = dash_info["guid"]
            
            print(f"\nExporting: {name}")
            result = migrator.migrate_dashboard(guid, name, dry_run=True)
            
            if result.success:
                # Get the converted dashboard
                nr_dashboard = nr_client.get_dashboard(guid)
                dt_dashboard, conv_results = migrator._convert_dashboard(nr_dashboard)
                
                # Count validation stats
                for cr in conv_results:
                    total_queries += 1
                    if any('live-validated' in f.lower() or 'dql live' in f.lower() for f in cr.fixes_applied):
                        validated_queries += 1
                
                filename = f"dt_{name.replace(' ', '_').replace('/', '_')}.json"
                with open(filename, 'w') as f:
                    json.dump(dt_dashboard, f, indent=2)
                print(f"  Saved to: {filename}")
        
        if registry:
            print(f"\n  ðŸ“Š Live validated {validated_queries}/{total_queries} queries against DT Grail API")
        return
    
    if args.dry_run or args.migrate:
        # Check credentials
        nr_key = args.nr_api_key or NR_API_KEY
        
        if not nr_key:
            print("ERROR: NR_API_KEY not set")
            return
        
        # ALWAYS get OAuth token â€” needed for live DQL validation in ALL modes
        # Not just for dashboard upload. The registry uses it for Grail API validation.
        oauth_token = get_dt_oauth_token()
        if oauth_token:
            print("âœ“ OAuth token obtained (live DQL validation enabled)")
        else:
            if args.migrate:
                print("ERROR: Could not obtain OAuth token for dashboards")
                return
            else:
                print("âš  OAuth unavailable â€” live DQL validation disabled (dry-run will still work)")
        
        if args.migrate and args.auto_create_slos:
            print("âœ“ Using OAuth token for Platform SLO creation")
            print("  Note: OAuth client needs slo:slos:read and slo:slos:write scopes")
        
        run_migration(
            dashboards, 
            dry_run=args.dry_run, 
            verbose=args.verbose,
            auto_create_slos=args.auto_create_slos,
            nr_api_key=nr_key,
            dt_url=DT_ENV_URL,
            dt_token=oauth_token
        )
        
        # Post-migration: SLO Audit
        if args.audit_slos and (args.migrate or args.dry_run):
            audit_token = oauth_token or DT_API_TOKEN
            
            if DT_ENV_URL and audit_token:
                print("\n")
                auditor = SLOAuditor(DT_ENV_URL, oauth_token=audit_token, api_token=DT_API_TOKEN,
                                    registry=registry)
                results = auditor.audit(fix=args.fix_slos and args.migrate)
                
                audit_file = f"slo_audit_{int(time.time())}.json"
                with open(audit_file, 'w') as f:
                    json.dump(results, f, indent=2, default=str)
                print(f"\n  ðŸ“„ Audit report saved to: {audit_file}")
            else:
                print("\n  âš  Skipping SLO audit: DT_ENV_URL or DT_API_TOKEN not configured")
    else:
        # Standalone --audit-slos without --migrate or --dry-run
        if args.audit_slos:
            audit_token = DT_API_TOKEN
            if not audit_token:
                print("Fetching OAuth token for SLO audit...")
                audit_token = get_dt_oauth_token()
            
            if not DT_ENV_URL or not audit_token:
                print("ERROR: DT_ENV_URL / DT_API_TOKEN not configured and OAuth failed.")
                return
            
            # Create registry for standalone audit mode
            standalone_registry = DTEnvironmentRegistry(DT_ENV_URL, oauth_token=audit_token, api_token=DT_API_TOKEN)
            auditor = SLOAuditor(DT_ENV_URL, oauth_token=audit_token, api_token=DT_API_TOKEN,
                                registry=standalone_registry)
            results = auditor.audit(fix=args.fix_slos)
            
            audit_file = f"slo_audit_{int(time.time())}.json"
            with open(audit_file, 'w') as f:
                json.dump(results, f, indent=2, default=str)
            print(f"\n  ðŸ“„ Audit report saved to: {audit_file}")
        
        elif args.validate_env:
            # â”€â”€ Pre-flight environment validation â”€â”€
            auth_token = DT_API_TOKEN
            if not auth_token:
                print("Fetching OAuth token for environment validation...")
                auth_token = get_dt_oauth_token()
            
            if not DT_ENV_URL or not auth_token:
                print("ERROR: DT_ENV_URL / DT_API_TOKEN not configured and OAuth failed.")
                return
            
            print("\n" + "=" * 80)
            print("  DT ENVIRONMENT PRE-FLIGHT VALIDATION")
            print("=" * 80)
            
            registry = DTEnvironmentRegistry(DT_ENV_URL, oauth_token=auth_token, api_token=DT_API_TOKEN)
            
            # 1. Validate METRIC_MAP targets
            print("\n  â”€â”€ Validating METRIC_MAP targets â”€â”€")
            registry._load_metrics()
            if registry._metrics:
                invalid = registry.validate_metric_map(METRIC_MAP)
                total_dt = sum(1 for v in METRIC_MAP.values() if v.startswith('dt.'))
                valid_count = total_dt - len(invalid)
                print(f"  {valid_count}/{total_dt} dt.* targets exist in environment")
                
                if invalid:
                    print(f"  âŒ {len(invalid)} invalid targets:")
                    for nr_key, info in sorted(invalid.items()):
                        suggestion = info.get('suggestion', '')
                        if suggestion:
                            print(f"     {nr_key}: '{info['target']}' â†’ try '{suggestion}'")
                        else:
                            print(f"     {nr_key}: '{info['target']}' â€” no match found")
                else:
                    print(f"  âœ… All METRIC_MAP targets valid!")
            else:
                print("  âš  Could not load metrics â€” check API token scopes")
            
            # 2. Entity discovery
            print("\n  â”€â”€ Entity Discovery â”€â”€")
            registry._load_entities()
            for etype, ids in sorted(registry._entity_type_index.items()):
                print(f"  {etype}: {len(ids)}")
                if len(ids) <= 5:
                    for eid in ids:
                        print(f"     {registry._entities[eid]['name']}")
            
            # 3. Dashboard inventory
            print("\n  â”€â”€ Existing Dashboards â”€â”€")
            registry._load_dashboards()
            if registry._dashboards:
                print(f"  Found {len(registry._dashboards)} dashboards:")
                for doc_id, dash in list(registry._dashboards.items())[:20]:
                    print(f"     {dash['name']}")
                if len(registry._dashboards) > 20:
                    print(f"     ... and {len(registry._dashboards) - 20} more")
            else:
                print("  No dashboards found (or Documents API not accessible)")
            
            # 4. Management Zones
            print("\n  â”€â”€ Management Zones â”€â”€")
            registry._load_management_zones()
            if registry._mgmt_zones:
                print(f"  Found {len(registry._mgmt_zones)} management zones:")
                for mz_id, mz in list(registry._mgmt_zones.items())[:15]:
                    print(f"     {mz['name']} ({len(mz.get('rules', []))} rules)")
            else:
                print("  No management zones found")
            
            # 5. Synthetic locations
            print("\n  â”€â”€ Synthetic Locations â”€â”€")
            registry._load_synthetic_locations()
            if registry._synth_locations:
                pub = [l for l in registry._synth_locations.values() if l['type'] == 'PUBLIC']
                priv = [l for l in registry._synth_locations.values() if l['type'] == 'PRIVATE']
                print(f"  {len(pub)} public, {len(priv)} private locations")
                for loc in priv:
                    print(f"     ðŸ”’ {loc['name']} ({loc['city']})")
            else:
                print("  No synthetic locations found")
            
            # Summary
            print("\n" + "=" * 80)
            registry.print_summary()
            
            if registry._load_errors:
                print(f"\n  âš  {len(registry._load_errors)} API errors during validation:")
                for err in registry._load_errors[:5]:
                    print(f"     {err}")
            
            print("=" * 80)
        
        elif args.validate_dql:
            # â”€â”€ Live DQL Validation: Convert all dashboards and validate every query â”€â”€
            effective_nr_key = args.nr_api_key or os.environ.get('NR_API_KEY', '')
            
            # Need OAuth for Grail API
            print("Fetching OAuth token for DQL validation...")
            oauth_token = get_dt_oauth_token()
            
            if not DT_ENV_URL or not oauth_token:
                print("ERROR: DT_ENV_URL + OAuth required for DQL live validation.")
                print("OAuth token is needed to submit queries to the Grail API.")
                return
            
            if not effective_nr_key:
                print("ERROR: NR_API_KEY required to fetch dashboards for conversion.")
                return
            
            print("\n" + "=" * 80)
            print("  DQL LIVE VALIDATION â€” CONVERTING & VALIDATING ALL DASHBOARDS")
            print("=" * 80)
            
            # Create registry with OAuth for Grail query API access
            registry = DTEnvironmentRegistry(DT_ENV_URL, oauth_token=oauth_token, api_token=DT_API_TOKEN or '')
            nr_client = NewRelicClient(effective_nr_key, NR_ACCOUNT_ID)
            converter = NRQLtoDQLConverter(registry=registry)
            
            # Track stats
            total_queries = 0
            valid_queries = 0
            invalid_queries = 0
            auto_fixed = 0
            skipped = 0
            errors_by_type = {}
            invalid_details = []
            
            for dash_info in MVP_DASHBOARDS:
                name = dash_info['name']
                guid = dash_info['guid']
                print(f"\n  â”€â”€ {name} â”€â”€")
                
                try:
                    nr_dashboard = nr_client.get_dashboard(guid)
                    pages = nr_dashboard.get('pages', [])
                    
                    for page in pages:
                        for widget in page.get('widgets', []):
                            raw_cfg = widget.get('rawConfiguration', {})
                            if isinstance(raw_cfg, str):
                                try:
                                    raw_cfg = json.loads(raw_cfg)
                                except (json.JSONDecodeError, TypeError):
                                    raw_cfg = {}
                            for query_obj in raw_cfg.get('nrqlQueries', []):
                                nrql = query_obj.get('query', '')
                                if not nrql:
                                    continue
                                
                                tile_title = widget.get('title', 'Untitled')
                                total_queries += 1
                                
                                result = converter.convert(nrql, tile_title)
                                
                                # Check if live validation caught something
                                has_dt_error = any('DT API syntax error' in w for w in result.warnings)
                                has_live_fix = any('live-validated' in f.lower() or 'live validation fix' in f.lower() for f in result.fixes_applied)
                                
                                if has_dt_error:
                                    invalid_queries += 1
                                    dt_error = next(w for w in result.warnings if 'DT API syntax error' in w)
                                    error_short = dt_error.replace('DT API syntax error: ', '')[:80]
                                    print(f"     âŒ {tile_title[:40]:40s} â†’ {error_short}")
                                    
                                    # Track error type
                                    parsed = registry.parse_dql_error(error_short)
                                    etype = parsed['error_type']
                                    errors_by_type[etype] = errors_by_type.get(etype, 0) + 1
                                    
                                    invalid_details.append({
                                        'dashboard': name,
                                        'tile': tile_title,
                                        'nrql': nrql,
                                        'dql': result.converted_dql,
                                        'error': error_short,
                                        'error_type': etype,
                                        'fixes_attempted': result.fixes_applied,
                                    })
                                elif has_live_fix:
                                    auto_fixed += 1
                                    valid_queries += 1
                                    fix_desc = next(f for f in result.fixes_applied if 'live validation' in f.lower())
                                    print(f"     ðŸ”§ {tile_title[:40]:40s} â†’ auto-fixed: {fix_desc[:50]}")
                                else:
                                    valid_queries += 1
                                    # Only print if verbose
                                    if args.verbose:
                                        print(f"     âœ… {tile_title[:40]:40s}")
                    
                except Exception as e:
                    print(f"     âš  Error fetching dashboard: {str(e)[:80]}")
                    skipped += 1
            
            # Summary
            print("\n" + "=" * 80)
            print(f"  DQL LIVE VALIDATION RESULTS")
            print("=" * 80)
            print(f"  Total queries:     {total_queries}")
            print(f"  âœ… Valid:           {valid_queries} ({100*valid_queries/max(total_queries,1):.0f}%)")
            print(f"  ðŸ”§ Auto-fixed:     {auto_fixed}")
            print(f"  âŒ Invalid:         {invalid_queries} ({100*invalid_queries/max(total_queries,1):.0f}%)")
            if skipped:
                print(f"  â­ Skipped:         {skipped}")
            
            if errors_by_type:
                print(f"\n  Errors by type:")
                for etype, count in sorted(errors_by_type.items(), key=lambda x: -x[1]):
                    print(f"     {etype:20s} {count}")
            
            if invalid_details:
                report_file = f"dql_validation_report_{int(time.time())}.json"
                with open(report_file, 'w') as f:
                    json.dump(invalid_details, f, indent=2, default=str)
                print(f"\n  ðŸ“„ Full error report: {report_file}")
            
            cache_stats = registry._dql_validation_cache
            print(f"\n  Cache: {len(cache_stats)} unique queries validated")
            print("=" * 80)
        
        else:
            parser.print_help()


if __name__ == "__main__":
    main()
