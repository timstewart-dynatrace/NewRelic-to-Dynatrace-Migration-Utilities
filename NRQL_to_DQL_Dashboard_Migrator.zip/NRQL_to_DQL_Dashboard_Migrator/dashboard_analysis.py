#!/usr/bin/env python3
"""
Dynatrace Dashboard Schema Discovery
- Fetches existing dashboards to understand the real schema
- Tests DQL queries against the API
- Helps us understand what actually works
"""

import os
import json
import requests

DT_ENV_URL = os.environ.get("DT_ENV_URL", "https://bxa51304.apps.dynatrace.com")
DT_API_TOKEN = os.environ.get("DT_API_TOKEN", "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjEifQ.eyJzdWIiOiIwM2JkMDRkYy04OWFiLTQyYjktODVhOS0yNmZlMjhjMzYzM2UiLCJyZXMiOiJ1cm46ZHRhY2NvdW50OjNhOWQ4OWJlLTRhMmQtNDFkNy1hNDc4LWI4ZGQyNDY2OWEzNyIsIl9jbGFpbV9uYW1lcyI6eyJncm91cHMiOiIwIn0sInByZWZlcnJlZF91c2VybmFtZSI6ImpvcmRhbi53cmlnaHRAdHJhY2UzLmNvbSIsImd0IjoiY2MiLCJpbnQiOmZhbHNlLCJjcyI6Ikg0c0lBQUFBQUFBQS8wdkpUeTdOVGMwcnNVcUJNb3F0aWxJVFV4UlNNTVhMaXpKTFVyRkpKS2JrWnVZQkFBWm9xK3RKQUFBQSIsImF1ZCI6ImR0MHMwMi5UT0VFTVlMUiIsInNjb3BlIjoiIiwiX2NsYWltX3NvdXJjZXMiOnsiMCI6eyJlbmRwb2ludCI6bnVsbH19LCJleHAiOjE3NjkxOTYxMzgsImlhdCI6MTc2OTE5NTgzOCwianRpIjoiODYwMTA2NGYtYjJmOC00MjlhLWJkMDQtYzEwNDgxNmYzNjA4IiwiZW1haWwiOiJqb3JkYW4ud3JpZ2h0QHRyYWNlMy5jb20ifQ.RRNjygFebVDPMru8YNcG-zqnmwri_SnYUvNg5SkRhajU2jbEkq6GzFEHPz4VD6EylAMXDFc0PkY5AOo_pRCeLQ")

def get_headers():
    return {"Authorization": f"Bearer {DT_API_TOKEN}"}

def list_dashboards():
    """List all dashboards via Documents API"""
    url = f"{DT_ENV_URL}/platform/document/v1/documents"
    params = {"filter": "type=='dashboard'"}
    
    response = requests.get(url, headers=get_headers(), params=params)
    print(f"List dashboards: {response.status_code}")
    
    if response.status_code == 200:
        data = response.json()
        docs = data.get('documents', [])
        print(f"Found {len(docs)} dashboards:")
        for doc in docs[:10]:
            print(f"  - {doc.get('name')} (id: {doc.get('id')})")
        return docs
    else:
        print(f"Error: {response.text}")
        return []

def get_dashboard_content(doc_id):
    """Get the full content of a dashboard"""
    url = f"{DT_ENV_URL}/platform/document/v1/documents/{doc_id}/content"
    
    response = requests.get(url, headers=get_headers())
    print(f"\nGet dashboard {doc_id}: {response.status_code}")
    
    if response.status_code == 200:
        # Content-Type might be application/json or multipart
        content_type = response.headers.get('Content-Type', '')
        print(f"Content-Type: {content_type}")
        
        if 'application/json' in content_type:
            return response.json()
        else:
            # Try to parse as JSON anyway
            try:
                return response.json()
            except:
                print(f"Raw response (first 1000 chars): {response.text[:1000]}")
                return None
    else:
        print(f"Error: {response.text}")
        return None

def validate_dql(query):
    """Validate a DQL query against DT API"""
    url = f"{DT_ENV_URL}/platform/grail/dql/v1/query:parse"
    
    headers = get_headers()
    headers["Content-Type"] = "application/json"
    
    payload = {"query": query}
    
    response = requests.post(url, headers=headers, json=payload)
    
    if response.status_code == 200:
        return {"valid": True, "response": response.json()}
    else:
        return {"valid": False, "error": response.text, "status": response.status_code}

def test_dql_queries():
    """Test various DQL query patterns"""
    test_queries = [
        # Basic fetch
        "fetch spans | limit 10",
        
        # With filter
        'fetch spans | filter service.name == "test"',
        
        # With summarize
        "fetch spans | summarize count()",
        
        # timeseries
        "timeseries avg(builtin:service.response.time)",
        
        # makeTimeseries (is this valid?)
        "fetch spans | makeTimeseries count()",
        
        # Filter with single quotes (INVALID?)
        "fetch spans | filter service.name == 'test'",
        
        # Filter with = instead of ==
        'fetch spans | filter service.name = "test"',
    ]
    
    print("\n" + "="*60)
    print("DQL QUERY VALIDATION")
    print("="*60)
    
    for query in test_queries:
        result = validate_dql(query)
        status = "✅ VALID" if result['valid'] else "❌ INVALID"
        print(f"\n{status}: {query[:50]}...")
        if not result['valid']:
            print(f"  Error: {result.get('error', 'Unknown')[:100]}")

def main():
    if not DT_API_TOKEN:
        print("ERROR: Set DT_API_TOKEN environment variable")
        print("export DT_API_TOKEN='dt0s02...'")
        return
    
    print("="*60)
    print("DYNATRACE DASHBOARD SCHEMA DISCOVERY")
    print("="*60)
    
    # List dashboards
    docs = list_dashboards()
    
    # Get content of first dashboard
    if docs:
        first_doc = docs[0]
        content = get_dashboard_content(first_doc['id'])
        
        if content:
            print("\n" + "="*60)
            print("DASHBOARD JSON STRUCTURE")
            print("="*60)
            print(f"Top-level keys: {list(content.keys())}")
            
            if 'tiles' in content:
                tiles = content['tiles']
                print(f"Number of tiles: {len(tiles)}")
                
                # Show first tile structure
                if tiles:
                    first_tile_key = list(tiles.keys())[0]
                    first_tile = tiles[first_tile_key]
                    print(f"\nFirst tile keys: {list(first_tile.keys())}")
                    print(f"First tile layout: {first_tile.get('layout')}")
                    
                    # Show the query if it's a data tile
                    if first_tile.get('type') == 'data':
                        query = first_tile.get('query', '')
                        print(f"First tile query (first 200 chars):\n{query[:200]}")
            
            # Save full content for analysis - same directory as script
            import sys
            script_dir = os.path.dirname(os.path.abspath(__file__)) if '__file__' in dir() else os.getcwd()
            output_path = os.path.join(script_dir, 'dt_dashboard_sample.json')
            with open(output_path, 'w') as f:
                json.dump(content, f, indent=2)
            print(f"\nFull content saved to: {output_path}")
    
    # Test DQL validation
    test_dql_queries()

if __name__ == "__main__":
    main()