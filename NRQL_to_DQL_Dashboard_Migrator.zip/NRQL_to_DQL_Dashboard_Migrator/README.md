# New Relic → Dynatrace Migration Toolkit

A production-grade migration platform for converting observability configurations from New Relic to Dynatrace. Covers dashboards, synthetic monitors, NRQL→DQL query translation, SLO migration, alert routing, and infrastructure monitoring.

## Components

| File | Purpose | Lines |
|------|---------|-------|
| `nrql_compiler.py` | NRQL→DQL compiler (lexer, parser, AST, emitter, tests) | ~4,900 |
| `dashboard_migrator.py` | Full dashboard migration orchestrator with SLO support | ~11,500 |
| `complete.py` | Synthetic monitor migration (5 core classes) | ~1,900 |
| `migrate_simple.py` | HTTP monitor migration (Simple/Ping → DT HTTP) | ~400 |
| `migrateicmp.py` | ICMP & NAM location monitor migration | ~360 |
| `auth.py` | OAuth token management for DT API access | — |
| `upload_lookups.py` | Lookup table upload for alert routing | — |
| `upload_all.py` / `upload_debug.py` | Batch upload utilities | — |
| `update_team_routing.py` | Team-based alert routing configuration | — |
| `script_api.py` | Script API monitor analysis | — |
| `analysis.py` / `smallanalysis.py` | Migration readiness analysis | — |

---

## NRQL → DQL Compiler (`nrql_compiler.py`)

### Architecture

Three-stage pipeline — **not** regex-based:

```
NRQL string → Lexer → Token stream → Parser → AST → Emitter → DQL string
```

1. **Lexer** (`NRQLLexer`): Tokenizes NRQL including string literals, backtick-quoted identifiers, double-quoted strings, operators, 30+ keywords. Strips `--` and `//` inline comments.
2. **Parser** (`NRQLParser`): Builds a typed AST with 9 condition types, expression trees, aggregation functions, FACET/TIMESERIES/COMPARE WITH/SINCE/UNTIL clauses, subqueries, and CASES blocks.
3. **Emitter** (`NRQLCompiler.emit()`): Context-aware DQL generation routing through 17 emission methods based on query classification.

### Quick Start

```python
from nrql_compiler import NRQLCompiler

compiler = NRQLCompiler()
result = compiler.compile("SELECT average(duration) FROM Transaction WHERE appName = 'MyApp' TIMESERIES")

print(result.dql)       # timeseries avg(duration), filter:{service.name == "MyApp"}
print(result.success)   # True
print(result.warnings)  # List of migration notes
```

### Query Classification & Emission Paths

| NR Source | Query Class | DQL Target | Emission Method |
|-----------|------------|-----------|-----------------|
| `Transaction`, `Span`, `BrowserInteraction` | `spans` | `fetch spans` | `_emit_fetch_query` |
| `Metric`, `SystemSample`, `ProcessSample` | `METRIC` | `timeseries` / `fetch dt.metrics` | `_emit_metric_query` |
| `Log` | `logs` | `fetch logs` | `_emit_fetch_query` |
| `SyntheticCheck`, `SyntheticRequest` | `bizevents` | `fetch bizevents` | `_emit_fetch_query` |
| `NrAiIncident`, custom events | `events` | `fetch bizevents` | `_emit_events_query` |
| `K8sPodSample`, `K8sContainerSample`, etc. | `K8S_*` | `timeseries` (metrics) or `fetch dt.entity.*` | `_emit_metric_query` / entity path |

### Aggregation Functions (26 handlers)

| NRQL | DQL | Notes |
|------|-----|-------|
| `count(*)` | `count()` | |
| `average(f)` | `avg(f)` | |
| `sum(f)`, `min(f)`, `max(f)` | Same | |
| `latest(f)` | `takeFirst(f)` | Semantic: DT takes first by ingest order |
| `uniqueCount(f)` | `countDistinctExact(f)` | |
| `uniques(f)` | `collectDistinct(f)` | |
| `percentile(f, N)` | `percentile(f, N)` | |
| `median(f)` | `percentile(f, 50)` | |
| `stddev(f)` | `stddev(f)` | |
| `rate(count(*), 1 minute)` | `count() / duration` | Approximate |
| `round(f, N)` | `round(f, N)` | |
| `substring(f, start, len)` | `substring(f, start, len)` | |
| `indexOf(f, str)` | `indexOf(f, str)` | |
| `histogram(f, width, count)` | `summarize ... by:{bin(f, width)}` | |
| `apdex(duration, T)` | Decomposed to `countIf()` expressions | See below |
| `percentage(count(*), WHERE ...)` | `100.0 * countIf(...) / count()` | |
| `funnel(...)` | Multi-step `countIf` + `fieldsAdd` | Conversion rates |
| `cdfPercentage(f, t1, t2)` | `countIf` decomposition | Cumulative distribution |
| `bucketPercentile(f, ...)` | Decomposed to `bin()` | |
| `clamp_max(f, N)` / `clamp_min(f, N)` | `if(f > N, N, f)` | |
| `if(cond, a, b)` | `if(cond, a, else: b)` | Named `else:` parameter |
| `cases(...)` | `if()/else:` chains | |
| `filter(f, WHERE ...)` | Inline filter expression | |
| `getField(f, key)` | `f[key]` | JSON field access |
| `jparse(f, path)` | JSON parse expression | |
| `derivative(f)` | Comment + warning | No direct DQL equivalent |
| `predictLinear(f)` | Comment → Davis AI | No direct DQL equivalent |
| `cardinality(f)` | Comment → DT metric browser | |
| `bytecountestimate(f)` | Comment → DT Data Explorer | |

### Apdex Decomposition

DQL has no built-in `apdex()`. The compiler decomposes it into duration range counting with proper DQL duration literals:

```
NRQL: apdex(duration, 0.7)
DQL:  (countIf(duration < 700ms) + countIf(duration >= 700ms and duration < 2800ms) * 0.5) / count()
```

Apdex zone filtering (`percentage(count(*), WHERE apdex(duration) = 'S')`) decomposes into:
- **Satisfied** (`'S'`): `countIf(duration < T)`
- **Tolerating** (`'T'`): `countIf(duration >= T and duration < 4T)`
- **Frustrated** (`'F'`): `countIf(duration >= 4T)`

Thresholds are converted to proper DQL duration literals via `_ms_to_duration_literal()`.

### WHERE / Condition Handling (9 condition types)

| NRQL | DQL | AST Type |
|------|-----|----------|
| `WHERE x = 'val'` | `\| filter x == "val"` | `ComparisonCond` |
| `WHERE x != 'val'` | `\| filter x != "val"` | `ComparisonCond` |
| `WHERE x > N` | `\| filter x > N` | `ComparisonCond` |
| `WHERE x IN ('a','b')` | `\| filter in(x, {"a","b"})` | `InListCond` |
| `WHERE x NOT IN (...)` | `\| filter not(in(x, {...}))` | `InListCond` (negated) |
| `WHERE x IN (SELECT ...)` | `\| lookup` or warning | `InSubqueryCond` |
| `WHERE x LIKE '%pat%'` | `\| filter contains(x, "pat")` | `LikeCond` |
| `WHERE x LIKE 'pre%'` | `\| filter startsWith(x, "pre")` | `LikeCond` |
| `WHERE x LIKE '%suf'` | `\| filter endsWith(x, "suf")` | `LikeCond` |
| `WHERE x NOT LIKE '...'` | `\| filter not(contains(...))` | `LikeCond` (negated) |
| `WHERE x RLIKE 'regex'` | `\| filter matches(x, "pattern")` | `RLikeCond` |
| `WHERE x IS NULL` | `\| filter isNull(x)` | `IsNullCond` |
| `WHERE x IS NOT NULL` | `\| filter isNotNull(x)` | `IsNullCond` (negated) |
| `WHERE NOT (...)` | `\| filter not(...)` | `NotCond` |
| `WHERE a AND b` / `OR` | `\| filter a and b` / `or` | `LogicalCond` |
| `WHERE startsWith(x, 'v')` | `startsWith(x, "v")` | `FuncCondition` |
| `WHERE endsWith(x, 'v')` | `endsWith(x, "v")` | `FuncCondition` |
| `WHERE matchesPhrase(x, 'v')` | `contains(x, "v")` | `FuncCondition` |
| `WHERE contains(x, 'v')` | `contains(x, "v")` | `FuncCondition` |

### FACET, TIMESERIES, and Clauses

- `FACET field` → `by: {field}` (timeseries) or `summarize ..., by: {field}` (fetch)
- `FACET a, b` → `by: {a, b}`
- `FACET field LIMIT N` → `by: {field}` + `| limit N`
- `TIMESERIES` → `timeseries` (metric) or `makeTimeseries` (span/log)
- `TIMESERIES 5 minutes` → `interval: 5m`
- `TIMESERIES AUTO` → No interval (DT auto-selects)
- `COMPARE WITH 1 week ago` → `shift:` parameter on timeseries; warning on makeTimeseries
- `ORDER BY field ASC/DESC` → `| sort field asc/desc`
- `LIMIT N` / `LIMIT MAX` → `| limit N` / `| limit 5000`
- `SINCE / UNTIL / AGO` → Stripped (DT time range set in dashboard tile config)
- `EXTRAPOLATE` → Emitted as comment (no DQL equivalent)

### Metric Queries

Single metric:
```
NRQL: SELECT average(cpuPercent) FROM SystemSample WHERE hostname = 'web-1' TIMESERIES
DQL:  timeseries avg(host.cpu.usage), filter:{host.name == "web-1"}
```

Multiple metrics (brace syntax):
```
NRQL: SELECT average(cpuPercent), average(memoryUsedPercent) FROM SystemSample FACET hostname TIMESERIES
DQL:  timeseries {cpuPercent = avg(host.cpu.usage), memoryUsedPercent = avg(host.mem.usage)}, by: {host.name}
```

Computed metrics (arithmetic between aggregations):
```
NRQL: SELECT (count(*) / average(duration)) * 100 FROM Transaction TIMESERIES
DQL:  timeseries {__agg0 = count(), __agg1 = avg(duration)}, ... | fieldsAdd (__agg0 / __agg1) * 100
```

### Context-Aware Field Mapping

`_map_field()` checks `_query_class` before mapping. In METRIC/K8S contexts, dimension names are preserved as custom metric dimensions rather than being incorrectly mapped to span fields.

**Metric dimension passthrough** (not remapped in metric context):
`id`, `target`, `topic`, `consumer_group`, `partition`, `cluster_id`, `principal_id`, `type`, `name`, `mode`

**Common field mappings:**

| NR Field | DT Field |
|----------|----------|
| `appName` / `entity.name` | `service.name` / `dt.entity.name` |
| `hostname` | `host.name` |
| `cpuPercent` | `host.cpu.usage` |
| `memoryUsedPercent` | `host.mem.usage` |
| `duration` | `duration` |
| `duration.ms` | `duration` (with simplification) |
| `error` | `error` |
| `http.statusCode` | `http.response.status_code` |
| `http.url` | `http.request.url` |
| `request.uri` | `http.route` |

### Duration Handling

NR durations in seconds/milliseconds are converted via `_ms_to_duration_literal()`:

| Input (ms) | Output |
|-----------|--------|
| 500 | `500ms` |
| 1000 | `1s` |
| 60000 | `1m` |
| 3600000 | `1h` |
| 0.7 (sub-ms) | `700us` |

A negative-lookahead regex prevents double-conversion of values that already have units.

### Validation

Two validators run on all emitted DQL:

1. **`_validate_dql()`**: Post-processor catches bare fields in summarize, invalid `shift:` on makeTimeseries, duration unit conversion for span queries, empty aggregation lists.
2. **`_validate_no_nested_aggregations()`**: Scans for aggregation functions nested inside other aggregation arguments. Adds warning if detected.

### Warnings System

```python
result = compiler.compile(nrql)
for w in result.warnings:
    print(w)
```

Warning categories: decomposition notes (apdex, percentage, funnel), nested aggregation detection, unknown metrics, unsupported features, duration conversion notes.

### Test Suite

```bash
python3 nrql_compiler.py
# 283 passed, 0 failed, 283 total
```

15 test sections + audit regression tests. **174 real production queries from customer dashboards: 174/174 compile clean (100%).**

---

## Dashboard Migrator (`dashboard_migrator.py`)

### Overview

Full end-to-end dashboard migration from NR to DT:

1. Extracts dashboards via NR NerdGraph API
2. Converts all NRQL queries to DQL using the compiler
3. Maps visualization types (NR widgets → DT tiles)
4. Migrates SLOs
5. Validates DQL against Grail API (optional)
6. Uploads to DT via Documents API

### CLI Modes

```bash
# List available NR dashboards
python3 dashboard_migrator.py --list

# Export dashboards to local JSON (dry run)
python3 dashboard_migrator.py --export --dashboard "Dashboard Name"

# Full migration (convert + upload to DT)
python3 dashboard_migrator.py --migrate --dashboard "Dashboard Name"

# Dry run (convert, validate, don't upload)
python3 dashboard_migrator.py --dry-run --dashboard "Dashboard Name"

# Validate all DQL queries against Grail API
python3 dashboard_migrator.py --validate-dql

# Validate DT environment connectivity
python3 dashboard_migrator.py --validate-env

# Validate only (convert + check, no upload)
python3 dashboard_migrator.py --validate-only --dashboard "Dashboard Name"

# SLO audit
python3 dashboard_migrator.py --audit-slos

# Auto-create SLOs in DT
python3 dashboard_migrator.py --auto-create-slos

# Fix SLO metric references
python3 dashboard_migrator.py --fix-slos

# Verbose output
python3 dashboard_migrator.py --migrate --dashboard "My Dashboard" --verbose
```

### Visualization Type Mapping

| NR Widget (`viz.*`) | DT Tile Type |
|---------------------|-------------|
| `viz.line` | `lineChart` |
| `viz.area` | `areaChart` |
| `viz.stacked-area` | `areaChart` |
| `viz.bar` | `barChart` |
| `viz.stacked-bar` | `barChart` |
| `viz.billboard` | `singleValue` |
| `viz.pie` | `pieChart` |
| `viz.table` | `table` |
| `viz.markdown` | `markdown` |
| `viz.heatmap` | `honeycomb` |
| `viz.histogram` | `histogram` |
| `viz.json` | `table` |
| `viz.bullet` | `gauge` |
| `viz.funnel` | `table` (no DT funnel) |
| `viz.scatter` | `scatterPlot` |

### Core Classes

| Class | Purpose |
|-------|---------|
| `NRQLtoDQLConverter` | NRQL→DQL with validation, SLO awareness, and auto-fix |
| `DQLSyntaxValidator` | Regex-based DQL structural validation (includes nested aggregation detection) |
| `DQLValidator` | Extended validation with semantic checks |
| `LayoutConverter` | NR grid layout → DT tile positioning |
| `NewRelicClient` | NR NerdGraph API client (dashboard fetch, listing) |
| `DynatraceClient` | DT Documents API client (dashboard create, schema detection) |
| `DTEnvironmentRegistry` | Live DT environment discovery (see below) |
| `SLOAuditor` | SLO metric validation, audit, and migration |
| `DashboardMigrator` | Main orchestrator (convert, validate, upload) |

### Specialized Converters

| Converter | Handles |
|-----------|---------|
| `RegexToDPLConverter` | RLIKE regex → DPL `matches()` pattern |
| `AparseConverter` | `aparse()` string extraction → DQL `parse` |
| `RateDerivativeConverter` | `rate()`/`derivative()` → DQL equivalents |
| `CompareWithConverter` | `COMPARE WITH` → `shift:` parameter |
| `FunnelConverter` | `funnel()` → multi-step countIf |
| `ExtrapolateHandler` | EXTRAPOLATE → comment |
| `BucketPercentileConverter` | `bucketPercentile()` → `bin()` |
| `WithAsConverter` | `WITH ... AS` subqueries → lookup |

### DTEnvironmentRegistry

Live discovery of the target DT environment:

- **Metrics**: `_load_metrics()`, `metric_exists()`, `find_metric()`, `get_metric_info()`, `validate_metric_map()`, `get_all_metrics()`
- **Entities**: `_load_entities()`, `find_entity()`, `find_entities_by_type()`, `entity_exists()`, `resolve_service_name()`
- **Dashboards**: `_load_dashboards()`, `dashboard_exists()`, `find_dashboard()`, `list_dashboards()`
- **Management Zones**: `_load_management_zones()`, `find_management_zone()`, `list_management_zones()`
- **Synthetic Locations**: `_load_synthetic_locations()`, `find_synthetic_location()`, `list_synthetic_locations()`
- **DQL Validation**: `validate_dql_syntax()`, `parse_dql_error()` — submit queries to Grail API
- **Fuzzy Matching**: `_tokenize()`, `_token_similarity()` for NR→DT name resolution

### SLO Migration

- Fetches SLO definitions from NR via `_fetch_slo_details_from_nr()`
- Analyzes SLO type: availability, latency, error rate, custom (`_infer_slo_type()`, `_analyze_slo_type()`)
- Checks for existing SLOs in DT to avoid duplicates (`_check_existing_slo_in_dt()`)
- Creates SLOs in DT with converted DQL queries (`_create_slo_in_dt()`)
- Validates metric references against live DT metrics
- Audits and fixes broken metric keys in existing SLOs (`SLOAuditor.audit()`)
- Deduplicates SLO tiles in dashboards (`_dedup_slo_tiles()`)
- Enables all SLO columns for table tiles (`_enable_all_slo_columns()`)

### Live DQL Validation

When OAuth credentials are available, the migrator validates every emitted DQL query against the Grail API. Results are cached per query. Catches errors the regex validator can't: unknown fields, invalid metric keys, type mismatches, parse errors.

```bash
# Requires DT_ENV_URL, DT_CLIENT_ID, DT_CLIENT_SECRET
python3 dashboard_migrator.py --validate-dql
```

---

## Synthetic Monitor Migration

### `complete.py` — Full Synthetic Migration (5 core classes)

- NR Scripted API → DT HTTP Monitor (with multi-step request chains)
- NR Simple/Ping → DT HTTP Monitor
- NR Scripted Browser → DT Browser Clickpath (where possible)
- Secure credential mapping
- Location mapping (NR location names → DT synthetic node IDs)
- Frequency mapping (NR intervals → DT intervals)

### `migrate_simple.py` — HTTP Monitor Migration (~400 lines)

Batch migration of NR Simple Browser / Ping monitors to DT HTTP monitors. URL extraction, response validation rules, SSL certificate checks, custom header migration.

### `migrateicmp.py` — ICMP & NAM Migration (~360 lines)

ICMP ping monitors and NAM (Network Application Monitoring) location monitors.

### Monitor Data Files

| File | Rows | Description |
|------|------|-------------|
| `simple_monitors.csv` | 823 | Simple/ping monitors with migration status |
| `icmp_monitors.csv` | 110 | ICMP monitors with migration status |
| `script_api_analysis.csv` | 434 | Scripted API monitors with complexity scoring |
| `script_api_analysis_v2.csv` | 434 | Updated with migration status |
| `other_monitors.csv` | 114 | Browser, step, and other monitor types |
| `prod_monitors20260121.csv` | — | Full production monitor inventory |

---

## Alert Routing

### Routing Configuration

| File | Rows | Purpose |
|------|------|---------|
| `condition_routing.csv` | 1,378 | NR alert condition → team routing |
| `entity_routing.csv` | 430 | Entity name + problem type → team + priority + runbook |
| `entity_fallbacks.csv` | 166 | Fallback routing when no specific rule matches |
| `namespace_routing.csv` | 8 | K8s namespace → team routing |
| `team_config.csv` | 32 | Team channel configs (Teams, email, OpsRamp, EasyVista) |

### Notification Routing (`nb-routing-*.json`)

Pre-built notification routing configurations for 30+ teams: alerts, aws-data, aws-network, aws, casis, ecom-red, ecom, expo, finance-apps, integration, it-operations, kafka, list, mlm, mongodb, monitoring, moxe-platform, mulesoft, order-api, panamax, payment, platform, pricing, product, routing, sae, salesforce, search, security, sre, user, webapps.

### Workflow Files

- `workflow-self-service.json` — Self-service workflow configuration
- `workflow-opsramp-lookup-tables.json` — OpsRamp integration lookup tables

### `update_team_routing.py`

Updates team-based alert routing rules in DT. Maps NR alert policies and conditions to DT alerting profiles with proper team ownership.

### `upload_lookups.py`

Uploads lookup tables to DT for use in alert routing workflows. Converts CSV routing configs to DT lookup table format.

---

## Environment Variables

```bash
# New Relic
NR_API_KEY=NRAK-...              # NR User API key
NR_ACCOUNT_ID=1234567            # NR account ID

# Dynatrace
DT_ENV_URL=https://xyz.live.dynatrace.com  # DT environment URL
DT_API_TOKEN=dt0c01.xxx         # DT API token (for monitor/dashboard CRUD)
DT_CLIENT_ID=dt0s02.xxx         # OAuth client ID (for Grail/Documents API)
DT_CLIENT_SECRET=dt0s02.xxx     # OAuth client secret
```

## Dependencies

- Python 3.8+
- `requests` (API clients)
- `openpyxl` (Excel file handling)
- No dependencies for `nrql_compiler.py` (pure Python stdlib)

---

## DQL Validation Corpus (`dql_validation_corpus_complete.yaml`)

A 1,410-line YAML corpus documenting every DQL syntax pattern the migration tools can emit, each mapped to a verbatim example from Dynatrace documentation proving it is valid syntax.

### Structure

**17 syntax sections** (crawled from docs.dynatrace.com):

| Section | Source Page | Coverage |
|---------|-----------|----------|
| 1 | commands/metric-commands | `timeseries`, `metrics` |
| 2 | commands/aggregation-commands | `makeTimeseries`, `summarize`, `fieldsSummary` |
| 3 | commands/data-source-commands | `fetch`, `data`, `describe`, `load` |
| 4 | commands/selection-and-modification-commands | `fields`, `fieldsAdd`, `fieldsKeep`, `fieldsRemove`, `fieldsRename` |
| 5 | commands/filtering-commands | `filter`, `filterOut`, `search`, `dedup` |
| 6 | commands/correlation-and-join-commands | `append`, `join`, `joinNested`, `lookup` |
| 7 | commands/structuring-commands | `expand`, `fieldsFlatten` |
| 8 | commands/extraction-and-parsing-commands | `parse` |
| 9 | commands/ordering-commands | `sort`, `limit` |
| 10 | dql-reference | Syntax, parameter groups, field naming |
| 11 | dql-examples (timeseries) | 17 metric query examples |
| 12 | dql-best-practices | Recommended patterns, reserved words |
| 13 | operators | `==`, `!=`, `<`, `>`, `<=`, `>=`, `and`, `or`, `not`, `in`, `~` |
| 14 | functions | String, conditional, conversion, aggregation, timestamp, array |
| 15 | querying-monitored-entities | `fetch dt.entity.*`, `entityName`, `entityAttr`, `classicEntitySelector` |
| 16 | dql-use-cases | XML parsing, JSON extraction |
| 17 | dynatrace-pattern-language | Parse patterns: `LD`, `IPADDR`, `LONG`, `INT`, etc. |

**6 semantic constraint sections** (Sections 18–23):

| Section | Coverage |
|---------|----------|
| 18 — Aggregation Function Constraints | `NO_NESTED_AGGREGATIONS`, `countIf` arg rules, `makeTimeseries`/`timeseries` aggregation subsets |
| 19 — Type System Constraints | Strong typing, duration units (`ns`/`us`/`ms`/`s`/`m`/`h`/`d`), field name rules, reserved words |
| 20 — Command Ordering Constraints | Pipeline order (`fetch → filter → summarize → sort → limit`), valid starting commands |
| 21 — Join/Lookup Constraints | Right-side 128MB limit, null key behavior, `lookup` single-match |
| 22 — NR Function Decomposition | `apdex` → multi-step, `percentage` → `countIf/count`, `funnel` → sequential steps, `histogram` → `bin()`, `uniqueCount` → `countDistinctExact` |
| 23 — Audit Trail | Claims vs delivery tracking |

**16 constraint rules** (`CONSTRAINT_*`) and **5 NR function decomposition patterns** (`NR_FUNC_*`).

---

## DQL Validator (`dql_validator.py`)

A standalone DQL syntax checker (352 lines, 9 rules) that validates emitted DQL against documented Dynatrace syntax rules. Each rule maps to a specific DT docs reference.

**Note**: This is a regex-based lint checker, not a full DQL parser. It catches structural errors (invalid commands, misplaced keywords, unbalanced delimiters) but cannot catch semantic errors (wrong field types, non-existent metrics). For semantic validation, use the live Grail API validation in `dashboard_migrator.py`.

---

## Gen3 Dashboard Schema (`dt_gen3_dashboard_schema.md`)

Complete field-by-field reference for the DT Gen3 (Documents API) dashboard JSON format. Documents every property that can be set programmatically so the migration platform can generate dashboards that need zero manual touch-up. Covers:

- Top-level document structure (version, variables, tiles, layouts, settings, annotations)
- Tile types and their query configurations
- Visualization settings per tile type
- Layout grid system
- Variable definitions and bindings
- Time frame and filter configurations

---

## Support Scripts

### `fix_moxe_dashboard.py`

Targeted fix script for the Moxe Prod Order dashboard. Addresses 6 root causes of broken tiles:

1. **Kafka metrics** (69 tiles) — Confluent Cloud custom metric dimension mapping (`id` → `span.id` was incorrect)
2. **Log queries** — Field name and filter syntax corrections
3. **K8s metrics** — Container memory/CPU metric key resolution
4. **Span duration** — NR `duration.ms/1000` simplification to DT `duration`
5. **Import log queries** — Complex log aggregation patterns
6. **Kafka lag timeseries** — Multi-FACET metric queries with custom dimensions

### `test_gen3_viz.py`

Test suite for Gen3 dashboard visualization enhancements. Validates that the `DashboardMigrator` correctly maps NR visualization types to DT Gen3 tile configurations.

---

## Audit Trail

### `HONEST_AUDIT.md`

Tracks all claims vs actual delivery across development sessions. Documents what was implemented, what was only discussed, and what still needs work. Updated with fix status after each session.

### `FIXES_CHANGELOG.md`

Chronological changelog of all fixes applied to the compiler and migrator.

---

## Known Limitations

- **Semantic correctness**: Structurally valid DQL doesn't guarantee data returns. Field existence and metric availability can only be verified via live DQL validation against the target DT environment.
- **DQL syntax validator**: The `DQLSyntaxValidator` in the dashboard migrator uses regex pattern matching, not a full DQL AST. It catches common structural errors but not all semantic issues.
- **EXTRAPOLATE**: No DQL equivalent.
- **Funnel**: Decomposed to sequential `countIf` steps — no native DQL funnel visualization.
- **Custom events**: Mapped to `bizevents` which may not match if DT is not ingesting the same event types.
- **Subquery IN clauses**: Converted to `lookup` where possible; complex subqueries may need manual rewrite.
- **derivative/predictLinear**: No direct DQL equivalents — emitted as comments pointing to Davis AI.
