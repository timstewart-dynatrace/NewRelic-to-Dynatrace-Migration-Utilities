#!/usr/bin/env python3
"""
Live DQL Validation Tool
========================

Validates ALL converted DQL queries against the Dynatrace Grail API.
Catches syntax errors, invalid fields, and unsupported patterns in real-time.

Usage:
    # Validate a single DQL query
    python validate_dql_live.py --query 'fetch spans | filter service.name == "test" | summarize count()'

    # Validate all queries from a dashboard JSON file
    python validate_dql_live.py --dashboard migrated_dashboard.json

    # Validate during migration (auto-enabled when registry is set)
    # Just pass DT credentials to the DashboardMigrator and it validates automatically

    # Batch validate — reads DQL queries from stdin (one per line or separated by ---)
    cat queries.txt | python validate_dql_live.py --stdin

Environment Variables:
    DT_ENV_URL     - Dynatrace environment URL (e.g., https://bxa51304.apps.dynatrace.com)
    DT_OAUTH_TOKEN - OAuth Bearer token for Platform API access
    DT_API_TOKEN   - API token for Classic API access (optional fallback)

Author: Jordan Wright / Trace3 Universal Migration Platform
"""

import os
import sys
import json
import time
import argparse
import requests
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass, field


@dataclass
class ValidationResult:
    query_name: str
    dql: str
    is_valid: bool
    error_message: str = ''
    auto_fix_applied: str = ''
    fixed_dql: str = ''
    attempt_count: int = 1


class LiveDQLValidator:
    """Validates DQL queries against the live Dynatrace Grail API."""
    
    def __init__(self, dt_url: str = None, oauth_token: str = None, api_token: str = None):
        self.dt_url = (dt_url or os.environ.get('DT_ENV_URL', '')).rstrip('/')
        self.oauth_token = oauth_token or os.environ.get('DT_OAUTH_TOKEN', '')
        self.api_token = api_token or os.environ.get('DT_API_TOKEN', '')
        
        if not self.dt_url:
            raise ValueError("DT_ENV_URL environment variable or --dt-url required")
        if not self.oauth_token and not self.api_token:
            raise ValueError("DT_OAUTH_TOKEN or DT_API_TOKEN environment variable required")
        
        # Normalize URL to .apps. domain for platform API
        self.platform_url = self.dt_url.replace('.live.', '.apps.')
        if '.apps.' not in self.platform_url:
            self.platform_url = self.dt_url  # Already correct or custom domain
        
        self._cache = {}
        self._rate_limit_wait = 0.1  # 100ms between requests
        self._stats = {
            'total': 0, 'valid': 0, 'invalid': 0, 'fixed': 0, 
            'api_errors': 0, 'cached': 0
        }
    
    def validate(self, dql: str, name: str = '', max_retries: int = 2) -> ValidationResult:
        """Validate a single DQL query against the Grail API.
        
        If invalid, attempts up to max_retries auto-fixes.
        """
        self._stats['total'] += 1
        
        # Strip comments for validation
        dql_clean = '\n'.join(
            line for line in dql.split('\n')
            if line.strip() and not line.strip().startswith('//')
        ).strip()
        
        if not dql_clean:
            return ValidationResult(
                query_name=name, dql=dql, is_valid=True,
                error_message='Empty query (comment-only)'
            )
        
        # Check cache
        cache_key = hash(dql_clean)
        if cache_key in self._cache:
            self._stats['cached'] += 1
            cached = self._cache[cache_key]
            return ValidationResult(
                query_name=name, dql=dql, is_valid=cached[0],
                error_message=cached[1]
            )
        
        current_dql = dql_clean
        result = ValidationResult(query_name=name, dql=dql, is_valid=False)
        
        for attempt in range(max_retries + 1):
            result.attempt_count = attempt + 1
            is_valid, error_msg = self._call_grail_api(current_dql)
            
            if is_valid is None:
                # API error — not a syntax issue
                self._stats['api_errors'] += 1
                result.is_valid = True  # Assume valid if API unavailable
                result.error_message = f'API unavailable: {error_msg}'
                return result
            
            if is_valid:
                self._stats['valid'] += 1
                result.is_valid = True
                if attempt > 0:
                    result.auto_fix_applied = f'Fixed after {attempt} attempt(s)'
                    result.fixed_dql = current_dql
                    self._stats['fixed'] += 1
                self._cache[cache_key] = (True, '')
                return result
            
            # Invalid — try auto-fix
            if attempt < max_retries:
                fixed = self._attempt_fix(current_dql, error_msg)
                if fixed and fixed != current_dql:
                    result.auto_fix_applied = f'Attempt {attempt + 1}: {error_msg[:60]}'
                    current_dql = fixed
                    time.sleep(self._rate_limit_wait)
                    continue
            
            # Exhausted retries
            self._stats['invalid'] += 1
            result.error_message = error_msg
            self._cache[cache_key] = (False, error_msg)
            return result
        
        return result
    
    def _call_grail_api(self, dql: str) -> Tuple[Optional[bool], str]:
        """Submit DQL to Grail API for validation.
        
        Returns:
            (True, '')           — valid DQL
            (False, error_msg)   — invalid DQL  
            (None, error_msg)    — API unavailable
        """
        url = f"{self.platform_url}/platform/storage/query/v1/query:execute"
        payload = {
            "query": dql,
            "defaultTimeframeStart": "now()-1m",
            "defaultTimeframeEnd": "now()",
            "maxResultRecords": 1,
            "requestTimeoutMilliseconds": 5000,
            "locale": "en_US"
        }
        
        headers = {"Content-Type": "application/json"}
        if self.oauth_token:
            headers["Authorization"] = f"Bearer {self.oauth_token}"
        elif self.api_token:
            headers["Authorization"] = f"Api-Token {self.api_token}"
        
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=10)
            
            if resp.status_code == 200:
                return True, ''
            
            if resp.status_code == 403:
                # Permission issue — syntax likely valid
                error_text = resp.text[:200]
                if 'scope' in error_text.lower() or 'permission' in error_text.lower():
                    return True, ''
            
            if resp.status_code == 429:
                # Rate limited — back off and retry
                time.sleep(1)
                return None, 'Rate limited'
            
            # Parse error message
            try:
                data = resp.json()
                error = data.get('error', {})
                if isinstance(error, dict):
                    msg = error.get('message', '')
                    violations = error.get('constraintViolations', [])
                    if violations:
                        msg = '; '.join(v.get('message', '') for v in violations if v.get('message'))
                    if not msg:
                        msg = str(data)[:200]
                else:
                    msg = str(error)[:200]
                return False, msg
            except:
                return False, resp.text[:200]
        
        except requests.exceptions.ConnectionError:
            return None, 'Connection refused'
        except requests.exceptions.Timeout:
            return None, 'Request timeout'
        except Exception as e:
            return None, str(e)[:200]
    
    def _attempt_fix(self, dql: str, error_msg: str) -> Optional[str]:
        """Attempt to fix DQL based on Grail API error message."""
        import re
        fixed = dql
        
        # Fix: "X isn't allowed here"
        not_allowed = re.search(r"`([^`]+)`\s+isn't allowed here", error_msg)
        if not_allowed:
            bad_token = not_allowed.group(1)
            
            # Single = → ==
            if bad_token == '=':
                fixed = re.sub(r'(?<![!<>=])=(?!=)', '==', fixed)
                return fixed
            
            # ( — usually from subquery remnants
            if bad_token == '(':
                # Remove content from ( to matching ) or end of line
                fixed = re.sub(r'\([^)]*\)', '', fixed)
                return fixed
            
            # Duration.Seconds, etc.
            field_fixes = {
                'Duration.Seconds': 'duration',
                'Duration.seconds': 'duration',
                'duration.ms': 'duration',
                'duration.Seconds': 'duration',
                'name': 'span.name',
                'parentId': 'span.parent_id',
                'traceId': 'trace_id',
                'SELECT': '',  # Remove NRQL fragments
                'FROM': '',
            }
            for bad, good in field_fixes.items():
                if bad_token == bad:
                    if good:
                        fixed = re.sub(r'(?<![.\w])' + re.escape(bad) + r'(?![.\w])', good, fixed)
                    else:
                        # Remove the line containing the bad token
                        lines = fixed.split('\n')
                        fixed = '\n'.join(l for l in lines if bad not in l)
                    return fixed
        
        # Fix: "column 'X' does not exist"
        col_missing = re.search(r"column '([^']+)' does not exist", error_msg, re.IGNORECASE)
        if col_missing:
            bad_col = col_missing.group(1)
            # Common NR→DT field fixes
            col_fixes = {
                'name': 'span.name',
                'parentId': 'span.parent_id',
                'id': 'span.id',
                'duration.ms': 'duration',
                'Duration.Seconds': 'duration',
            }
            replacement = col_fixes.get(bad_col, '')
            if replacement:
                fixed = fixed.replace(bad_col, replacement)
                return fixed
        
        return None
    
    def validate_dashboard_json(self, json_path: str) -> List[ValidationResult]:
        """Validate all DQL queries in a migrated dashboard JSON file."""
        with open(json_path) as f:
            dashboard = json.load(f)
        
        results = []
        tiles = dashboard.get('tiles', [])
        
        for i, tile in enumerate(tiles):
            title = tile.get('title', f'Tile {i+1}')
            queries = tile.get('queries', [])
            
            for j, query in enumerate(queries):
                dql = query.get('value', '')
                if dql and not dql.strip().startswith('// Empty'):
                    name = f"{title} (query {j+1})" if len(queries) > 1 else title
                    result = self.validate(dql, name=name)
                    results.append(result)
                    time.sleep(self._rate_limit_wait)
        
        return results
    
    def print_report(self, results: List[ValidationResult]):
        """Print a formatted validation report."""
        print("\n" + "=" * 80)
        print("  DQL LIVE VALIDATION REPORT")
        print("=" * 80)
        
        valid_count = sum(1 for r in results if r.is_valid)
        invalid_count = sum(1 for r in results if not r.is_valid)
        fixed_count = sum(1 for r in results if r.auto_fix_applied)
        
        # Print failures first
        if invalid_count > 0:
            print(f"\n  ❌ FAILURES ({invalid_count}):")
            print("-" * 80)
            for r in results:
                if not r.is_valid:
                    print(f"\n  ❌ {r.query_name}")
                    print(f"     Error: {r.error_message[:120]}")
                    # Show first 3 non-comment lines
                    dql_lines = [l.strip() for l in r.dql.split('\n') if l.strip() and not l.strip().startswith('//')]
                    for l in dql_lines[:3]:
                        print(f"     DQL: {l[:100]}")
        
        # Print auto-fixes
        if fixed_count > 0:
            print(f"\n  🔧 AUTO-FIXED ({fixed_count}):")
            print("-" * 80)
            for r in results:
                if r.auto_fix_applied:
                    print(f"  🔧 {r.query_name}: {r.auto_fix_applied}")
        
        # Summary
        print(f"\n" + "=" * 80)
        print(f"  RESULTS: {valid_count} valid, {invalid_count} invalid, "
              f"{fixed_count} auto-fixed, {len(results)} total")
        if invalid_count == 0:
            print("  ALL QUERIES VALID ✅")
        else:
            print(f"  {invalid_count} QUERIES NEED ATTENTION ❌")
        print("=" * 80)
        
        return invalid_count == 0


def main():
    parser = argparse.ArgumentParser(description='Validate DQL queries against live Dynatrace Grail API')
    parser.add_argument('--query', '-q', help='Single DQL query to validate')
    parser.add_argument('--dashboard', '-d', help='Dashboard JSON file to validate')
    parser.add_argument('--stdin', action='store_true', help='Read queries from stdin (--- separated)')
    parser.add_argument('--dt-url', help='Dynatrace environment URL (or DT_ENV_URL env var)')
    parser.add_argument('--oauth-token', help='OAuth token (or DT_OAUTH_TOKEN env var)')
    parser.add_argument('--api-token', help='API token (or DT_API_TOKEN env var)')
    parser.add_argument('--retries', type=int, default=2, help='Max auto-fix retries per query')
    args = parser.parse_args()
    
    try:
        validator = LiveDQLValidator(
            dt_url=args.dt_url,
            oauth_token=args.oauth_token,
            api_token=args.api_token
        )
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    
    results = []
    
    if args.query:
        result = validator.validate(args.query, name='CLI query', max_retries=args.retries)
        results.append(result)
    
    elif args.dashboard:
        results = validator.validate_dashboard_json(args.dashboard)
    
    elif args.stdin:
        # Read from stdin, split by ---
        content = sys.stdin.read()
        queries = content.split('---') if '---' in content else content.split('\n\n')
        for i, q in enumerate(queries):
            q = q.strip()
            if q:
                result = validator.validate(q, name=f'Query {i+1}', max_retries=args.retries)
                results.append(result)
    
    else:
        parser.print_help()
        sys.exit(1)
    
    all_valid = validator.print_report(results)
    sys.exit(0 if all_valid else 1)


if __name__ == '__main__':
    main()