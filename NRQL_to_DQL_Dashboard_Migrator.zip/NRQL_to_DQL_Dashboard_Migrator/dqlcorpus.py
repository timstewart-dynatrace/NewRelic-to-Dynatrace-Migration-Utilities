# ============================================================================
# DQL VALIDATION CORPUS — COMPLETE
# ============================================================================
# Every DQL pattern our NRQL→DQL migration tools can emit, mapped to a real
# verbatim example from Dynatrace documentation proving it is valid syntax.
#
# Source pages crawled (all from docs.dynatrace.com):
#   1. commands/metric-commands          (timeseries, metrics)
#   2. commands/aggregation-commands     (makeTimeseries, summarize, fieldsSummary)
#   3. commands/data-source-commands     (fetch, data, describe, load)
#   4. commands/selection-and-modification-commands (fields, fieldsAdd, fieldsKeep, fieldsRemove, fieldsRename)
#   5. commands/filtering-commands       (filter, filterOut, search, dedup)
#   6. commands/correlation-and-join-commands (append, join, joinNested, lookup)
#   7. commands/structuring-commands     (expand, fieldsFlatten)
#   8. commands/extraction-and-parsing-commands (parse)
#   9. commands/ordering-commands        (sort, limit)
#   10. dql-reference                    (syntax, parameter groups, field naming)
#   11. dql-examples (timeseries)        (17 metric query examples)
#   12. dql-best-practices               (recommended patterns, reserved words)
#   13. operators                        (==, !=, <, >, <=, >=, and, or, not, in, ~)
#   14. functions                        (string, conditional, conversion, aggregation, timestamp, array)
#   15. querying-monitored-entities      (fetch dt.entity.*, entityName, entityAttr, classicEntitySelector)
#   16. dql-use-cases                    (XML parsing, JSON extraction)
#   17. dynatrace-pattern-language       (parse patterns: LD, IPADDR, LONG, INT, etc.)
#
# Last updated: 2026-02-06
# ============================================================================


# ############################################################################
# SECTION 1: timeseries COMMAND (metric queries)
# Source: commands/metric-commands + dql-examples
# ############################################################################

# === 1.1 SYNTAX ===
# timeseries [column =] aggregation(metricKey [, filter:] [, default:] [, rollup:] [, rate:] [, scalar:])
#            [, [column =] aggregation(metricKey, ...), ...]
#            [, by:] [, filter:] [, union:] [, nonempty:]
#            [, interval: | bins:] [, from:] [, to:] [,timeframe:] [,shift:]
#            [,bucket: bucket, …]

# --- 1.1a: Single metric, no params ---
TS_SINGLE:
  example: timeseries usage=avg(dt.host.cpu.usage)
  source: metric-commands Example 1

# --- 1.1b: Single metric + alias + by + filter + interval + from ---
TS_SINGLE_FULL:
  example: |
    timeseries min_cpu=min(dt.host.cpu.usage), max(dt.host.cpu.usage, default:99.9), by:dt.entity.host, filter:in(dt.entity.host, "HOST-1", "HOST-2"), interval:1h, from:-7d
  source: metric-commands Example 2

# --- 1.1c: by: single field (no braces required) ---
TS_BY_SINGLE_BARE:
  example: timeseries min(dt.host.cpu.iowait, default:-1), by: dt.entity.host
  source: metric-commands Example 3

# --- 1.1d: by: single field with braces (also valid) ---
TS_BY_SINGLE_BRACED:
  example: timeseries time=percentile(dt.service.request.response_time, 99.9), by:{dt.entity.service}
  source: metric-commands Example 6

# --- 1.1e: by: multiple fields (braces REQUIRED) ---
TS_BY_MULTI:
  example: |
    timeseries {
      cpu_allocatable = min(dt.kubernetes.node.cpu_allocatable),
      requests_cpu = max(dt.kubernetes.container.requests_cpu)
    },
    by:{dt.entity.kubernetes_cluster, dt.entity.kubernetes_node}
  source: dql-examples Example 6

# --- 1.1f: Multiple aggregations with braces (CRITICAL PATTERN) ---
TS_MULTI_AGG_BRACED:
  example: |
    timeseries by:{dt.entity.host}, {
      bytes_read=sum(dt.host.disk.bytes_read, scalar:true),
      bytes_written=sum(dt.host.disk.bytes_written, scalar:true)
    }
  source: dql-examples Example 5
  notes: |
    Braces REQUIRED around multiple aggregations when by:/filter: present.
    Without braces, parser cannot distinguish alias=agg() from named param.
    Error without braces: "The parameters should be grouped with curly braces"

# --- 1.1g: Multiple aggregations + fieldsAdd arithmetic ---
TS_MULTI_AGG_ARITHMETIC:
  example: |
    timeseries {
      new = sum(dt.process.network.sessions.new),
      reset = sum(dt.process.network.sessions.reset, default:0),
      timeout = sum(dt.process.network.sessions.timeout, default:0)
    },
    by:{dt.entity.host}
    | fieldsAdd result = 100 * (reset[] + timeout[]) / new[]
  source: dql-examples Example 9
  notes: |
    [] operator accesses individual timeseries array elements for
    element-wise arithmetic. This is the documented way to do
    inter-metric calculations. Use m1[] / m2[], NOT toDouble(m1)/toDouble(m2).

# --- 1.1h: filter: with braces ---
TS_FILTER_BRACED:
  example: |
    timeseries idle=avg(dt.host.cpu.idle),
    by:{dt.entity.host},
    filter:{dt.entity.host == "HOST-EFAB6D2FE7274823"}
  source: dql-examples Example 8

# --- 1.1i: filter: with in() ---
TS_FILTER_IN:
  example: |
    timeseries usage=avg(dt.host.cpu.usage),
    filter: {in(
      dt.entity.host,
      classicEntitySelector("type(host),ipAddress(\"10.102.39.126\")")
    )}
  source: dql-examples Example 3

# --- 1.1j: filter: with startsWith ---
TS_FILTER_STARTSWITH:
  example: |
    timeseries num_hosts = count(dt.host.cpu.usage),
    by:{aws.availability_zone},
    filter:{startsWith(aws.availability_zone, "us-east-1")}
  source: dql-examples Example 14

# --- 1.1k: shift parameter ---
TS_SHIFT:
  example: |
    timeseries avail=avg(dt.host.disk.avail), by:{dt.entity.host}, from:-24h
    | append [
      timeseries avail.yesterday=avg(dt.host.disk.avail), by:{dt.entity.host}, shift:-168h
    ]
  source: dql-examples Example 13

# --- 1.1l: rate parameter ---
TS_RATE:
  example: |
    timeseries sum(dt.service.request.failure_count, rate:1s),
    filter:{startsWith(endpoint.name, "/api/accounts")}
  source: dql-examples Example 12

# --- 1.1m: rollup parameter ---
TS_ROLLUP:
  example: timeseries percentile(dt.host.cpu.usage, 90, rollup:avg)
  source: metric-commands Percentile section

# --- 1.1n: nonempty + default ---
TS_NONEMPTY:
  example: |
    timeseries availability = sum(dt.host.availability, default:0),
    nonempty:true,
    filter:{availability.state == "up"}
  source: dql-examples Example 10

# --- 1.1o: scalar parameter ---
TS_SCALAR:
  example: |
    timeseries usage=avg(dt.host.cpu.usage, scalar:true), by:{dt.entity.host}
    | fieldsAdd cpuCores = entityAttr(dt.entity.host, "cpuCores")
    | summarize by:{cpuCores}, avg(usage), count_hosts=count()
  source: dql-examples Example 7

# --- 1.1p: union parameter ---
TS_UNION:
  example: |
    timeseries
    failure_count=sum(log.readiness_probe.failure_count, default:0),
    success_count=sum(log.readiness_probe.success_count, default:0),
    by:{dt.entity.host},
    union:true
  source: dql-examples Example 11

# --- 1.1q: timeseries + summarize chain ---
TS_SUMMARIZE_CHAIN:
  example: |
    timeseries usage=avg(dt.host.cpu.usage), by:{dt.entity.host}
    | summarize count()
  source: dql-examples Example 4

# --- 1.1r: timeseries + fieldsAdd entityName ---
TS_ENTITY_NAME:
  example: |
    timeseries usage=avg(dt.host.cpu.usage), by: dt.entity.host
    | fieldsAdd entityName(dt.entity.host)
  source: dql-examples Example 2

# --- 1.1s: timeseries + summarize iterative ---
TS_SUMMARIZE_ITERATIVE:
  example: |
    timeseries usage=avg(dt.host.cpu.usage), by: dt.entity.host
    | fieldsAdd entityName(dt.entity.host)
    | filter dt.entity.host.name == "EasyTrade"
    | summarize usage=avg(usage[]), by:{timeframe, interval}
  source: metric-commands Aggregating multiple timeseries

# --- 1.1t: K8s annotation splitting ---
TS_K8S_ANNOTATIONS:
  example: |
    timeseries cpu_usage = sum(dt.kubernetes.container.cpu_usage, rollup:max),
    by:{dt.entity.cloud_application}
    | fieldsAdd annotations = entityAttr(dt.entity.cloud_application, "kubernetesAnnotations")
    | fieldsAdd component = annotations[`app.kubernetes.io/component`]
    | summarize cpu_usage = sum(cpu_usage[]),
    by:{timeframe, interval, component}
  source: dql-examples Example 17


# ############################################################################
# SECTION 2: makeTimeseries COMMAND (logs, spans, events → timeseries)
# Source: commands/aggregation-commands
# ############################################################################

# === 2.1 SYNTAX ===
# makeTimeseries [by: { [expression, …] }] [, interval] [, bins]
#                [, from] [, to] [, timeframe] [, time ,] [, spread ,]
#                [, nonempty ,] [, scalar:] aggregation, …

# --- 2.1a: Basic count ---
MTS_COUNT:
  example: |
    fetch logs
    | filter dt.entity.host == "HOST-15FE58391F97B7AA" and loglevel == "ERROR"
    | makeTimeseries count()
  source: aggregation-commands makeTimeseries Example 1

# --- 2.1b: Multiple aggregations (braces REQUIRED) ---
MTS_MULTI_AGG:
  example: |
    fetch bizevents, from: now() - 7d
    | filter in(event.type, array("com.easytrade.long-sell", "com.easytrade.quick-sell"))
    | makeTimeseries {
      count(),
      high_volume = countIf(amount >= 100 and amount <= 10000),
      max(price)
    },
    by: { accountId },
    interval: 1d
  source: aggregation-commands makeTimeseries Example 3

# --- 2.1c: Spans with percentiles ---
MTS_SPANS_PERCENTILE:
  example: |
    fetch spans
    | filter request.is_root_span == true
    | filter endpoint.name == "GET /api/cart"
    | makeTimeseries {
      avg = avg(duration),
      p50 = median(duration),
      p90 = percentile(duration, 90)
    }
  source: aggregation-commands makeTimeseries Example 4
  notes: |
    Span time field defaults to start_time (not timestamp).
    Valid span fields: service.name, endpoint.name, duration,
    request.is_root_span, http.request.method, http.route, span.kind

# --- 2.1d: countDistinct with scalar ---
MTS_COUNT_DISTINCT:
  example: |
    fetch logs
    | makeTimeseries countDistinct(dt.entity.host, scalar: true),
    by:{k8s.cluster.name}
  source: aggregation-commands makeTimeseries Example 4b

# --- 2.1e: nonempty + default ---
MTS_NONEMPTY:
  example: |
    fetch logs
    | filter status >= 500
    | makeTimeseries count = count(default: 0), interval: 30m, nonempty: true
  source: aggregation-commands makeTimeseries nonempty Example 2

# --- 2.1f: Aggregation functions list ---
# Available: min, max, sum, avg, count, countIf, percentile,
#            countDistinctExact, countDistinctApprox, start, end, median


# ############################################################################
# SECTION 3: summarize COMMAND
# Source: commands/aggregation-commands
# ############################################################################

# === 3.1 SYNTAX ===
# summarize [field =] aggregation, ... [, by: {[field =] expression, ...}]

# --- 3.1a: Single aggregation ---
SUM_SINGLE:
  example: |
    data record(value = 2), record(value = 3)
    | summarize sum(value)
  source: aggregation-commands summarize Example 1

# --- 3.1b: With alias and by ---
SUM_ALIAS_BY:
  example: |
    | summarize sum = sum(value), by: { category = cat }
  source: aggregation-commands summarize Example 2

# --- 3.1c: Multiple aggregations with braces ---
SUM_MULTI_BRACED:
  example: |
    fetch logs
    | summarize {
      errors = countIf(loglevel == "ERROR"),
      warnings = countIf(loglevel == "WARN"),
      severe = countIf(loglevel == "DEBUG")
    },
    by: {
      dt.entity.host,
      dt.entity.process_group
    }
  source: aggregation-commands summarize practical example
  notes: Braces REQUIRED for multiple aggregations AND multiple by fields.

# --- 3.1d: summarize instead of join ---
SUM_INSTEAD_OF_JOIN:
  example: |
    | summarize {
      value = takeAny(value),
      amount = arrayRemoveNulls(collectArray(amount))
    },
    by: { key }
    | expand amount
  source: aggregation-commands summarize Example 5

# --- 3.1e: Element-wise sum ---
SUM_ELEMENT_WISE:
  example: |
    data record(a = array(2, 2)), record(a = array(7, 1))
    | summarize sum(a[])
  source: aggregation-commands summarize Example 6

# --- 3.1f: by: with alias expression ---
SUM_BY_ALIAS:
  example: |
    | summarize event_count = count(), by:{country=client.loc_cc, customer}
  source: dql-reference


# ############################################################################
# SECTION 4: fetch COMMAND (data sources)
# Source: commands/data-source-commands
# ############################################################################

# --- 4.1: Basic fetch ---
FETCH_BASIC:
  example: fetch logs
  source: data-source-commands Example 1

# --- 4.2: Relative timeframe ---
FETCH_RELATIVE:
  example: fetch logs, from: -24h, to: -2h
  source: data-source-commands Example 2

# --- 4.3: Absolute timeframe ---
FETCH_ABSOLUTE:
  example: fetch logs, timeframe:"2021-10-20T00:00:00Z/2021-10-28T12:00:00Z"
  source: data-source-commands Example 3

# --- 4.4: Bucket filter ---
FETCH_BUCKET:
  example: fetch logs, bucket:{"default_logs", "logs_365_*"}
  source: data-source-commands Example 4

# --- 4.5: Sampling ---
FETCH_SAMPLING:
  example: |
    fetch logs, from: -7d, samplingRatio: 100
    | summarize c = countIf(loglevel == "ERROR") * takeAny(dt.system.sampling_ratio)
  source: data-source-commands Example 5

# --- 4.6: Scan limit ---
FETCH_SCANLIMIT:
  example: fetch logs, scanLimitGBytes:100
  source: dql-best-practices

# --- 4.7: Fetch entities ---
FETCH_ENTITIES:
  example: fetch dt.entity.host
  source: querying-monitored-entities

# --- 4.8: load (lookup data) ---
LOAD_LOOKUP:
  example: load "/lookups/pricelist"
  source: data-source-commands load Example 1

# --- 4.9: data command ---
DATA_CMD:
  example: |
    data record(a = "DQL", b = 1, c = 0),
    record(a = "Dynatrace Query Language", b = 2.9, e = "1"),
    record()
  source: data-source-commands data Example 1

# --- 4.10: data from JSON ---
DATA_JSON:
  example: |
    data json:"""[{"amount": 1152, "accountId": 12}, {"amount": 709, "accountId": 96}]"""
  source: data-source-commands data Example 2


# ############################################################################
# SECTION 5: filter / filterOut / search / dedup
# Source: commands/filtering-commands
# ############################################################################

# --- 5.1: filter equality ---
FILTER_EQ:
  example: |
    | filter event == "search failed"
  source: filtering-commands filter Example 1

# --- 5.2: filter multiple conditions ---
FILTER_MULTI:
  example: |
    | filter in(host, array("B", "C")) or prodId == 3
  source: filtering-commands filter Example 2

# --- 5.3: filter with matchesPhrase ---
FILTER_MATCHES:
  example: |
    fetch logs
    | filter loglevel == "ERROR" and matchesPhrase(content, "failed")
  source: filtering-commands filter practical example

# --- 5.4: filterOut ---
FILTEROUT:
  example: |
    fetch logs
    | filterOut loglevel == "NONE" or loglevel == "INFO"
  source: filtering-commands filterOut practical example

# --- 5.5: search ---
SEARCH:
  example: |
    fetch logs
    | search "nullpointer"
  source: filtering-commands search Example 1

# --- 5.6: search in specific field ---
SEARCH_FIELD:
  example: |
    fetch logs
    | filter in(aws.region, "us-east-1", "eu-west-1")
    | search content ~ "error"
  source: filtering-commands search Example 3
  notes: |
    ~ operator is case-insensitive token matching with wildcard support.
    field ~ "term" searches only that field.
    "term" alone searches all fields.

# --- 5.7: search + aggregate ---
SEARCH_AGGREGATE:
  example: |
    fetch logs
    | search content ~ "*timeout"
    | summarize timeouts = count(), by:loglevel
    | sort timeouts desc
  source: filtering-commands search Example 4

# --- 5.8: dedup ---
DEDUP:
  example: |
    | dedup location, sort: { timestamp desc }
  source: filtering-commands dedup Example 2

# --- 5.9: dedup with multiple fields ---
DEDUP_MULTI:
  example: |
    | dedup { timestamp, location }, sort: { bookings desc }
  source: filtering-commands dedup Example 3


# ############################################################################
# SECTION 6: fields / fieldsAdd / fieldsKeep / fieldsRemove / fieldsRename
# Source: commands/selection-and-modification-commands
# ############################################################################

# --- 6.1: fields (keep + order) ---
FIELDS:
  example: |
    | fields event, k8s.pod.name, status
  source: selection-and-modification-commands fields Example 1

# --- 6.2: fields with expression + rename ---
FIELDS_EXPR:
  example: |
    | fields concat(status, ": ", event),
      process_group = dt.entity.process_group,
      uid = upper(k8s.pod.uid)
  source: selection-and-modification-commands fields Example 2

# --- 6.3: fieldsAdd with expression ---
FIELDSADD:
  example: |
    | fieldsAdd uid = upper(k8s.pod.uid)
  source: selection-and-modification-commands fieldsAdd Example 1

# --- 6.4: fieldsAdd conditional (if/else) ---
FIELDSADD_IF:
  example: |
    | fieldsAdd severity = if(status == "NONE", "INFO", else: status)
  source: selection-and-modification-commands fieldsAdd Example 2

# --- 6.5: fieldsAdd chained conditionals ---
FIELDSADD_CHAINED_IF:
  example: |
    | fieldsAdd quarter = if(month >= 1 and month <=3, "Q1")
    | fieldsAdd quarter = if(month >= 4 and month <= 6, "Q2", else:quarter)
    | fieldsAdd quarter = if(month >= 7 and month <= 9, "Q3", else: quarter)
    | fieldsAdd quarter = if(month >= 10 and month <= 12, "Q4", else:quarter)
  source: selection-and-modification-commands fieldsAdd Example 3

# --- 6.6: fieldsAdd arithmetic on timeseries ---
FIELDSADD_TS_ARITHMETIC:
  example: |
    | fieldsAdd result = cpu_allocatable[] - requests_cpu[]
  source: dql-examples Example 6
  notes: [] operator for element-wise array operations on timeseries

# --- 6.7: fieldsKeep ---
FIELDSKEEP:
  example: |
    | fieldsKeep event, status
  source: selection-and-modification-commands fieldsKeep Example

# --- 6.8: fieldsKeep with pattern ---
FIELDSKEEP_PATTERN:
  example: |
    | fieldsKeep event, "dt.entity.*"
  source: selection-and-modification-commands fieldsKeep pattern Example

# --- 6.9: fieldsRemove ---
FIELDSREMOVE:
  example: |
    | fieldsRemove k8s.namespace.name, k8s.pod.name, k8s.pod.uid
  source: selection-and-modification-commands fieldsRemove Example

# --- 6.10: fieldsRemove with pattern ---
FIELDSREMOVE_PATTERN:
  example: |
    fetch logs
    | fieldsAdd severity = lower(loglevel)
    | fieldsRemove loglevel, "k8s.cluster.*"
  source: selection-and-modification-commands fieldsRemove pattern Example

# --- 6.11: fieldsRename ---
FIELDSRENAME:
  example: |
    | fieldsRename host = dt.entity.host, `Process Group` = dt.entity.process_group
  source: selection-and-modification-commands fieldsRename Example
  notes: Backticks required for field names with spaces

# --- 6.12: fieldsAdd total_payload_MB ---
FIELDSADD_MATH:
  example: |
    | fieldsAdd total_payload_MB = total_payload/1000000
  source: dql-reference Line 9


# ############################################################################
# SECTION 7: append / join / joinNested / lookup
# Source: commands/correlation-and-join-commands
# ############################################################################

# --- 7.1: append ---
APPEND:
  example: |
    timeseries gctime = sum(dt.runtime.jvm.pgi.cpu_time_suspension),
    filter: dt.entity.host == "HOST-84D65AF93A3C185A"
    | fields total_gc = arraySum(gctime)
    | append [
      fetch logs
      | filter dt.entity.host == "HOST-84D65AF93A3C185A" and loglevel == "WARN"
      | summarize warnings = count()
    ]
  source: correlation-and-join-commands append practical example

# --- 7.2: append for comparing timeseries ---
APPEND_TS_COMPARE:
  example: |
    timeseries idle=avg(dt.host.cpu.idle),
    by:{dt.entity.host},
    filter:{dt.entity.host == "HOST-EFAB6D2FE7274823"}
    | append [
      timeseries system=avg(dt.host.cpu.system),
      by:{dt.entity.host},
      filter:{dt.entity.host == "HOST-EFAB6D2FE7274823"}
    ]
  source: dql-examples Example 8

# --- 7.3: join inner ---
JOIN_INNER:
  example: |
    data record(key = "a", value = 1), record(key = "b", value = 2)
    | join [
      data record(key = "b", amount = 10), record(key = "c", amount = 20)
    ],
    on: { key }
  source: correlation-and-join-commands join Example 1

# --- 7.4: join leftOuter ---
JOIN_LEFT_OUTER:
  example: |
    | join [...],
    kind: leftOuter,
    on: { key }
  source: correlation-and-join-commands join Example 2

# --- 7.5: join outer ---
JOIN_OUTER:
  example: |
    | join [...],
    on: { key },
    kind: outer
  source: correlation-and-join-commands join Example 3

# --- 7.6: join with complex condition ---
JOIN_COMPLEX:
  example: |
    | join [...] on:{left[service.id] == right[id], left[cloudType] == right[cloud], dt.entity.host}
  source: correlation-and-join-commands join syntax

# --- 7.7: join with entity lookup ---
JOIN_ENTITY:
  example: |
    fetch bizevents
    | filter event.provider == "www.easytrade.com"
    | summarize count = count(), by: { dt.entity.host }
    | join [ fetch dt.entity.host ],
      on: { left[dt.entity.host] == right[id] },
      fields: { host.name = entity.name }
    | fields host.name, count
  source: correlation-and-join-commands join practical example

# --- 7.8: join with executionOrder ---
JOIN_EXEC_ORDER:
  example: |
    | join [ fetch logs ],
      kind: leftOuter,
      on: { trace_id },
      executionOrder: leftFirst,
      fields: { log.timestamp = timestamp, content }
  source: correlation-and-join-commands join executionOrder example

# --- 7.9: joinNested ---
JOIN_NESTED:
  example: |
    fetch dt.entity.process_group
    | joinNested services = [
      fetch dt.entity.service
      | fieldsAdd dt.entity.process_group = runs_on[dt.entity.process_group]
    ],
    on: { left[id] == right[dt.entity.process_group] },
    fields: { id, name = entity.name }
  source: correlation-and-join-commands joinNested practical example

# --- 7.10: lookup ---
LOOKUP:
  example: |
    | lookup [
      data record(key = "b", amount = 10), record(key = "c", amount = 20)
    ],
    sourceField: key,
    lookupField: key,
    prefix: "lookuptable."
  source: correlation-and-join-commands lookup Example

# --- 7.11: lookup cluster name to log ---
LOOKUP_ENTITY:
  example: |
    fetch logs
    | filter isNotNull(dt.entity.kubernetes_cluster)
    | lookup [ fetch dt.entity.kubernetes_cluster ],
      sourceField: dt.entity.kubernetes_cluster,
      lookupField: id,
      fields: { cluster.name = entity.name }
  source: correlation-and-join-commands lookup Example 1

# --- 7.12: lookup with nested field ---
LOOKUP_NESTED:
  example: |
    fetch dt.entity.service_instance
    | lookup [ fetch dt.entity.host ],
      sourceField: runs_on[dt.entity.host],
      lookupField: id,
      fields: { host.name = entity.name }
  source: correlation-and-join-commands lookup Example 2

# --- 7.13: lookup with load ---
LOOKUP_LOAD:
  example: |
    fetch bizevents
    | lookup [ load "/lookups/pricelist" ],
      sourceField: product.id,
      lookupField: product.id
  source: data-source-commands load Example 2


# ############################################################################
# SECTION 8: parse / expand / fieldsFlatten
# Source: commands/extraction-and-parsing-commands + commands/structuring-commands
# ############################################################################

# --- 8.1: parse ---
PARSE:
  example: |
    data record(content="117.16.75.9--[14/Mar/2016:23:34:25 +0200] GET//setup.php HTTP/1.1 404 474")
    | parse content, "IPV4:ip LD HTTPDATE:time ']' LD:text"
  source: extraction-and-parsing-commands parse Example
  notes: |
    Uses Dynatrace Pattern Language (DPL).
    Common matchers: LD (leading data/skip), IPADDR, IPV4, LONG, INT,
    SPACE, HTTPDATE, WORD, DATA, NSPACE, EOL, EOS, JSON, XML
    Named capture: TYPE:fieldname

# --- 8.2: parse from dql-reference ---
PARSE_FULL:
  example: |
    | parse content, "LD IPADDR:ip ':' LONG:payload SPACE LD 'HTTP_STATUS' SPACE INT:http_status LD (EOL| EOS)"
  source: dql-reference Line 4

# --- 8.3: parse JSON ---
PARSE_JSON:
  example: |
    | parse Response, "JSON:json"
    | fields timestamp, json
    | fieldsFlatten json, prefix:"offerdetails."
  source: structuring-commands fieldsFlatten practical example

# --- 8.4: expand ---
EXPAND:
  example: |
    data record(ts = toTimestamp("2019-08-01T13:30"), events = array("start", "shutdown", "crash"))
    | expand events
  source: structuring-commands expand Example

# --- 8.5: fieldsFlatten ---
FIELDS_FLATTEN:
  example: |
    | fieldsFlatten r, depth: 2
  source: structuring-commands fieldsFlatten Example


# ############################################################################
# SECTION 9: sort / limit
# Source: commands/ordering-commands
# ############################################################################

SORT:
  example: |
    | sort failedRequests desc
  source: dql-reference Line 11

LIMIT:
  example: |
    | limit 3
  source: dql-examples Example 2


# ############################################################################
# SECTION 10: OPERATORS
# Source: operators
# ############################################################################

# Comparison: ==, !=, <, >, <=, >=
# Logical:    and, or, not
# String:     ~ (case-insensitive token match with wildcard)
# Membership: in (subquery or array)
# Null:       isNull(), isNotNull(), isTrueOrNull()

OP_TILDE:
  example: |
    | filter k8s.namespace.name ~ "astro*"
  source: dql-best-practices
  notes: |
    ~ is case-insensitive. Supports * wildcard at start/end.
    Better perf than matchesValue(lower(field), "pattern").

OP_IN_ARRAY:
  example: |
    | filter in(host, array("B", "C")) or prodId == 3
  source: filtering-commands filter Example 2

OP_IN_TIMESERIES:
  example: |
    filter:in(dt.entity.host, "HOST-1", "HOST-2")
  source: metric-commands Example 2
  notes: |
    Inside timeseries filter:, in() takes bare values.
    In pipe filter, in() takes array() or {}.

OP_IS_NOT_NULL:
  example: |
    | filter isNotNull(dt.entity.kubernetes_cluster)
  source: correlation-and-join-commands lookup Example 1

OP_NULL_HANDLING:
  example: |
    | filter isTrueOrNull(log.source != "logsourcename")
  source: operators null handling
  notes: |
    filter field != "val" does NOT include nulls.
    Use isTrueOrNull() to include records where field is null.


# ############################################################################
# SECTION 11: ENTITY QUERIES
# Source: querying-monitored-entities
# ############################################################################

ENTITY_FETCH:
  example: fetch dt.entity.host
  source: querying-monitored-entities

ENTITY_NAME:
  example: |
    | fieldsAdd entityName(dt.entity.host)
  source: dql-examples Example 2

ENTITY_ATTR:
  example: |
    | fieldsAdd cpuCores = entityAttr(dt.entity.host, "cpuCores")
  source: dql-examples Example 7

ENTITY_SELECTOR:
  example: |
    | filter in(id, classicEntitySelector("type(service), fromRelationship.runsOnHost(type(host), tag([AWS]Category:ABC))"))
  source: querying-monitored-entities


# ############################################################################
# SECTION 12: BEST PRACTICES
# Source: dql-best-practices
# ############################################################################

BP_FILTER_FIRST:
  rule: |
    Place filter immediately after fetch.
    Use == for known values, ~ for partial/wildcard.
  source: dql-best-practices

BP_SORT_LAST:
  rule: |
    Place sort at END of query, not right after fetch.
    Sorting early reduces performance.
  source: dql-best-practices

BP_RESERVED_WORDS:
  rule: |
    Do NOT use as field names or dimensions:
    fetch, filter, fields, fieldsAdd, fieldsRemove, sort, limit, summarize
  source: dql-best-practices

BP_SCAN_LIMIT:
  example: fetch logs, scanLimitGBytes:100
  source: dql-best-practices


# ############################################################################
# SECTION 13: CURLY BRACE RULES (critical syntax)
# Source: dql-reference (Parameter groups section)
# ############################################################################

# "If several parameters, either mandatory or optional, belong together,
#  you should group them with curly braces ({})."
# — dql-reference

BRACE_RULE_1:
  rule: |
    timeseries multiple aggregations → {} REQUIRED when by:/filter: present
    Example: timeseries {a = sum(m1), b = avg(m2)}, by:{field}
  source: dql-examples Examples 5,6,9

BRACE_RULE_2:
  rule: |
    timeseries by: single field → braces optional
    Example: timeseries avg(m), by: dt.entity.host
    Example: timeseries avg(m), by:{dt.entity.host}
  source: metric-commands Examples 3-6

BRACE_RULE_3:
  rule: |
    timeseries by: multiple fields → {} REQUIRED
    Example: timeseries avg(m), by:{field1, field2}
  source: dql-examples Example 6

BRACE_RULE_4:
  rule: |
    timeseries filter: → {} recommended for all expressions
    All docs examples use filter:{expr}
  source: dql-examples Examples 3,8,10,12,14

BRACE_RULE_5:
  rule: |
    makeTimeseries multiple aggregations → {} REQUIRED
    Example: | makeTimeseries {count(), avg(duration)}, by:{field}
  source: aggregation-commands makeTimeseries Examples 3,4

BRACE_RULE_6:
  rule: |
    summarize multiple aggregations → {} REQUIRED
    Example: | summarize {count(), sum(value)}, by:{field1, field2}
  source: aggregation-commands summarize practical example

BRACE_RULE_7:
  rule: |
    summarize by: multiple fields → {} REQUIRED
    Example: | summarize count(), by:{field1, field2}
  source: aggregation-commands summarize Examples


# ############################################################################
# SECTION 14: KNOWN DT METRIC KEYS
# (for validating metric name resolution in compiler)
# ############################################################################

# K8s Container:
#   dt.kubernetes.container.cpu_usage              (nanoseconds/min)
#   dt.kubernetes.container.memory_working_set     (bytes)
#   dt.kubernetes.container.limits_cpu             (millicores)
#   dt.kubernetes.container.limits_memory          (bytes)
#   dt.kubernetes.container.requests_cpu           (millicores)
#   dt.kubernetes.container.requests_memory        (bytes)

# K8s Node:
#   dt.kubernetes.node.cpu_allocatable             (millicores)
#   dt.kubernetes.node.memory_allocatable          (bytes)

# K8s PVC:
#   dt.kubernetes.persistentvolumeclaim.used       (bytes)
#   dt.kubernetes.persistentvolumeclaim.capacity   (bytes)

# Host:
#   dt.host.cpu.usage       (%, 0-100)
#   dt.host.cpu.idle        (%)
#   dt.host.cpu.system      (%)
#   dt.host.cpu.user        (%)
#   dt.host.cpu.iowait      (%)
#   dt.host.cpu.load        (load avg)
#   dt.host.disk.avail      (bytes)
#   dt.host.disk.bytes_read (bytes)
#   dt.host.disk.bytes_written (bytes)
#   dt.host.availability    (0 or 1)

# Service:
#   dt.service.request.count             (count)
#   dt.service.request.failure_count     (count)
#   dt.service.request.response_time     (nanoseconds, histogram)

# Process:
#   dt.process.network.sessions.new      (count)
#   dt.process.network.sessions.reset    (count)
#   dt.process.network.sessions.timeout  (count)

# Runtime:
#   dt.runtime.jvm.pgi.cpu_time_suspension (duration)


# ############################################################################
# SECTION 15: KNOWN DATA OBJECT FIELDS
# (for validating field names in compiler)
# ############################################################################

# fetch logs:
#   timestamp, content, loglevel, status, log.source
#   service.name, k8s.pod.name, k8s.namespace.name, k8s.cluster.name
#   dt.entity.host, dt.entity.process_group, dt.entity.kubernetes_cluster
#   dt.system.bucket, dt.system.sampling_ratio, trace_id, span_id

# fetch spans:
#   timestamp, start_time, duration, span.kind, span.name
#   service.name, endpoint.name, http.request.method, http.route
#   http.request.path, http.url, http.status_code
#   messaging.destination, request.is_root_span, trace_id, span_id
#   span.events (array of records)
#   NOT: entity.name (use service.name)
#   NOT: pod_name (use k8s.pod.name)

# fetch bizevents:
#   timestamp, event.type, event.provider, event.category
#   dt.entity.host, trace_id

# fetch dt.entity.host:
#   id, entity.name, tags, managementZones, ...

# fetch dt.entity.service:
#   id, entity.name, runs_on, ...


# ############################################################################
# SECTION 16: KNOWN INVALID PATTERNS (things we must NOT emit)
# ############################################################################

INVALID_ENTITY_NAME_ON_SPANS:
  bad: "fetch spans | filter entity.name == \"my-service\""
  correct: "fetch spans | filter service.name == \"my-service\""
  notes: entity.name not a filterable field on spans

INVALID_POD_NAME:
  bad: "| filter pod_name == \"my-pod\""
  correct: "| filter k8s.pod.name == \"my-pod\""
  notes: NR nomenclature. DT uses OTel semantic conventions.

INVALID_DATA_SERVICE_NAME:
  bad: "| filter data.service.name == \"svc\""
  correct: "| filter service.name == \"svc\""
  notes: data. prefix is NR artifact

INVALID_MULTI_TS_NO_BRACES:
  bad: "timeseries a = sum(m1), b = sum(m2), by:{node}"
  correct: "timeseries {a = sum(m1), b = sum(m2)}, by:{node}"
  notes: |
    Parser error: "The parameters should be grouped with curly braces"

INVALID_NR_METRIC_KEYS:
  bad_keys:
    - k8s.container.memoryWorkingSetBytes
    - k8s.container.cpuUsedCores
    - cpuUsedCores
    - memoryUsedBytes
    - allocatableCpuUtilization
    - fsCapacityUtilization
  notes: |
    NR metric key format. DT uses dt.* prefix with snake_case.
    Must be resolved through METRIC_FIELD_MAP or METRIC_TRANSFORMS.

INVALID_SPAN_ID_AS_DIMENSION:
  bad: "timeseries avg(topic_offset_lag), filter: span.id == \"lkc_123\""
  correct: "Requires Confluent Cloud extension with proper metric dimensions"
  notes: span.id is trace correlation, not a Kafka cluster ID

INVALID_BARE_FILTER_ON_TIMESERIES:
  bad: "timeseries avg(m), filter: field == \"val\""
  correct: "timeseries avg(m), filter:{field == \"val\"}"
  notes: All DT docs examples use filter:{} with braces

INVALID_ELSE_STANDALONE:
  bad: "| fieldsAdd x = else(a/b, 0)"
  correct: "| fieldsAdd x = if(isNotNull(b) and b != 0, a/b, else: 0)"
  notes: |
    else() is not a standalone function in DQL.
    Use if(condition, value, else: default) pattern.
    Or use coalesce() for null fallbacks.


# ############################################################################
# SECTION 17: CONVERSION/CAST FUNCTIONS
# (commonly needed in metric transforms)
# ############################################################################

# toDouble(expr)  — cast to double
# toLong(expr)    — cast to long
# toString(expr)  — cast to string
# toTimestamp(str) — parse timestamp string
# arraySum(arr)   — sum of array
# arrayAvg(arr)   — average of array
# coalesce(a, b)  — first non-null value
# if(cond, val, else: default) — conditional
# isNull(expr), isNotNull(expr) — null checks
# lower(str), upper(str) — case conversion
# contains(str, substr) — substring check
# startsWith(str, prefix) — prefix check
# endsWith(str, suffix) — suffix check
# matchesPhrase(str, phrase) — token match
# matchesValue(str, pattern) — pattern match with wildcard
# formatTimestamp(ts, format: "pattern") — format timestamp
# concat(a, b, ...) — string concatenation
# in(field, val1, val2) — membership (in timeseries filter:)
# in(field, array(v1, v2)) — membership (in pipe filter)


# ############################################################################
# END OF CORPUS
# ############################################################################


# ============================================================================
# ADDENDUM: SEMANTIC CONSTRAINTS & ERROR CATEGORIES
# ============================================================================
# This section was MISSING from the original "complete" corpus.
# The original only covered structural syntax. This covers semantic
# rules that the DQL engine enforces at execution time.
# ============================================================================


# ############################################################################
# SECTION 18: AGGREGATION FUNCTION CONSTRAINTS
# Source: dql-reference, aggregation-commands, aggregation-functions
# ############################################################################

# --- 18.1: NO NESTED AGGREGATIONS ---
# DQL aggregation functions CANNOT contain other aggregation functions
# as arguments. This is a hard constraint.
# Error: NO_NESTED_AGGREGATIONS / DQL-SYNTAX-ERROR
# 
# This constraint applies to ALL aggregation functions:
#   count, countIf, sum, avg, min, max, percentile, median,
#   countDistinct, countDistinctExact, countDistinctApprox,
#   collectArray, collectDistinct, correlation, stddev,
#   takeFirst, takeLast, takeAny, start, end
#
# These functions accept ONLY:
#   - Field references (e.g., duration, status)
#   - Literal values (e.g., 500, "error")
#   - Scalar expressions (e.g., duration / 1000)
#   - Conditions (for countIf only)
#
# They do NOT accept other aggregation function calls.

CONSTRAINT_NO_NESTED_AGG:
  rule: |
    Aggregation functions cannot be nested inside other aggregation functions.
    countIf(countIf(...)) is INVALID.
    sum(avg(...)) is INVALID.
    max(count()) is INVALID.
  invalid_examples:
    - "countIf(countIf(duration < 500us) + countIf(duration >= 500us))"
    - "sum(avg(response_time))"
    - "max(count())"
    - "percentage wrapping apdex which emits countIf inside countIf"
  valid_alternatives:
    - |
      Use multi-step pipeline:
      | summarize satisfied = countIf(duration < 0.5), total = count()
      | fieldsAdd apdex_score = (toDouble(satisfied) / toDouble(total))
    - |
      Use fieldsAdd after summarize for derived calculations:
      | summarize a = countIf(cond1), b = countIf(cond2), total = count()
      | fieldsAdd result = 100.0 * toDouble(a + b) / toDouble(total)
  error_type: NO_NESTED_AGGREGATIONS
  exception_type: DQL-SYNTAX-ERROR
  source: DQL engine runtime validation (observed from screenshot error)

# --- 18.2: AGGREGATION ONLY IN SUMMARIZE/MAKETIMESERIES/TIMESERIES ---
CONSTRAINT_AGG_CONTEXT:
  rule: |
    Aggregation functions can ONLY be used inside:
      - summarize command
      - makeTimeseries command
      - timeseries command (metric-specific aggregations)
    They CANNOT be used in:
      - filter expressions
      - fieldsAdd expressions (except on timeseries array results with [])
      - sort expressions
  source: dql-reference "The required parameter is aggregation"

# --- 18.3: COUNTIF TAKES A CONDITION, NOT A VALUE ---
CONSTRAINT_COUNTIF_ARG:
  rule: |
    countIf() accepts a BOOLEAN CONDITION as its argument.
    countIf(duration < 500) is VALID (condition evaluates to bool).
    countIf(duration) is INVALID (duration is numeric, not boolean).
    countIf(status == 200) is VALID.
    countIf("error") is INVALID (string literal is not a condition).
  source: aggregation-functions countIf documentation

# --- 18.4: MAKETIMESERIES AGGREGATION SUBSET ---
CONSTRAINT_MTS_AGG_SUBSET:
  rule: |
    makeTimeseries supports ONLY these 9 aggregation functions:
      min, max, sum, avg, count, countIf, percentile,
      countDistinctExact, countDistinctApprox
    Others like collectArray, stddev, takeAny etc. are NOT available
    in makeTimeseries (only in summarize).
  source: aggregation-commands "Nine aggregation functions are available"

# --- 18.5: TIMESERIES AGGREGATION SUBSET ---
CONSTRAINT_TS_AGG_SUBSET:
  rule: |
    timeseries (metric query) supports:
      min, max, sum, avg, count, percentile, rate
    Plus metric-specific: rollup, default, scalar
    It does NOT support: countIf, countDistinct, collectArray, etc.
    These are metric aggregations, not record aggregations.
  source: metric-commands


# ############################################################################
# SECTION 19: TYPE SYSTEM CONSTRAINTS
# Source: data-types, aggregation-functions
# ############################################################################

CONSTRAINT_STRONG_TYPING:
  rule: |
    DQL is STRONGLY TYPED. Functions and operators accept only declared types.
    Mixing incompatible types returns null (not an error in most cases).
    Examples:
      sum(long_field + double_field) → double (compatible)
      sum(string_field) → null (string not summable)
      avg(boolean_field) → null (boolean not averageable)
      count() → always works (counts records, not values)
  source: data-types "strongly typed data"

CONSTRAINT_TYPE_MIXING_IN_AGG:
  rule: |
    When aggregating mixed types:
      long + double → double
      long + long → double (for avg/sum)
      duration + duration → duration (for sum)
      string + anything → null
      boolean + numeric → null
    If you mix two incompatible data types, the result is null.
  source: aggregation-functions "combining homogeneous data types"

CONSTRAINT_DURATION_UNITS:
  rule: |
    DQL duration literals: ns, us, ms, s, m, h, d
    When comparing durations to numbers, explicit units required.
    duration < 500 is AMBIGUOUS (what unit?)
    duration < 500ms is EXPLICIT
    NR durations are often in seconds. DT span durations are nanoseconds.
    Must convert: NR 0.5 (seconds) → DT 500ms or 500000us or 500000000ns
  source: data-types duration section

# --- 19.1: FIELD NAME RULES ---
CONSTRAINT_FIELD_NAMES:
  rule: |
    Field names can use any Unicode characters.
    Field names using characters OTHER than a-zA-Z0-9_. must use backticks.
    Field names starting with characters OTHER than a-zA-Z_ must use backticks.
    Backticks and backslashes inside field names must be escaped.
    Reserved words as field names require backticks.
  invalid_examples:
    - "fieldsAdd 2xx_count = ..."
    - "fieldsAdd my field = ..."
  valid_examples:
    - "fieldsAdd `2xx_count` = ..."
    - "fieldsAdd `my field` = ..."
  source: dql-reference "Syntax verification"

# --- 19.2: RESERVED WORDS ---
CONSTRAINT_RESERVED_WORDS:
  rule: |
    Do NOT use as field names or dimensions without backticks:
      fetch, filter, fields, fieldsAdd, fieldsRemove,
      sort, limit, summarize
  source: dql-best-practices


# ############################################################################
# SECTION 20: COMMAND ORDERING CONSTRAINTS
# Source: dql-best-practices, filtering-commands
# ############################################################################

CONSTRAINT_COMMAND_ORDER:
  rule: |
    Recommended pipeline order:
    1. fetch (starting command)
    2. filter / filterOut / search (reduce data early)
    3. parse / fieldsAdd (transform)
    4. summarize / makeTimeseries (aggregate)
    5. fieldsAdd (post-agg calculations)
    6. sort (at end)
    7. limit (at end)
    
    Anti-patterns:
    - sort right after fetch (degrades performance)
    - limit before summarize (wrong aggregates)
    - summarize after sort (unnecessary sort)
  source: dql-best-practices "Recommended order of commands"

CONSTRAINT_SEARCH_POSITION:
  rule: |
    search can only appear after these commands:
      filter, filterOut, fieldsKeep, fieldsRemove, fieldsRename, limit, append
    search CANNOT appear after summarize, sort, fieldsAdd, etc.
  source: filtering-commands search "Best practices and limitations"

CONSTRAINT_STARTING_COMMANDS:
  rule: |
    Valid starting commands (first in pipeline):
      fetch, data, timeseries, load
    All other commands require pipe input.
  source: data-source-commands


# ############################################################################
# SECTION 21: JOIN/LOOKUP CONSTRAINTS
# Source: correlation-and-join-commands
# ############################################################################

CONSTRAINT_JOIN_SIZE:
  rule: |
    Right side of join has 128 MB result size limit.
    If exceeded, query fails.
    Mitigations:
      - Filter/aggregate on right side
      - Use executionOrder: leftFirst if left is smaller
      - Use lookup instead of join for simple key matching
  source: correlation-and-join-commands "Limits"

CONSTRAINT_JOIN_NULLS:
  rule: |
    When key values on BOTH sides are null, records are NOT matched.
    This applies to join, lookup, and joinNested.
  source: correlation-and-join-commands join/lookup Parameters

CONSTRAINT_LOOKUP_SINGLE_MATCH:
  rule: |
    lookup returns only the FIRST matching record from the lookup table.
    If multiple matches exist, only top result is retrieved.
    For multiple matches, use join instead.
  source: correlation-and-join-commands lookup


# ############################################################################
# SECTION 22: NR-SPECIFIC FUNCTIONS WITH NO DQL EQUIVALENT
# (Functions that require decomposition, not 1:1 mapping)
# ############################################################################

NR_FUNC_APDEX:
  nrql: "apdex(duration, t:0.5)"
  meaning: "(satisfied + tolerating/2) / total"
  correct_dql: |
    fetch spans
    | filter service.name == "myservice"
    | summarize {
      satisfied = countIf(duration < 500ms),
      tolerating = countIf(duration >= 500ms and duration < 2s),
      total = count()
    }
    | fieldsAdd apdex = (toDouble(satisfied) + toDouble(tolerating) * 0.5) / toDouble(total)
  wrong_dql: |
    (countIf(duration < 0.5) + countIf(duration >= 0.5 and duration < 2.0) * 0.5) / count()
    # This puts countIf inside a division with count() — works but fragile
  notes: |
    CRITICAL: apdex MUST be decomposed into separate summarize aggregations
    then combined with fieldsAdd. It CANNOT be expressed as a single expression
    because that would require nested aggregations or aggregations in arithmetic
    context. The multi-step approach is the only safe pattern.

NR_FUNC_PERCENTAGE:
  nrql: "percentage(count(*), WHERE error IS TRUE)"
  meaning: "100 * matching_count / total_count"
  correct_dql: |
    fetch spans
    | summarize {
      matching = countIf(error == true),
      total = count()
    }
    | fieldsAdd pct = 100.0 * toDouble(matching) / toDouble(total)
  wrong_dql: |
    100.0 * countIf(error == true) / count()
    # This works ONLY inside summarize, NOT as a standalone expression
  notes: |
    percentage() wrapping apdex() is the compound case that caused the
    AEM_PROD bug. percentage(count(*), WHERE apdex(duration, 'T')...)
    decomposes apdex into countIf, then wraps that in percentage's countIf,
    creating nested aggregations.

NR_FUNC_FUNNEL:
  nrql: "funnel(session, WHERE action='view' AS 'Views', WHERE action='buy' AS 'Purchases')"
  correct_dql: |
    fetch spans
    | summarize {
      views = countIf(action == "view"),
      purchases = countIf(action == "buy")
    }
    | fieldsAdd conversion = 100.0 * toDouble(purchases) / toDouble(views)
  notes: No DQL funnel equivalent. Must decompose into separate countIf steps.

NR_FUNC_HISTOGRAM:
  nrql: "histogram(duration, 10, 20)"
  correct_dql: |
    fetch spans
    | makeTimeseries count(), by:{bin(duration, 10)}
  notes: |
    DQL has no histogram() function. Use bin() in by: clause with
    makeTimeseries or summarize.

NR_FUNC_UNIQUECOUNT:
  nrql: "uniqueCount(userId)"
  correct_dql: "countDistinctExact(userId)"
  notes: Direct mapping, but note exact vs approx variants in DQL.


# ############################################################################
# SECTION 23: THINGS I CLAIMED WERE DONE BUT WEREN'T
# (Honest audit of gaps in delivered code)
# ############################################################################

# AUDIT ITEM 1: Context-aware _map_field()
# STATUS: NOT IMPLEMENTED in delivered nrql_compiler.py
# CLAIMED: Session 2026-02-06-14-51-16 discussed it extensively
# REALITY: The delivered file has plain _map_field with no context parameter.
#          _query_class is NOT set. Metric dimension fields like 'id' and
#          'target' still get incorrectly mapped to span fields.
# IMPACT: Kafka/custom metric queries produce wrong filter dimensions.

# AUDIT ITEM 2: dql_validator.py
# STATUS: Built as regex-based checker
# CLAIMED: "validation framework"
# REALITY: Regex pattern matching, not AST-based. Doesn't catch semantic
#          errors like nested aggregations. Should be deleted or replaced
#          with compiler test cases.

# AUDIT ITEM 3: This corpus itself
# STATUS: Was missing Sections 18-22 entirely
# CLAIMED: "Complete" at 17 sections
# REALITY: Only covered structural syntax. Missing semantic constraints,
#          type system rules, command ordering, NR function decomposition,
#          and all error categories that DQL throws at runtime.


# ============================================================================
# END OF COMPLETE CORPUS (including semantic constraints)
# ============================================================================