# Code Review: NRQL-to-DQL Dashboard Migrator

**Reviewer:** Claude Opus 4.6
**Date:** 2026-02-09
**Scope:** Full codebase review — security, architecture, conversion correctness, code quality
**Comparison Reference:** [`nrql-translator`](../nrql-translator/) (TypeScript library by Dynatrace team)

---

## Table of Contents

- [Executive Summary](#executive-summary)
- [P0 — Critical Security Issues](#p0--critical-security-issues)
- [P1 — Conversion Logic Errors (Silently Wrong Data)](#p1--conversion-logic-errors-silently-wrong-data)
- [P2 — Conversion Logic Warnings (Subtle Data Differences)](#p2--conversion-logic-warnings-subtle-data-differences)
- [P3 — Architecture & Maintainability](#p3--architecture--maintainability)
- [P4 — Code Quality Issues](#p4--code-quality-issues)
- [P5 — Testing Gaps](#p5--testing-gaps)
- [Comparison with nrql-translator](#comparison-with-nrql-translator)
- [Recommendations Summary](#recommendations-summary)

---

## Executive Summary

This is an impressive, production-grade migration toolkit. The compiler architecture (lexer → parser → AST → emitter) is solid, coverage of 26+ aggregation functions and 9 condition types is thorough, and the 283-test suite with 174 real production queries at 100% clean compilation is strong evidence it works.

However, there are **critical security issues** (hardcoded credentials committed to git), **conversion logic errors** that produce silently wrong dashboard data, and **architectural concerns** (552KB single file) that will impede maintenance.

**Issue counts by priority:**

| Priority | Count | Description |
|----------|-------|-------------|
| P0 | 4 | Hardcoded credentials, no .gitignore, token logging |
| P1 | 6 | Conversion errors producing wrong numbers |
| P2 | 8 | Subtle semantic differences, edge cases |
| P3 | 5 | Architecture, file organization, API resilience |
| P4 | 9 | Code quality, dead code, error handling |
| P5 | 5 | Test framework, coverage gaps |

---

## P0 — Critical Security Issues

### P0-1: Hardcoded JWT Token in `dashboard_analysis.py:14`

```python
DT_API_TOKEN = os.environ.get("DT_API_TOKEN", "eyJhbGciOiJFUzI1NiIs...")
```

A **real, full JWT token** is committed as a default value. Decoded contents:
- **Email:** `jordan.wright@trace3.com`
- **Account:** `3a9d89be-4a2d-41d7-a478-b8dd24669a37`
- **Environment:** `bxa51304.apps.dynatrace.com`
- **Expiry:** 2026-01-23 (expired, but still a credential leak)

**Action:** Remove immediately. Rotate the associated OAuth client credentials. Replace with:
```python
DT_API_TOKEN = os.environ.get("DT_API_TOKEN", "")
```

### P0-2: No `.gitignore` File

The repository has **no `.gitignore` at all**. Currently committed:
- `__pycache__/` directory
- 90+ `migration_report_*.json` files (containing NR GUIDs and DT dashboard IDs)
- `slo_audit_*.json` files

**Action:** Add `.gitignore` covering:
```
__pycache__/
*.pyc
migration_report_*.json
slo_audit_*.json
.env
*.egg-info/
```

### P0-3: Hardcoded Dynatrace Environment URL

`dashboard_migrator.py:3108`:
```python
dt_url='https://cwt03869.apps.dynatrace.com',
```

Production environment URL hardcoded in source.

**Action:** Move to environment variable.

### P0-4: OAuth Token Partially Logged to stdout

`dashboard_migrator.py:10859`:
```python
print(f"OAuth Token: {effective_dt_token[:20]}...{effective_dt_token[-10:]} (len={len(effective_dt_token)})")
```

Prints first 20 and last 10 characters of tokens. This leaks enough of the token to potentially identify or reconstruct it, and these logs could end up in CI/CD systems, shared terminals, or log aggregators.

**Action:** Remove or replace with a simple "OAuth token obtained" message.

---

## P1 — Conversion Logic Errors (Silently Wrong Data)

These issues produce queries that **run successfully** in DT but return **different numbers** than the equivalent NR dashboard.

### P1-1: `rate()` Silently Drops the Rate Calculation

**File:** `nrql_compiler.py:2841-2845`

```python
if name_low == 'rate':
    self.warnings.append("rate() not directly supported...")
    if node.args and isinstance(node.args[0], FunctionCall):
        return self._emit_function(node.args[0])  # Just returns count()
    return 'count()'
```

**Problem:** `rate(count(*), 1 minute)` in NR = events per second. The compiler emits just `count()` — the **raw total count** for the entire time window. A dashboard showing "500 req/min" in NR would show "15,000" (or whatever the total) in DT.

**Fix:** Emit `count()` in `makeTimeseries` then add `| fieldsAdd rate = count / (interval_seconds)`, or use DQL's native rate calculation where available.

### P1-2: `duration.ms` → `duration` Without Unit Conversion in Filters

**File:** `nrql_compiler.py:1431`

```python
'duration.ms': 'duration',
```

**Problem:** `WHERE duration.ms > 1000` (meaning > 1 second) becomes `WHERE duration > 1000`. DT's `duration` field is a typed duration — bare `1000` is interpreted as **1000 nanoseconds** (0.001 milliseconds), not 1000 milliseconds. Thresholds are off by a factor of **1,000,000**.

The compiler has `_ms_to_duration_literal()` but doesn't apply it when mapping `duration.ms` comparisons in filter contexts.

**Fix:** When `duration.ms` appears in a comparison, convert the threshold value: `duration.ms > 1000` → `duration > 1s` (not `duration > 1000`).

### P1-3: `stddev()` Compiler Emits Native, Migrator Replaces with `avg()`

**Compiler:** `nrql_compiler.py:2854` — emits `stddev(field)` as native DQL
**Migrator:** `dashboard_migrator.py:4774-4786` — blindly replaces:

```python
if 'stddev(' in dql:
    new_lines.append(line.replace('stddev(', '/* stddev unsupported in DQL */ avg('))
```

**Problem:** Standard deviation is replaced with average — a completely different statistic. DQL `summarize` DOES support `stddev()`; `makeTimeseries` does not.

**Fix:** Make the replacement context-dependent. Only replace in `makeTimeseries` lines, not `summarize`.

### P1-4: `matchesPhrase()` → `contains()` — Case Sensitivity Change

**File:** `nrql_compiler.py:1415`

```python
'matchesphrase': 'contains',
```

**Problem:** NR `matchesPhrase()` is **case-insensitive**. DQL `contains()` is **case-sensitive**. Queries matching `WHERE matchesPhrase(name, 'error')` would match "Error", "ERROR", "error" in NR but **only** "error" in DT.

**Fix:** Use DQL's case-insensitive variant where available, or wrap with `lower()`: `contains(lower(field), "error")`.

### P1-5: `http.url` → `http.request.path` Loses Host and Scheme

**File:** `nrql_compiler.py:1443`

```python
'http.url': 'http.request.path',
```

**Problem:** NR `http.url` contains the full URL (`https://api.example.com/v1/users?id=1`). DT `http.request.path` is just the path (`/v1/users`). Queries like `WHERE http.url LIKE '%example.com%'` will never match because the hostname isn't in the path.

The `nrql-translator` (TypeScript) maps `http.url` → `http.request.url` which preserves the full URL — that's the correct DT field.

**Fix:** Map to `http.request.url` (full URL) instead of `http.request.path`.

### P1-6: `latest()` Semantic Mismatch

**File:** `nrql_compiler.py:1391`

```python
'latest': 'takeLast',
```

**Problem:** NR `latest(field)` returns the value with the **most recent timestamp**. DQL `takeLast()` returns the **last value by ingest order**, which is not the same when data arrives out of order (common in distributed systems). The `nrql-translator` uses `last()` which has similar issues.

**Impact:** "Current value" tiles (billboards showing latest CPU, memory, etc.) may show stale data instead of the most recent reading.

**Fix:** For single-value tiles, `avg()` over a short window is often more accurate. Add warning noting the semantic difference. Consider `takeMax(timestamp)` + `lookup` pattern for truly latest-by-time.

---

## P2 — Conversion Logic Warnings (Subtle Data Differences)

### P2-1: `apdex()` Emits Nested Aggregations That Grail Rejects

**File:** `nrql_compiler.py:2989-2993`

```python
return (
    f"(countIf(duration < {threshold}s) + "
    f"countIf(duration >= {threshold}s and duration < {frustrated_t}s) * 0.5) "
    f"/ count()"
)
```

The inline expression nests `countIf()` inside arithmetic. `_decompose_computed_aggs()` fixes this for `makeTimeseries` queries, but `summarize` queries pass the nested form through — Grail rejects with `NO_NESTED_AGGREGATIONS`.

### P2-2: `COMPARE WITH 1 month ago` → `-30d`

**File:** `nrql_compiler.py:1505`

```python
'month': ('d', 30),
```

Months approximated as 30 days. January has 31, February has 28/29. Month-over-month comparisons will be misaligned by 1-3 days.

### P2-3: `TransactionError` Filter is Too Narrow

**File:** `nrql_compiler.py:2320-2321`

```python
if from_type == 'transactionerror':
    parts.append('| filter otel.status_code == "ERROR"')
```

NR `TransactionError` includes all errors regardless of OTel status. Should be:
```python
'| filter error == true or otel.status_code == "ERROR"'
```

### P2-4: Double Field Mapping Creates Conflicts

- **Compiler:** `'parentId': 'span.parent_id'` (`nrql_compiler.py:1464`)
- **Migrator post-fix:** `'parentId': 'trace.parent_span_id'` (`dashboard_migrator.py:4574`)

Both run in sequence. The correct DT field depends on context (span vs trace query).

### P2-5: `LIKE` Complex Patterns Route to Wrong DQL Function

**File:** `nrql_compiler.py:~3330`

Patterns with `%` in the middle (like `%foo%bar%`) convert to `matchesPhrase(field, ".*foo.*bar.*")`. But DQL `matchesPhrase()` is a **text search function**, NOT a regex function. Should use `matchesPattern()` or `matches()`.

### P2-6: `uniqueCount()` → `countDistinctExact()` Performance

**File:** `nrql_compiler.py:1390`

NR's `uniqueCount()` uses HyperLogLog (approximate). The compiler maps to `countDistinctExact()` which does exact counting — much more expensive on high-cardinality fields. `countDistinctApprox()` would better match NR's behavior and performance characteristics.

### P2-7: Bare `name` Field Replacement is Risky

**File:** `dashboard_migrator.py:4607-4620`

Regex `(?<![.\w])name(?![.\w])` replaces bare `name` with `span.name` in span queries. Could match inside string literals or user-defined aliases.

### P2-8: `LIMIT MAX` Handling

**File:** `nrql_compiler.py:819`

`LIMIT MAX` → `LIMIT 5000` hardcoded. NR's actual MAX varies by query type (up to 5000 for events, but different for metrics). DQL has its own limits. The migrator post-processing (`dashboard_migrator.py:4702-4705`) then **strips** `limit max` entirely, so the two components disagree.

---

## P3 — Architecture & Maintainability

### P3-1: `dashboard_migrator.py` is 552KB / ~11,500 Lines

This single file contains **16 classes** and **3 top-level functions**:

| Class | Approx Lines | Suggested Module |
|-------|-------------|-----------------|
| `DQLSyntaxValidator` | ~240 | `validators/syntax.py` |
| `NRQLtoDQLConverter` | ~4,900 | `converter/nrql_to_dql.py` |
| 8 specialized converters | ~460 total | `converter/specialized.py` |
| `NewRelicClient` | ~100 | `clients/newrelic.py` |
| `DynatraceClient` | ~150 | `clients/dynatrace.py` |
| `DTEnvironmentRegistry` | ~940 | `registry/environment.py` |
| `SLOAuditor` | ~490 | `slo/auditor.py` |
| `DashboardMigrator` | ~1,450 | `migrator/dashboard.py` |
| `LayoutConverter` | ~35 | `converter/layout.py` |
| Data classes | ~50 | `models.py` |

**Impact:** IDE navigation, code review, merge conflicts, and onboarding are all significantly harder with a single 11K-line file.

### P3-2: No Retry/Backoff on API Calls

Both `NewRelicClient` and `DynatraceClient` make HTTP calls without:
- Retry logic
- Exponential backoff
- Rate limit handling
- Request timeouts (some calls have no timeout at all)

A single API timeout or 429 response will crash the entire migration.

### P3-3: GraphQL Injection Risk in `NewRelicClient`

**File:** `dashboard_migrator.py:~7730`

Dashboard GUIDs are interpolated directly into GraphQL queries via f-strings:
```python
entity(guid: "{guid}")
```

If `guid` comes from untrusted input, this is a GraphQL injection vector. Should use GraphQL variables.

### P3-4: `MVP_DASHBOARDS` List Hardcoded

The list of dashboards to migrate is hardcoded in the file with specific GUIDs and owner names for the US Foods migration. This couples the generic migration tool to a specific customer engagement.

### P3-5: Duplicate Validation Logic

`DQLSyntaxValidator` exists in both `dashboard_migrator.py` (inline) and `dqlvalidator.py` (standalone). They overlap but aren't identical — bugs fixed in one may not be fixed in the other.

---

## P4 — Code Quality Issues

### P4-1: Dead Code After `return` in `_validate_no_nested_aggregations()`

**File:** `nrql_compiler.py:3415-3419`

The `METRIC_DIMENSION_PASSTHROUGH` class attribute definition appears after a `return` statement inside a method. It works because Python processes class-level attributes at class definition time (not at method execution), but it's confusing and looks like dead code.

### P4-2: Hacky Anonymous Class Creation

**File:** `nrql_compiler.py:1629`

```python
type('TS', (), {'interval': sb})()
```

Creates an anonymous class just to pass an interval value to `_format_interval()`. Should use a `namedtuple` or simple dict.

### P4-3: Re-importing `re` Inside Methods

**File:** `nrql_compiler.py:3379`

```python
import re as _re  # re is already imported at module level
```

### P4-4: Bare `except:` Clauses Throughout

Multiple files use `except:` or `except Exception as e` with only `print()` — errors are silently swallowed. Examples:
- `dashboard_analysis.py:56`
- `test.py:201`
- Various locations in `dashboard_migrator.py`

### P4-5: `dashboard_analysis.py` Has Dead Test Function

`test_dql_queries()` (lines 79-113) is defined but never called.

### P4-6: `test.py` Uses Non-Deterministic Hash Caching

```python
self._cache[hash(dql_clean)] = result
```

Python 3.3+ randomizes hash seeds by default. Cache behavior is non-deterministic across runs.

### P4-7: Migration Reports Contain Infrastructure Details

90+ `migration_report_*.json` files committed with NR GUIDs, DT dashboard IDs, and error messages containing trace IDs. Not credentials per se, but operational details that shouldn't be in version control.

### P4-8: Token Leaked in Error Messages

`migration_report_20260123_224118.json` and similar files contain:
```json
"error": "Failed to create dashboard: 401 - {\"error\":{\"code\":401,\"message\":\"Bearer token is malformed\",\"details\":{\"traceId\":\"510fa26310956d027f2613ce4822a22c\"}}}"
```

### P4-9: `dqlvalidator.py` Crashes on Missing Data

Line ~109: `[l for l in lines if 'pod_name' in l][0]` will crash with `IndexError` if no match found. Similar pattern at line ~120.

---

## P5 — Testing Gaps

### P5-1: Custom Test Framework

Both `nrql_compiler.py` and `test.py` use custom `test()` functions instead of `unittest`/`pytest`. This means:
- No IDE test runner integration
- No parallel test execution
- No selective test running
- No test discovery
- No CI/CD integration without wrapping

### P5-2: No Negative Tests for Conversion Logic

The 283 tests verify that valid NRQL compiles. Missing:
- Tests that invalid NRQL produces proper errors (not crashes)
- Tests for empty queries, comments-only, unicode characters
- Tests for very long queries (performance)
- Tests that verify **semantic correctness** of the DQL output (not just string matching)

### P5-3: No Integration Tests Against Live DT

The 174 production query tests verify compilation, but don't verify the DQL actually returns data. The live validation mode exists (`--validate-dql`) but isn't part of the automated test suite.

### P5-4: `dqlvalidator.py` Tests Are Minimal

`test_validator()` checks only happy-path cases. Missing:
- `by: {single_field}` (should pass)
- `by: field1, field2` (bare fields without braces)
- Escaped field names with backticks
- Multiline queries
- Queries with comments

### P5-5: No Regression Tests for Migrator Post-Processing

The migrator's 16-check `_validate_and_fix_dql()` method has no dedicated tests. Each regex substitution could introduce regressions (e.g., the `stddev → avg` replacement).

---

## Comparison with nrql-translator

The TypeScript [`nrql-translator`](../nrql-translator/) provides useful comparison points:

| Aspect | `nrql-translator` (TS) | This Repo (Python) |
|--------|----------------------|-------------------|
| **Architecture** | Regex-based parsing | Formal lexer/parser/AST |
| **Scale** | ~1,500 lines | ~16,400 lines |
| **Functions** | 11 basic | 26+ with decompositions |
| **Event types** | 13 | 23 + K8S routing |
| **Field mappings** | ~50 | ~60 + context-aware |
| **Validation** | Confidence levels | Live Grail API |
| **Dashboard migration** | No | Yes (full pipeline) |

### Where `nrql-translator` Makes Better Choices

| Mapping | `nrql-translator` | This Repo | Better |
|---------|-------------------|-----------|--------|
| `http.url` | `http.request.url` | `http.request.path` | TS (preserves full URL) |
| `latest()` | `last()` | `takeLast()` | Neither (both lose timestamp ordering) |
| `uniqueCount()` | `countDistinct()` | `countDistinctExact()` | TS (matches NR's approximate behavior) |

### Where This Repo is Stronger

- Handles `apdex`, `percentage`, `funnel`, `histogram`, `cdfPercentage`, `rate`, `derivative` (TS has none of these)
- Context-aware field mapping (metric dimensions preserved in metric queries)
- Proper AST means correct handling of nested expressions, operator precedence, parenthesization
- Live DQL validation against Grail API
- Complete dashboard migration pipeline (not just query translation)

---

## Recommendations Summary

### Immediate (Do Now)

| # | Action | File |
|---|--------|------|
| 1 | Remove hardcoded JWT from `dashboard_analysis.py:14` | `dashboard_analysis.py` |
| 2 | Add `.gitignore` | Root |
| 3 | Remove token logging at line 10859 | `dashboard_migrator.py` |
| 4 | Remove hardcoded DT URL at line 3108 | `dashboard_migrator.py` |
| 5 | Remove migration report JSONs from git tracking | Root |

### Short-Term (Next Sprint)

| # | Action | Impact |
|---|--------|--------|
| 6 | Fix `http.url` → `http.request.url` mapping | P1 — wrong filter results |
| 7 | Fix `duration.ms` unit conversion in filter comparisons | P1 — thresholds off by 10^6 |
| 8 | Fix `rate()` to emit actual rate calculation | P1 — wrong dashboard numbers |
| 9 | Make `stddev()` replacement context-dependent | P1 — wrong statistic |
| 10 | Fix `matchesPhrase()` → case-insensitive variant | P1 — missed filter matches |
| 11 | Resolve compiler vs migrator `parentId` mapping conflict | P2 — wrong field in traces |

### Medium-Term (Planned Work)

| # | Action | Impact |
|---|--------|--------|
| 12 | Split `dashboard_migrator.py` into package modules | Maintainability |
| 13 | Add retry/backoff to API clients | Resilience |
| 14 | Use GraphQL variables instead of f-string interpolation | Security |
| 15 | Migrate tests to pytest | CI/CD integration |
| 16 | Add regression tests for migrator post-processing | Prevent regressions |
| 17 | Deduplicate `DQLSyntaxValidator` (one source of truth) | Consistency |
| 18 | Fix `apdex()` decomposition for `summarize` context | Correctness |

### Consider

| # | Action | Notes |
|---|--------|-------|
| 19 | Use `countDistinctApprox()` for `uniqueCount()` | Better perf match to NR |
| 20 | Externalize `MVP_DASHBOARDS` to config file | Decouple from customer |
| 21 | Add semantic test suite (verify DQL output meaning, not just string) | Long-term correctness |
| 22 | Consider `COMPARE WITH` calendar month logic | Low impact but more correct |

---

*Review generated by Claude Opus 4.6 — 2026-02-09*
