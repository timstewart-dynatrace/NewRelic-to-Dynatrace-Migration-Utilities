#!/usr/bin/env python3
"""
DQL Syntax Validator
====================
Validates that DQL output from our NRQL compiler/dashboard migrator
conforms to documented Dynatrace DQL syntax rules.

This is NOT regex guessing. Every rule maps to a specific DT docs reference.
"""

import re
import sys

class DQLValidationError:
    def __init__(self, rule_id: str, message: str, line: str, docs_ref: str):
        self.rule_id = rule_id
        self.message = message
        self.line = line
        self.docs_ref = docs_ref

    def __repr__(self):
        return f"[{self.rule_id}] {self.message}\n  Line: {self.line}\n  Docs: {self.docs_ref}"


def validate_dql(dql: str) -> list[DQLValidationError]:
    """Validate a DQL query against documented syntax rules."""
    errors = []
    lines = [l.strip() for l in dql.strip().split('\n') if l.strip() and not l.strip().startswith('//')]
    full_dql = ' '.join(lines)

    # =========================================================================
    # RULE TS-1: timeseries multi-agg must use {} when by:/filter: present
    # Docs: dql-examples Example 6, Example 9
    # =========================================================================
    if full_dql.startswith('timeseries ') or '| timeseries ' in full_dql:
        ts_part = full_dql.split('| timeseries ')[-1] if '| timeseries ' in full_dql else full_dql
        ts_part = ts_part.replace('timeseries ', '', 1)

        # Count number of " = sum(" or " = avg(" etc patterns before by:/filter:
        # These indicate multiple aggregation aliases
        agg_pattern = re.findall(r'(\w+)\s*=\s*(sum|avg|min|max|count|percentile)\(', ts_part)

        if len(agg_pattern) >= 2:
            # Multiple aggregations — must be wrapped in {}
            # Check if the aggregations are inside {}
            brace_depth = 0
            first_agg_in_brace = False
            for i, ch in enumerate(ts_part):
                if ch == '{':
                    brace_depth += 1
                    if brace_depth == 1 and i < 5:  # { near start = agg group
                        first_agg_in_brace = True
                elif ch == '}':
                    brace_depth -= 1

            if not first_agg_in_brace:
                # Check if by: or filter: present
                has_by_or_filter = 'by:' in ts_part or 'filter:' in ts_part
                if has_by_or_filter:
                    errors.append(DQLValidationError(
                        'TS-1', 
                        'Multiple timeseries aggregations must be wrapped in {} when by:/filter: is present',
                        ts_part[:100],
                        'dql-examples Example 6: timeseries {cpu_alloc=min(...), req_cpu=max(...)}, by:{...}'
                    ))

    # =========================================================================
    # RULE TS-2: timeseries by: with multiple fields must use {}
    # Docs: dql-examples Example 6
    # =========================================================================
    by_match = re.search(r',\s*by:\s*(\S)', full_dql)
    if by_match:
        char_after_by = by_match.group(1)
        # Check if what follows by: is a brace or a bare field
        by_section = full_dql[by_match.end()-1:]
        if char_after_by != '{':
            # Bare field — check if it's actually multiple fields
            # Look for comma before next keyword
            next_keyword = re.search(r',\s*(filter:|interval:|shift:|from:|to:|nonempty:|union:|bucket:)', by_section)
            bare_part = by_section[:next_keyword.start()] if next_keyword else by_section
            if ',' in bare_part:
                errors.append(DQLValidationError(
                    'TS-2',
                    'Multiple by: fields must be wrapped in {}',
                    bare_part[:80],
                    'dql-examples Example 6: by:{dt.entity.kubernetes_cluster, dt.entity.kubernetes_node}'
                ))

    # =========================================================================
    # RULE FLD-1: entity.name is not valid on fetch spans — use service.name
    # Source: Verified in DT environment (not a documented field)
    # =========================================================================
    if 'fetch spans' in full_dql and 'entity.name' in full_dql:
        errors.append(DQLValidationError(
            'FLD-1',
            'entity.name is not a valid filter field on spans — use service.name',
            full_dql[:100],
            'DT span fields: service.name, span.kind, duration, endpoint.name, http.request.method'
        ))

    # =========================================================================
    # RULE FLD-2: pod_name is not a valid DQL field — use k8s.pod.name
    # Source: OTel semantic conventions, DT docs examples
    # =========================================================================
    if 'pod_name' in full_dql and 'k8s.pod.name' not in full_dql:
        errors.append(DQLValidationError(
            'FLD-2',
            'pod_name is not a valid DQL field — use k8s.pod.name (OTel semconv)',
            [l for l in lines if 'pod_name' in l][0] if any('pod_name' in l for l in lines) else '',
            'DT docs: k8s.pod.name, k8s.namespace.name, k8s.cluster.name'
        ))

    # =========================================================================
    # RULE FLD-3: data.service.name is not valid — use service.name
    # =========================================================================
    if 'data.service.name' in full_dql:
        errors.append(DQLValidationError(
            'FLD-3',
            'data.service.name is not a valid field — use service.name',
            [l for l in lines if 'data.service.name' in l][0],
            'DT log fields: service.name'
        ))

    # =========================================================================
    # RULE MET-1: NR metric keys used instead of DT metric keys
    # =========================================================================
    nr_to_dt_metrics = {
        'k8s.container.memoryWorkingSetBytes': 'dt.kubernetes.container.memory_working_set',
        'k8s.container.cpuUsedCores': 'dt.kubernetes.container.cpu_usage',
        'cpuUsedCores': 'dt.kubernetes.container.cpu_usage',
        'memoryUsedBytes': 'dt.kubernetes.container.memory_working_set',
    }
    for nr_key, dt_key in nr_to_dt_metrics.items():
        if nr_key in full_dql:
            errors.append(DQLValidationError(
                'MET-1',
                f'NR metric key "{nr_key}" used — DT equivalent is "{dt_key}"',
                nr_key,
                'DT metrics: dt.kubernetes.container.* prefix'
            ))

    # =========================================================================
    # RULE MET-2: Custom metrics used as if they're span fields
    # (e.g. topic_offset_lag with span.id filter)
    # =========================================================================
    kafka_metrics = ['topic_offset_lag', 'group_offset_lag', 'topic_offset_delta', 'topic_end_delta']
    for km in kafka_metrics:
        if km in full_dql and 'span.id' in full_dql:
            errors.append(DQLValidationError(
                'MET-2',
                f'Kafka metric "{km}" used with span.id filter — these are custom metrics, not spans',
                full_dql[:100],
                'Confluent Cloud extension: kafka_consumergroup_* metrics'
            ))

    # =========================================================================
    # RULE SYN-1: makeTimeseries multi-agg should use {}
    # Docs: aggregation-commands makeTimeseries Example 3, 4
    # =========================================================================
    if 'makeTimeseries' in full_dql:
        mts_match = re.search(r'makeTimeseries\s+(.+?)$', full_dql)
        if mts_match:
            mts_part = mts_match.group(1)
            # Count aggregation functions
            agg_calls = re.findall(r'(count|avg|sum|min|max|percentile|countIf|median)\s*\(', mts_part)
            if len(agg_calls) >= 2:
                # Check if wrapped in {}
                if not mts_part.strip().startswith('{'):
                    errors.append(DQLValidationError(
                        'SYN-1',
                        'makeTimeseries with multiple aggregations should use {}',
                        mts_part[:80],
                        'aggregation-commands makeTimeseries Example 3: makeTimeseries {count(), high_volume=countIf(...)}'
                    ))

    # =========================================================================
    # RULE SYN-2: summarize multi-agg should use {}
    # Docs: aggregation-commands summarize practical example
    # =========================================================================
    if '| summarize' in full_dql or full_dql.startswith('summarize'):
        sum_match = re.search(r'summarize\s+(.+?)(?:,\s*by:|$)', full_dql)
        if sum_match:
            sum_part = sum_match.group(1)
            agg_calls = re.findall(r'(count|avg|sum|min|max|percentile|countIf|takeAny|collectArray|countDistinct)\s*\(', sum_part)
            if len(agg_calls) >= 2 and not sum_part.strip().startswith('{'):
                errors.append(DQLValidationError(
                    'SYN-2',
                    'summarize with multiple aggregations should use {}',
                    sum_part[:80],
                    'aggregation-commands summarize: | summarize {min(value), max(value)}, by:{field}'
                ))

    # =========================================================================
    # RULE TS-3: timeseries filter: should use {} for safety
    # Docs: All examples use filter:{expr}
    # =========================================================================
    ts_filter_bare = re.search(r'timeseries\s.*,\s*filter:\s*(?!\{)(\S)', full_dql)
    if ts_filter_bare:
        # Bare filter without braces — warn
        errors.append(DQLValidationError(
            'TS-3',
            'timeseries filter: should use {} braces for safety (all docs examples use braces)',
            full_dql[ts_filter_bare.start():ts_filter_bare.end()+20],
            'dql-examples: filter:{startsWith(aws.availability_zone, "us-east-1")}'
        ))

    return errors


def validate_all_tiles(dashboard: dict) -> dict:
    """Validate all tiles in a dashboard JSON."""
    import json
    tiles = dashboard.get('tiles', {})
    results = {'valid': 0, 'errors': 0, 'warnings': 0, 'details': []}

    for tid, tile in sorted(tiles.items(), key=lambda x: int(x[0])):
        if tile.get('type') == 'markdown':
            continue
        query = tile.get('query', '')
        title = tile.get('title', '')
        if not query.strip():
            continue

        errors = validate_dql(query)
        if errors:
            results['errors'] += 1
            results['details'].append({
                'tile_id': tid,
                'title': title,
                'errors': [str(e) for e in errors]
            })
        else:
            results['valid'] += 1

    return results


# ========================
# SELF-TESTS
# ========================

def test_validator():
    """Test the validator against known good and bad patterns."""
    print("=" * 70)
    print("DQL SYNTAX VALIDATOR — SELF-TESTS")
    print("=" * 70)

    passed = 0
    failed = 0

    def check(name, dql, expected_rule=None, should_pass=True):
        nonlocal passed, failed
        errors = validate_dql(dql)
        rule_ids = [e.rule_id for e in errors]

        if should_pass and not errors:
            print(f"  ✅ {name}")
            passed += 1
        elif not should_pass and expected_rule and expected_rule in rule_ids:
            print(f"  ✅ {name} (caught {expected_rule})")
            passed += 1
        elif not should_pass and errors and expected_rule is None:
            print(f"  ✅ {name} (caught {[e.rule_id for e in errors]})")
            passed += 1
        else:
            print(f"  ❌ {name}")
            print(f"     Expected: {'PASS' if should_pass else f'FAIL with {expected_rule}'}")
            print(f"     Got: {rule_ids if errors else 'PASS'}")
            for e in errors:
                print(f"     {e}")
            failed += 1

    # ---- Valid patterns (from DT docs) ----
    print("\n  Valid patterns (should pass):")

    check("Single metric", 
        "timeseries usage=avg(dt.host.cpu.usage)")

    check("Single metric with by/filter",
        'timeseries avg(dt.host.cpu.usage), by:{dt.entity.host}, filter:{dt.entity.host == "HOST-1"}')

    check("Multi-metric with braces (Example 6)",
        'timeseries {cpu_alloc = min(dt.kubernetes.node.cpu_allocatable), req_cpu = max(dt.kubernetes.container.requests_cpu)}, by:{dt.entity.kubernetes_cluster, dt.entity.kubernetes_node}')

    check("Multi-metric failure rate (Example 9)",
        'timeseries {new = sum(dt.process.network.sessions.new), reset = sum(dt.process.network.sessions.reset, default:0)}, by:{dt.entity.host}')

    check("fetch logs with filter",
        'fetch logs\n| filter service.name == "my-svc" and loglevel == "ERROR"\n| makeTimeseries count(), by:{k8s.pod.name}')

    check("fetch spans with service.name",
        'fetch spans\n| filter service.name == "my-svc"\n| makeTimeseries avg(duration)')

    check("fieldsAdd after timeseries",
        'timeseries {used = sum(dt.kubernetes.persistentvolumeclaim.used), cap = sum(dt.kubernetes.persistentvolumeclaim.capacity)}, by:{k8s.node.name}\n| fieldsAdd util = (toDouble(used) / toDouble(cap)) * 100')

    check("summarize with braces",
        'fetch logs\n| summarize {errors = countIf(loglevel == "ERROR"), warns = countIf(loglevel == "WARN")}, by:{service.name}')

    # ---- Invalid patterns (should fail) ----
    print("\n  Invalid patterns (should catch errors):")

    check("Multi-metric WITHOUT braces", 
        'timeseries used = sum(dt.kubernetes.persistentvolumeclaim.used), cap = sum(dt.kubernetes.persistentvolumeclaim.capacity), by:{k8s.node.name}',
        expected_rule='TS-1', should_pass=False)

    check("entity.name on spans",
        'fetch spans\n| filter entity.name == "my-service"',
        expected_rule='FLD-1', should_pass=False)

    check("pod_name instead of k8s.pod.name",
        'fetch logs\n| filter service.name == "svc"\n| makeTimeseries count(), by:{pod_name}',
        expected_rule='FLD-2', should_pass=False)

    check("data.service.name",
        'fetch logs\n| filter data.service.name == "svc"',
        expected_rule='FLD-3', should_pass=False)

    check("NR metric key memoryWorkingSetBytes",
        'timeseries avg(k8s.container.memoryWorkingSetBytes)',
        expected_rule='MET-1', should_pass=False)

    check("Kafka metric with span.id",
        'timeseries avg(topic_offset_lag), by:{target}, filter: span.id == "lkc_123"',
        expected_rule='MET-2', should_pass=False)

    print(f"\n{'='*70}")
    print(f"  RESULTS: {passed} passed, {failed} failed")
    if failed == 0:
        print("  ALL TESTS PASS ✅")
    print(f"{'='*70}")
    return failed == 0


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--test':
        success = test_validator()
        sys.exit(0 if success else 1)
    elif len(sys.argv) > 1:
        # Validate a dashboard JSON file
        import json
        with open(sys.argv[1]) as f:
            dashboard = json.load(f)
        results = validate_all_tiles(dashboard)
        print(f"Valid tiles: {results['valid']}")
        print(f"Tiles with errors: {results['errors']}")
        for detail in results['details']:
            print(f"\nTile {detail['tile_id']} ({detail['title']}):")
            for err in detail['errors']:
                print(f"  {err}")
    else:
        test_validator()