#!/usr/bin/env python3
"""
NRQL Compiler: AST-based NRQL â†’ DQL Translation
================================================

Architecture:
    NRQL string â†’ Lexer â†’ Token[] â†’ Parser â†’ AST â†’ DQLEmitter â†’ DQL string

This replaces regex-based conversion with a proper compiler pipeline.
Structural bugs like duplicate aggregations, unnamed positional params,
leaked subqueries, and wrong alias syntax are impossible by construction.

Usage:
    compiler = NRQLCompiler()
    result = compiler.compile("SELECT count(*) FROM Transaction WHERE appName = 'my-app' TIMESERIES")
    print(result.dql)

Integration:
    # In NRQLtoDQLConverter.convert():
    result = self._compiler.compile(nrql)
    if result.success:
        return result  # AST path
    else:
        return self._regex_convert(nrql)  # Fallback

Author: Jordan Wright / Trace3 Universal Migration Platform
"""

from __future__ import annotations
import re
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import List, Optional, Union, Tuple, Dict, Any, Set


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# SECTION 1: TOKENS & LEXER
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

class TokenType(Enum):
    # Keywords
    SELECT = auto(); FROM = auto(); WHERE = auto()
    AND = auto(); OR = auto(); NOT = auto()
    AS = auto(); FACET = auto(); TIMESERIES = auto()
    SINCE = auto(); UNTIL = auto(); LIMIT = auto()
    IN = auto(); LIKE = auto(); RLIKE = auto()
    IS = auto(); NULL = auto(); TRUE = auto(); FALSE = auto()
    COMPARE = auto(); WITH = auto()
    ORDER = auto(); BY = auto(); ASC = auto(); DESC = auto()
    EXTRAPOLATE = auto(); AUTO = auto(); RAW = auto(); AGO = auto()
    CASES = auto(); OFFSET = auto(); MAX_KW = auto()
    # Literals & identifiers
    NUMBER = auto(); STRING = auto(); IDENTIFIER = auto()
    # Operators
    EQ = auto(); NEQ = auto(); LT = auto(); GT = auto()
    LTE = auto(); GTE = auto()
    PLUS = auto(); MINUS = auto(); STAR = auto(); SLASH = auto(); PERCENT = auto()
    # Punctuation
    LPAREN = auto(); RPAREN = auto(); COMMA = auto()
    # End
    EOF = auto()

KEYWORDS = {
    'select': TokenType.SELECT, 'from': TokenType.FROM, 'where': TokenType.WHERE,
    'and': TokenType.AND, 'or': TokenType.OR, 'not': TokenType.NOT,
    'as': TokenType.AS, 'facet': TokenType.FACET, 'timeseries': TokenType.TIMESERIES,
    'since': TokenType.SINCE, 'until': TokenType.UNTIL, 'limit': TokenType.LIMIT,
    'in': TokenType.IN, 'like': TokenType.LIKE, 'rlike': TokenType.RLIKE,
    'is': TokenType.IS, 'null': TokenType.NULL, 'true': TokenType.TRUE, 'false': TokenType.FALSE,
    'compare': TokenType.COMPARE, 'with': TokenType.WITH,
    'order': TokenType.ORDER, 'by': TokenType.BY, 'asc': TokenType.ASC, 'desc': TokenType.DESC,
    'extrapolate': TokenType.EXTRAPOLATE, 'auto': TokenType.AUTO, 'raw': TokenType.RAW,
    'ago': TokenType.AGO, 'cases': TokenType.CASES, 'offset': TokenType.OFFSET,
}

# These identifiers are NOT keywords â€” they're valid field/function names
# that happen to look like keywords in some contexts
NON_KEYWORD_IDENTS = {'count', 'average', 'sum', 'max', 'min', 'rate', 'filter',
                       'percentage', 'percentile', 'uniquecount', 'latest', 'earliest',
                       'uniques', 'median', 'stddev', 'apdex', 'funnel', 'histogram',
                       'substring', 'indexof', 'length', 'concat', 'lower', 'upper',
                       'abs', 'ceil', 'floor', 'round', 'if', 'capture', 'aparse',
                       'bytecountestimate', 'allcolumnsearch', 'cardinality',
                       'cdfpercentage', 'derivative', 'eventtype', 'getfield',
                       'keyset', 'mapkeys', 'mapvalues',
                       # Phase 2+3 additions
                       'jparse', 'blob', 'clamp_max', 'clamp_min', 'ln',
                       'buckets', 'bucketpercentile', 'predictlinear',
                       'aggregationendtime', 'inner', 'left', 'join', 'on',
                       'slide', 'predict', 'show', 'event', 'types', 'timezone'}


@dataclass
class Token:
    type: TokenType
    value: Any
    pos: int
    def __repr__(self):
        return f'Token({self.type.name}, {self.value!r})'


class LexError(Exception):
    """Lexer error with position info."""
    def __init__(self, msg: str, pos: int = -1):
        self.pos = pos
        super().__init__(msg)


class NRQLLexer:
    """Tokenize an NRQL string."""

    def __init__(self, source: str):
        self.src = source
        self.pos = 0

    def tokenize(self) -> List[Token]:
        tokens: List[Token] = []
        while self.pos < len(self.src):
            c = self.src[self.pos]

            # Skip whitespace
            if c in ' \t\n\r':
                self.pos += 1
                continue

            # SQL line comments (-- to end of line)
            if c == '-' and self.pos + 1 < len(self.src) and self.src[self.pos + 1] == '-':
                # Skip to end of line
                while self.pos < len(self.src) and self.src[self.pos] != '\n':
                    self.pos += 1
                continue

            # Skip semicolons (statement terminators)
            if c == ';':
                self.pos += 1
                continue

            # String literal  (single-quoted)
            if c == "'":
                tokens.append(self._string())
                continue

            # Number (including leading decimal like .30)
            if c.isdigit() or (c == '.' and self.pos + 1 < len(self.src) and self.src[self.pos + 1].isdigit()):
                tokens.append(self._number())
                continue

            # Two-char operators
            two = self.src[self.pos:self.pos + 2]
            if two == '!=':
                tokens.append(Token(TokenType.NEQ, '!=', self.pos)); self.pos += 2; continue
            if two == '<=':
                tokens.append(Token(TokenType.LTE, '<=', self.pos)); self.pos += 2; continue
            if two == '>=':
                tokens.append(Token(TokenType.GTE, '>=', self.pos)); self.pos += 2; continue

            # Single-char operators & punctuation
            OP_MAP = {
                '=': TokenType.EQ, '<': TokenType.LT, '>': TokenType.GT,
                '+': TokenType.PLUS, '-': TokenType.MINUS, '*': TokenType.STAR,
                '/': TokenType.SLASH, '%': TokenType.PERCENT,
                '(': TokenType.LPAREN, ')': TokenType.RPAREN, ',': TokenType.COMMA,
            }
            if c in OP_MAP:
                tokens.append(Token(OP_MAP[c], c, self.pos)); self.pos += 1; continue

            # Backtick-quoted identifier
            if c == '`':
                tokens.append(self._backtick_ident())
                continue

            # Identifier or keyword
            if c.isalpha() or c == '_':
                tokens.append(self._identifier())
                continue

            # Double-quoted string literal (used for aliases like AS "95th")
            if c == '"':
                tokens.append(self._dquote_string())
                continue

            # Skip characters that appear in NR queries but aren't syntactically meaningful
            # Colon (:) can appear in function call contexts
            if c == ':':
                self.pos += 1
                continue

            # Template variables: {{varName}} â†’ treat as identifier
            if c == '{' and self.pos + 1 < len(self.src) and self.src[self.pos + 1] == '{':
                tpl_start = self.pos
                self.pos += 2  # skip {{
                m = re.match(r'[a-zA-Z_][a-zA-Z0-9_]*', self.src[self.pos:])
                var_name = m.group(0) if m else 'template_var'
                if m:
                    self.pos += len(m.group(0))
                # Skip closing }}
                while self.pos < len(self.src) and self.src[self.pos] == '}':
                    self.pos += 1
                tokens.append(Token(TokenType.STRING, var_name, tpl_start))
                continue

            # Brackets: field['key'] or field[0] â†’ skip entire bracket expression
            if c == '[':
                self.pos += 1  # skip [
                depth = 1
                while self.pos < len(self.src) and depth > 0:
                    if self.src[self.pos] == '[': depth += 1
                    elif self.src[self.pos] == ']': depth -= 1
                    self.pos += 1
                continue

            if c in '{}':
                self.pos += 1
                continue

            raise LexError(f"Unexpected character '{c}' at position {self.pos}", self.pos)

        tokens.append(Token(TokenType.EOF, None, self.pos))
        return tokens

    def _string(self) -> Token:
        start = self.pos
        self.pos += 1  # skip '
        buf = []
        while self.pos < len(self.src):
            c = self.src[self.pos]
            if c == "'":
                # Escaped '' ?
                if self.pos + 1 < len(self.src) and self.src[self.pos + 1] == "'":
                    buf.append("'")
                    self.pos += 2
                else:
                    self.pos += 1
                    return Token(TokenType.STRING, ''.join(buf), start)
            elif c == '\\' and self.pos + 1 < len(self.src):
                buf.append(self.src[self.pos + 1])
                self.pos += 2
            else:
                buf.append(c)
                self.pos += 1
        raise LexError(f"Unterminated string at position {start}", start)

    def _dquote_string(self) -> Token:
        """Parse a double-quoted string literal: "value" â†’ STRING token."""
        start = self.pos
        self.pos += 1  # skip opening "
        buf = []
        while self.pos < len(self.src):
            c = self.src[self.pos]
            if c == '"':
                self.pos += 1  # skip closing "
                return Token(TokenType.STRING, ''.join(buf), start)
            elif c == '\\' and self.pos + 1 < len(self.src):
                buf.append(self.src[self.pos + 1])
                self.pos += 2
            else:
                buf.append(c)
                self.pos += 1
        raise LexError(f"Unterminated double-quoted string at position {start}", start)

    def _number(self) -> Token:
        start = self.pos
        # Match: 123, 12.34, .30, 10e8, 1.5e-3
        m = re.match(r'(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?', self.src[self.pos:])
        if not m:
            raise LexError(f"Invalid number at position {start}", start)
        s = m.group(0)
        self.pos += len(s)
        val = float(s) if ('.' in s or 'e' in s.lower()) else int(s)
        return Token(TokenType.NUMBER, val, start)

    def _identifier(self) -> Token:
        start = self.pos
        # Identifiers can contain letters, digits, underscores, dots, colons (for builtin:*)
        m = re.match(r'[a-zA-Z_][a-zA-Z0-9_.:]*', self.src[self.pos:])
        if not m:
            raise LexError(f"Invalid identifier at position {start}", start)
        raw = m.group(0)
        # Trim trailing dots/colons
        raw = raw.rstrip('.').rstrip(':')
        self.pos += len(raw)
        low = raw.lower()
        # 'max' as keyword only in certain contexts (LIMIT MAX, SINCE MAX)
        if low == 'max':
            return Token(TokenType.MAX_KW, raw, start)
        if low in KEYWORDS and low not in NON_KEYWORD_IDENTS:
            return Token(KEYWORDS[low], raw, start)
        return Token(TokenType.IDENTIFIER, raw, start)

    def _backtick_ident(self) -> Token:
        start = self.pos
        self.pos += 1  # skip `
        buf = []
        while self.pos < len(self.src) and self.src[self.pos] != '`':
            buf.append(self.src[self.pos])
            self.pos += 1
        if self.pos >= len(self.src):
            raise LexError(f"Unterminated backtick identifier at position {start}", start)
        self.pos += 1  # skip `
        return Token(TokenType.IDENTIFIER, ''.join(buf), start)


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# SECTION 2: AST NODES
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@dataclass
class ASTNode:
    pass

# â”€â”€ Expressions â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@dataclass
class StarExpr(ASTNode):
    """count(*)"""
    pass

@dataclass
class LiteralExpr(ASTNode):
    value: Any   # int, float, str, bool, None

@dataclass
class FieldRef(ASTNode):
    name: str    # e.g. 'http.response.statusCode', 'appName'

@dataclass
class FunctionCall(ASTNode):
    name: str
    args: List[ASTNode]
    where_clause: Optional[Condition] = None   # for filter(), percentage()

@dataclass
class BinaryOp(ASTNode):
    op: str      # +, -, *, /, %
    left: ASTNode
    right: ASTNode

@dataclass
class UnaryMinus(ASTNode):
    operand: ASTNode

@dataclass
class TimeInterval(ASTNode):
    """1 minute, 5 seconds, etc."""
    value: Union[int, float]
    unit: str    # second, minute, hour, day, week, month

# â”€â”€ Conditions â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@dataclass
class Condition(ASTNode):
    pass

@dataclass
class ComparisonCond(Condition):
    op: str      # =, !=, <, >, <=, >=
    left: ASTNode
    right: ASTNode

@dataclass
class LogicalCond(Condition):
    op: str      # AND, OR
    left: Condition
    right: Condition

@dataclass
class NotCond(Condition):
    operand: Condition

@dataclass
class IsNullCond(Condition):
    expr: ASTNode
    negated: bool = False   # IS NOT NULL

@dataclass
class InListCond(Condition):
    expr: ASTNode
    values: List[ASTNode]
    negated: bool = False

@dataclass
class InSubqueryCond(Condition):
    expr: ASTNode
    subquery: Query
    negated: bool = False

@dataclass
class LikeCond(Condition):
    expr: ASTNode
    pattern: str
    negated: bool = False

@dataclass
class RLikeCond(Condition):
    expr: ASTNode
    pattern: str
    negated: bool = False

# â”€â”€ Clauses & Query â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

@dataclass
class SelectItem(ASTNode):
    expression: ASTNode
    alias: Optional[str] = None

@dataclass
class FacetItem(ASTNode):
    expression: ASTNode
    alias: Optional[str] = None

@dataclass
class TimeseriesClause(ASTNode):
    interval: Optional[str] = None   # 'AUTO', '1 minute', None
    slide_by: Optional[str] = None   # 'AUTO', 'MAX', '1 minute', None

@dataclass
class LimitClause(ASTNode):
    value: Union[int, str]   # number or 'MAX'

@dataclass
class OrderByClause(ASTNode):
    expression: ASTNode
    direction: str = 'ASC'

@dataclass
class JoinClause(ASTNode):
    join_type: str             # 'INNER' or 'LEFT'
    subquery: 'Query'
    on_left: Optional[str] = None    # parent key (or None if same key)
    on_right: Optional[str] = None   # subquery key

@dataclass
class Query(ASTNode):
    select_items: List[SelectItem]
    from_clause: str
    where_clause: Optional[Condition] = None
    facet_items: Optional[List[FacetItem]] = None
    timeseries: Optional[TimeseriesClause] = None
    since_raw: Optional[str] = None
    until_raw: Optional[str] = None
    limit: Optional[LimitClause] = None
    order_by: Optional[OrderByClause] = None
    compare_with_raw: Optional[str] = None
    extrapolate: bool = False
    join_clause: Optional[JoinClause] = None
    facet_order_by: Optional[ASTNode] = None  # FACET ... ORDER BY agg()
    with_timezone: Optional[str] = None
    predict: bool = False


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# SECTION 3: PARSER (Recursive Descent)
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

TIME_UNITS = {'second', 'seconds', 'sec', 's',
              'minute', 'minutes', 'min',
              'hour', 'hours', 'hr', 'h',
              'day', 'days', 'd',
              'week', 'weeks', 'w',
              'month', 'months'}

# Functions that accept a WHERE clause as their last argument
WHERE_FUNCTIONS = {'percentage', 'filter', 'apdex', 'funnel'}

# Known aggregation functions (used to detect aggregation context)
AGG_FUNCTIONS = {'count', 'sum', 'average', 'avg', 'max', 'min', 'percentile',
                 'uniquecount', 'uniques', 'latest', 'earliest', 'last', 'first',
                 'median', 'stddev', 'rate', 'filter', 'percentage', 'apdex',
                 'funnel', 'histogram', 'cdfpercentage', 'countdistinct',
                 'bucketpercentile', 'derivative', 'cardinality',
                 'aggregationendtime', 'predictlinear'}


class ParseError(Exception):
    def __init__(self, msg: str, pos: int = -1):
        self.pos = pos
        super().__init__(msg)


class NRQLParser:
    """Recursive-descent parser for NRQL â†’ AST."""

    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0

    # â”€â”€ Helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _cur(self) -> Token:
        return self.tokens[min(self.pos, len(self.tokens) - 1)]

    def _peek(self, offset: int = 0) -> Token:
        idx = self.pos + offset
        return self.tokens[min(idx, len(self.tokens) - 1)]

    def _at_end(self) -> bool:
        return self._cur().type == TokenType.EOF

    def _check(self, *types: TokenType) -> bool:
        return self._cur().type in types

    def _match(self, *types: TokenType) -> Optional[Token]:
        if self._cur().type in types:
            t = self._cur()
            self.pos += 1
            return t
        return None

    def _expect(self, tt: TokenType) -> Token:
        t = self._cur()
        if t.type != tt:
            raise ParseError(
                f"Expected {tt.name}, got {t.type.name} ('{t.value}') at pos {t.pos}",
                t.pos
            )
        self.pos += 1
        return t

    def _check_ident(self, *names: str) -> bool:
        """Check if current token is an identifier with one of the given names (case-insensitive)."""
        t = self._cur()
        if t.type == TokenType.IDENTIFIER:
            return t.value.lower() in {n.lower() for n in names}
        if t.type == TokenType.MAX_KW:
            return 'max' in {n.lower() for n in names}
        return False

    # â”€â”€ Top-level query â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def parse(self) -> Query:
        # Handle SHOW EVENT TYPES
        if self._check_ident('show'):
            return self._parse_show_event_types()
        # Handle WITH...AS CTEs by inlining
        if self._check(TokenType.WITH):
            return self._parse_with_cte()
        # Handle FROM-first syntax: FROM EventType SELECT ...
        if self._check(TokenType.FROM):
            return self._parse_from_first()
        q = self._parse_query()
        if not self._at_end():
            raise ParseError(f"Unexpected token: {self._cur()}", self._cur().pos)
        return q

    def _parse_show_event_types(self) -> Query:
        """Parse SHOW EVENT TYPES [SINCE ...] â€” metadata query."""
        self.pos += 1  # skip 'show'
        # Consume 'event' and 'types' identifiers
        if self._check_ident('event'):
            self.pos += 1
        if self._check_ident('types'):
            self.pos += 1
        since = None
        if self._check(TokenType.SINCE):
            self.pos += 1
            since = self._consume_time_expr()
        # Return a synthetic query that the emitter can recognize
        return Query(
            select_items=[SelectItem(expression=FunctionCall('SHOW_EVENT_TYPES', []))],
            from_clause='__SHOW_EVENT_TYPES__',
            since_raw=since,
        )

    def _peek_with_timezone(self) -> bool:
        """Check if current WITH is followed by TIMEZONE (to distinguish from WITH...AS)."""
        if not self._check(TokenType.WITH):
            return False
        nxt = self._peek(1)
        return nxt.type == TokenType.IDENTIFIER and nxt.value.lower() == 'timezone'

    def _try_parse_join(self) -> Optional[JoinClause]:
        """Try to parse [INNER|LEFT] JOIN (subquery) ON [leftKey =] rightKey after FROM clause."""
        join_type = 'INNER'
        if self._check_ident('inner'):
            join_type = 'INNER'
            self.pos += 1
        elif self._check_ident('left'):
            join_type = 'LEFT'
            self.pos += 1

        if not self._check_ident('join'):
            # If we consumed inner/left but no join follows, back up
            if join_type != 'INNER' or (join_type == 'INNER' and self.pos > 0):
                # Only back up if we actually consumed a token
                pass
            return None

        self.pos += 1  # consume 'join'
        self._expect(TokenType.LPAREN)
        # Parse the subquery (can be FROM-first or SELECT-first)
        if self._check(TokenType.FROM):
            sub = self._parse_from_first()
        else:
            sub = self._parse_query()
        self._expect(TokenType.RPAREN)

        # Parse ON clause
        on_left = None
        on_right = None
        if self._check_ident('on'):
            self.pos += 1
            # Could be: ON key  or  ON leftKey = rightKey
            key1_tok = self._cur()
            if key1_tok.type in (TokenType.IDENTIFIER, TokenType.MAX_KW):
                key1 = key1_tok.value
                self.pos += 1
                if self._match(TokenType.EQ):
                    # ON leftKey = rightKey
                    key2_tok = self._cur()
                    if key2_tok.type in (TokenType.IDENTIFIER, TokenType.MAX_KW):
                        key2 = key2_tok.value
                        self.pos += 1
                        on_left = key1
                        on_right = key2
                    else:
                        on_left = key1
                        on_right = key1
                else:
                    # ON key (same on both sides)
                    on_left = key1
                    on_right = key1

        return JoinClause(join_type=join_type, subquery=sub,
                          on_left=on_left, on_right=on_right)

    def _parse_from_first(self) -> Query:
        """Parse NR FROM-first syntax: FROM EventType [JOIN ...] [WITH ...] SELECT ... WHERE ... etc.
        Rewrites to standard SELECT...FROM internally.
        Also handles: FROM EventType WITH aparse(field, 'pat') AS (alias) SELECT ..."""
        self._expect(TokenType.FROM)
        from_tok = self._cur()
        if from_tok.type in (TokenType.IDENTIFIER, TokenType.MAX_KW):
            from_type = from_tok.value
            self.pos += 1
        else:
            raise ParseError(f"Expected event type after FROM, got {from_tok}", from_tok.pos)

        # Handle JOIN: FROM Event [INNER|LEFT] JOIN (subquery) ON key
        join_clause = self._try_parse_join()

        # Handle inline WITH (computed columns): FROM Span WITH aparse(...) AS (alias) SELECT ...
        # But NOT WITH TIMEZONE â€” that's a separate clause at end
        if self._check(TokenType.WITH) and not self._peek_with_timezone():
            self.pos += 1  # skip WITH
            # Consume everything until we hit SELECT
            depth = 0
            while not self._at_end():
                if self._check(TokenType.LPAREN):
                    depth += 1
                elif self._check(TokenType.RPAREN):
                    depth -= 1
                elif self._check(TokenType.SELECT) and depth == 0:
                    break
                self.pos += 1
        
        self._expect(TokenType.SELECT)
        select_items = self._parse_select_list()
        
        where = None; facet = None; timeseries = None
        since = None; until = None; limit = None
        order_by = None; compare_with = None; extrapolate = False
        facet_order_by = None; with_timezone = None; predict = False

        while not self._at_end():
            if self._check(TokenType.WHERE):
                self.pos += 1
                where = self._parse_condition()
            elif self._check(TokenType.FACET):
                self.pos += 1
                facet = self._parse_facet_list()
                fob, fob_order = self._try_parse_facet_order_by()
                if fob:
                    facet_order_by = fob
                    order_by = fob_order
            elif self._check(TokenType.TIMESERIES):
                self.pos += 1
                timeseries = self._parse_timeseries_clause()
            elif self._check_ident('predict'):
                self.pos += 1
                predict = True
            elif self._check(TokenType.SINCE):
                self.pos += 1
                since = self._consume_time_expr()
            elif self._check(TokenType.UNTIL):
                self.pos += 1
                until = self._consume_time_expr()
            elif self._check(TokenType.LIMIT):
                self.pos += 1
                if self._check(TokenType.MAX_KW):
                    self.pos += 1
                    limit = LimitClause(value='MAX')
                else:
                    limit = LimitClause(value=int(self._expect(TokenType.NUMBER).value))
            elif self._check(TokenType.ORDER):
                self.pos += 1
                self._expect(TokenType.BY)
                expr = self._parse_expression()
                direction = 'ASC'
                if self._match(TokenType.ASC): direction = 'ASC'
                elif self._match(TokenType.DESC): direction = 'DESC'
                order_by = OrderByClause(expression=expr, direction=direction)
            elif self._check(TokenType.COMPARE):
                self.pos += 1
                self._expect(TokenType.WITH)
                compare_with = self._consume_time_expr()
            elif self._check(TokenType.EXTRAPOLATE):
                self.pos += 1
                extrapolate = True
            elif self._check(TokenType.WITH) and self._peek_with_timezone():
                self.pos += 1  # skip WITH
                self.pos += 1  # skip 'timezone' identifier
                with_timezone = self._expect(TokenType.STRING).value
            else:
                break

        return Query(
            select_items=select_items, from_clause=from_type,
            where_clause=where, facet_items=facet, timeseries=timeseries,
            since_raw=since, until_raw=until, limit=limit,
            order_by=order_by, compare_with_raw=compare_with,
            extrapolate=extrapolate, join_clause=join_clause,
            facet_order_by=facet_order_by, with_timezone=with_timezone,
            predict=predict,
        )

    def _parse_with_cte(self) -> Query:
        """Parse: WITH name AS (subquery) SELECT ... FROM name ...
        Strategy: inline the CTE â€” replace name references in FROM with the subquery's FROM."""
        self._expect(TokenType.WITH)
        cte_name_tok = self._cur()
        if cte_name_tok.type not in (TokenType.IDENTIFIER, TokenType.MAX_KW):
            raise ParseError(f"Expected CTE name, got {cte_name_tok}", cte_name_tok.pos)
        cte_name = cte_name_tok.value
        self.pos += 1
        self._expect(TokenType.AS)
        self._expect(TokenType.LPAREN)
        # Parse inner query
        inner = self._parse_query()
        self._expect(TokenType.RPAREN)
        # Parse outer query
        outer = self._parse_query()
        # If outer's FROM matches CTE name, replace with inner's FROM and merge WHERE
        if outer.from_clause.lower() == cte_name.lower():
            outer.from_clause = inner.from_clause
            # Merge WHERE clauses (inner AND outer)
            if inner.where_clause and outer.where_clause:
                outer.where_clause = LogicalCond('AND', inner.where_clause, outer.where_clause)
            elif inner.where_clause:
                outer.where_clause = inner.where_clause
        return outer

    def _parse_query(self) -> Query:
        self._expect(TokenType.SELECT)
        select_items = self._parse_select_list()
        self._expect(TokenType.FROM)
        # FROM clause: could be an identifier or a keyword used as event type
        from_tok = self._cur()
        if from_tok.type in (TokenType.IDENTIFIER, TokenType.MAX_KW):
            from_type = from_tok.value
            self.pos += 1
        else:
            raise ParseError(f"Expected event type after FROM, got {from_tok}", from_tok.pos)

        # Handle JOIN: SELECT ... FROM Event [INNER|LEFT] JOIN (subquery) ON key
        join_clause = self._try_parse_join()

        # Handle inline WITH (computed columns): SELECT ... FROM Metric WITH aparse(...) AS (alias) WHERE ...
        # But NOT WITH TIMEZONE â€” that's a separate clause at end
        if self._check(TokenType.WITH) and not self._peek_with_timezone():
            self.pos += 1  # skip WITH
            depth = 0
            while not self._at_end():
                if self._check(TokenType.LPAREN):
                    depth += 1
                elif self._check(TokenType.RPAREN):
                    depth -= 1
                    if depth < 0:
                        depth = 0
                # Stop at clause keywords when not inside parens
                elif depth == 0 and self._check(TokenType.WHERE, TokenType.FACET,
                        TokenType.TIMESERIES, TokenType.SINCE, TokenType.UNTIL,
                        TokenType.LIMIT, TokenType.ORDER, TokenType.COMPARE,
                        TokenType.EXTRAPOLATE):
                    break
                self.pos += 1

        where = None; facet = None; timeseries = None
        since = None; until = None; limit = None
        order_by = None; compare_with = None; extrapolate = False
        facet_order_by = None; with_timezone = None; predict = False

        while not self._at_end():
            if self._check(TokenType.WHERE):
                self.pos += 1
                where = self._parse_condition()
            elif self._check(TokenType.FACET):
                self.pos += 1
                facet = self._parse_facet_list()
                fob, fob_order = self._try_parse_facet_order_by()
                if fob:
                    facet_order_by = fob
                    order_by = fob_order
            elif self._check(TokenType.TIMESERIES):
                self.pos += 1
                timeseries = self._parse_timeseries_clause()
            elif self._check_ident('predict'):
                self.pos += 1
                predict = True
            elif self._check(TokenType.SINCE):
                self.pos += 1
                since = self._consume_time_expr()
            elif self._check(TokenType.UNTIL):
                self.pos += 1
                until = self._consume_time_expr()
            elif self._check(TokenType.LIMIT):
                self.pos += 1
                if self._check(TokenType.MAX_KW):
                    self.pos += 1
                    limit = LimitClause(value='MAX')
                else:
                    limit = LimitClause(value=int(self._expect(TokenType.NUMBER).value))
            elif self._check(TokenType.ORDER):
                self.pos += 1
                self._expect(TokenType.BY)
                expr = self._parse_expression()
                direction = 'ASC'
                if self._match(TokenType.ASC): direction = 'ASC'
                elif self._match(TokenType.DESC): direction = 'DESC'
                order_by = OrderByClause(expression=expr, direction=direction)
            elif self._check(TokenType.COMPARE):
                self.pos += 1
                self._expect(TokenType.WITH)
                compare_with = self._consume_time_expr()
            elif self._check(TokenType.EXTRAPOLATE):
                self.pos += 1
                extrapolate = True
            elif self._check(TokenType.WITH) and self._peek_with_timezone():
                self.pos += 1  # skip WITH
                self.pos += 1  # skip 'timezone' identifier
                with_timezone = self._expect(TokenType.STRING).value
            else:
                break

        return Query(
            select_items=select_items, from_clause=from_type,
            where_clause=where, facet_items=facet, timeseries=timeseries,
            since_raw=since, until_raw=until, limit=limit,
            order_by=order_by, compare_with_raw=compare_with,
            extrapolate=extrapolate, join_clause=join_clause,
            facet_order_by=facet_order_by, with_timezone=with_timezone,
            predict=predict,
        )

    # â”€â”€ SELECT list â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _parse_select_list(self) -> List[SelectItem]:
        items = [self._parse_select_item()]
        while self._match(TokenType.COMMA):
            items.append(self._parse_select_item())
        return items

    def _parse_select_item(self) -> SelectItem:
        expr = self._parse_expression()
        alias = None
        if self._match(TokenType.AS):
            # Alias can be identifier or string
            tok = self._cur()
            if tok.type == TokenType.IDENTIFIER:
                alias = tok.value; self.pos += 1
            elif tok.type == TokenType.STRING:
                alias = tok.value; self.pos += 1
            elif tok.type == TokenType.MAX_KW:
                alias = tok.value; self.pos += 1
            else:
                raise ParseError(f"Expected alias name after AS, got {tok}", tok.pos)
        return SelectItem(expression=expr, alias=alias)

    # â”€â”€ FACET list â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _parse_facet_list(self) -> List[FacetItem]:
        # Handle FACET CASES(...)
        if self._check(TokenType.CASES):
            self.pos += 1
            # CASES is complex â€” parse as a special function call
            self._expect(TokenType.LPAREN)
            args = self._parse_cases_args()
            self._expect(TokenType.RPAREN)
            return [FacetItem(expression=FunctionCall('cases', args))]

        items = [self._parse_facet_item()]
        while self._match(TokenType.COMMA):
            items.append(self._parse_facet_item())
        return items

    def _parse_facet_item(self) -> FacetItem:
        # Handle CASES(...) appearing as a facet item (not just first position)
        if self._check(TokenType.CASES):
            self.pos += 1
            self._expect(TokenType.LPAREN)
            args = self._parse_cases_args()
            self._expect(TokenType.RPAREN)
            return FacetItem(expression=FunctionCall('cases', args))
        expr = self._parse_expression()
        alias = None
        if self._match(TokenType.AS):
            tok = self._cur()
            if tok.type in (TokenType.IDENTIFIER, TokenType.STRING, TokenType.MAX_KW):
                alias = tok.value; self.pos += 1
            else:
                raise ParseError(f"Expected alias after AS in FACET, got {tok}", tok.pos)
        return FacetItem(expression=expr, alias=alias)

    def _parse_cases_args(self) -> List[ASTNode]:
        """Parse CASES(WHERE cond AS 'label', WHERE cond2 AS 'label2', ...)
        Also handles:
        - WHERE cond, 'label' (comma-separated variant)
        - matchesPhrase(field, val) as 'label' (bare function without WHERE)"""
        args = []
        while not self._check(TokenType.RPAREN) and not self._at_end():
            if self._match(TokenType.WHERE):
                cond = self._parse_condition()
                args.append(cond)
                # Label can follow with AS or comma
                if self._match(TokenType.AS):
                    args.append(self._parse_expression())
                elif self._check(TokenType.COMMA):
                    self._match(TokenType.COMMA)
                    if not self._check(TokenType.WHERE) and not self._check(TokenType.RPAREN):
                        args.append(self._parse_expression())
                        self._match(TokenType.COMMA)
                    continue
            else:
                # Bare expression (e.g., matchesPhrase(targetUrl, "/search") as 'label')
                args.append(self._parse_expression())
                # Check for AS alias after bare expression
                if self._match(TokenType.AS):
                    args.append(self._parse_expression())
            self._match(TokenType.COMMA)  # optional trailing comma
        return args

    def _try_parse_facet_order_by(self) -> Tuple[Optional[ASTNode], Optional[OrderByClause]]:
        """Try to parse FACET ... ORDER BY expr [ASC|DESC] immediately after facet items.
        Returns (facet_order_by_expr, order_by_clause) or (None, None)."""
        if not self._check(TokenType.ORDER):
            return None, None
        saved = self.pos
        self.pos += 1
        if not self._check(TokenType.BY):
            self.pos = saved
            return None, None
        self.pos += 1
        expr = self._parse_expression()
        direction = 'DESC'  # FACET ORDER BY defaults to DESC
        if self._match(TokenType.ASC): direction = 'ASC'
        elif self._match(TokenType.DESC): direction = 'DESC'
        return expr, OrderByClause(expression=expr, direction=direction)

    # â”€â”€ TIMESERIES â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _parse_timeseries_clause(self) -> TimeseriesClause:
        if self._check(TokenType.AUTO):
            self.pos += 1
            slide = self._parse_slide_by()
            return TimeseriesClause(interval='AUTO', slide_by=slide)
        if self._check(TokenType.MAX_KW):
            self.pos += 1
            slide = self._parse_slide_by()
            return TimeseriesClause(interval='MAX', slide_by=slide)
        if self._check(TokenType.NUMBER):
            val = self._cur().value
            self.pos += 1
            unit = self._consume_time_unit()
            if unit:
                slide = self._parse_slide_by()
                return TimeseriesClause(interval=f"{val} {unit}", slide_by=slide)
            else:
                slide = self._parse_slide_by()
                return TimeseriesClause(interval=str(val), slide_by=slide)
        return TimeseriesClause()

    def _parse_slide_by(self) -> Optional[str]:
        """Parse optional SLIDE BY clause after TIMESERIES interval."""
        if not self._check_ident('slide'):
            return None
        self.pos += 1  # consume 'slide'
        self._expect(TokenType.BY)
        if self._check(TokenType.AUTO):
            self.pos += 1
            return 'AUTO'
        if self._check(TokenType.MAX_KW):
            self.pos += 1
            return 'MAX'
        if self._check(TokenType.NUMBER):
            val = self._cur().value
            self.pos += 1
            unit = self._consume_time_unit()
            if unit:
                return f"{val} {unit}"
            return str(val)
        return None

    def _consume_time_unit(self) -> Optional[str]:
        """If current token is a time unit identifier, consume and return it."""
        t = self._cur()
        if t.type == TokenType.IDENTIFIER and t.value.lower() in TIME_UNITS:
            self.pos += 1
            return t.value.lower()
        if t.type == TokenType.MAX_KW:
            # 'max' is not a time unit
            return None
        return None

    def _consume_time_expr(self) -> str:
        """Consume a time expression as raw text (SINCE/UNTIL/COMPARE WITH).
        Examples: '1 hour ago', '2024-01-01', 'yesterday', MAX"""
        parts = []
        if self._check(TokenType.MAX_KW):
            self.pos += 1
            return 'MAX'
        # Consume tokens until we hit a clause keyword
        clause_kws = {TokenType.WHERE, TokenType.FACET, TokenType.TIMESERIES,
                      TokenType.SINCE, TokenType.UNTIL, TokenType.LIMIT,
                      TokenType.ORDER, TokenType.COMPARE, TokenType.EXTRAPOLATE, TokenType.EOF}
        while not self._at_end() and self._cur().type not in clause_kws:
            t = self._cur()
            if t.type == TokenType.STRING:
                parts.append(f"'{t.value}'")
            elif t.type == TokenType.NUMBER:
                parts.append(str(t.value))
            elif t.type == TokenType.AGO:
                parts.append('ago')
            elif t.type == TokenType.IDENTIFIER:
                parts.append(t.value)
            elif t.type == TokenType.MAX_KW:
                parts.append(t.value)
            elif t.type == TokenType.MINUS:
                parts.append('-')
            else:
                break
            self.pos += 1
        return ' '.join(parts)

    # â”€â”€ Conditions (WHERE clause) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _parse_condition(self) -> Condition:
        return self._parse_or()

    def _parse_or(self) -> Condition:
        left = self._parse_and()
        while self._match(TokenType.OR):
            right = self._parse_and()
            left = LogicalCond('OR', left, right)
        return left

    def _parse_and(self) -> Condition:
        left = self._parse_not()
        while self._match(TokenType.AND):
            right = self._parse_not()
            left = LogicalCond('AND', left, right)
        return left

    def _parse_not(self) -> Condition:
        if self._match(TokenType.NOT):
            return NotCond(self._parse_not())
        return self._parse_primary_condition()

    def _parse_primary_condition(self) -> Condition:
        # Parenthesized â€” could be a grouped condition OR an arithmetic expression
        if self._check(TokenType.LPAREN):
            # Try as grouped condition first (backtrack if fails)
            saved_pos = self.pos
            try:
                self.pos += 1  # skip (
                cond = self._parse_condition()
                self._expect(TokenType.RPAREN)
                return cond
            except ParseError:
                # Not a grouped condition â€” backtrack and parse as expression comparison
                self.pos = saved_pos

        # Bare boolean function conditions: isNotNull(field), isNull(field)
        # NR allows these as standalone WHERE conditions without a comparison operator
        if self._check(TokenType.IDENTIFIER):
            func_name = self._cur().value.lower()
            if func_name in ('isnotnull', 'isnull') and self._peek(1).type == TokenType.LPAREN:
                self.pos += 1  # skip function name
                self.pos += 1  # skip (
                inner_expr = self._parse_expression()
                self._expect(TokenType.RPAREN)
                return IsNullCond(expr=inner_expr, negated=(func_name == 'isnotnull'))

        # Parse left-hand expression (includes parenthesized arithmetic like (a/b)*100)
        left = self._parse_expression()

        # IS [NOT] NULL / IS [NOT] TRUE / IS [NOT] FALSE
        if self._check(TokenType.IS):
            self.pos += 1
            negated = bool(self._match(TokenType.NOT))
            if self._check(TokenType.NULL):
                self.pos += 1
                return IsNullCond(expr=left, negated=negated)
            elif self._check(TokenType.TRUE):
                self.pos += 1
                # IS TRUE â†’ field == true,  IS NOT TRUE â†’ field != true
                op = '!=' if negated else '=='
                return ComparisonCond(left=left, op=op, right=LiteralExpr(True))
            elif self._check(TokenType.FALSE):
                self.pos += 1
                # IS FALSE â†’ field == false,  IS NOT FALSE â†’ field != false
                op = '!=' if negated else '=='
                return ComparisonCond(left=left, op=op, right=LiteralExpr(False))
            else:
                self._expect(TokenType.NULL)  # Will raise proper error

        # [NOT] IN (...)
        negated = False
        if self._check(TokenType.NOT):
            # Peek ahead for IN or LIKE
            if self._peek(1).type in (TokenType.IN, TokenType.LIKE, TokenType.RLIKE):
                self.pos += 1
                negated = True

        if self._match(TokenType.IN):
            return self._parse_in_clause(left, negated)

        # [NOT] LIKE
        if self._match(TokenType.LIKE):
            pattern = self._expect(TokenType.STRING).value
            return LikeCond(expr=left, pattern=pattern, negated=negated)

        # [NOT] RLIKE
        if self._match(TokenType.RLIKE):
            # Handle r'...' raw string prefix (NR syntax)
            if self._check(TokenType.IDENTIFIER) and self._cur().value.lower() == 'r':
                self.pos += 1  # skip 'r' prefix
            pattern = self._expect(TokenType.STRING).value
            return RLikeCond(expr=left, pattern=pattern, negated=negated)

        # Comparison: =, !=, <, >, <=, >=
        op_map = {
            TokenType.EQ: '=', TokenType.NEQ: '!=',
            TokenType.LT: '<', TokenType.GT: '>',
            TokenType.LTE: '<=', TokenType.GTE: '>=',
        }
        for tt, op_str in op_map.items():
            if self._match(tt):
                right = self._parse_expression()
                return ComparisonCond(op=op_str, left=left, right=right)

        raise ParseError(
            f"Expected comparison operator after expression, got {self._cur()}",
            self._cur().pos
        )

    def _parse_in_clause(self, left: ASTNode, negated: bool) -> Condition:
        self._expect(TokenType.LPAREN)
        # Check for subquery: IN (FROM Type SELECT ...) or IN (SELECT expr FROM Type WHERE ...)
        if self._check(TokenType.FROM) or self._check(TokenType.SELECT):
            subquery = self._parse_subquery()
            self._expect(TokenType.RPAREN)
            return InSubqueryCond(expr=left, subquery=subquery, negated=negated)
        # Value list
        values = [self._parse_expression()]
        while self._match(TokenType.COMMA):
            values.append(self._parse_expression())
        self._expect(TokenType.RPAREN)
        return InListCond(expr=left, values=values, negated=negated)

    def _parse_subquery(self) -> Query:
        """Parse subquery in either NR syntax:
           FROM Type SELECT expr [WHERE condition] [LIMIT MAX]
           SELECT expr FROM Type [WHERE condition] [LIMIT MAX]
        """
        if self._check(TokenType.SELECT):
            # SELECT-first: SELECT expr FROM Type [WHERE ...] [LIMIT MAX]
            self._expect(TokenType.SELECT)
            sel = [self._parse_select_item()]
            self._expect(TokenType.FROM)
            from_tok = self._cur()
            if from_tok.type in (TokenType.IDENTIFIER, TokenType.MAX_KW):
                from_type = from_tok.value; self.pos += 1
            else:
                raise ParseError(f"Expected event type in subquery, got {from_tok}", from_tok.pos)
        else:
            # FROM-first: FROM Type SELECT expr [WHERE ...]
            self._expect(TokenType.FROM)
            from_tok = self._cur()
            if from_tok.type in (TokenType.IDENTIFIER, TokenType.MAX_KW):
                from_type = from_tok.value; self.pos += 1
            else:
                raise ParseError(f"Expected event type in subquery, got {from_tok}", from_tok.pos)
            self._expect(TokenType.SELECT)
            sel = [self._parse_select_item()]
        
        where = None
        if self._check(TokenType.WHERE):
            self.pos += 1
            where = self._parse_condition()
        
        # Handle LIMIT [MAX|number] inside subquery â€” consume but ignore
        if self._check(TokenType.LIMIT):
            self.pos += 1  # skip LIMIT
            if self._check(TokenType.MAX_KW) or self._check(TokenType.NUMBER):
                self.pos += 1  # skip MAX or number
        
        return Query(select_items=sel, from_clause=from_type, where_clause=where)

    # â”€â”€ Expressions (arithmetic) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _parse_expression(self) -> ASTNode:
        return self._parse_additive()

    def _parse_additive(self) -> ASTNode:
        left = self._parse_multiplicative()
        while self._check(TokenType.PLUS, TokenType.MINUS):
            op = '+' if self._cur().type == TokenType.PLUS else '-'
            self.pos += 1
            right = self._parse_multiplicative()
            left = BinaryOp(op, left, right)
        return left

    def _parse_multiplicative(self) -> ASTNode:
        left = self._parse_unary()
        while self._check(TokenType.STAR, TokenType.SLASH, TokenType.PERCENT):
            t = self._cur()
            op = {TokenType.STAR: '*', TokenType.SLASH: '/', TokenType.PERCENT: '%'}[t.type]
            self.pos += 1
            right = self._parse_unary()
            left = BinaryOp(op, left, right)
        return left

    def _parse_unary(self) -> ASTNode:
        if self._match(TokenType.MINUS):
            return UnaryMinus(self._parse_unary())
        return self._parse_primary()

    def _parse_primary(self) -> ASTNode:
        t = self._cur()

        # Star (wildcard)
        if t.type == TokenType.STAR:
            self.pos += 1
            return StarExpr()

        # Number literal
        if t.type == TokenType.NUMBER:
            self.pos += 1
            # Check for time interval: NUMBER IDENTIFIER(time_unit)
            if (self._cur().type == TokenType.IDENTIFIER and
                    self._cur().value.lower() in TIME_UNITS):
                unit = self._cur().value.lower()
                self.pos += 1
                return TimeInterval(value=t.value, unit=unit)
            return LiteralExpr(t.value)

        # String literal
        if t.type == TokenType.STRING:
            self.pos += 1
            return LiteralExpr(t.value)

        # Boolean / null
        if t.type == TokenType.TRUE:
            self.pos += 1; return LiteralExpr(True)
        if t.type == TokenType.FALSE:
            self.pos += 1; return LiteralExpr(False)
        if t.type == TokenType.NULL:
            self.pos += 1; return LiteralExpr(None)

        # Parenthesized expression
        if t.type == TokenType.LPAREN:
            self.pos += 1
            expr = self._parse_expression()
            self._expect(TokenType.RPAREN)
            return expr

        # Identifier: function call or field reference
        if t.type in (TokenType.IDENTIFIER, TokenType.MAX_KW):
            name = t.value
            self.pos += 1
            # Function call?
            if self._check(TokenType.LPAREN):
                self.pos += 1  # consume (
                args, where_clause = self._parse_function_args(name)
                self._expect(TokenType.RPAREN)
                return FunctionCall(name=name, args=args, where_clause=where_clause)
            return FieldRef(name)

        raise ParseError(f"Expected expression, got {t}", t.pos)

    def _parse_function_args(self, func_name: str) -> Tuple[List[ASTNode], Optional[Condition]]:
        """Parse function arguments, handling WHERE inside filter()/percentage(),
        if(condition, trueVal, falseVal), funnel(col, WHERE...AS pairs), and OR coalesce pattern."""
        args: List[ASTNode] = []
        where_clause: Optional[Condition] = None

        if self._check(TokenType.RPAREN):
            return args, None

        # NR's if(condition, trueVal, falseVal) â€” first arg is a condition
        if func_name.lower() == 'if':
            cond = self._parse_condition()
            args.append(cond)
            while self._match(TokenType.COMMA):
                args.append(self._parse_expression())
            return args, None

        # NR's funnel(column, WHERE cond AS 'label', WHERE cond AS 'label', ...)
        # Parse like CASES: first arg is column, then WHERE/AS pairs
        if func_name.lower() == 'funnel':
            args.append(self._parse_expression())  # column (e.g. session)
            self._match(TokenType.COMMA)  # consume comma after column
            while not self._check(TokenType.RPAREN) and not self._at_end():
                if self._check(TokenType.WHERE):
                    self.pos += 1  # skip WHERE
                    cond = self._parse_condition()
                    args.append(cond)
                    if self._match(TokenType.AS):
                        args.append(self._parse_expression())  # label string
                else:
                    args.append(self._parse_expression())
                self._match(TokenType.COMMA)  # optional separator
            return args, None

        args.append(self._parse_expression())

        # Handle NR OR-coalesce inside function args: average(fieldA OR fieldB)
        # This means "use fieldA, or if null, fieldB". We take the first arg.
        if self._check(TokenType.OR):
            self.pos += 1  # skip OR
            # Consume the rest until RPAREN, discarding the fallback expression
            depth = 1
            while not self._at_end() and depth > 0:
                if self._check(TokenType.LPAREN):
                    depth += 1
                elif self._check(TokenType.RPAREN):
                    if depth == 1:
                        break
                    depth -= 1
                self.pos += 1
            return args, None

        while self._match(TokenType.COMMA):
            # Check for WHERE in functions that support it
            if (func_name.lower() in WHERE_FUNCTIONS and self._check(TokenType.WHERE)):
                self.pos += 1
                where_clause = self._parse_condition()
                break
            args.append(self._parse_expression())

        return args, where_clause


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# SECTION 4: DQL EMITTER
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

# NR event type â†’ query classification (determines which DQL shape to use)
# METRIC/K8S_* â†’ timeseries command; everything else â†’ fetch command
QUERY_CLASS_MAP = {
    'transaction': 'spans', 'transactionerror': 'spans', 'span': 'spans',
    'log': 'logs', 'logevent': 'logs',
    # Metric sources â†’ timeseries command
    'metric': 'METRIC', 'systemsample': 'METRIC', 'processsample': 'METRIC',
    'networksample': 'METRIC', 'storagesample': 'METRIC', 'containersample': 'METRIC',
    # K8s â†’ timeseries with K8s metric mapping
    'k8snodesample': 'K8S_NODE_METRIC', 'k8scontainersample': 'K8S_WORKLOAD_METRIC',
    'k8spodsample': 'K8S_POD_METRIC', 'k8sclustersample': 'K8S_CLUSTER_METRIC',
    'k8sdeploymentsample': 'K8S_WORKLOAD_METRIC',
    # Browser/RUM
    'pageview': 'bizevents', 'pageaction': 'bizevents',
    'browserinteraction': 'bizevents', 'ajaxrequest': 'bizevents',
    'javascripterror': 'bizevents',
    # Synthetic
    'syntheticcheck': 'dt.synthetic.http.request', 'syntheticsrequest': 'dt.synthetic.http.request',
    # Events
    'infrastructureevent': 'EVENTS',
    # Lambda / Custom
    'awslambdainvocation': 'spans', 'nrcustomappevent': 'bizevents',
}

# For backward compat â€” the old name still used in emit_lookup
EVENT_TYPE_MAP = QUERY_CLASS_MAP

# NR function â†’ DQL function
FUNC_MAP = {
    'count': 'count', 'sum': 'sum', 'average': 'avg', 'avg': 'avg',
    'max': 'max', 'min': 'min', 'percentile': 'percentile',
    'stddev': 'stddev', 'rate': 'count',  # rate not directly supported; stddev IS native in DQL summarize
    'variance': 'variance',  # DQL native variance() aggregation
    'uniquecount': 'countDistinctExact', 'uniques': 'collectDistinct',
    'latest': 'takeLast', 'earliest': 'takeFirst', 'last': 'takeLast', 'first': 'takeFirst',
    'median': 'percentile',  # â†’ percentile(field, 50)
    # String
    'substring': 'substring', 'indexof': 'indexOf', 'length': 'stringLength',
    'concat': 'concat', 'lower': 'lower', 'upper': 'upper',
    'capture': 'extract', 'aparse': 'parse',
    'replace': 'replaceAll', 'trim': 'trim',
    'startswith': 'startsWith', 'endswith': 'endsWith',
    # Math
    'abs': 'abs', 'ceil': 'ceil', 'floor': 'floor', 'round': 'round',
    'sqrt': 'sqrt', 'pow': 'pow', 'log': 'log', 'log10': 'log10', 'exp': 'exp',
    'ln': 'log',  # ln(x) is natural log = log(x) in DQL
    'cbrt': 'cbrt', 'sign': 'sign',
    # Time
    'dateof': 'formatTimestamp', 'hourof': 'getHour', 'minuteof': 'getMinute',
    'dayofweek': 'getDayOfWeek', 'weekof': 'getWeekOfYear',
    'monthof': 'getMonth', 'yearof': 'getYear',
    # Type
    'numeric': 'toDouble', 'string': 'toString',
    'toDouble': 'toDouble', 'toLong': 'toLong', 'toNumber': 'toNumber',
    'toBoolean': 'toBoolean', 'toTimestamp': 'toTimestamp',
    # If
    'if': 'if',
    # Boolean matching functions (NR WHERE helpers â†’ DQL string functions)
    'matchesphrase': 'contains', 'matchesvalue': 'contains',
    # Phase 2-3 additions
    'buckets': 'bin',
    'aggregationendtime': 'end',
}

# NR filter() â†’ DQL funcIf mapping
FILTER_IF_MAP = {
    'count': 'countIf', 'sum': 'sumIf', 'average': 'avgIf', 'avg': 'avgIf',
    'max': 'maxIf', 'min': 'minIf',
}

# NR field â†’ DT field (common attributes)
FIELD_MAP = {
    'appname': 'service.name', 'appName': 'service.name',
    'transactionname': 'span.name', 'name': 'span.name',
    'duration': 'duration', 'duration.ms': 'duration',
    'databaseduration': 'db.duration', 'externalduration': 'http.duration',
    'host': 'host.name', 'hostname': 'host.name', 'fullhostname': 'host.name',
    'httpresponsecode': 'http.response.status_code',
    'httpResponseCode': 'http.response.status_code',
    'http.statuscode': 'http.response.status_code',
    'http.statusCode': 'http.response.status_code',
    'response.status': 'http.response.status_code',
    'httpresponsestatuscode': 'http.response.status_code',
    'request.uri': 'http.request.path', 'request.url': 'http.request.path',
    'request.method': 'http.request.method',
    'http.method': 'http.request.method', 'httpmethod': 'http.request.method',
    'http.url': 'http.request.path', 'httpurl': 'http.request.path',
    'error.message': 'error.message',
    'entityguid': 'dt.entity.service', 'entityname': 'dt.entity.name',
    'entity.name': 'dt.entity.name',
    'cpupercent': 'host.cpu.usage', 'memoryusedpercent': 'host.memory.usage',
    'diskusedpercent': 'host.disk.usage',
    'message': 'content', 'level': 'loglevel', 'log.level': 'loglevel',
    # K8s
    'k8s.containername': 'k8s.container.name', 'k8s.podname': 'k8s.pod.name',
    'k8s.clustername': 'k8s.cluster.name', 'k8s.namespacename': 'k8s.namespace.name',
    'k8s.nodename': 'k8s.node.name', 'k8s.deploymentname': 'k8s.deployment.name',
    'clustername': 'k8s.cluster.name', 'podname': 'k8s.pod.name',
    'namespace': 'k8s.namespace.name', 'namespacename': 'k8s.namespace.name',
    'containername': 'k8s.container.name', 'nodename': 'k8s.node.name',
    # Browser/RUM
    'pageurl': 'page.url', 'pageUrl': 'page.url',
    'userAgentName': 'browser.name', 'useragentname': 'browser.name',
    'userAgentOS': 'os.name', 'useragentos': 'os.name',
    'city': 'geo.city', 'regionCode': 'geo.region', 'countryCode': 'geo.country',
    'deviceType': 'device.type', 'devicetype': 'device.type',
    # Span/Trace IDs (critical for subquery joins)
    'parentId': 'span.parent_id', 'parentid': 'span.parent_id',
    'parent.id': 'span.parent_id',
    'id': 'span.id',
    'traceId': 'trace_id', 'traceid': 'trace_id',
    'guid': 'span.id',
    'nr.guid': 'span.id',
    # Duration variants
    'Duration.Seconds': 'duration', 'duration.seconds': 'duration',
    'Duration.seconds': 'duration', 'duration.Seconds': 'duration',
    'Duration.Ms': 'duration', 'Duration.ms': 'duration',
    'durationMs': 'duration', 'Duration.Minutes': 'duration',
    # Transaction metadata
    'transactiontype': 'span.kind', 'transactionType': 'span.kind',
    'error': 'error', 'error.class': 'error.type',
    'errortype': 'error.type', 'errorType': 'error.type',
    'errormessage': 'error.message', 'errorMessage': 'error.message',
    'response.status': 'http.response.status_code',
    'response.statuscode': 'http.response.status_code',
    'databasecallcount': 'db.call_count', 'databaseCallCount': 'db.call_count',
    'externalcallcount': 'http.call_count', 'externalCallCount': 'http.call_count',
    'deploymentname': 'k8s.deployment.name', 'deploymentName': 'k8s.deployment.name',
}


def _parse_compare_shift(raw: str) -> Optional[str]:
    """Convert NR COMPARE WITH time expression to DQL shift: duration.
    
    '1 week ago' â†’ '-7d'
    '1 day ago'  â†’ '-1d'
    '7 days ago' â†’ '-7d'
    '24 hours ago' â†’ '-24h'
    '1 month ago' â†’ '-30d'
    """
    m = re.match(r'(\d+)\s+(week|day|hour|minute|month|second)s?\s+ago',
                 raw.strip(), re.IGNORECASE)
    if not m:
        return None
    val = int(m.group(1))
    unit = m.group(2).lower()
    unit_map = {
        'week': ('d', 7), 'day': ('d', 1), 'hour': ('h', 1),
        'minute': ('m', 1), 'month': ('d', 30), 'second': ('s', 1),
    }
    suffix, mult = unit_map.get(unit, ('d', 1))
    return f"-{val * mult}{suffix}"


class DQLEmitter:
    """Walk the NRQL AST and emit valid DQL.
    
    Handles ALL query types:
    - Span/Transaction queries â†’ fetch spans | makeTimeseries/summarize
    - Log queries â†’ fetch logs | ...
    - Metric queries (SystemSample, Metric) â†’ timeseries func(dt.metric)
    - K8s queries â†’ timeseries func(dt.kubernetes.metric)  
    - Events queries â†’ fetch events | fields
    - Browser/RUM â†’ fetch bizevents | ...
    """

    def __init__(self, field_map: Dict[str, str] = None, metric_map: Dict[str, str] = None,
                 metric_transforms: Dict[str, Dict] = None, metric_resolver=None):
        self.field_map = {**FIELD_MAP, **(field_map or {})}
        self.metric_map = metric_map or {}
        self.metric_transforms = metric_transforms or {}
        self.metric_resolver = metric_resolver  # callable(field_key, raw_field) â†’ (dt_metric, warning)
        self.warnings: List[str] = []
        self._agg_counter = 0  # for auto-naming aggregations

    def emit(self, query: Query) -> str:
        """Emit a complete DQL query from an NRQL AST."""
        self.warnings = []
        self._agg_counter = 0
        self._histogram_bin_expr = None  # Set by histogram() handler for by:{bin()} injection
        self._funnel_steps = []  # Set by funnel() handler for conversion rate fieldsAdd
        self._query_class = 'spans'  # Default; updated below after classify

        # Handle SHOW EVENT TYPES
        if query.from_clause == '__SHOW_EVENT_TYPES__':
            self.warnings.append("SHOW EVENT TYPES â†’ use DT Schema browser or: fetch dt.entity.type")
            return ("// SHOW EVENT TYPES has no direct DQL equivalent\n"
                    "// In Dynatrace, use the Schema browser in Notebooks/Dashboards\n"
                    "// or query: fetch dt.entity.type | fields entity.type | dedup entity.type")

        from_type = query.from_clause.lower().replace('_', '').replace('-', '')
        query_class = self._classify_query(from_type)
        self._query_class = query_class  # Store for context-aware field mapping

        if query_class == 'METRIC':
            dql = self._emit_metric_query(query, from_type)
        elif query_class.startswith('K8S_'):
            dql = self._emit_metric_query(query, from_type)
        elif query_class == 'EVENTS':
            dql = self._emit_events_query(query)
        else:
            dql = self._emit_fetch_query(query, query_class)

        # Validate emitted DQL for nested aggregation errors
        dql = self._validate_no_nested_aggregations(dql)

        # COMPARE WITH handling
        # DQL shift: parameter ONLY works on the `timeseries` command (metric queries).
        # It does NOT work on `makeTimeseries` (span/event queries).
        # For makeTimeseries, time comparison requires append[] with shifted subquery,
        # which is too complex to auto-generate. Add comment for manual overlay.
        if query.compare_with_raw:
            shift_dur = _parse_compare_shift(query.compare_with_raw)
            # Check for timeseries command (metric queries use standalone 'timeseries',
            # span queries use '| makeTimeseries')
            has_ts_cmd = ('| timeseries ' in dql or 
                          any(l.strip().startswith('timeseries ') for l in dql.split('\n')))
            has_make_ts = 'makeTimeseries' in dql
            if shift_dur and has_ts_cmd and not has_make_ts:
                # Metric queries: timeseries command supports shift: natively
                lines = dql.split('\n')
                for i, line in enumerate(lines):
                    if '| timeseries ' in line or line.strip().startswith('timeseries '):
                        lines[i] = line.rstrip() + f", shift:{shift_dur}"
                        break
                dql = '\n'.join(lines)
                self.warnings.append(
                    f"COMPARE WITH {query.compare_with_raw} â†’ DQL shift:{shift_dur} "
                    f"(overlays current + shifted series)"
                )
            else:
                # Span/event queries: makeTimeseries does NOT support shift:
                # Use DT dashboard time-shift overlay instead
                self.warnings.append(
                    f"COMPARE WITH {query.compare_with_raw}: use DT dashboard time-shift "
                    f"overlay (makeTimeseries does not support shift: parameter)"
                )

        # EXTRAPOLATE â€” NR statistical extrapolation for sampled data
        if query.extrapolate:
            dql += "\n// EXTRAPOLATE â†’ DT does not sample span data; full fidelity by default"
            self.warnings.append(
                "EXTRAPOLATE removed: DT Grail stores full-fidelity data, no sampling"
            )

        # JOIN clause â€” emit as DQL lookup
        if query.join_clause:
            dql = self._emit_join_clause(query, dql)

        # FACET ... ORDER BY â€” emit as comment (DQL doesn't have facet selection override)
        if query.facet_order_by:
            order_expr = self._emit_expr(query.facet_order_by)
            dql += f"\n// FACET ORDER BY {order_expr} â†’ DQL sorts by first summarize column; reorder SELECT to match"
            self.warnings.append(
                f"FACET ORDER BY {order_expr}: DQL uses first aggregation for facet selection. "
                f"Reorder SELECT columns to achieve equivalent."
            )

        # SLIDE BY â†’ DQL rolling() window function
        # NR: TIMESERIES 1 hour SLIDE BY 5 minutes = 1h window sliding every 5m
        # DQL: makeTimeseries ..., interval: 5m | fieldsAdd rolling(avg, 12)  [12 = 60/5]
        if query.timeseries and query.timeseries.slide_by:
            sb = query.timeseries.slide_by
            window_interval = query.timeseries.interval
            
            # Parse both intervals to seconds for ratio calculation
            window_secs = self._interval_to_seconds(window_interval)
            slide_secs = self._interval_to_seconds(sb)
            
            if window_secs and slide_secs and slide_secs > 0:
                rolling_points = max(2, window_secs // slide_secs)
                slide_dql = self._format_interval(
                    type('TS', (), {'interval': sb})()
                )
                
                if slide_dql:
                    # Replace interval: in existing DQL with slide interval
                    # (the window interval was already emitted, we need the slide interval instead)
                    if f'interval: ' in dql:
                        dql = re.sub(r'interval: \S+', f'interval: {slide_dql}', dql)
                    elif 'makeTimeseries' in dql:
                        # No interval was set (AUTO/MAX) â€” add the slide interval
                        dql = dql.replace('makeTimeseries ', f'makeTimeseries ', 1)
                        # Find the makeTimeseries line and add interval
                        lines = dql.split('\n')
                        for i, line in enumerate(lines):
                            if 'makeTimeseries' in line:
                                lines[i] = line.rstrip() + f", interval: {slide_dql}"
                                break
                        dql = '\n'.join(lines)
                    
                    # Extract aggregation names from makeTimeseries/timeseries line
                    # and add rolling() for each
                    agg_names = self._extract_agg_names_from_dql(dql)
                    if agg_names:
                        rolling_lines = []
                        for agg_name, agg_func in agg_names:
                            # Map NR aggregation to rolling function
                            rolling_func = self._agg_to_rolling_func(agg_func)
                            new_name = f"sliding_{agg_name}" if agg_name else f"sliding_{rolling_func}"
                            rolling_lines.append(
                                f"| fieldsAdd {new_name} = rolling({rolling_func}, {rolling_points})"
                            )
                        dql += '\n' + '\n'.join(rolling_lines)
                
                self.warnings.append(
                    f"SLIDE BY {sb} â†’ rolling() with {rolling_points}-point window "
                    f"(interval: {slide_dql or sb}). "
                    f"Original columns contain raw per-interval values; "
                    f"sliding_* columns contain the smoothed rolling window."
                )
            elif window_secs and sb.upper() in ('AUTO', 'MAX'):
                # SLIDE BY AUTO/MAX: NR picks a slide interval automatically.
                # DQL equivalent: keep the window interval and use rolling(3) as a
                # sensible default (3-point moving average/sum smoothing).
                agg_names = self._extract_agg_names_from_dql(dql)
                if agg_names:
                    rolling_lines = []
                    for agg_name, agg_func in agg_names:
                        rolling_func = self._agg_to_rolling_func(agg_func)
                        new_name = f"sliding_{agg_name}" if agg_name else f"sliding_{rolling_func}"
                        rolling_lines.append(
                            f"| fieldsAdd {new_name} = rolling({rolling_func}, 3)"
                        )
                    dql += '\n' + '\n'.join(rolling_lines)
                self.warnings.append(
                    f"SLIDE BY {sb} â†’ rolling() with 3-point window (auto). "
                    f"Adjust the rolling point count to tune smoothing."
                )
            else:
                # Can't calculate ratio â€” emit guidance
                dql += (f"\n// SLIDE BY {sb} â†’ adjust makeTimeseries interval and apply rolling()")
                self.warnings.append(
                    f"SLIDE BY {sb}: couldn't auto-convert. "
                    f"Set interval to slide value and use rolling() window function."
                )

        # PREDICT â€” DT uses Davis AI for predictions
        if query.predict:
            dql += "\n// PREDICT â†’ use Dynatrace Davis AI predictions or forecasting API"
            self.warnings.append("PREDICT: use Davis AI anomaly detection for forecasting in DT")

        # WITH TIMEZONE â€” DT uses UTC internally
        if query.with_timezone:
            dql += f"\n// WITH TIMEZONE '{query.with_timezone}' â†’ DT stores UTC; apply TZ in dashboard settings"
            self.warnings.append(
                f"WITH TIMEZONE '{query.with_timezone}': DT uses UTC. "
                f"Set timezone in dashboard/notebook display settings."
            )

        return dql

    def _emit_join_clause(self, query: Query, base_dql: str) -> str:
        """Emit JOIN as DQL lookup command."""
        jc = query.join_clause
        sub = jc.subquery

        # Determine subquery fetch type
        sub_from = sub.from_clause.lower().replace('_', '').replace('-', '')
        sub_class = self._classify_query(sub_from)
        if sub_class in ('METRIC',) or sub_class.startswith('K8S_'):
            sub_fetch = f"timeseries /* {sub.from_clause} */"
        else:
            sub_fetch = f"fetch {sub_class}"

        # Build subquery filter
        sub_filter = ''
        if sub.where_clause:
            sub_filter = f"\n| filter {self._emit_condition(sub.where_clause)}"

        # Build subquery fields from select items
        sub_fields = []
        for item in sub.select_items:
            expr_str = self._emit_agg_expr(item.expression)
            if item.alias:
                sub_fields.append(f"{self._sanitize_alias(item.alias)}={expr_str}")
            else:
                sub_fields.append(expr_str)

        # Build lookup command
        on_left = self._map_field(jc.on_left) if jc.on_left else 'id'
        on_right = self._map_field(jc.on_right) if jc.on_right else on_left

        join_type_str = "// LEFT " if jc.join_type == 'LEFT' else "// "
        sub_fields_str = ', '.join(sub_fields) if sub_fields else '*'

        lookup_line = (
            f'| lookup [{sub_fetch}{sub_filter} | fields {on_right}, {sub_fields_str}], '
            f'sourceField:{on_left}, lookupField:{on_right}, prefix:"sub."'
        )

        self.warnings.append(
            f"{jc.join_type} JOIN on {jc.on_left}={jc.on_right}: converted to DQL lookup command"
        )

        return f"{join_type_str}JOIN converted to lookup\n{base_dql}\n{lookup_line}"

    def _classify_query(self, from_type: str) -> str:
        """Determine which DQL shape to use."""
        mapped = QUERY_CLASS_MAP.get(from_type, '')
        if mapped:
            return mapped
        # Heuristics
        if 'metric' in from_type or 'sample' in from_type:
            return 'METRIC'
        if 'log' in from_type:
            return 'logs'
        if 'event' in from_type:
            return 'EVENTS'
        if 'span' in from_type or 'transaction' in from_type:
            return 'spans'
        return 'spans'

    # â”€â”€ METRIC QUERIES (timeseries command) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    @staticmethod
    def _format_interval(ts: Optional[TimeseriesClause]) -> Optional[str]:
        """Convert NRQL TIMESERIES interval to DQL interval: value.
        Returns None for AUTO/MAX/empty (let DT auto-select bucket size)."""
        if not ts or not ts.interval:
            return None
        if ts.interval.upper() in ('AUTO', 'MAX'):
            return None
        m = re.match(
            r'(\d+(?:\.\d+)?)\s*'
            r'(second|seconds|sec|s|minute|minutes|min|m|hour|hours|hr|h|day|days|d|week|weeks|w)$',
            ts.interval.strip(), re.IGNORECASE
        )
        if not m:
            return None
        val = m.group(1)
        unit = m.group(2).lower()
        unit_map = {
            'second': 's', 'seconds': 's', 'sec': 's', 's': 's',
            'minute': 'm', 'minutes': 'm', 'min': 'm', 'm': 'm',
            'hour': 'h', 'hours': 'h', 'hr': 'h', 'h': 'h',
            'day': 'd', 'days': 'd', 'd': 'd',
            'week': 'w', 'weeks': 'w', 'w': 'w',
        }
        dql_unit = unit_map.get(unit, 'm')
        if '.' in val and val.endswith('.0'):
            val = val[:-2]
        return f"{val}{dql_unit}"

    @staticmethod
    def _interval_to_seconds(interval_str: Optional[str]) -> Optional[int]:
        """Convert NR interval string to seconds. Returns None if unparseable."""
        if not interval_str or interval_str.upper() in ('AUTO', 'MAX'):
            return None
        m = re.match(
            r'(\d+(?:\.\d+)?)\s*'
            r'(second|seconds|sec|s|minute|minutes|min|m|hour|hours|hr|h|day|days|d|week|weeks|w)$',
            interval_str.strip(), re.IGNORECASE
        )
        if not m:
            return None
        val = float(m.group(1))
        unit = m.group(2).lower()
        unit_secs = {
            'second': 1, 'seconds': 1, 'sec': 1, 's': 1,
            'minute': 60, 'minutes': 60, 'min': 60, 'm': 60,
            'hour': 3600, 'hours': 3600, 'hr': 3600, 'h': 3600,
            'day': 86400, 'days': 86400, 'd': 86400,
            'week': 604800, 'weeks': 604800, 'w': 604800,
        }
        return int(val * unit_secs.get(unit, 60))

    @staticmethod
    def _extract_agg_names_from_dql(dql: str) -> List[Tuple[str, str]]:
        """Extract (name, function) pairs from makeTimeseries/timeseries line.
        
        Examples:
            'makeTimeseries avg(duration)' â†’ [('avg', 'avg')]
            'makeTimeseries total=count(), by:...' â†’ [('total', 'count')]
            'makeTimeseries p95=percentile(duration, 95), cnt=count()' â†’ [('p95', 'percentile'), ('cnt', 'count')]
        """
        results = []
        for line in dql.split('\n'):
            stripped = line.strip().lstrip('| ')
            if not (stripped.startswith('makeTimeseries') or stripped.startswith('timeseries')):
                continue
            # Extract the aggregation part (everything after the command, before by:/interval:/filter:)
            cmd_end = stripped.find(' ') + 1
            agg_part = stripped[cmd_end:]
            # Remove by:{...}, interval:, filter:, shift:
            agg_part = re.sub(r',\s*(by:\s*\{[^}]*\}|interval:\s*\S+|filter:\s*.+|shift:\s*\S+)', '', agg_part)
            
            # Parse individual aggregations: name=func(args) or func(args)
            # Split on commas that aren't inside parentheses
            depth = 0
            current = ''
            parts = []
            for ch in agg_part:
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
                elif ch == ',' and depth == 0:
                    parts.append(current.strip())
                    current = ''
                    continue
                current += ch
            if current.strip():
                parts.append(current.strip())
            
            for part in parts:
                # Named: name=func(args)
                m = re.match(r'(\w+)\s*=\s*(\w+)\s*\(', part)
                if m:
                    results.append((m.group(1), m.group(2)))
                    continue
                # Unnamed: func(args)
                m = re.match(r'(\w+)\s*\(', part)
                if m:
                    results.append((m.group(1), m.group(1)))
            break  # Only process first matching line
        return results

    @staticmethod
    def _agg_to_rolling_func(agg_func: str) -> str:
        """Map DQL aggregation function to rolling() function name.
        rolling() supports: avg, sum, min, max, count, median, stddev."""
        mapping = {
            'avg': 'avg', 'count': 'sum', 'countIf': 'sum',
            'sum': 'sum', 'min': 'min', 'max': 'max',
            'percentile': 'avg', 'countDistinctExact': 'avg', 'countDistinctApprox': 'avg',
            'stddev': 'stddev', 'median': 'median', 'variance': 'avg',
        }
        return mapping.get(agg_func, 'avg')

    def _emit_metric_query(self, query: Query, from_type: str) -> str:
        """Emit metric-type queries: timeseries func(dt.metric), by:{}, filter:{}
        
        Handles three patterns:
        1. Simple: SELECT avg(cpuPercent) â†’ timeseries avg(dt.host.cpu.usage)
        2. Transform: SELECT latest(errorRate) â†’ calculated expression from METRIC_TRANSFORMS
        3. Arithmetic: SELECT (latest(a)/latest(b))*100 â†’ timeseries with fieldsAdd
        4. Entity: SELECT latest(isReady) â†’ entity fetch (not a valid timeseries metric)
        """
        parts_notes: List[str] = []
        
        # Detect K8s context for context-aware metric resolution
        query_class = self._classify_query(from_type)
        self._current_k8s_context = query_class.startswith('K8S_') if query_class else False

        # â”€â”€ K8s entity field interception â”€â”€
        # Some K8s fields (isReady, status, isScheduled) are entity properties, not
        # timeseries metrics.  Detect them early and emit entity fetch DQL instead.
        if self._current_k8s_context:
            agg_preview = self._extract_metric_aggs(query.select_items)
            if agg_preview:
                first_raw_key = agg_preview[0][2].lower().replace('.', '').replace('_', '').replace('`', '')
                entity_info = self.K8S_ENTITY_FIELDS.get(first_raw_key)
                if entity_info:
                    dql = entity_info['dql']
                    # Append cluster/namespace filter from WHERE clause if present
                    if query.where_clause:
                        filter_str = self._emit_condition(query.where_clause)
                        dql += f"\n| filter {filter_str}"
                    return entity_info['note'] + '\n' + dql

        # Build filter string
        filter_str = ''
        if query.where_clause:
            remaining, metric_conds = self._split_metric_conditions(query.where_clause)
            if remaining:
                f = self._emit_condition(remaining)
                filter_str = f", filter:{{{f}}}"
            if metric_conds:
                parts_notes.append(
                    f"// NOTE: Metric-based filtering ({', '.join(metric_conds)}) "
                    f"applied as post-aggregation threshold in DT"
                )

        # Build by string
        by_str = ''
        if query.facet_items:
            by_items = self._emit_facet_items(query.facet_items)
            by_str = f", by: {{{by_items}}}"

        # Analyze SELECT items for arithmetic-between-aggs patterns
        for item in query.select_items:
            if self._is_computed_metric_expr(item.expression):
                # Pattern 3: arithmetic between aggregations
                dql = self._emit_computed_metric(item, by_str, filter_str)
                if parts_notes:
                    return '\n'.join(parts_notes) + '\n' + dql
                return dql

        # Patterns 1 & 2: simple aggregation or transform
        agg_items = self._extract_metric_aggs(query.select_items)

        if not agg_items:
            return self._emit_fetch_query(query, 'spans')

        # Check first metric for METRIC_TRANSFORMS
        first_func, first_field, first_raw = agg_items[0]
        field_key = first_raw.lower().replace('.', '').replace('_', '').replace('`', '')
        transform = self.metric_transforms.get(field_key)

        if transform:
            dql = self._emit_metric_transform(transform, by_str, filter_str)
            if len(agg_items) > 1:
                extras = [raw for _, _, raw in agg_items[1:]]
                parts_notes.append(f"// NOTE: Additional metrics in original: {', '.join(extras)}")
            if parts_notes:
                return '\n'.join(parts_notes) + '\n' + dql
            return dql

        # Pattern 1: simple metric(s)
        dt_metric = self._resolve_metric_field(field_key, first_raw)
        dt_func = self._map_metric_agg(first_func)

        interval_str = self._format_interval(query.timeseries)
        interval_part = f", interval: {interval_str}" if interval_str else ""

        if len(agg_items) > 1:
            # Multiple simple metrics: emit all as multi-metric timeseries with braces
            ts_parts = []
            for func_name, field_name, raw in agg_items:
                fk = raw.lower().replace('.', '').replace('_', '').replace('`', '')
                resolved = self._resolve_metric_field(fk, raw)
                mapped_func = self._map_metric_agg(func_name)
                alias = self._sanitize_alias(raw.split('.')[-1] if '.' in raw else raw)
                ts_parts.append(f"{alias} = {mapped_func}({resolved})")
            dql = f"timeseries {{{', '.join(ts_parts)}}}{by_str}{filter_str}{interval_part}"
        else:
            dql = f"timeseries {dt_func}({dt_metric}){by_str}{filter_str}{interval_part}"

        if parts_notes:
            return '\n'.join(parts_notes) + '\n' + dql
        return dql

    def _is_computed_metric_expr(self, node: ASTNode) -> bool:
        """Check if expression is arithmetic between multiple aggregation calls.
        e.g., (latest(a)/latest(b))*100"""
        if isinstance(node, BinaryOp):
            has_agg_left = self._contains_agg(node.left)
            has_agg_right = self._contains_agg(node.right)
            # Arithmetic between two agg branches, or agg with literal
            if has_agg_left and (has_agg_right or isinstance(node.right, LiteralExpr)):
                # Need at least 2 distinct agg calls to qualify
                aggs = []
                self._collect_aggs(node, aggs)
                return len(aggs) >= 2
        return False

    def _contains_agg(self, node: ASTNode) -> bool:
        """Check if node tree contains any aggregation function call."""
        if isinstance(node, FunctionCall) and node.name.lower() in AGG_FUNCTIONS:
            return True
        if isinstance(node, BinaryOp):
            return self._contains_agg(node.left) or self._contains_agg(node.right)
        if isinstance(node, UnaryMinus):
            return self._contains_agg(node.operand)
        return False

    def _collect_aggs(self, node: ASTNode, aggs: List):
        """Collect all aggregation FunctionCall nodes from expression tree."""
        if isinstance(node, FunctionCall) and node.name.lower() in AGG_FUNCTIONS:
            aggs.append(node)
        elif isinstance(node, BinaryOp):
            self._collect_aggs(node.left, aggs)
            self._collect_aggs(node.right, aggs)
        elif isinstance(node, UnaryMinus):
            self._collect_aggs(node.operand, aggs)

    def _emit_computed_metric(self, item: SelectItem, by_str: str, filter_str: str) -> str:
        """Emit a computed metric expression as multi-metric timeseries + fieldsAdd.
        
        Input AST: (latest(fsInodesUsed) / latest(fsInodes)) * 100 as fsInodeCapacityUtilization
        Output DQL:
            timeseries m1 = avg(dt.kubernetes.node.filesystem.inodes_used),
                       m2 = avg(dt.kubernetes.node.filesystem.inodes){by}{filter}
            | fieldsAdd fsInodeCapacityUtilization = (toDouble(m1) / toDouble(m2)) * 100
        """
        # Collect all aggregation calls
        aggs: List[FunctionCall] = []
        self._collect_aggs(item.expression, aggs)

        # Assign temp names and resolve metrics
        agg_aliases: Dict[int, str] = {}  # id(agg_node) â†’ alias name
        ts_parts: List[str] = []

        for i, agg in enumerate(aggs):
            alias = f"m{i+1}"
            agg_aliases[id(agg)] = alias

            # Get field and resolve to DT metric
            raw_field = ''
            if agg.args and not isinstance(agg.args[0], StarExpr):
                raw_field = self._extract_field_name(agg.args[0])
            field_key = raw_field.lower().replace('.', '').replace('_', '').replace('`', '')
            dt_metric = self._resolve_metric_field(field_key, raw_field)
            dt_func = self._map_metric_agg(agg.name.lower())

            ts_parts.append(f"{alias} = {dt_func}({dt_metric})")

        # Build timeseries line
        # DQL requires curly braces around multiple aggregations to disambiguate
        # from named parameters like by: and filter:
        if len(ts_parts) > 1:
            dql = f"timeseries {{{', '.join(ts_parts)}}}{by_str}{filter_str}"
        else:
            dql = f"timeseries {ts_parts[0]}{by_str}{filter_str}"

        # Build the arithmetic expression with alias references
        calc_expr = self._emit_computed_expr(item.expression, agg_aliases)

        # Result name
        result_name = self._sanitize_alias(item.alias) if item.alias else 'result'

        dql += f"\n| fieldsAdd {result_name} = {calc_expr}"

        return dql

    def _emit_computed_expr(self, node: ASTNode, agg_aliases: Dict[int, str]) -> str:
        """Emit arithmetic expression with agg calls replaced by toDouble(alias) refs."""
        if isinstance(node, FunctionCall) and node.name.lower() in AGG_FUNCTIONS:
            alias = agg_aliases.get(id(node), 'unknown')
            return f"toDouble({alias})"
        if isinstance(node, BinaryOp):
            left = self._emit_computed_expr(node.left, agg_aliases)
            right = self._emit_computed_expr(node.right, agg_aliases)
            return f"({left} {node.op} {right})"
        if isinstance(node, LiteralExpr):
            v = node.value
            if isinstance(v, (int, float)):
                return f"{float(v)}" if isinstance(v, int) else str(v)
            return str(v)
        if isinstance(node, UnaryMinus):
            inner = self._emit_computed_expr(node.operand, agg_aliases)
            return f"-{inner}"
        # Fallback
        return self._emit_expr(node)

    def _emit_metric_transform(self, transform: Dict, by_str: str, filter_str: str) -> str:
        """Emit a METRIC_TRANSFORMS calculated expression."""
        ttype = transform['type']
        note = transform.get('note', '')

        if ttype == 'calculated':
            template = transform.get('dql_single', transform['dql'])
            dql = template.replace('{by}', by_str).replace('{filter}', filter_str)
        elif ttype == 'multi_metric':
            dql = transform['dql'].replace('{by}', by_str).replace('{filter}', filter_str)
        elif ttype == 'unit_convert':
            metric = transform['metric']
            post_calc = transform.get('post_calc', '')
            alias = metric.split('.')[-1][:12]
            dql = f"timeseries {alias} = avg({metric}){by_str}{filter_str}"
            if post_calc:
                dql += f"\n{post_calc.replace('{alias}', alias)}"
        else:
            dql = f"// Unknown transform type: {ttype}"

        if note:
            dql = f"// {note}\n{dql}"
        return dql

    def _extract_metric_aggs(self, items: List[SelectItem]) -> List[Tuple[str, str, str]]:
        """Extract (func, dt_func, raw_field) tuples from SELECT items for metric queries."""
        results = []
        for item in items:
            extracted = self._walk_for_agg(item.expression)
            if extracted:
                results.extend(extracted)
        return results

    def _walk_for_agg(self, node: ASTNode) -> List[Tuple[str, str, str]]:
        """Walk expression tree to find aggregation function calls."""
        if isinstance(node, FunctionCall):
            if node.name.lower() in AGG_FUNCTIONS:
                raw_field = ''
                if node.args and not isinstance(node.args[0], StarExpr):
                    raw_field = self._extract_field_name(node.args[0])
                return [(node.name.lower(), node.name.lower(), raw_field)]
        if isinstance(node, BinaryOp):
            left = self._walk_for_agg(node.left)
            right = self._walk_for_agg(node.right)
            return (left or []) + (right or [])
        return []

    def _extract_field_name(self, node: ASTNode) -> str:
        """Get raw field name from expression node."""
        if isinstance(node, FieldRef):
            return node.name
        if isinstance(node, FunctionCall):
            # nested: avg(something(field))
            if node.args:
                return self._extract_field_name(node.args[0])
        return ''

    # K8s context-specific metric overrides.
    # Some NR fields (memoryUsedBytes, cpuPercent, etc.) appear in both host and K8s contexts.
    # When FROM is K8sContainerSample/K8sNodeSample, these must map to dt.kubernetes.* metrics.
    K8S_METRIC_OVERRIDES = {
        'memoryusedbytes': 'dt.kubernetes.container.memory_working_set',
        'memoryused': 'dt.kubernetes.container.memory_working_set',
        'cpuusedbytes': 'dt.kubernetes.container.cpu_usage',
        'cpupercent': 'dt.kubernetes.container.cpu_usage',
        'diskused': 'dt.kubernetes.persistentvolumeclaim.used',
        'diskusedbytes': 'dt.kubernetes.persistentvolumeclaim.used',
        'restartcount': 'dt.kubernetes.container.restarts',
        'restartcountdelta': 'dt.kubernetes.container.restarts',
        'cpuusedcores': 'dt.kubernetes.container.cpu_usage',
        'memoryworkingsetbytes': 'dt.kubernetes.container.memory_working_set',
    }

    # K8s fields that are NOT valid timeseries metrics â€” they need entity queries instead.
    # When encountered, _emit_metric_query redirects to an entity-based DQL fetch.
    K8S_ENTITY_FIELDS = {
        'isready': {
            'dql': (
                'fetch dt.entity.cloud_application'
                ' | fields entity.name, readyReplicas = readyReplicas, desiredReplicas = desiredReplicas'
            ),
            'note': '// isReady â†’ DT uses entity properties, not timeseries metrics. '
                    'Compare readyReplicas vs desiredReplicas for readiness.',
        },
        'status': {
            'dql': (
                'fetch dt.entity.cloud_application'
                ' | fields entity.name, status = cloudApplicationStatus'
            ),
            'note': '// status â†’ DT uses entity properties for workload status.',
        },
        'isscheduled': {
            'dql': (
                'fetch dt.entity.cloud_application_instance'
                ' | fields entity.name, phase = cloudApplicationInstancePhase'
            ),
            'note': '// isScheduled â†’ DT uses entity phase property, not timeseries metrics.',
        },
    }

    def _resolve_metric_field(self, field_key: str, raw_field: str) -> str:
        """Resolve NR field to DT metric.
        
        Resolution order:
        1. K8s context overrides (when query is FROM K8s*Sample)
        2. Static METRIC_MAP (fast, known mappings)
        3. Live registry resolver (validates metric exists, fuzzy finds correction)
        4. Passthrough with warning
        """
        # 0. K8s context overrides
        if getattr(self, '_current_k8s_context', False):
            k8s_metric = self.K8S_METRIC_OVERRIDES.get(field_key)
            if k8s_metric:
                return k8s_metric
        
        # 1. Static map
        dt_metric = self.metric_map.get(field_key)
        if dt_metric:
            # If we have a live resolver, validate this mapping actually exists
            if self.metric_resolver:
                validated, warning = self.metric_resolver(field_key, raw_field, dt_metric)
                if warning:
                    self.warnings.append(warning)
                return validated
            return dt_metric

        # 2. Live resolver (handles fuzzy matching, text search)
        if self.metric_resolver:
            resolved, warning = self.metric_resolver(field_key, raw_field, None)
            if warning:
                self.warnings.append(warning)
            if resolved:
                return resolved

        # Already a DT metric?
        if raw_field.startswith('dt.') or raw_field.startswith('builtin:'):
            return raw_field

        # 3. Passthrough with warning
        self.warnings.append(f"Unknown metric '{raw_field}' â€” no METRIC_MAP entry, no live registry match")
        return raw_field

    def _map_metric_agg(self, func: str) -> str:
        """Map aggregation function for timeseries command.
        timeseries only supports: sum, avg, min, max, count, percentile, countDistinct"""
        func_low = func.lower()
        if func_low in ('latest', 'last', 'first', 'earliest', 'average'):
            return 'avg'
        # Special metric-context functions
        if func_low == 'derivative':
            self.warnings.append("derivative() â†’ DQL delta() in timeseries context")
            return 'delta'
        if func_low == 'bucketpercentile':
            self.warnings.append("bucketPercentile() â†’ DQL percentile() for Prometheus histograms")
            return 'percentile'
        dt = FUNC_MAP.get(func_low, func_low)
        # Validate it's a valid timeseries aggregation
        valid_ts = {'sum', 'avg', 'min', 'max', 'count', 'countIf',
                    'countDistinctExact', 'countDistinctApprox',
                    'percentile', 'stddev', 'variance', 'delta'}
        if dt not in valid_ts:
            self.warnings.append(f"'{dt}' not valid for timeseries â€” using avg")
            return 'avg'
        return dt

    def _split_metric_conditions(self, cond: Condition) -> Tuple[Optional[Condition], List[str]]:
        """Split WHERE clause into entity-filterable and metric-value conditions.
        Metric conditions like 'memoryUsedBytes > 1000' can't go in timeseries filter:."""
        metric_fields = {
            'allocatablememoryutilization', 'memoryusedbytes', 'memoryavailablebytes',
            'fscapacityutilization', 'fsavailablebytes', 'fsinodesused', 'fsinodes',
            'cpuusedbytes', 'allocatablecpuutilization', 'fsinodescapacityutilization',
        }
        stripped: List[str] = []

        def walk(c: Condition) -> Optional[Condition]:
            if isinstance(c, ComparisonCond):
                if isinstance(c.left, FieldRef) and c.left.name.lower().replace('.','').replace('_','') in metric_fields:
                    stripped.append(c.left.name)
                    return None
                return c
            if isinstance(c, LogicalCond):
                left = walk(c.left)
                right = walk(c.right)
                if left is None and right is None: return None
                if left is None: return right
                if right is None: return left
                return LogicalCond(c.op, left, right)
            if isinstance(c, NotCond):
                inner = walk(c.operand)
                return NotCond(inner) if inner else None
            return c

        remaining = walk(cond)
        return remaining, stripped

    # â”€â”€ EVENTS QUERIES (fetch events) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _emit_events_query(self, query: Query) -> str:
        """Emit InfrastructureEvent â†’ fetch events | fields | filter"""
        parts: List[str] = ['fetch events']

        if query.where_clause:
            parts.append(f"| filter {self._emit_condition(query.where_clause)}")

        # Select â†’ fields
        field_exprs = [self._emit_expr(item.expression) for item in query.select_items
                       if not self._is_agg_expr(item.expression)]
        if field_exprs:
            parts.append(f"| fields {', '.join(field_exprs)}")

        if query.limit and query.limit.value != 'MAX':
            parts.append(f"| limit {query.limit.value}")

        return '\n'.join(parts)

    # â”€â”€ FETCH QUERIES (spans, logs, bizevents, etc.) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _emit_fetch_query(self, query: Query, fetch_type: str) -> str:
        """Emit standard fetch queries: fetch type | filter | makeTimeseries/summarize"""
        parts: List[str] = []

        # 1. fetch <type>
        parts.append(f"fetch {fetch_type}")

        # 1b. Auto-filter for TransactionError â†’ only error spans
        from_type = query.from_clause.lower().replace('_', '').replace('-', '')
        if from_type == 'transactionerror':
            parts.append('| filter otel.status_code == "ERROR"')

        # 2. Filter â€” extract subqueries for separate lookup steps
        subqueries: List[InSubqueryCond] = []
        remaining_where = None
        if query.where_clause:
            remaining_where, subqueries = self._extract_subqueries(query.where_clause)

        if remaining_where:
            filter_str = self._emit_condition(remaining_where)
            parts.append(f"| filter {filter_str}")

        # 3. Lookup steps from subqueries
        for sq in subqueries:
            self._emit_lookup(sq, parts)

        # 4. Aggregation
        has_agg = self._has_aggregation(query.select_items)
        has_ts = query.timeseries is not None

        if has_ts or has_agg:
            cmd = 'makeTimeseries' if has_ts else 'summarize'
            by_clause = ''
            
            # â”€â”€ CASES in FACET handling â”€â”€
            # DQL's by:{} clause only accepts field references, not computed
            # expressions like if(contains(...)). When FACET contains CASES
            # (which emits if/else chains), we must:
            #   1. Emit fieldsAdd to create computed grouping column(s)
            #   2. Reference the column name in by:{}
            facet_fields_add = []
            if query.facet_items:
                has_cases = any(
                    isinstance(fi.expression, FunctionCall) and fi.expression.name.lower() == 'cases'
                    for fi in query.facet_items
                )
                if has_cases:
                    # Pre-compute CASES expressions as fieldsAdd columns
                    by_refs = []
                    for i, item in enumerate(query.facet_items):
                        if isinstance(item.expression, FunctionCall) and item.expression.name.lower() == 'cases':
                            col_name = item.alias or f'_category_{i+1}'
                            col_name = self._sanitize_alias(col_name)
                            cases_expr = self._emit_expr(item.expression)
                            facet_fields_add.append(f"{col_name} = {cases_expr}")
                            by_refs.append(col_name)
                        else:
                            expr_str = self._emit_expr(item.expression)
                            if item.alias:
                                by_refs.append(f"{self._sanitize_alias(item.alias)}={expr_str}")
                            else:
                                by_refs.append(expr_str)
                    by_clause = f", by: {{{', '.join(by_refs)}}}"
                else:
                    by_items = self._emit_facet_items(query.facet_items)
                    by_clause = f", by: {{{by_items}}}"
            
            # Emit fieldsAdd for CASES before aggregation
            for fa in facet_fields_add:
                parts.append(f"| fieldsAdd {fa}")

            # Interval for makeTimeseries
            interval_clause = ''
            if has_ts:
                interval_str = self._format_interval(query.timeseries)
                if interval_str:
                    interval_clause = f", interval: {interval_str}"

            # Check for computed-aggregation expressions that need decomposition
            # (cdfPercentage, percentage(), arithmetic between aggs)
            decomposed = self._decompose_computed_aggs(
                query.select_items, is_timeseries=has_ts)

            if decomposed:
                agg_exprs, fields_add = decomposed
                # Inject histogram bin if set during expression emission
                if self._histogram_bin_expr:
                    if by_clause:
                        by_clause = by_clause.rstrip('}') + f", {self._histogram_bin_expr}}}"
                    else:
                        by_clause = f", by: {{{self._histogram_bin_expr}}}"
                    self._histogram_bin_expr = None
                agg_str = self._format_agg_list(cmd, agg_exprs)
                parts.append(f"| {cmd} {agg_str}{by_clause}{interval_clause}")
                for fa in fields_add:
                    parts.append(f"| fieldsAdd {fa}")
                # DO NOT use fieldsRemove here. DT visualization requires all
                # makeTimeseries columns for data mapping (Time, Values, Names).
                # Removing _m1/_m2 intermediates causes "No field available" errors.
                # Extra columns are harmless â€” users toggle them off in chart legend.
            else:
                agg_exprs = self._emit_aggregations(
                    query.select_items, needs_naming=has_ts)
                # Inject histogram bin if set during expression emission
                if self._histogram_bin_expr:
                    if by_clause:
                        by_clause = by_clause.rstrip('}') + f", {self._histogram_bin_expr}}}"
                    else:
                        by_clause = f", by: {{{self._histogram_bin_expr}}}"
                    self._histogram_bin_expr = None
                agg_str = self._format_agg_list(cmd, agg_exprs)
                parts.append(
                    f"| {cmd} {agg_str}{by_clause}{interval_clause}")
        else:
            # No aggregation â€” project fields
            field_exprs = [self._emit_expr(item.expression) for item in query.select_items]
            parts.append(f"| fields {', '.join(field_exprs)}")
            if query.facet_items:
                by_items = self._emit_facet_items(query.facet_items)
                parts.append(f"| summarize by: {{{by_items}}}")

        # 4b. Funnel conversion rates (if funnel was decomposed into countIf steps)
        if self._funnel_steps and len(self._funnel_steps) >= 2:
            for i in range(len(self._funnel_steps) - 1):
                step_cur = self._funnel_steps[i][0]
                step_next = self._funnel_steps[i + 1][0]
                label_cur = self._funnel_steps[i][1]
                label_next = self._funnel_steps[i + 1][1]
                safe_cur = re.sub(r'[^a-zA-Z0-9_]', '_', label_cur)
                safe_next = re.sub(r'[^a-zA-Z0-9_]', '_', label_next)
                parts.append(
                    f"| fieldsAdd conv_{safe_cur}_to_{safe_next} = "
                    f"(toDouble({step_next}) / toDouble({step_cur})) * 100.0"
                )
            self._funnel_steps = []

        # 5. Sort
        if query.order_by:
            direction = "asc" if query.order_by.direction == 'ASC' else "desc"
            expr = self._emit_expr(query.order_by.expression)
            parts.append(f"| sort {expr} {direction}")

        # 6. Limit
        if query.limit and query.limit.value != 'MAX':
            parts.append(f"| limit {query.limit.value}")

        return '\n'.join(parts)

    # â”€â”€ Aggregations â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _has_aggregation(self, items: List[SelectItem]) -> bool:
        return any(self._is_agg_expr(item.expression) for item in items)

    def _is_agg_expr(self, node: ASTNode) -> bool:
        if isinstance(node, FunctionCall):
            if node.name.lower() in AGG_FUNCTIONS:
                return True
            # Arithmetic on aggregations
        if isinstance(node, BinaryOp):
            return self._is_agg_expr(node.left) or self._is_agg_expr(node.right)
        if isinstance(node, UnaryMinus):
            return self._is_agg_expr(node.operand)
        return False

    DQL_RESERVED_WORDS = {
        'duration', 'timestamp', 'timeframe', 'string', 'long', 'double',
        'boolean', 'ip', 'record', 'array', 'true', 'false', 'null',
        'fetch', 'filter', 'summarize', 'fields', 'sort', 'limit',
        'lookup', 'join', 'append', 'parse', 'from', 'to', 'by',
        'asc', 'desc', 'not', 'and', 'or', 'in', 'is',
    }

    def _sanitize_alias(self, alias: str) -> str:
        """Sanitize alias for DQL: backtick-escape reserved words, digit-prefixed,
        and special-character identifiers."""
        if not alias:
            return alias
        # Starts with digit â†’ backtick
        if alias[0].isdigit():
            return f'`{alias}`'
        # DQL reserved word â†’ backtick
        if alias.lower() in self.DQL_RESERVED_WORDS:
            return f'`{alias}`'
        # Contains spaces or special chars â†’ backtick
        if re.search(r'[^a-zA-Z0-9_]', alias):
            return f'`{alias}`'
        return alias

    def _format_agg_list(self, cmd: str, agg_exprs: List[str]) -> str:
        """Format aggregation list for makeTimeseries/summarize.
        
        DQL requires curly braces for BOTH makeTimeseries AND summarize
        when multiple aggregations are present. Without braces, the parser
        can't distinguish aliased aggregations from named parameters.
        
        Single agg:  summarize count()          / makeTimeseries count()
        Multi agg:   summarize {count(), avg(d)} / makeTimeseries {count(), avg(d)}
        """
        # Count actual aggregation items (multi-percentile expansions contain
        # commas within a single list item, so split on ', ' to count real items)
        total_items = 0
        for expr in agg_exprs:
            # Multi-percentile expansions like "p95=percentile(x,95), p99=percentile(x,99)"
            # are a single list item but contain multiple comma-separated aggregations
            total_items += expr.count('), ') + 1

        joined = ', '.join(agg_exprs)
        
        if total_items > 1 and cmd in ('makeTimeseries', 'summarize'):
            return '{' + joined + '}'
        return joined

    def _emit_aggregations(self, items: List[SelectItem], needs_naming: bool) -> List[str]:
        """Emit SELECT items as DQL aggregation expressions.
        Deduplicates identical expressions without aliases.
        Auto-names positional-ambiguous aggregations in makeTimeseries."""
        seen: Dict[str, str] = {}  # normalized_expr â†’ emitted_str
        result: List[str] = []

        for item in items:
            expr_str = self._emit_agg_expr(item.expression)

            # Determine alias
            alias = self._sanitize_alias(item.alias) if item.alias else None

            # Dedup: if same expression with no alias, skip
            normalized = expr_str.lower().strip()
            if not alias and normalized in seen:
                continue
            seen[normalized] = expr_str

            # Auto-name if needed (makeTimeseries requires named params for multi-arg funcs)
            # BUT: multi-percentile expansion already embeds aliases (e.g., "p95=percentile(...), p99=...")
            already_named = '=' in expr_str.split('(')[0] if '(' in expr_str else '=' in expr_str
            if alias and already_named:
                # Expression has embedded alias AND user alias â†’ replace embedded with user's
                # e.g., "p95=percentile(x, 95)" + alias "Percentile" â†’ "Percentile=percentile(x, 95)"
                # For multi-percentile expansions like "p95=percentile(x,95), p99=percentile(x,99)",
                # keep embedded aliases since user's single alias can't cover multiple expansions
                if ', ' in expr_str and expr_str.count('=') > 1:
                    # Multi-expansion: keep as-is (user alias doesn't apply to split results)
                    result.append(expr_str)
                else:
                    # Single expansion: replace embedded alias with user's
                    eq_pos = expr_str.index('=')
                    result.append(f"{alias}={expr_str[eq_pos+1:]}")
            elif alias:
                result.append(f"{alias}={expr_str}")
            elif already_named:
                # Expression already has embedded alias(es) from multi-percentile expansion
                result.append(expr_str)
            elif needs_naming and self._needs_naming(item.expression):
                auto_name = self._auto_name(item.expression)
                result.append(f"{auto_name}={expr_str}")
            else:
                result.append(expr_str)

        return result

    def _needs_naming(self, node: ASTNode) -> bool:
        """Does this aggregation need an explicit name in makeTimeseries?"""
        if isinstance(node, FunctionCall):
            # percentile(field, N) â€” the N is ambiguous as a positional param
            if node.name.lower() == 'percentile' and len(node.args) >= 2:
                return True
            # Any function with 2+ comma-separated args inside makeTimeseries
            if len(node.args) >= 2 and node.name.lower() in AGG_FUNCTIONS:
                return True
        return False

    def _auto_name(self, node: ASTNode) -> str:
        """Generate an automatic alias for an aggregation."""
        if isinstance(node, FunctionCall):
            name = node.name.lower()
            if name == 'percentile' and len(node.args) >= 2:
                pct_arg = node.args[1]
                if isinstance(pct_arg, LiteralExpr) and isinstance(pct_arg.value, (int, float)):
                    return f"p{int(pct_arg.value)}"
            return f"{FUNC_MAP.get(name, name)}_{self._next_counter()}"
        return f"agg_{self._next_counter()}"

    # â”€â”€ Computed-aggregation decomposition for makeTimeseries â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _contains_computed_agg(self, node: ASTNode) -> bool:
        """Check if expression contains arithmetic between aggregations or
        multi-expansion functions (cdfPercentage, percentage) that produce
        expressions invalid in makeTimeseries."""
        if isinstance(node, FunctionCall):
            name_low = node.name.lower()
            # cdfPercentage expands into multiple countIf/count arithmetic
            if name_low == 'cdfpercentage':
                return True
            # percentage(count(*), WHERE cond) â†’ 100*countIf/count
            if name_low == 'percentage' and node.where_clause:
                return True
        if isinstance(node, BinaryOp):
            # Arithmetic between two aggregation calls
            left_agg = self._is_agg_expr(node.left)
            right_agg = self._is_agg_expr(node.right)
            if left_agg and right_agg:
                return True
            # One side is agg, other is literal â†’ also invalid in makeTimeseries
            # e.g. countIf(x) / count() * 100
            if left_agg or right_agg:
                return True
        return False

    def _decompose_computed_aggs(self, items: List, is_timeseries: bool):
        """Decompose arithmetic-on-aggregations into component aggs + fieldsAdd.

        For makeTimeseries, expressions like:
            100.0 * countIf(error) / count()
            cdfPercentage(duration, 1000, 2000)
            filter(count(*), WHERE x >= 500) / count(*) * 100

        ...are invalid because makeTimeseries only accepts simple aggregation calls.

        This decomposes them into:
            makeTimeseries _matched=countIf(error), _total=count()
            | fieldsAdd error_pct = 100.0 * toDouble(_matched) / toDouble(_total)

        Returns (agg_strings, fieldsAdd_strings) or None if no decomposition needed.
        """
        if not is_timeseries:
            return None

        needs_decomp = any(
            self._contains_computed_agg(item.expression) for item in items
        )
        if not needs_decomp:
            return None

        agg_strings: List[str] = []
        fields_add: List[str] = []
        counter = [0]
        seen_count: List[str] = []  # track deduplicated count() aliases

        def next_id():
            counter[0] += 1
            return counter[0]

        def get_count_alias():
            """Reuse a single count() aggregation across decomposed items."""
            if not seen_count:
                alias = f"_total_{next_id()}"
                agg_strings.append(f"{alias}=count()")
                seen_count.append(alias)
            return seen_count[0]

        # Pre-scan: if ANY item needs decomposition with a count() total,
        # create the shared count alias NOW so standalone count(*) items
        # that appear earlier can reuse it.
        # IMPORTANT: Only create count() if the expression actually USES count(),
        # not just because there's a BinaryOp with any aggregation.
        def _expr_needs_count(expr):
            """Check if expression actually requires a count() decomposition."""
            if isinstance(expr, FunctionCall):
                if expr.name.lower() in ('cdfpercentage', 'percentage'):
                    return True
                if expr.name.lower() == 'count':
                    return True  # Direct count() usage
            if isinstance(expr, BinaryOp):
                return _expr_needs_count(expr.left) or _expr_needs_count(expr.right)
            return False
        
        any_needs_count = any(
            _expr_needs_count(item.expression)
            for item in items
        )
        if any_needs_count:
            get_count_alias()  # pre-create _total_1

        for item in items:
            expr = item.expression

            # â”€â”€ cdfPercentage(field, t1, t2, ...) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            if (isinstance(expr, FunctionCall)
                    and expr.name.lower() == 'cdfpercentage'
                    and len(expr.args) >= 2):
                field_str = self._emit_expr(expr.args[0])
                total_alias = get_count_alias()

                for i, arg in enumerate(expr.args[1:]):
                    t_str = self._emit_expr(arg)
                    t_label = t_str.replace('.', '_').replace('-', '_')
                    below_alias = f"_below_{t_label}_{next_id()}"
                    agg_strings.append(
                        f"{below_alias}=countIf({field_str} <= {t_str})")
                    pct_name = f"pct_le_{t_label}"
                    fields_add.append(
                        f"{pct_name} = 100.0 * toDouble({below_alias})"
                        f" / toDouble({total_alias})")

                self.warnings.append(
                    "cdfPercentage() â†’ decomposed into countIf/count "
                    "aggregations + fieldsAdd percentages"
                )
                continue

            # â”€â”€ percentage(count(*), WHERE cond) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            if (isinstance(expr, FunctionCall)
                    and expr.name.lower() == 'percentage'
                    and expr.where_clause):
                cond_str = self._emit_condition(expr.where_clause)
                matched_alias = f"_matched_{next_id()}"
                total_alias = get_count_alias()
                agg_strings.append(f"{matched_alias}=countIf({cond_str})")
                result_name = self._sanitize_alias(item.alias) if item.alias else f"percentage_{next_id()}"
                fields_add.append(
                    f"{result_name} = 100.0 * toDouble({matched_alias})"
                    f" / toDouble({total_alias})")
                continue

            # â”€â”€ BinaryOp between aggregations â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            if (isinstance(expr, BinaryOp)
                    and self._contains_computed_agg(expr)):
                aggs: list = []
                self._collect_aggs(expr, aggs)
                agg_aliases: dict = {}
                for agg in aggs:
                    alias = f"_m{next_id()}"
                    agg_aliases[id(agg)] = alias
                    agg_str = self._emit_agg_expr(agg)
                    # Deduplicate count() across items
                    if agg_str == 'count()' and seen_count:
                        agg_aliases[id(agg)] = seen_count[0]
                    else:
                        agg_strings.append(f"{alias}={agg_str}")
                        if agg_str == 'count()':
                            seen_count.append(alias)
                calc_expr = self._emit_computed_expr(expr, agg_aliases)
                result_name = self._sanitize_alias(item.alias) if item.alias else f"computed_{next_id()}"
                fields_add.append(f"{result_name} = {calc_expr}")
                continue

            # â”€â”€ Normal aggregation â€” pass through â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
            agg_str = self._emit_agg_expr(expr)
            # If this is count() and we already have a named count() from
            # a decomposed item, reuse that alias (skip adding a duplicate)
            if agg_str == 'count()' and seen_count:
                # Add a fieldsAdd alias if the user gave it one
                if item.alias:
                    fields_add.append(
                        f"{self._sanitize_alias(item.alias)} = toDouble({seen_count[0]})")
                continue
            if item.alias:
                agg_strings.append(f"{self._sanitize_alias(item.alias)}={agg_str}")
            elif self._needs_naming(expr):
                auto_name = self._auto_name(expr)
                agg_strings.append(f"{auto_name}={agg_str}")
            else:
                agg_strings.append(agg_str)

        # Deduplicate agg_strings (e.g. multiple count() from different items)
        seen = set()
        deduped = []
        for a in agg_strings:
            if a not in seen:
                seen.add(a)
                deduped.append(a)

        return deduped, fields_add

    def _next_counter(self) -> int:
        self._agg_counter += 1
        return self._agg_counter

    def _emit_agg_expr(self, node: ASTNode) -> str:
        """Emit an aggregation expression, handling NR-specific transforms."""
        if isinstance(node, FunctionCall):
            return self._emit_function(node)
        if isinstance(node, BinaryOp):
            left = self._emit_agg_expr(node.left)
            right = self._emit_agg_expr(node.right)
            return f"{left} {node.op} {right}"
        if isinstance(node, UnaryMinus):
            return f"-{self._emit_agg_expr(node.operand)}"
        if isinstance(node, LiteralExpr):
            return self._emit_literal(node)
        return self._emit_expr(node)

    # â”€â”€ Functions â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _emit_function(self, node: FunctionCall) -> str:
        name_low = node.name.lower()

        # â”€â”€ percentage(count(*), WHERE cond) â†’ (100.0 * countIf(cond) / count())
        if name_low == 'percentage' and node.where_clause:
            cond_str = self._emit_condition(node.where_clause)
            # Check if the emitted condition contains aggregation functions
            # (e.g., from apdex() decomposition). If so, we have nested
            # aggregations which DQL rejects with NO_NESTED_AGGREGATIONS.
            agg_keywords = ['countIf(', 'count()', 'sum(', 'avg(', 'min(', 'max(', 'percentile(']
            has_nested_agg = any(kw in cond_str for kw in agg_keywords)
            if has_nested_agg:
                self.warnings.append(
                    "percentage() wrapping aggregation functions detected. "
                    "DQL does not support nested aggregations. "
                    "This query needs manual decomposition into: "
                    "summarize step1 aggregations | fieldsAdd percentage calculation"
                )
                return (
                    f"// ERROR: Nested aggregation detected - manual fix required\n"
                    f"// Original: percentage(count(*), WHERE <complex condition>)\n"
                    f"// Fix: Use multi-step pipeline:\n"
                    f"//   | summarize matching = countIf(<simple_condition>), total = count()\n"
                    f"//   | fieldsAdd pct = 100.0 * toDouble(matching) / toDouble(total)\n"
                    f"(100.0 * countIf({cond_str}) / count())"
                )
            return f"(100.0 * countIf({cond_str}) / count())"

        # â”€â”€ filter(func(field), WHERE cond) â†’ funcIf(field, cond)
        if name_low == 'filter' and node.where_clause and node.args:
            inner = node.args[0]
            if isinstance(inner, FunctionCall):
                dt_if = FILTER_IF_MAP.get(inner.name.lower())
                if dt_if:
                    field_str = ', '.join(self._emit_expr(a) for a in inner.args) if inner.args else ''
                    cond_str = self._emit_condition(node.where_clause)
                    if field_str and not isinstance(inner.args[0], StarExpr):
                        return f"{dt_if}({field_str}, {cond_str})"
                    else:
                        return f"{dt_if}({cond_str})"
                else:
                    # Generic: func(field) with WHERE â†’ can't convert to If-variant
                    self.warnings.append(
                        f"filter({inner.name}(...), WHERE ...) has no DQL funcIf equivalent"
                    )

        # â”€â”€ rate(count(*), 1 minute) â†’ count() with warning
        if name_low == 'rate':
            self.warnings.append("rate() not directly supported in DQL makeTimeseries; using base aggregation")
            if node.args and isinstance(node.args[0], FunctionCall):
                return self._emit_function(node.args[0])
            return 'count()'

        # â”€â”€ median(field) â†’ percentile(field, 50)
        if name_low == 'median':
            if node.args:
                field_str = self._emit_expr(node.args[0])
                return f"percentile({field_str}, 50)"
            return "percentile(duration, 50)"

        # â”€â”€ stddev(field) â†’ DQL native stddev() (available in summarize)
        if name_low == 'stddev':
            if node.args:
                field_str = self._emit_expr(node.args[0])
                return f"stddev({field_str})"
            return "stddev(duration)"

        # â”€â”€ substring(str, start, end) â†’ substring(str, from:start, to:end)
        # DQL requires named parameters for substring
        if name_low == 'substring' and len(node.args) == 3:
            str_expr = self._emit_expr(node.args[0])
            start_expr = self._emit_expr(node.args[1])
            end_expr = self._emit_expr(node.args[2])
            return f"substring({str_expr}, from:{start_expr}, to:{end_expr})"

        # â”€â”€ histogram(field, numBars, ceiling, [width]) â†’ summarize count(), by:{bin(field, width)}
        # NR signature: histogram(attribute, numBars, ceiling)
        #   - numBars: number of bars/buckets to display
        #   - ceiling: upper limit of the histogram range
        #   - width (optional): explicit bar width override
        # DT's bin(field, width) needs width = ceiling / numBars
        if name_low == 'histogram':
            field_expr = self._emit_expr(node.args[0]) if node.args else "duration"
            # Extract bin width from args
            bin_width = None
            if len(node.args) >= 4:
                bin_width = self._emit_expr(node.args[3])
            elif len(node.args) >= 3:
                try:
                    num_bars = float(self._emit_expr(node.args[1]))
                    ceiling = float(self._emit_expr(node.args[2]))
                    if num_bars > 0:
                        raw_width = ceiling / num_bars
                        # Use integer if it divides evenly, float otherwise
                        bin_width = str(int(raw_width)) if raw_width == int(raw_width) else str(raw_width)
                except (ValueError, ZeroDivisionError):
                    bin_width = "1"
            elif len(node.args) >= 2:
                # histogram(field, numBars) â€” no ceiling, default to 1s width
                bin_width = "1"
            if not bin_width or bin_width == "0":
                bin_width = "1"
            
            self.warnings.append(f"histogram({field_expr}) â†’ count() by bin({field_expr}, {bin_width}) as categoricalBarChart")
            self._histogram_bin_expr = f"bin({field_expr}, {bin_width})"
            return "count()"

        # â”€â”€ funnel(steps) â†’ DQL countIf() decomposition with conversion rates
        if name_low == 'funnel':
            # AST args: [column, cond1, label1, cond2, label2, ...]
            # â†’ summarize step1=countIf(cond1), step2=countIf(cond2), ...
            # â†’ fieldsAdd conv_1_2 = (step2 / step1) * 100
            self._funnel_steps = []  # Store for post-processing by emit()
            args_iter = iter(node.args)
            
            # Skip the column argument (first arg, e.g. 'session')
            try:
                next(args_iter)
            except StopIteration:
                return "count()"
            
            # Collect (condition, label) pairs
            steps = []
            pending_cond = None
            for arg in args_iter:
                if isinstance(arg, (ComparisonCond, LogicalCond, NotCond,
                                    IsNullCond, InListCond, LikeCond, RLikeCond)):
                    pending_cond = arg
                elif isinstance(arg, LiteralExpr) and pending_cond:
                    label = str(arg.value)
                    steps.append((pending_cond, label))
                    pending_cond = None
            # If last condition had no label
            if pending_cond:
                steps.append((pending_cond, f"Step {len(steps)+1}"))
            
            if not steps:
                return "count()"
            
            # Build countIf aggregations
            agg_parts = []
            for i, (cond, label) in enumerate(steps, 1):
                safe_label = re.sub(r'[^a-zA-Z0-9_]', '_', label)
                cond_str = self._emit_condition(cond)
                agg_parts.append(f"step{i}_{safe_label}=countIf({cond_str})")
            
            # Store steps for fieldsAdd conversion rates
            self._funnel_steps = [(f"step{i+1}_{re.sub(r'[^a-zA-Z0-9_]', '_', label)}", label) 
                                  for i, (_, label) in enumerate(steps)]
            
            self.warnings.append(
                f"FUNNEL decomposed into {len(steps)} countIf() steps with conversion rates. "
                f"Use DT's Funnel tile visualization for best results."
            )
            return ', '.join(agg_parts)

        # â”€â”€ apdex(t:threshold) â†’ proper DT Apdex calculation
        if name_low == 'apdex':
            # NR apdex forms:
            #   apdex(0.5)              -> threshold only
            #   apdex(duration, 0.5)    -> field + threshold
            #   apdex(duration, t:3)    -> field + t:N syntax
            #   apdex(duration, t:0.5)  -> field + t:N syntax
            #
            # DQL has NO apdex() function. Must decompose into multi-step:
            #   | summarize satisfied=countIf(duration < T), tolerating=countIf(duration >= T and duration < 4T), total=count()
            #   | fieldsAdd apdex = (toDouble(satisfied) + toDouble(tolerating) * 0.5) / toDouble(total)
            #
            # CRITICAL: Cannot use single-expression form because it creates
            # nested aggregations (countIf inside arithmetic inside countIf)
            # which DQL rejects with NO_NESTED_AGGREGATIONS error.
            threshold = 0.5  # default
            if node.args:
                for arg in node.args:
                    if isinstance(arg, LiteralExpr) and isinstance(arg.value, (int, float)):
                        threshold = float(arg.value)
                    elif isinstance(arg, FieldRef):
                        # Check for t:N pattern (tokenized as single identifier)
                        import re as _re
                        t_match = _re.match(r'^t:(\d+(?:\.\d+)?)$', arg.name, _re.IGNORECASE)
                        if t_match:
                            threshold = float(t_match.group(1))
            frustrated_t = threshold * 4
            self.warnings.append(
                f"apdex(t:{threshold}) decomposed into multi-step: "
                f"summarize satisfied/tolerating/total then fieldsAdd"
            )
            # Emit as a comment + the multi-step pattern
            # We return just the countIf expressions for use in summarize context,
            # but flag that this needs post-processing into multi-step
            self._apdex_decomposition = {
                'threshold': threshold,
                'frustrated': frustrated_t,
            }
            # Return a placeholder that _emit_select will expand into multi-step
            return (
                f"(countIf(duration < {threshold}s) + "
                f"countIf(duration >= {threshold}s and duration < {frustrated_t}s) * 0.5) "
                f"/ count()"
            )

        # â”€â”€ CASES(WHERE cond, 'label', ...) â†’ if(cond, "label", else:if(cond2, "label2", else:"Other"))
        # Also handles: CASES(matchesPhrase(field, val) as 'label', ...) â€” bare function conditions
        if name_low == 'cases':
            # Args alternate: condition/expression, label, condition/expression, label, ...
            pairs = []
            i = 0
            while i < len(node.args):
                arg = node.args[i]
                if i + 1 < len(node.args):
                    if isinstance(arg, Condition):
                        cond = self._emit_condition(arg)
                        label = self._emit_expr(node.args[i + 1])
                        pairs.append((cond, label))
                        i += 2
                    elif isinstance(arg, FunctionCall):
                        # Bare function condition: matchesPhrase(field, val) as 'label'
                        # Emit as a DQL boolean expression
                        cond = self._emit_function(arg)
                        label = self._emit_expr(node.args[i + 1])
                        pairs.append((cond, label))
                        i += 2
                    else:
                        i += 1
                else:
                    i += 1
            if not pairs:
                return "\"Other\""
            # Build nested if chain: if(cond1, "label1", else:if(cond2, "label2", else:"Other"))
            # DQL requires the third parameter to be named 'else:'
            result = "\"Other\""
            for cond, label in reversed(pairs):
                result = f"if({cond}, {label}, else:{result})"
            return result

        # â”€â”€ Multi-percentile: percentile(duration, 50, 90, 95, 99)
        if name_low == 'percentile' and len(node.args) >= 3:
            field_str = self._emit_expr(node.args[0])
            pcts = []
            for a in node.args[1:]:
                if isinstance(a, LiteralExpr):
                    pcts.append(int(a.value))
            return ', '.join(f"p{p}=percentile({field_str}, {p})" for p in pcts)

        # â”€â”€ count(*) â†’ count()
        if name_low == 'count':
            if not node.args or (len(node.args) == 1 and isinstance(node.args[0], StarExpr)):
                return "count()"
            # count(field) â†’ countIf(isNotNull(field))
            if len(node.args) == 1:
                field_str = self._emit_expr(node.args[0])
                return f"countIf(isNotNull({field_str}))"

        # â”€â”€ derivative(attr, time_interval) â†’ delta(field) / time
        if name_low == 'derivative':
            if node.args:
                field_str = self._emit_expr(node.args[0])
                if len(node.args) >= 2 and isinstance(node.args[1], TimeInterval):
                    ti = node.args[1]
                    self.warnings.append(
                        f"derivative({field_str}, {ti.value} {ti.unit}) â†’ "
                        f"DQL delta() or rate() over makeTimeseries interval"
                    )
                    return f"delta({field_str})"
                self.warnings.append(f"derivative() â†’ DQL delta() function")
                return f"delta({field_str})"
            return "delta(duration)"

        # â”€â”€ jparse(jsonStr, 'path') or jparse(jsonStr)[key] â†’ record field access
        if name_low == 'jparse':
            if node.args:
                field_str = self._emit_expr(node.args[0])
                if len(node.args) >= 2:
                    path_arg = node.args[1]
                    if isinstance(path_arg, LiteralExpr) and isinstance(path_arg.value, str):
                        # jparse(field, '$.key') â†’ field[`key`]
                        path = path_arg.value.lstrip('$').lstrip('.')
                        return f"{field_str}[`{path}`]"
                self.warnings.append("jparse() â†’ access JSON fields directly in DQL (record type)")
                return field_str
            return "/* jparse() */"

        # â”€â”€ clamp_max(value, max) â†’ if(value > max, max, value)
        if name_low == 'clamp_max':
            if len(node.args) >= 2:
                val_str = self._emit_expr(node.args[0])
                max_str = self._emit_expr(node.args[1])
                return f"if({val_str} > {max_str}, {max_str}, else:{val_str})"
            args_str = ', '.join(self._emit_expr(a) for a in node.args)
            return f"clamp_max({args_str})"

        # â”€â”€ clamp_min(value, min) â†’ if(value < min, min, value)
        if name_low == 'clamp_min':
            if len(node.args) >= 2:
                val_str = self._emit_expr(node.args[0])
                min_str = self._emit_expr(node.args[1])
                return f"if({val_str} < {min_str}, {min_str}, else:{val_str})"
            args_str = ', '.join(self._emit_expr(a) for a in node.args)
            return f"clamp_min({args_str})"

        # â”€â”€ cdfPercentage(attr, threshold1, threshold2, ...) â†’ countIf(attr <= t)/count()*100
        if name_low == 'cdfpercentage':
            if len(node.args) >= 2:
                field_str = self._emit_expr(node.args[0])
                parts = []
                for arg in node.args[1:]:
                    t_str = self._emit_expr(arg)
                    parts.append(f"(100.0 * countIf({field_str} <= {t_str}) / count())")
                self.warnings.append(
                    "cdfPercentage() â†’ computed as countIf(field <= threshold) / count() * 100"
                )
                return ', '.join(parts)
            return "/* cdfPercentage() requires field and threshold args */"

        # â”€â”€ bucketPercentile(bucket_attr, p1, p2, ...) â†’ percentile(attr, p)
        if name_low == 'bucketpercentile':
            if node.args:
                field_str = self._emit_expr(node.args[0])
                if len(node.args) >= 2:
                    pcts = []
                    for a in node.args[1:]:
                        if isinstance(a, LiteralExpr):
                            pcts.append(int(a.value))
                    self.warnings.append(
                        "bucketPercentile() (Prometheus histogram) â†’ DQL percentile(). "
                        "Ensure metric uses _bucket suffix."
                    )
                    if pcts:
                        return ', '.join(f"p{p}=percentile({field_str}, {p})" for p in pcts)
                # Default percentiles: 1, 25, 50, 75, 99
                return (f"p1=percentile({field_str}, 1), p25=percentile({field_str}, 25), "
                        f"p50=percentile({field_str}, 50), p75=percentile({field_str}, 75), "
                        f"p99=percentile({field_str}, 99)")
            return "percentile(duration, 50)"

        # â”€â”€ getField(result, 'key') â†’ result[`key`]
        if name_low == 'getfield':
            if len(node.args) >= 2:
                obj_str = self._emit_expr(node.args[0])
                key_arg = node.args[1]
                if isinstance(key_arg, LiteralExpr) and isinstance(key_arg.value, str):
                    return f"{obj_str}[`{key_arg.value}`]"
                key_str = self._emit_expr(key_arg)
                return f"{obj_str}[{key_str}]"
            if node.args:
                return self._emit_expr(node.args[0])
            return "/* getField() */"

        # â”€â”€ cardinality() â†’ emit warning (no DQL equivalent)
        if name_low == 'cardinality':
            self.warnings.append("cardinality() has no direct DQL equivalent; use countDistinct() on dimensions")
            if node.args:
                field_str = self._emit_expr(node.args[0])
                return f"countDistinct({field_str})"
            return "/* cardinality() â†’ use DT metric browser */"

        # â”€â”€ predictLinear(attr, seconds) â†’ Davis AI forecast
        if name_low == 'predictlinear':
            self.warnings.append("predictLinear() â†’ use Dynatrace Davis AI predictions")
            if node.args:
                return self._emit_expr(node.args[0])
            return "/* predictLinear() â†’ Davis AI */"

        # â”€â”€ blob() â†’ not supported
        if name_low == 'blob':
            self.warnings.append("blob() binary data handling not supported in DQL")
            if node.args:
                return self._emit_expr(node.args[0])
            return "/* blob() not supported */"

        # â”€â”€ mapKeys() / mapValues() â†’ record field access
        if name_low in ('mapkeys', 'mapvalues'):
            self.warnings.append(f"{node.name}() â†’ use record field access in DQL")
            if node.args:
                return self._emit_expr(node.args[0])
            return f"/* {node.name}() â†’ record access */"

        # â”€â”€ keyset() / eventType() â†’ metadata queries
        if name_low in ('keyset', 'eventtype'):
            self.warnings.append(f"{node.name}() â†’ use DT Schema browser")
            return f"/* {node.name}() â†’ use DT Schema browser */"

        # â”€â”€ bytecountestimate() â†’ data volume queries
        if name_low == 'bytecountestimate':
            self.warnings.append("bytecountestimate() â†’ use DT Data Explorer for ingest volume")
            if node.args:
                return f"/* bytecountestimate({self._emit_expr(node.args[0])}) */"
            return "/* bytecountestimate() â†’ DT Data Explorer */"

        # â”€â”€ Generic function mapping
        return self._emit_function_call(node)

    def _emit_function_call(self, node: ASTNode) -> str:
        if not isinstance(node, FunctionCall):
            return self._emit_expr(node)
        name_low = node.name.lower()
        dt_func = FUNC_MAP.get(name_low, node.name)
        
        # DQL if() requires the third parameter to be named 'else:'
        # NR: if(cond, trueVal, falseVal) â†’ DQL: if(cond, trueVal, else:falseVal)
        if name_low == 'if' and len(node.args) >= 3:
            cond_str = self._emit_condition(node.args[0]) if isinstance(node.args[0], Condition) else self._emit_expr(node.args[0])
            true_str = self._emit_expr(node.args[1])
            false_str = self._emit_expr(node.args[2])
            return f"if({cond_str}, {true_str}, else:{false_str})"
        
        # DQL indexOf() optional 3rd param must be named 'from:'
        # NR: indexOf(str, substr, startPos) â†’ DQL: indexOf(str, substr, from:startPos)
        if name_low == 'indexof' and len(node.args) >= 3:
            expr_str = self._emit_expr(node.args[0])
            substr_str = self._emit_expr(node.args[1])
            from_str = self._emit_expr(node.args[2])
            return f"indexOf({expr_str}, {substr_str}, from:{from_str})"
        
        # DQL round() optional 2nd param must be named 'scale:'
        # NR: round(val, precision) â†’ DQL: round(val, scale:precision)
        if name_low == 'round' and len(node.args) >= 2:
            val_str = self._emit_expr(node.args[0])
            scale_str = self._emit_expr(node.args[1])
            return f"round({val_str}, scale:{scale_str})"
        
        args_str = ', '.join(self._emit_expr(a) for a in node.args)
        return f"{dt_func}({args_str})"

    # â”€â”€ Conditions â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _emit_condition(self, cond: Condition) -> str:
        if isinstance(cond, LogicalCond):
            left = self._emit_condition(cond.left)
            right = self._emit_condition(cond.right)
            op = cond.op.lower()  # and, or
            return f"{left} {op} {right}"

        if isinstance(cond, NotCond):
            inner = self._emit_condition(cond.operand)
            return f"not({inner})"

        if isinstance(cond, ComparisonCond):
            # â”€â”€ INTERCEPT: aparse(field, 'pattern') = 'value' â†’ field == 'reconstructed' â”€â”€
            # NR aparse extracts the wildcard portion. If compared to a literal,
            # we can reconstruct the full string and emit a direct equality check.
            if isinstance(cond.left, FunctionCall) and cond.left.name.lower() == 'aparse':
                if len(cond.left.args) >= 2 and isinstance(cond.right, LiteralExpr):
                    field_expr = self._emit_expr(cond.left.args[0])
                    pattern_node = cond.left.args[1]
                    value = str(cond.right.value)
                    op = '==' if cond.op == '=' else cond.op
                    
                    if isinstance(pattern_node, LiteralExpr):
                        pattern = str(pattern_node.value)
                        # Count wildcards (% or *)
                        wildcards = pattern.count('%') + pattern.count('*')
                        if wildcards == 1:
                            # Single wildcard â†’ reconstruct full string
                            full_str = pattern.replace('%', value).replace('*', value)
                            if op in ('==', '!='):
                                return f'{field_expr} {op} "{full_str}"'
                            else:
                                # For contains/startsWith checks with the pattern prefix
                                prefix = pattern.split('%')[0].split('*')[0]
                                if prefix and op == '==':
                                    return f'startsWith({field_expr}, "{prefix}") and endsWith({field_expr}, "{value}")'
                    
                    # Fallback: use contains for the value part
                    self.warnings.append(f"aparse() converted to contains() â€” verify match logic")
                    return f'contains({field_expr}, "{value}")'

            left = self._emit_expr(cond.left)
            right = self._emit_expr(cond.right)
            op = '==' if cond.op == '=' else cond.op
            # Smart remap: if filtering http.request.path against a full URL, use http.url
            if left == 'http.request.path' and isinstance(cond.right, LiteralExpr):
                val = str(cond.right.value)
                if val.startswith('http://') or val.startswith('https://'):
                    left = 'http.url'
            return f"{left} {op} {right}"

        if isinstance(cond, IsNullCond):
            expr = self._emit_expr(cond.expr)
            return f"isNotNull({expr})" if cond.negated else f"isNull({expr})"

        if isinstance(cond, InListCond):
            expr = self._emit_expr(cond.expr)
            vals = ', '.join(self._emit_expr(v) for v in cond.values)
            neg = "not " if cond.negated else ""
            return f"{neg}in({expr}, {{{vals}}})"

        if isinstance(cond, LikeCond):
            return self._emit_like(cond)

        if isinstance(cond, RLikeCond):
            expr = self._emit_expr(cond.expr)
            neg = "not " if cond.negated else ""
            # Convert RE2 regex to DPL pattern for matches()
            # DPL uses * for .*, ? for ., no anchoring needed
            dpl_pattern = cond.pattern
            dpl_pattern = dpl_pattern.replace('.*', '*').replace('.+', '?*')
            dpl_pattern = dpl_pattern.replace('.', '?')
            # Strip regex anchors
            dpl_pattern = dpl_pattern.lstrip('^').rstrip('$')
            return f'{neg}matches({expr}, "{dpl_pattern}")'

        if isinstance(cond, InSubqueryCond):
            # Should have been extracted already, but emit as comment if not
            self.warnings.append("InSubqueryCond should have been extracted to lookup")
            return "true"

        return "true"

    def _emit_like(self, cond: LikeCond) -> str:
        """Convert LIKE pattern to DQL contains/startsWith/endsWith."""
        expr = self._emit_expr(cond.expr)
        p = cond.pattern
        neg_wrap = lambda s: f"not({s})" if cond.negated else s

        # Smart remap: if filtering http.request.path against full URL pattern, use http.url
        if expr == 'http.request.path' and (p.startswith('http://') or p.startswith('https://')):
            expr = 'http.url'

        # %pattern% â†’ contains
        if p.startswith('%') and p.endswith('%') and len(p) > 2:
            inner = p[1:-1]
            return neg_wrap(f'contains({expr}, "{inner}")')
        # pattern% â†’ startsWith
        if p.endswith('%') and not p.startswith('%'):
            inner = p[:-1]
            return neg_wrap(f'startsWith(toString({expr}), "{inner}")')
        # %pattern â†’ endsWith
        if p.startswith('%') and not p.endswith('%'):
            inner = p[1:]
            return neg_wrap(f'endsWith(toString({expr}), "{inner}")')
        # No wildcard â†’ exact match
        if '%' not in p:
            op = '!=' if cond.negated else '=='
            return f'{expr} {op} "{p}"'
        # Complex pattern with % in middle â†’ matchesPhrase
        regex = p.replace('%', '.*').replace('_', '.')
        return neg_wrap(f'matchesPhrase({expr}, "{regex}")')

    # â”€â”€ Expressions â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _emit_expr(self, node: ASTNode) -> str:
        if isinstance(node, StarExpr):
            return '*'
        if isinstance(node, LiteralExpr):
            return self._emit_literal(node)
        if isinstance(node, FieldRef):
            return self._map_field(node.name)
        if isinstance(node, FunctionCall):
            return self._emit_function(node)
        if isinstance(node, BinaryOp):
            left = self._emit_expr(node.left)
            right = self._emit_expr(node.right)
            # Simplify duration.ms/1000 â†’ duration (DT duration is a typed field, 
            # no manual msâ†’seconds conversion needed)
            if left == 'duration' and node.op == '/' and right in ('1000', '1000.0'):
                return 'duration'
            # Simplify duration*1000 or similar ms conversions
            if left == 'duration' and node.op == '*' and right in ('1000', '1000.0'):
                return 'duration'
            return f"{left} {node.op} {right}"
        if isinstance(node, UnaryMinus):
            return f"-{self._emit_expr(node.operand)}"
        if isinstance(node, TimeInterval):
            return f"{node.value}"
        if isinstance(node, Condition):
            return self._emit_condition(node)
        return str(node)

    def _emit_literal(self, node: LiteralExpr) -> str:
        if isinstance(node.value, str):
            return f'"{node.value}"'
        if isinstance(node.value, bool):
            return 'true' if node.value else 'false'
        if node.value is None:
            return 'null'
        return str(node.value)

    def _validate_no_nested_aggregations(self, dql: str) -> str:
        """Check emitted DQL for nested aggregation patterns.
        
        DQL error NO_NESTED_AGGREGATIONS occurs when an aggregation function
        contains another aggregation function as an argument. This detects
        common patterns and adds warnings.
        """
        import re as _re
        agg_funcs = ['countIf', 'count', 'sum', 'avg', 'min', 'max', 
                     'percentile', 'median', 'countDistinctExact', 'countDistinctApprox',
                     'collectArray', 'collectDistinct', 'stddev', 'takeAny', 'takeFirst', 'takeLast']
        agg_pattern = '|'.join(_re.escape(f) for f in agg_funcs)
        
        # Find aggregation calls and check if their arguments contain other agg calls
        # Simple heuristic: find funcName( and check if before the matching ) there's another funcName(
        for func in agg_funcs:
            pattern = func + '('
            idx = 0
            while True:
                idx = dql.find(pattern, idx)
                if idx == -1:
                    break
                # Find matching close paren
                depth = 1
                pos = idx + len(pattern)
                while pos < len(dql) and depth > 0:
                    if dql[pos] == '(':
                        depth += 1
                    elif dql[pos] == ')':
                        depth -= 1
                    pos += 1
                # Extract the argument string
                arg_str = dql[idx + len(pattern):pos - 1]
                # Check if it contains another aggregation function call
                for inner_func in agg_funcs:
                    if inner_func + '(' in arg_str:
                        self.warnings.append(
                            f"NESTED AGGREGATION DETECTED: {func}() contains {inner_func}() "
                            f"which DQL will reject with NO_NESTED_AGGREGATIONS. "
                            f"Decompose into: summarize step | fieldsAdd calculation"
                        )
                        break
                idx = pos
        return dql

        # Fields that are custom metric dimensions — do NOT remap in metric context.
    # In METRIC/K8S queries, these are dimension names on custom metrics (e.g.,
    # Confluent Cloud kafka metrics use 'id', 'topic', 'target' as dimensions).
    # In span/log context, they should be mapped normally.
    METRIC_DIMENSION_PASSTHROUGH = {
        'id', 'target', 'topic', 'consumer_group', 'partition',
        'cluster_id', 'principal_id', 'type', 'name', 'mode',
    }

    def _map_field(self, name: str) -> str:
        """Map NR field to DT field, with context awareness.
        
        In METRIC/K8S query contexts, generic dimension field names like
        'id', 'target', 'topic' are preserved as-is because they're custom
        metric dimensions (e.g., Confluent Cloud Kafka metrics).
        
        In span/log contexts, they get mapped normally (e.g., id -> span.id).
        """
        low = name.lower()
        
        # In metric context, don't remap ambiguous dimension names
        query_class = getattr(self, '_query_class', 'spans')
        if query_class in ('METRIC',) or (isinstance(query_class, str) and query_class.startswith('K8S_')):
            if low in self.METRIC_DIMENSION_PASSTHROUGH:
                return name  # Preserve as custom metric dimension
        
        # Check exact match first
        if name in self.field_map:
            return self.field_map[name]
        # Case-insensitive
        if low in self.field_map:
            return self.field_map[low]
        # Pass through unmapped fields
        return name

    # â”€â”€ FACET items â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _emit_facet_items(self, items: List[FacetItem]) -> str:
        """Emit FACET items as DQL by: clause content.
        DQL uses alias=expr, not expr as alias."""
        parts = []
        for item in items:
            expr_str = self._emit_expr(item.expression)
            if item.alias:
                parts.append(f"{self._sanitize_alias(item.alias)}={expr_str}")
            else:
                parts.append(expr_str)
        return ', '.join(parts)

    # â”€â”€ Subquery extraction â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

    def _extract_subqueries(self, cond: Condition) -> Tuple[Optional[Condition], List[InSubqueryCond]]:
        """Extract InSubqueryCond nodes from a condition tree.
        Returns (remaining_condition, [subquery_conditions])."""
        subqueries: List[InSubqueryCond] = []

        def walk(c: Condition) -> Optional[Condition]:
            if isinstance(c, InSubqueryCond):
                subqueries.append(c)
                return None  # Remove from tree
            if isinstance(c, LogicalCond):
                left = walk(c.left)
                right = walk(c.right)
                if left is None and right is None:
                    return None
                if left is None:
                    return right
                if right is None:
                    return left
                return LogicalCond(c.op, left, right)
            if isinstance(c, NotCond):
                inner = walk(c.operand)
                if inner is None:
                    return None
                return NotCond(inner)
            return c

        remaining = walk(cond)
        return remaining, subqueries

    def _emit_lookup(self, sq: InSubqueryCond, parts: List[str]):
        """Emit a DQL lookup command from a subquery IN condition.
        
        IN (subquery)     â†’ lookup + filter isNotNull(sub.field) â€” keep matches
        NOT IN (subquery) â†’ lookup + filter isNull(sub.field)    â€” keep non-matches
        """
        field = self._emit_expr(sq.expr)
        sub = sq.subquery
        sub_from = sub.from_clause.lower().replace('_', '').replace('-', '')
        # Subqueries are always against fetchable types (spans, logs, etc.)
        fetch_map = {'transaction': 'spans', 'span': 'spans', 'log': 'logs',
                     'transactionerror': 'spans', 'pageview': 'bizevents'}
        fetch_type = fetch_map.get(sub_from, 'spans')
        sel_field = self._emit_expr(sub.select_items[0].expression)

        sub_filter = ''
        if sub.where_clause:
            sub_filter = f" | filter {self._emit_condition(sub.where_clause)}"

        parts.append(
            f'| lookup [fetch {fetch_type}{sub_filter} | fields {sel_field}], '
            f'sourceField:{field}, lookupField:{sel_field}, prefix:"sub."'
        )
        
        # IN â†’ keep matched rows; NOT IN â†’ keep unmatched rows
        null_check = 'isNull' if sq.negated else 'isNotNull'
        parts.append(f'| filter {null_check}(sub.{sel_field})')


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# SECTION 5: COMPILER ORCHESTRATOR
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

@dataclass
class CompileResult:
    success: bool
    dql: str = ''
    confidence: str = 'HIGH'
    warnings: List[str] = field(default_factory=list)
    fixes: List[str] = field(default_factory=list)
    error: str = ''
    ast: Optional[Query] = None
    original_nrql: str = ''


class NRQLCompiler:
    """
    Top-level compiler: NRQL string â†’ DQL string.

    Orchestrates: Lexer â†’ Parser â†’ DQLEmitter
    Handles errors gracefully and provides diagnostic info.

    Usage:
        compiler = NRQLCompiler()
        result = compiler.compile("SELECT count(*) FROM Transaction WHERE appName = 'x' TIMESERIES")
        if result.success:
            print(result.dql)
    """

    def __init__(self, field_map: Dict[str, str] = None, metric_map: Dict[str, str] = None,
                 metric_transforms: Dict[str, Dict] = None, metric_resolver=None):
        self.field_map = field_map or {}
        self.metric_map = metric_map or {}
        self.metric_transforms = metric_transforms or {}
        self.metric_resolver = metric_resolver  # callable(field_key, raw_field, static_mapped) â†’ (dt_metric, warning)

    def compile(self, nrql: str, title: str = '') -> CompileResult:
        """Compile NRQL to DQL."""
        result = CompileResult(success=False, original_nrql=nrql)

        # Phase 0: Expand NR shorthand metrics before lexing
        # NR has magic field names that are actually function(field) shorthands
        nrql = self._expand_nr_shorthands(nrql)

        # Phase 1: Lex
        try:
            lexer = NRQLLexer(nrql)
            tokens = lexer.tokenize()
        except LexError as e:
            result.error = f"Lexer error: {e}"
            return result

        # Phase 2: Parse
        try:
            parser = NRQLParser(tokens)
            ast = parser.parse()
            result.ast = ast
        except ParseError as e:
            result.error = f"Parse error: {e}"
            return result

        # Phase 3: Emit DQL
        try:
            emitter = DQLEmitter(field_map=self.field_map, metric_map=self.metric_map,
                                 metric_transforms=self.metric_transforms,
                                 metric_resolver=self.metric_resolver)
            dql = emitter.emit(ast)
            # Collapse NRQL to single line so the comment never leaks raw code
            nrql_oneline = ' '.join(nrql.split())
            result.dql = f"// Original NRQL: {nrql_oneline}\n{dql}"
            result.warnings = emitter.warnings
            result.success = True
            result.confidence = 'HIGH'

            # Downgrade confidence if there are warnings
            if any('not directly supported' in w for w in result.warnings):
                result.confidence = 'MEDIUM'

        except Exception as e:
            result.error = f"Emitter error: {e}"
            return result

        # Phase 4: DQL Syntax Validation
        # Catch known invalid patterns BEFORE the query reaches Dynatrace
        result.dql, validation_fixes = self._validate_dql(result.dql)
        if validation_fixes:
            result.fixes = (result.fixes or []) + validation_fixes

        return result

    @staticmethod
    def _expand_nr_shorthands(nrql: str) -> str:
        """
        Expand NR shorthand metric names into function(field) calls.
        
        NR has magic field names in SELECT that are actually aggregation shorthands:
          averageduration    â†’ average(duration)
          averageResponseTime â†’ average(duration)  (same underlying metric)
          maxduration        â†’ max(duration)
          minduration        â†’ min(duration)
          medianDuration     â†’ median(duration)
          
        These appear as bare identifiers without parentheses and would otherwise
        be treated as field references by the parser.
        """
        import re
        # Map of shorthand â†’ expanded form
        # Use word boundary to avoid matching inside longer identifiers
        shorthands = {
            r'\baverage[Dd]uration\b': 'average(duration)',
            r'\baverage[Rr]esponse[Tt]ime\b': 'average(duration)',
            r'\bmax[Dd]uration\b': 'max(duration)',
            r'\bmin[Dd]uration\b': 'min(duration)',
            r'\bmedian[Dd]uration\b': 'median(duration)',
            r'\bapdex[Ss]core\b': 'apdex(duration)',
            r'\bapdex[Pp]erf[Zz]one\b': 'apdex(duration)',
            r'\berror[Rr]ate\b': 'percentage(count(*), WHERE error IS TRUE)',
            r'\bthroughput\b': 'rate(count(*), 1 minute)',
        }
        
        for pattern, replacement in shorthands.items():
            nrql = re.sub(pattern, replacement, nrql)
        
        return nrql

    @staticmethod
    def _ms_to_duration_literal(ms: float) -> str:
        """Convert milliseconds to the most readable DQL duration literal.
        
        DQL supports: ns, us, ms, s, m, h, d
        Examples: 2000ms â†’ 2s, 500ms â†’ 500ms, 60000ms â†’ 1m, 100ms â†’ 100ms
        """
        if ms <= 0:
            return "0s"
        # Try to find the cleanest unit
        if ms >= 86_400_000 and ms % 86_400_000 == 0:
            return f"{int(ms // 86_400_000)}d"
        if ms >= 3_600_000 and ms % 3_600_000 == 0:
            return f"{int(ms // 3_600_000)}h"
        if ms >= 60_000 and ms % 60_000 == 0:
            return f"{int(ms // 60_000)}m"
        if ms >= 1000 and ms % 1000 == 0:
            return f"{int(ms // 1000)}s"
        if ms == int(ms):
            return f"{int(ms)}ms"
        # Sub-millisecond: use microseconds
        us = ms * 1000
        if us == int(us):
            return f"{int(us)}us"
        return f"{ms}ms"

    def _validate_dql(self, dql: str) -> Tuple[str, List[str]]:
        """Post-compilation DQL syntax validator.
        
        Catches known invalid patterns and auto-corrects them:
        - Bare fields in summarize/makeTimeseries (must be aggregation functions)
        - shift: parameter on makeTimeseries (only valid on timeseries command)
        - Invalid parameter names
        - Empty aggregation lists
        - Duration unit mismatch (NR milliseconds â†’ DT nanoseconds)
        
        Returns (corrected_dql, list_of_fixes_applied).
        """
        fixes = []
        lines = dql.split('\n')
        new_lines = []
        
        # Determine if this is a span query (duration in nanoseconds)
        full_dql = '\n'.join(lines)
        is_span_query = 'fetch spans' in full_dql
        
        for line in lines:
            stripped = line.strip()
            
            # Skip comments
            if stripped.startswith('//'):
                new_lines.append(line)
                continue
            
            # â”€â”€ Check 1: shift: on makeTimeseries (invalid â€” only timeseries supports it)
            if '| makeTimeseries' in line and 'shift:' in line:
                # Remove shift: parameter
                fixed = re.sub(r',\s*shift:[^\s,]+', '', line)
                if fixed != line:
                    fixes.append("Removed invalid shift: from makeTimeseries (only timeseries command supports shift:)")
                    line = fixed
            
            # â”€â”€ Check 2: Bare fields in summarize/makeTimeseries
            # Pattern: "| summarize fieldName" where fieldName is not a function call
            m = re.match(r'^(\s*\|\s*(?:summarize|makeTimeseries)\s+)(.*)', line)
            if m:
                prefix = m.group(1)
                agg_part = m.group(2)
                # Check if the aggregation part contains at least one function call
                # Valid: count(), avg(duration), name=count()
                # Invalid: duration, span.name, service.name
                if agg_part and not re.search(r'[a-zA-Z_]\w*\s*\(', agg_part):
                    # No function call found â€” these are bare fields
                    # Convert to | fields instead
                    fields = agg_part.split(',')
                    # Strip any by: clause
                    field_names = []
                    by_part = ''
                    for f in fields:
                        f = f.strip()
                        if f.startswith('by:'):
                            by_part = f', {f}'
                        else:
                            field_names.append(f)
                    if field_names:
                        line = f"| fields {', '.join(field_names)}"
                        fixes.append(f"Corrected bare fields in summarize â†’ | fields ('{', '.join(field_names)}' are not aggregations)")
            
            # â”€â”€ Check 3: Duration unit conversion (NR ms â†’ DT duration literals)
            # DT's `duration` field is a DURATION TYPE, not a raw integer.
            # Comparisons and bin() need duration literals: 2s, 500ms, etc.
            # NR duration is in MILLISECONDS.
            # Safe patterns matched:
            #   duration >= 2000  â†’ duration >= 2s
            #   bin(duration, 2000) â†’ bin(duration, 2s)
            # NOT matched (safe):
            #   percentile(duration, 95) â€” 95 is percentile %, not duration
            #   avg(duration) â€” no literal to convert
            if is_span_query:
                # Convert duration comparison literals to DQL duration literals
                def _dur_cmp(m):
                    op, val_str = m.group(1), m.group(2)
                    ms = float(val_str)
                    lit = NRQLCompiler._ms_to_duration_literal(ms)
                    fixes.append(f"Duration: {val_str}ms â†’ {lit}")
                    return f"duration {op} {lit}"
                line = re.sub(
                    r'(?<![.\w])duration\s*(>=|<=|>|<|==|!=)\s*(\d+(?:\.\d+)?)',
                    _dur_cmp, line)
                
                # Convert bin(duration, width) to use duration literals
                def _dur_bin(m):
                    ms = float(m.group(1))
                    lit = NRQLCompiler._ms_to_duration_literal(ms)
                    fixes.append(f"Duration bin: {ms}ms â†’ {lit}")
                    return f"bin(duration, {lit})"
                line = re.sub(
                    r'bin\(\s*duration\s*,\s*(\d+(?:\.\d+)?)\s*\)',
                    _dur_bin, line)
            
            new_lines.append(line)
        
        return '\n'.join(new_lines), fixes

    def parse_only(self, nrql: str) -> Tuple[Optional[Query], str]:
        """Parse NRQL to AST without emitting DQL. Useful for analysis."""
        try:
            tokens = NRQLLexer(nrql).tokenize()
            ast = NRQLParser(tokens).parse()
            return ast, ''
        except (LexError, ParseError) as e:
            return None, str(e)


# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
# SECTION 6: TESTS
# â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

def run_tests():
    """Comprehensive test suite."""
    compiler = NRQLCompiler()
    passed = 0
    failed = 0
    total = 0

    def test(name: str, nrql: str, checks: List[callable], expect_success: bool = True):
        nonlocal passed, failed, total
        total += 1
        result = compiler.compile(nrql)

        if result.success != expect_success:
            print(f"  âŒ {name}")
            print(f"     Expected success={expect_success}, got {result.success}")
            if result.error:
                print(f"     Error: {result.error}")
            if result.dql:
                print(f"     DQL: {result.dql[:120]}")
            failed += 1
            return

        all_ok = True
        for check_fn in checks:
            try:
                check_fn(result)
            except AssertionError as e:
                if all_ok:
                    print(f"  âŒ {name}")
                print(f"     Check failed: {e}")
                all_ok = False

        if all_ok:
            print(f"  âœ… {name}")
            passed += 1
        else:
            dql_lines = [l for l in result.dql.split('\n') if not l.startswith('//')]
            for l in dql_lines:
                if l.strip():
                    print(f"     {l}")
            failed += 1

    def dql_has(text):
        def check(r):
            assert text in r.dql, f"Expected '{text}' in DQL"
        return check

    def dql_not_has(text):
        def check(r):
            assert text not in r.dql, f"Did not expect '{text}' in DQL"
        return check

    def code_has(text):
        """Check non-comment lines of DQL."""
        def check(r):
            code = '\n'.join(l for l in r.dql.split('\n') if not l.strip().startswith('//'))
            assert text in code, f"Expected '{text}' in DQL code lines"
        return check

    def code_not_has(text):
        def check(r):
            code = '\n'.join(l for l in r.dql.split('\n') if not l.strip().startswith('//'))
            assert text not in code, f"Did not expect '{text}' in DQL code lines"
        return check

    def no_dup_count():
        def check(r):
            code = '\n'.join(l for l in r.dql.split('\n') if 'makeTimeseries' in l or 'summarize' in l)
            count_occurrences = code.count('count()')
            assert count_occurrences <= 1, f"Found {count_occurrences} count() in aggregation line: {code}"
        return check

    print("=" * 80)
    print("  NRQL COMPILER TEST SUITE")
    print("=" * 80)

    # â”€â”€ GROUP 1: The 5 Original Bugs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 1: The 5 Original Bugs")
    print("  " + "-" * 40)

    test("Bug1: Duplicate count() dedup",
         "SELECT count(*) as total, count(*) as success FROM Transaction "
         "WHERE appName = 'prod-usf-auth-api' AND request.headers.kind = 'server' "
         "AND net.protocol.name = 'http' TIMESERIES",
         [dql_has('makeTimeseries'), dql_has('total=count()'), dql_has('success=count()')])

    test("Bug2: percentile naming",
         "SELECT percentile(duration, 99) FROM Transaction "
         "WHERE appName = 'prod-usf-auth-api' AND kind = 'client' FACET http.url TIMESERIES",
         [dql_has('p99=percentile(duration, 99)'), dql_has('by:')])

    test("Bug3: Triple count() â†’ single",
         "SELECT count(*), count(*), count(*) FROM Transaction "
         "WHERE appName = 'prod-usf-user-domain-api' TIMESERIES",
         [no_dup_count()])

    test("Bug4: Subquery â†’ lookup",
         "SELECT count(*) FROM Transaction WHERE appName = 'prod-usf-auth-api' "
         "AND http.route = '/auth-api/v1/oauth/token' "
         "AND trace.id IN (FROM Span SELECT trace.id WHERE appName = 'prod-usf-auth-api' "
         "AND grant_type = 'punchthru') FACET httpResponseCode TIMESERIES",
         [code_has('lookup [fetch spans'), code_has('isNotNull(sub.trace.id)'),
          code_not_has('FROM Span SELECT')])

    test("Bug5: as alias â†’ alias=expr",
         "SELECT count(*) as Occurrences, max(timestamp) as Latest FROM Log "
         "WHERE service.name = 'prod-usf-user-integration-api' AND level = 'ERROR' "
         "FACET substring(logger, indexOf(logger, '.', -1) + 1) as Logger, "
         "error.message as Message",
         [code_has('Logger=substring'), code_has('Message=error.message'),
          code_not_has(' as Logger'), code_not_has(' as Message')])

    # â”€â”€ GROUP 2: Core Conversions â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 2: Core Conversions")
    print("  " + "-" * 40)

    test("Simple count",
         "SELECT count(*) FROM Transaction WHERE appName = 'my-api' TIMESERIES",
         [dql_has('fetch spans'), dql_has('service.name == "my-api"'), dql_has('makeTimeseries count()')])

    test("Average with FACET",
         "SELECT average(duration) FROM Transaction WHERE appName = 'api' FACET name TIMESERIES",
         [dql_has('avg(duration)'), dql_has('by: {span.name}')])

    test("Non-timeseries aggregation",
         "SELECT count(*), average(duration) FROM Transaction WHERE appName = 'api'",
         [dql_has('summarize'), dql_not_has('makeTimeseries')])

    test("Log query",
         "SELECT count(*) FROM Log WHERE level = 'ERROR' AND message LIKE '%timeout%'",
         [dql_has('fetch logs'), dql_has('loglevel == "ERROR"'),
          dql_has('contains(content, "timeout")')])

    test("Multiple aggregations",
         "SELECT count(*), average(duration), max(duration) FROM Transaction TIMESERIES",
         [dql_has('makeTimeseries {count(), avg(duration), max(duration)}')])

    test("uniqueCount â†’ countDistinctExact",
         "SELECT uniqueCount(host) FROM Transaction WHERE appName = 'api'",
         [dql_has('countDistinctExact(host.name)')])

    test("Field mapping: httpResponseCode",
         "SELECT count(*) FROM Transaction WHERE httpResponseCode >= 500 TIMESERIES",
         [dql_has('http.response.status_code >= 500')])

    # â”€â”€ GROUP 3: NR-Specific Functions â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 3: NR-Specific Functions")
    print("  " + "-" * 40)

    test("percentage() â†’ countIf/count",
         "SELECT percentage(count(*), WHERE duration > 1) FROM Transaction TIMESERIES",
         [dql_has('countIf(duration > 1ms)'), dql_has('fieldsAdd'),
          dql_has('toDouble')])

    test("filter() â†’ funcIf",
         "SELECT filter(count(*), WHERE httpResponseCode >= 500) FROM Transaction TIMESERIES",
         [dql_has('countIf(http.response.status_code >= 500)')])

    test("filter(average) â†’ avgIf",
         "SELECT filter(average(duration), WHERE error IS NOT NULL) FROM Transaction TIMESERIES",
         [dql_has('avgIf(duration, isNotNull(error))')])

    test("rate() â†’ count with warning",
         "SELECT rate(count(*), 1 minute) FROM Transaction TIMESERIES",
         [dql_has('count()'),
          lambda r: r.warnings and any('rate()' in w for w in r.warnings)])

    test("Multi-percentile expansion",
         "SELECT percentile(duration, 50, 90, 95, 99) FROM Transaction TIMESERIES",
         [dql_has('p50=percentile(duration, 50)'), dql_has('p99=percentile(duration, 99)')])

    test("median â†’ percentile 50",
         "SELECT median(duration) FROM Transaction TIMESERIES",
         [dql_has('percentile(duration, 50)')])

    # â”€â”€ GROUP 4: Conditions â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 4: Conditions")
    print("  " + "-" * 40)

    test("= â†’ ==",
         "SELECT count(*) FROM Transaction WHERE appName = 'x'",
         [dql_has('service.name == "x"')])

    test("IS NULL / IS NOT NULL",
         "SELECT count(*) FROM Transaction WHERE error IS NOT NULL AND host IS NULL",
         [dql_has('isNotNull(error)'), dql_has('isNull(host.name)')])

    test("IN list",
         "SELECT count(*) FROM Transaction WHERE appName IN ('a', 'b', 'c')",
         [dql_has('in(service.name, {"a", "b", "c"})')])

    test("NOT IN",
         "SELECT count(*) FROM Transaction WHERE appName NOT IN ('x')",
         [dql_has('not in(service.name, {"x"})')])

    test("LIKE patterns: contains",
         "SELECT count(*) FROM Transaction WHERE name LIKE '%payment%'",
         [dql_has('contains(span.name, "payment")')])

    test("LIKE patterns: startsWith",
         "SELECT count(*) FROM Transaction WHERE httpResponseCode LIKE '2%'",
         [dql_has('startsWith(toString(http.response.status_code), "2")')])

    test("Complex AND/OR",
         "SELECT count(*) FROM Transaction WHERE (appName = 'a' OR appName = 'b') AND error IS NOT NULL",
         [dql_has('service.name == "a" or service.name == "b"'), dql_has('isNotNull(error)')])

    # â”€â”€ GROUP 5: Arithmetic Expressions â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 5: Arithmetic Expressions")
    print("  " + "-" * 40)

    test("Error percentage calculation",
         "SELECT filter(count(*), WHERE httpResponseCode >= 500) / "
         "filter(count(*), WHERE httpResponseCode IS NOT NULL) * 100 "
         "FROM Transaction TIMESERIES",
         [dql_has('countIf(http.response.status_code >= 500)'),
          dql_has('countIf(isNotNull(http.response.status_code))'),
          dql_has('* 100')])

    test("Unary minus",
         "SELECT count(*) FROM Transaction WHERE duration > -1",
         [dql_has('duration > -1')])

    # â”€â”€ GROUP 6: Edge Cases â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 6: Edge Cases")
    print("  " + "-" * 40)

    test("LIMIT clause",
         "SELECT count(*) FROM Transaction FACET appName LIMIT 20",
         [dql_has('limit 20')])

    test("ORDER BY",
         "SELECT count(*) FROM Transaction FACET appName ORDER BY count(*) DESC",
         [dql_has('sort count() desc')])

    test("SINCE/UNTIL are captured (not emitted to DQL)",
         "SELECT count(*) FROM Transaction SINCE 1 hour ago UNTIL 5 minutes ago TIMESERIES",
         [dql_has('makeTimeseries count()'),
          lambda r: r.ast and r.ast.since_raw == '1 hour ago'])

    test("Backtick-quoted field",
         "SELECT average(`k8s.container.cpuUsedCores`) FROM Metric WHERE appName = 'api'",
         [dql_has('avg(k8s.container.cpuUsedCores)')])

    test("String with escaped quotes",
         "SELECT count(*) FROM Transaction WHERE name = 'it''s a test'",
         [dql_has("""it's a test""")])

    test("Multiple FACET items with aliases",
         "SELECT count(*) FROM Transaction FACET appName as Service, host as Host",
         [dql_has('Service=service.name'), dql_has('Host=host.name')])

    test("Empty count star",
         "SELECT count(*) FROM Log",
         [dql_has('fetch logs'), dql_has('count()')])

    test("Boolean comparison",
         "SELECT count(*) FROM Transaction WHERE error = true TIMESERIES",
         [dql_has('error == true')])

    # â”€â”€ GROUP 7: Real-World Complex Queries â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 7: Real-World Complex Queries")
    print("  " + "-" * 40)

    test("Auth API P99 latency by URL path (Bug2 variant)",
         "SELECT percentile(duration, 99) FROM Transaction "
         "WHERE appName = 'prod-usf-auth-api' AND span.kind = 'client' "
         "AND net.protocol.name = 'http' "
         "AND NOT name LIKE '%userpassword%' AND name LIKE '%panamax%' "
         "FACET http.url TIMESERIES",
         [dql_has('p99=percentile(duration, 99)'),
          code_has('not(contains(span.name, "userpassword"))'),
          code_has('contains(span.name, "panamax")')])

    test("User domain server count (Bug3 variant)",
         "SELECT count(*) FROM Transaction WHERE appName = 'prod-usf-user-domain-api' "
         "AND span.kind = 'server' TIMESERIES",
         [dql_has('makeTimeseries count()'), dql_has('span.kind == "server"')])

    test("Integration API error log analysis (Bug5 variant)",
         "SELECT count(*) as Occurrences, max(timestamp) as Latest FROM Log "
         "WHERE service.name = 'prod-usf-user-integration-api' AND level = 'ERROR' "
         "FACET substring(logger, indexOf(logger, '.', -1) + 1) as Logger, "
         "error.message as Message",
         [dql_has('Occurrences=count()'), dql_has('Latest=max(timestamp)'),
          code_has('Logger=substring'), code_has('Message=error.message')])

    # â”€â”€ GROUP 8: Metric Queries (timeseries command) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 8: Metric Queries")
    print("  " + "-" * 40)

    test("SystemSample â†’ timeseries",
         "SELECT average(cpuPercent) FROM SystemSample WHERE hostname = 'web-1' TIMESERIES",
         [dql_has('timeseries avg('), code_not_has('fetch'), code_not_has('makeTimeseries')])

    test("SystemSample memory",
         "SELECT average(memoryUsedPercent) FROM SystemSample FACET hostname TIMESERIES",
         [dql_has('timeseries avg('), dql_has('by: {host.name}')])

    test("Metric query passthrough",
         "SELECT sum(cpuPercent) FROM Metric WHERE appName = 'api' TIMESERIES",
         [dql_has('timeseries sum(')])

    test("latest() on metric â†’ avg()",
         "SELECT latest(cpuPercent) FROM SystemSample FACET hostname",
         [dql_has('timeseries avg(')])

    # â”€â”€ GROUP 9: K8s Queries â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 9: K8s Queries")
    print("  " + "-" * 40)

    test("K8sNodeSample basic",
         "SELECT latest(memoryUsedBytes) FROM K8sNodeSample FACET nodeName TIMESERIES",
         [dql_has('timeseries avg('), dql_has('by: {k8s.node.name}')])

    test("K8sContainerSample",
         "SELECT average(cpuUsedCores) FROM K8sContainerSample FACET containerName TIMESERIES",
         [dql_has('timeseries'), dql_has('by: {k8s.container.name}')])

    test("K8s metric filter stripping",
         "SELECT latest(allocatableMemoryUtilization) FROM K8sNodeSample "
         "WHERE allocatableMemoryUtilization < 90 AND clusterName = 'prod' FACET nodeName",
         [dql_has('k8s.cluster.name'), code_not_has('allocatableMemoryUtilization <')])

    test("K8s computed metric: (latest(a)/latest(b))*100",
         "SELECT (latest(fsInodesUsed)/latest(fsInodes))*100 as fsInodeCapacityUtilization "
         "FROM K8sNodeSample WHERE clusterName = 'prod' FACET nodeName TIMESERIES",
         [dql_has('timeseries'), dql_has('fieldsAdd'),
          dql_has('fsInodeCapacityUtilization'), dql_has('toDouble'),
          code_not_has('fetch'), code_not_has('makeTimeseries')])

    test("K8s computed + bare aggs + parenthesized WHERE arithmetic",
         "SELECT (latest(fsInodesUsed)/latest(fsInodes))*100 as fsInodeCapacityUtilization, "
         "latest(fsInodesUsed), latest(fsInodes) FROM K8sNodeSample "
         "WHERE (fsInodesUsed/fsInodes)*100 < 90 AND clusterName LIKE 'usf-moxe%' "
         "FACET nodeName TIMESERIES",
         [dql_has('timeseries'), dql_has('fieldsAdd'),
          dql_has('fsInodeCapacityUtilization'), dql_has('toDouble')])

    # â”€â”€ GROUP 10: Events Queries â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 10: Events & Special Types")
    print("  " + "-" * 40)

    test("InfrastructureEvent â†’ fetch events",
         "SELECT summary, category FROM InfrastructureEvent WHERE category = 'kubernetes' LIMIT 50",
         [dql_has('fetch events'), dql_has('filter'), dql_has('limit 50')])

    test("histogram() â†’ count() with bin() for categoricalBarChart",
         "SELECT histogram(duration) FROM Transaction WHERE appName = 'api'",
         [dql_has('fetch spans'), dql_has('count()'), dql_has('bin(duration'),
          lambda r: any('histogram' in w for w in r.warnings)])

    test("PageView browser query",
         "SELECT count(*) FROM PageView WHERE pageUrl LIKE '%checkout%' FACET userAgentName",
         [dql_has('fetch bizevents'), dql_has('page.url'), dql_has('browser.name')])

    # â”€â”€ GROUP 11: Structural completeness â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 11: Structural Completeness")
    print("  " + "-" * 40)

    test("COMPARE WITH â†’ warning (makeTimeseries lacks shift:)",
         "SELECT count(*) FROM Transaction COMPARE WITH 1 week ago TIMESERIES",
         [dql_not_has('shift:'), lambda r: any('COMPARE WITH' in w for w in r.warnings)])

    test("EXTRAPOLATE â†’ full fidelity comment",
         "SELECT count(*) FROM Transaction EXTRAPOLATE",
         [dql_has('full fidelity'), lambda r: any('EXTRAPOLATE' in w for w in r.warnings)])

    test("WITH...AS CTE â†’ inlined",
         "WITH errors AS (SELECT count(*) FROM TransactionError WHERE appName = 'api') "
         "SELECT count(*) FROM errors WHERE error.class = 'TimeoutError'",
         [dql_has('fetch spans'), dql_has('service.name == \"api\"'), dql_has('error.class')])

    test("apdex() â†’ calculated approximation",
         "SELECT apdex(0.5) FROM Transaction WHERE appName = 'api'",
         [dql_has('countIf'), dql_has('duration'), lambda r: any('apdex' in w for w in r.warnings)])

    test("FACET CASES â†’ fieldsAdd + by:{col}",
         "SELECT count(*) FROM Transaction FACET CASES(WHERE duration < 0.5 AS 'Fast', "
         "WHERE duration < 2 AS 'Normal', WHERE duration >= 2 AS 'Slow')",
         [dql_has('fieldsAdd'), dql_has('if('), dql_has('"Fast"'), dql_has('by: {_category_')])

    # â”€â”€ GROUP 12: Real-world parser gaps (from --all run) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 12: Real-World Parser Gaps")
    print("  " + "-" * 40)

    test("FROM-first syntax: FROM Span SELECT",
         "FROM Span SELECT count(*) WHERE entity.name = 'my-api' FACET http.route TIMESERIES",
         [dql_has('fetch spans'), dql_has('makeTimeseries'), dql_has('dt.entity.name')])

    test("FROM Log SELECT",
         "FROM Log SELECT count(*) WHERE container_name = 'nginx' FACET level",
         [dql_has('fetch logs'), dql_has('container_name')])

    test("FROM Metric SELECT",
         "FROM Metric SELECT average(apm.service.transaction.duration) WHERE appName = 'api'",
         [dql_has('timeseries'), dql_has('service.name')])

    test("SQL comments stripped",
         "SELECT average(duration) -- this is a comment\nFROM Transaction WHERE appName = 'api'",
         [dql_has('fetch spans'), dql_has('avg(duration)')])

    test("Semicolons ignored",
         "SELECT count(*) FROM Transaction WHERE appName = 'api';",
         [dql_has('fetch spans'), dql_has('count()')])

    test("Scientific notation 10e8",
         "SELECT rate((bytecountestimate() / 10e8) * .30, 1 month) FROM Span",
         [lambda r: r.success])

    test("IS TRUE / IS FALSE",
         "SELECT count(*) FROM TransactionError WHERE error IS NOT FALSE AND appId IN ('123')",
         [dql_has('error != false'), dql_has("appId")])

    test("OR coalesce in function args",
         "SELECT average(memoryFreePercent OR memoryFreeBytes/memoryTotalBytes*100) FROM SystemSample TIMESERIES FACET hostname",
         [lambda r: r.success, dql_has('timeseries')])

    test("FROM Span SELECT with aliases",
         "FROM Span SELECT count(*) AS 'Total', average(duration.ms) AS 'Avg' WHERE entity.name = 'api' COMPARE WITH 1 week ago",
         [dql_has('fetch spans'), dql_has('Total=count()'), 
          lambda r: any('COMPARE WITH' in w for w in r.warnings)])

    test("CASES in mid-FACET position",
         "SELECT count(*) FROM Span WHERE http.route = '/api' FACET http.statusCode, "
         "CASES(WHERE http.statusCode >= 200 AND http.statusCode < 400 AS 'Success', "
         "WHERE http.statusCode >= 400 AS 'Error') COMPARE WITH 1 week ago",
         [dql_has('fetch spans'), dql_has('if('), dql_has('"Success"')])

    test("WITH inline FROM-first (aparse computed column)",
         "FROM Span WITH aparse(host.name, 'search-cron-*-job%') AS (job) "
         "SELECT average(duration.ms) WHERE service.name = 'api'",
         [dql_has('fetch spans'), dql_has('avg(duration)')])

    test("WITH inline SELECT-first",
         "SELECT average(k8s.container.cpuUsedCores) FROM Metric "
         "WITH aparse(k8s.jobName, 'search-cron-*') AS (job) WHERE containerName = 'api'",
         [lambda r: r.success, dql_has('timeseries')])

    test("Template variables {{var}}",
         "SELECT average(k8s.container.cpuUsedCores) FROM Metric "
         "WHERE k8s.containerName = {{api}} AND k8s.clusterName = 'prod'",
         [lambda r: r.success, dql_has('timeseries')])

    test("Bracket access field['key']",
         "SELECT sum(apm.service.error.count['count']) / count(apm.service.transaction.duration) "
         "FROM Metric WHERE appName = 'api'",
         [lambda r: r.success, dql_has('timeseries')])

    test("if(condition, trueVal, falseVal) in SELECT",
         "FROM Log SELECT trace.id, level, if(level='ERROR', context, '') as error "
         "WHERE service.name = 'api' LIMIT 20",
         [dql_has('fetch logs'), dql_has('if('), dql_has('limit 20')])

    # â”€â”€ GROUP 10: Phase 1 â€” SLIDE BY, derivative, jparse, FACET ORDER BY â”€
    print("\n  Group 10: Phase 1 â€” HIGH Priority Gaps")
    print("  " + "-" * 40)

    test("SLIDE BY clause",
         "SELECT average(duration) FROM Transaction TIMESERIES 5 minutes SLIDE BY 1 minute",
         [lambda r: r.success, dql_has('rolling('), dql_has('interval: 1m')])

    test("SLIDE BY AUTO",
         "SELECT average(duration) FROM Transaction TIMESERIES 5 minutes SLIDE BY AUTO",
         [lambda r: r.success, dql_has('rolling(')])

    test("SLIDE BY MAX",
         "SELECT average(duration) FROM Transaction TIMESERIES 5 minutes SLIDE BY MAX",
         [lambda r: r.success, dql_has('rolling(')])

    test("TIMESERIES MAX (no SLIDE BY)",
         "SELECT average(duration) FROM Transaction TIMESERIES MAX",
         [lambda r: r.success])

    test("derivative() function",
         "SELECT derivative(count(*), 1 minute) FROM Transaction TIMESERIES",
         [lambda r: r.success, dql_has('delta(')])

    test("derivative() simple",
         "FROM Metric SELECT derivative(apm.service.transaction.duration) TIMESERIES",
         [lambda r: r.success, dql_has('delta(')])

    test("jparse() with path",
         "FROM Log SELECT jparse(message, '$.error.code') WHERE service.name = 'api'",
         [lambda r: r.success, dql_has('[`error.code`]')])

    test("jparse() simple",
         "FROM Log SELECT jparse(message) WHERE level = 'ERROR'",
         [lambda r: r.success])

    test("FACET ORDER BY aggregate",
         "FROM Transaction SELECT average(duration) TIMESERIES FACET appName ORDER BY max(responseSize)",
         [lambda r: r.success, dql_has('FACET ORDER BY')])

    test("FACET ORDER BY preserves sort",
         "SELECT count(*) FROM Transaction FACET appName ORDER BY count(*) DESC",
         [dql_has('sort count() desc'), dql_has('FACET ORDER BY')])

    # â”€â”€ GROUP 11: Phase 2 â€” JOIN, clamp, buckets, cdf, etc. â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 11: Phase 2 â€” MEDIUM Priority Gaps")
    print("  " + "-" * 40)

    test("clamp_max()",
         "SELECT clamp_max(average(duration), 10) FROM Transaction",
         [lambda r: r.success, dql_has('if(avg(duration) > 10, 10, else:avg(duration))')])

    test("clamp_min()",
         "SELECT clamp_min(average(duration), 1) FROM Transaction",
         [lambda r: r.success, dql_has('if(avg(duration) < 1, 1, else:avg(duration))')])

    test("clamp_max + clamp_min combined",
         "SELECT clamp_max(average(duration), 10), clamp_min(average(duration), 1) FROM Transaction",
         [lambda r: r.success, dql_has('if('), dql_has('> 10'), dql_has('< 1')])

    test("cdfPercentage()",
         "FROM PageView SELECT cdfPercentage(firstPaint, 0.5, 1.0)",
         [lambda r: r.success, dql_has('countIf('), dql_has('<= 0.5'), dql_has('<= 1.0')])

    test("bucketPercentile() with specific percentiles",
         "SELECT bucketPercentile(duration_bucket, 50, 75, 90) FROM Metric",
         [lambda r: r.success, dql_has('percentile(')])

    test("bucketPercentile() default percentiles",
         "SELECT bucketPercentile(duration_bucket) FROM Metric",
         [lambda r: r.success, dql_has('percentile(duration_bucket')])

    test("getField()",
         "SELECT getField(percentile(duration, 95), '95.0') FROM Transaction",
         [lambda r: r.success, dql_has('[`95.0`]')])

    test("INNER JOIN with subquery",
         "FROM PageView JOIN (FROM PageAction SELECT count(*) FACET session, currentUrl) ON session "
         "SELECT count(*) FACET browserTransactionName",
         [lambda r: r.success, dql_has('lookup')])

    test("LEFT JOIN with subquery",
         "FROM PageView LEFT JOIN (FROM PageAction SELECT count(*) FACET session) ON session "
         "SELECT count(*) FACET browserTransactionName",
         [lambda r: r.success, dql_has('lookup'), dql_has('LEFT')])

    test("JOIN with different keys",
         "FROM Transaction JOIN (FROM Metric SELECT average(duration) FACET appName) ON name = appName "
         "SELECT average(duration)",
         [lambda r: r.success, dql_has('lookup')])

    # â”€â”€ GROUP 12: Phase 3 â€” LOW Priority Gaps â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 12: Phase 3 â€” LOW Priority Gaps")
    print("  " + "-" * 40)

    test("WITH TIMEZONE",
         "SELECT count(*) FROM Transaction SINCE Monday UNTIL Tuesday WITH TIMEZONE 'America/New_York'",
         [lambda r: r.success, dql_has("America/New_York")])

    test("PREDICT clause",
         "FROM Transaction SELECT count(*) WHERE error IS TRUE TIMESERIES PREDICT",
         [lambda r: r.success, dql_has('PREDICT'), dql_has('Davis AI')])

    test("SHOW EVENT TYPES",
         "SHOW EVENT TYPES SINCE 1 day ago",
         [lambda r: r.success, dql_has('SHOW EVENT TYPES'), dql_has('Schema browser')])

    test("ln() â†’ log()",
         "SELECT ln(duration) FROM Transaction LIMIT 10",
         [lambda r: r.success, dql_has('log(duration)')])

    test("cardinality()",
         "SELECT cardinality(appName) FROM Transaction",
         [lambda r: r.success, dql_has('countDistinct(')])

    test("predictLinear()",
         "SELECT predictLinear(cpuPercent, 3600) FROM SystemSample",
         [lambda r: r.success])

    test("blob() passthrough",
         "SELECT blob(message) FROM Log LIMIT 5",
         [lambda r: r.success])

    test("mapKeys() passthrough",
         "SELECT mapKeys(tags) FROM Transaction",
         [lambda r: r.success])

    test("mapValues() passthrough",
         "SELECT mapValues(tags) FROM Transaction",
         [lambda r: r.success])

    test("keyset() metadata",
         "SELECT keyset() FROM Transaction",
         [lambda r: r.success, dql_has('Schema browser')])

    test("eventType() metadata",
         "SELECT eventType() FROM Transaction",
         [lambda r: r.success, dql_has('Schema browser')])

    test("bytecountestimate() ingest",
         "SELECT bytecountestimate() FROM Transaction SINCE 1 day ago",
         [lambda r: r.success, dql_has('bytecountestimate')])

    test("aggregationendtime()",
         "SELECT aggregationendtime(), count(*) FROM Transaction TIMESERIES 1 hour",
         [lambda r: r.success, dql_has('end(')])

    test("buckets() â†’ bin()",
         "SELECT count(*) FROM Transaction FACET buckets(duration, 10, 5)",
         [lambda r: r.success, dql_has('bin(')])

    # â”€â”€ GROUP 13: Combinations & edge cases â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n  Group 13: Combinations & Edge Cases")
    print("  " + "-" * 40)

    test("SLIDE BY + FACET ORDER BY combined",
         "SELECT average(duration) FROM Transaction "
         "FACET appName ORDER BY max(duration) "
         "TIMESERIES 5 minutes SLIDE BY 1 minute",
         [lambda r: r.success, dql_has('SLIDE BY'), dql_has('FACET ORDER BY')])

    test("derivative + TIMESERIES + FACET",
         "SELECT derivative(count(*), 1 minute) FROM Transaction TIMESERIES FACET appName",
         [lambda r: r.success, dql_has('delta(')])

    test("clamp + jparse in same query",
         "FROM Log SELECT clamp_max(numeric(jparse(message, '$.latency')), 1000) WHERE level = 'INFO'",
         [lambda r: r.success, dql_has('if('), dql_has('1000')])

    test("WITH TIMEZONE + COMPARE WITH",
         "SELECT count(*) FROM Transaction SINCE 1 day ago COMPARE WITH 1 week ago "
         "WITH TIMEZONE 'America/Chicago'",
         [lambda r: r.success, dql_has('America/Chicago'), dql_not_has('shift:')])

    test("PREDICT + TIMESERIES",
         "SELECT average(duration) FROM Transaction TIMESERIES 1 hour PREDICT",
         [lambda r: r.success, dql_has('Davis AI')])

    # â”€â”€ Subquery / Lookup Tests â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    
    test("IN (SELECT ... FROM ...) subquery â†’ lookup",
         "FROM Span SELECT duration, db.statement WHERE service.name = 'my-api' "
         "AND parentId in (SELECT id from Span where service.name = 'my-api' "
         "and name = 'list-cmd-01' limit max) limit max",
         [lambda r: r.success, dql_has('lookup [fetch spans'),
          dql_has('sourceField:span.parent_id'), dql_has('lookupField:span.id'),
          dql_has('isNotNull(sub.span.id)')])

    test("IN (FROM ... SELECT ...) subquery â†’ lookup",
         "SELECT count(*) FROM Span WHERE service.name = 'order-api' "
         "AND trace.id IN (FROM Span SELECT trace.id WHERE appName = 'auth-api' "
         "AND name = 'authenticate') FACET name TIMESERIES",
         [lambda r: r.success, dql_has('lookup [fetch spans'),
          dql_has('sourceField:trace.id'), dql_has('lookupField:trace.id'),
          dql_has('isNotNull(sub.trace.id)')])

    test("NOT IN subquery â†’ lookup + isNull",
         "FROM Span SELECT count(*) WHERE name NOT IN (SELECT name FROM Span WHERE error.class IS NOT NULL)",
         [lambda r: r.success, dql_has('lookup [fetch spans'),
          dql_has('isNull(sub.span.name)')])

    test("duration.ms/1000 â†’ duration (simplification)",
         "SELECT (duration.ms)/1000 as seconds FROM Span WHERE name = 'mongodb.find'",
         [lambda r: r.success, dql_has('duration'), dql_not_has('/ 1000')])

    # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
    # GROUP 14: 100% CONVERSION GUARANTEE â€” STRUCTURAL VALIDITY
    # Every test auto-checks: success, no NRQL leaks, balanced syntax,
    # no invalid functions. If ANY fail, compiler emits invalid DQL.
    # â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
    print("\n  Group 14: 100% Conversion Guarantee â€” Structural Validity")
    print("  " + "-" * 60)

    NRQL_KEYWORDS = ['SELECT ', 'FACET ', 'SINCE ', 'UNTIL ', 'TIMESERIES ',
                     'EXTRAPOLATE', 'COMPARE WITH', 'LIMIT MAX']
    NRQL_EVENTS = ['FROM Transaction ', 'FROM TransactionError ', 'FROM Span ',
                   'FROM Log ', 'FROM Metric ', 'FROM SystemSample',
                   'FROM ProcessSample', 'FROM K8sContainerSample',
                   'FROM K8sNodeSample', 'FROM K8sPodSample',
                   'FROM PageView', 'FROM SyntheticCheck', 'FROM NetworkSample',
                   'FROM StorageSample', 'FROM ContainerSample',
                   'FROM K8sClusterSample', 'FROM K8sDeploymentSample',
                   'FROM PageAction', 'FROM BrowserInteraction',
                   'FROM JavaScriptError', 'FROM AjaxRequest',
                   'FROM InfrastructureEvent', 'FROM AwsLambdaInvocation']
    INVALID_FUNCS = ['uniqueCount(', 'median(', 'apdex(',
                     'bytecountestimate(', 'latest(', 'earliest(']
    DQL_RESERVED_ALIASES = {'duration', 'timestamp', 'timeframe', 'string',
                            'long', 'double', 'boolean', 'ip', 'record',
                            'array', 'fetch', 'filter', 'summarize', 'fields',
                            'sort', 'limit', 'lookup', 'join', 'append',
                            'parse', 'from', 'to', 'by', 'in', 'is', 'not',
                            'and', 'or', 'true', 'false', 'null'}

    def valid_dql():
        """Universal structural validity check for ANY DQL output."""
        def check(r):
            code = '\n'.join(l for l in r.dql.split('\n')
                             if l.strip() and not l.strip().startswith('//'))
            if not code.strip():
                return
            for kw in NRQL_KEYWORDS:
                assert kw not in code, f"NRQL keyword leaked: '{kw.strip()}'"
            for et in NRQL_EVENTS:
                assert et not in code, f"NR event type leaked: '{et.strip()}'"
            for fn in INVALID_FUNCS:
                idx = code.find(fn)
                if idx >= 0:
                    before = code[max(0, idx-40):idx]
                    assert '/*' in before, f"Invalid function '{fn}'"
            depth = 0
            for ch in code:
                if ch == '(': depth += 1
                elif ch == ')': depth -= 1
                assert depth >= 0, "Unbalanced parens (too many closing)"
            assert depth == 0, f"Unbalanced parens ({depth} unclosed)"
            assert code.count('`') % 2 == 0, f"Unbalanced backticks"
            assert code.count('"') % 2 == 0, f"Unbalanced quotes"
            bd = 0
            for ch in code:
                if ch == '{': bd += 1
                elif ch == '}': bd -= 1
            assert bd == 0, f"Unbalanced braces ({bd})"
            assert not re.search(r'\|\s*\|', code), "Empty pipe segment"
            for line in code.split('\n'):
                cmd = line.strip().lstrip('| ')
                if cmd.startswith('fieldsAdd '):
                    for agg in ['sum(', 'avg(', 'count(', 'min(', 'max(',
                                'countDistinct(', 'percentile(']:
                        m2 = re.search(r'=\s*' + re.escape(agg), cmd[10:])
                        if m2:
                            assert False, f"Aggregation {agg} in fieldsAdd"
            for line in code.split('\n'):
                cmd = line.strip().lstrip('| ')
                if cmd.startswith(('summarize ', 'makeTimeseries ',
                                   'timeseries ', 'fieldsAdd ')):
                    for m2 in re.finditer(r'(?<![`\w])(\w+)\s*=(?!=)', cmd):
                        alias = m2.group(1)
                        if alias.lower() in DQL_RESERVED_ALIASES:
                            assert f'`{alias}`' in line, \
                                f"Bare reserved alias '{alias}'"
            for line in code.split('\n'):
                for m2 in re.finditer(r'(?<![`\w])(\d\w+)\s*=(?!=)', line):
                    alias = m2.group(1)
                    assert f'`{alias}`' in line, f"Bare digit-prefix alias '{alias}'"
            for m2 in re.finditer(r'substring\(([^)]+)\)', code):
                args = m2.group(1)
                parts = [p.strip() for p in args.split(',')]
                if len(parts) >= 3:
                    assert 'from:' in args, f"substring without named params"
        return check

    V = valid_dql

    # â”€â”€ 14a: Every aggregation function â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n    14a: Every aggregation function")

    test("G14: count(*)", "SELECT count(*) FROM Transaction", [V(), code_has('count()')])
    test("G14: sum(field)", "SELECT sum(duration) FROM Transaction", [V(), code_has('sum(duration)')])
    test("G14: average(field)", "SELECT average(duration) FROM Transaction", [V(), code_has('avg(duration)')])
    test("G14: max(field)", "SELECT max(duration) FROM Transaction", [V(), code_has('max(duration)')])
    test("G14: min(field)", "SELECT min(duration) FROM Transaction", [V(), code_has('min(duration)')])
    test("G14: percentile(f,95)", "SELECT percentile(duration, 95) FROM Transaction", [V(), code_has('percentile(duration, 95)')])
    test("G14: percentile multi", "SELECT percentile(duration, 50, 90, 95, 99) FROM Transaction", [V(), code_has('p50='), code_has('p99=')])
    test("G14: uniqueCountâ†’countDistinctExact", "SELECT uniqueCount(appName) FROM Transaction", [V(), code_has('countDistinctExact(service.name)')])
    test("G14: uniquesâ†’collectDistinct", "SELECT uniques(appName) FROM Transaction", [V(), code_has('collectDistinct(service.name)')])
    test("G14: latestâ†’takeLast", "SELECT latest(duration) FROM Transaction", [V(), code_has('takeLast(duration)')])
    test("G14: earliestâ†’takeFirst", "SELECT earliest(timestamp) FROM Transaction", [V(), code_has('takeFirst(timestamp)')])
    test("G14: medianâ†’percentile 50", "SELECT median(duration) FROM Transaction", [V(), code_has('percentile(duration, 50)')])
    test("G14: stddevâ†’stddev (DQL native)", "SELECT stddev(duration) FROM Transaction", [V(), code_has('stddev(')])
    test("G14: rate(count,1m)", "SELECT rate(count(*), 1 minute) FROM Transaction", [V()])
    test("G14: percentageâ†’countIf", "SELECT percentage(count(*), WHERE duration > 1) FROM Transaction", [V(), code_has('countIf(')])
    test("G14: filter(count)â†’countIf", "SELECT filter(count(*), WHERE error IS true) FROM Transaction", [V(), code_has('countIf(')])
    test("G14: filter(sum)â†’sumIf", "SELECT filter(sum(duration), WHERE error IS true) FROM Transaction", [V(), code_has('sumIf(')])
    test("G14: filter(avg)â†’avgIf", "SELECT filter(average(duration), WHERE duration > 1) FROM Transaction", [V(), code_has('avgIf(')])
    test("G14: apdex(f,t)", "SELECT apdex(duration, 0.5) FROM Transaction", [V(), code_not_has('apdex(')])
    test("G14: histogram(f,c,b)", "SELECT histogram(duration, 10, 20) FROM Transaction", [V(), code_has('bin(')])
    test("G14: derivative(count,1m)", "SELECT derivative(count(*), 1 minute) FROM Transaction TIMESERIES", [V(), code_has('delta(')])
    test("G14: cdfPercentage", "FROM PageView SELECT cdfPercentage(duration, 1, 3, 5)", [V(), code_has('countIf(')])

    # â”€â”€ 14b: Every scalar/string/math function â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n    14b: Every scalar/string/math function")

    test("G14: substring 3-arg named", "SELECT substring(request.uri, 0, 50) FROM Transaction LIMIT 10", [V(), code_has('from:0'), code_has('to:50')])
    test("G14: substring 2-arg", "SELECT substring(request.uri, 5) FROM Transaction LIMIT 10", [V(), code_has('substring(')])
    test("G14: indexOf", "SELECT indexOf(name, '.') FROM Transaction LIMIT 10", [V(), code_has('indexOf(span.name')])
    test("G14: lengthâ†’stringLength", "SELECT length(name) FROM Transaction LIMIT 10", [V(), code_has('stringLength(span.name')])
    test("G14: lower()", "SELECT lower(name) FROM Transaction LIMIT 10", [V(), code_has('lower(span.name')])
    test("G14: upper()", "SELECT upper(name) FROM Transaction LIMIT 10", [V(), code_has('upper(span.name')])
    test("G14: concat()", "SELECT concat(appName, '-', name) FROM Transaction LIMIT 10", [V(), code_has('concat(service.name')])
    test("G14: abs()", "SELECT abs(duration - 1) FROM Transaction LIMIT 10", [V(), code_has('abs(')])
    test("G14: ceil()", "SELECT ceil(duration) FROM Transaction LIMIT 10", [V(), code_has('ceil(')])
    test("G14: floor()", "SELECT floor(duration) FROM Transaction LIMIT 10", [V(), code_has('floor(')])
    test("G14: round()", "SELECT round(duration, 2) FROM Transaction LIMIT 10", [V(), code_has('round(')])
    test("G14: sqrt()", "SELECT sqrt(duration) FROM Transaction LIMIT 10", [V(), code_has('sqrt(')])
    test("G14: powâ†’pow (DQL native)", "SELECT pow(duration, 2) FROM Transaction LIMIT 10", [V(), code_has('pow(')])
    test("G14: log10()", "SELECT log10(duration) FROM Transaction LIMIT 10", [V(), code_has('log10(')])
    test("G14: lnâ†’log", "SELECT ln(duration) FROM Transaction LIMIT 10", [V(), code_has('log(duration')])
    test("G14: exp()", "SELECT exp(duration) FROM Transaction LIMIT 10", [V(), code_has('exp(')])
    test("G14: numericâ†’toDouble", "SELECT numeric('123') FROM Transaction LIMIT 10", [V(), code_has('toDouble(')])
    test("G14: stringâ†’toString", "SELECT string(httpResponseCode) FROM Transaction LIMIT 10", [V(), code_has('toString(')])
    test("G14: if(cond,a,b)", "SELECT if(duration > 1, 'slow', 'fast') FROM Transaction LIMIT 10", [V(), code_has('if(')])

    # â”€â”€ 14c: Every time function â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n    14c: Every time function")

    test("G14: dateOfâ†’formatTimestamp", "SELECT count(*) FROM Transaction FACET dateOf(timestamp)", [V(), code_has('formatTimestamp(')])
    test("G14: hourOfâ†’getHour", "SELECT count(*) FROM Transaction FACET hourOf(timestamp)", [V(), code_has('getHour(')])
    test("G14: minuteOfâ†’getMinute", "SELECT count(*) FROM Transaction FACET minuteOf(timestamp)", [V(), code_has('getMinute(')])
    test("G14: dayOfWeekâ†’getDayOfWeek", "SELECT count(*) FROM Transaction FACET dayOfWeek(timestamp)", [V(), code_has('getDayOfWeek(')])
    test("G14: weekOfâ†’getWeekOfYear", "SELECT count(*) FROM Transaction FACET weekOf(timestamp)", [V(), code_has('getWeekOfYear(')])
    test("G14: monthOfâ†’getMonth", "SELECT count(*) FROM Transaction FACET monthOf(timestamp)", [V(), code_has('getMonth(')])
    test("G14: yearOfâ†’getYear", "SELECT count(*) FROM Transaction FACET yearOf(timestamp)", [V(), code_has('getYear(')])
    test("G14: aggregationendtimeâ†’end", "SELECT aggregationendtime(), count(*) FROM Transaction TIMESERIES 1 hour", [V(), code_has('end(')])

    # â”€â”€ 14d: Every event type â†’ DQL data source â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n    14d: Every event type â†’ DQL data source")

    test("G14: Transactionâ†’spans", "SELECT count(*) FROM Transaction", [V(), code_has('fetch spans')])
    test("G14: TransactionErrorâ†’spans+error", "SELECT count(*) FROM TransactionError", [V(), code_has('fetch spans'), code_has('otel.status_code')])
    test("G14: Spanâ†’spans", "SELECT count(*) FROM Span", [V(), code_has('fetch spans')])
    test("G14: Logâ†’logs", "FROM Log SELECT count(*)", [V(), code_has('fetch logs')])
    test("G14: LogEventâ†’logs", "SELECT count(*) FROM LogEvent", [V(), code_has('fetch logs')])
    test("G14: SystemSampleâ†’metric", "SELECT average(cpuPercent) FROM SystemSample TIMESERIES", [V(), code_has('timeseries')])
    test("G14: ProcessSampleâ†’metric", "SELECT average(cpuPercent) FROM ProcessSample TIMESERIES", [V(), code_has('timeseries')])
    test("G14: NetworkSampleâ†’metric", "SELECT average(transmitBytesPerSecond) FROM NetworkSample TIMESERIES", [V(), code_has('timeseries')])
    test("G14: K8sContainerSampleâ†’k8s", "SELECT average(cpuUsedCores) FROM K8sContainerSample TIMESERIES", [V(), code_has('timeseries')])
    test("G14: K8sNodeSampleâ†’k8s", "SELECT average(cpuUsedCores) FROM K8sNodeSample TIMESERIES", [V(), code_has('timeseries')])
    test("G14: K8sPodSampleâ†’k8s", "SELECT average(cpuUsedCores) FROM K8sPodSample TIMESERIES", [V(), code_has('timeseries')])
    test("G14: K8sClusterSampleâ†’k8s", "SELECT count(*) FROM K8sClusterSample", [V()])
    test("G14: K8sDeploymentSampleâ†’k8s", "SELECT count(*) FROM K8sDeploymentSample", [V()])
    test("G14: PageViewâ†’bizevents", "SELECT count(*) FROM PageView", [V(), code_has('fetch bizevents')])
    test("G14: PageActionâ†’bizevents", "SELECT count(*) FROM PageAction", [V(), code_has('fetch bizevents')])
    test("G14: BrowserInteractionâ†’bizevents", "SELECT count(*) FROM BrowserInteraction", [V(), code_has('fetch bizevents')])
    test("G14: JavaScriptErrorâ†’bizevents", "SELECT count(*) FROM JavaScriptError", [V(), code_has('fetch bizevents')])
    test("G14: AjaxRequestâ†’bizevents", "SELECT count(*) FROM AjaxRequest", [V(), code_has('fetch bizevents')])
    test("G14: SyntheticCheckâ†’synthetic", "SELECT count(*) FROM SyntheticCheck", [V(), code_has('dt.synthetic')])
    test("G14: InfrastructureEventâ†’events", "SELECT count(*) FROM InfrastructureEvent", [V()])
    test("G14: AwsLambdaInvocationâ†’spans", "SELECT count(*) FROM AwsLambdaInvocation", [V(), code_has('fetch spans')])
    test("G14: NrCustomAppEventâ†’bizevents", "SELECT count(*) FROM NrCustomAppEvent", [V(), code_has('fetch bizevents')])

    # â”€â”€ 14e: Critical field mappings â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n    14e: Critical field mappings")

    test("G14: appNameâ†’service.name", "SELECT count(*) FROM Transaction WHERE appName = 'x'", [V(), code_has('service.name')])
    test("G14: hostâ†’host.name", "SELECT count(*) FROM Transaction FACET host", [V(), code_has('host.name')])
    test("G14: hostnameâ†’host.name", "SELECT count(*) FROM Transaction FACET hostname", [V(), code_has('host.name')])
    test("G14: httpResponseCodeâ†’http.response.status_code", "SELECT count(*) FROM Transaction FACET httpResponseCode", [V(), code_has('http.response.status_code')])
    test("G14: http.statusCodeâ†’http.response.status_code", "SELECT count(*) FROM Transaction WHERE http.statusCode = 200", [V(), code_has('http.response.status_code')])
    test("G14: transactionTypeâ†’span.kind", "SELECT count(*) FROM Transaction WHERE transactionType = 'Web'", [V(), code_has('span.kind'), code_not_has('transactionType')])
    test("G14: request.uriâ†’http.request.path", "SELECT count(*) FROM Transaction WHERE request.uri LIKE '%api%'", [V(), code_has('http.request.path')])
    test("G14: request.methodâ†’http.request.method", "SELECT count(*) FROM Transaction FACET request.method", [V(), code_has('http.request.method')])
    test("G14: errorTypeâ†’error.type", "SELECT count(*) FROM Transaction FACET errorType", [V(), code_has('error.type'), code_not_has('errorType')])
    test("G14: errorMessageâ†’error.message", "SELECT count(*) FROM Transaction FACET errorMessage", [V(), code_has('error.message')])
    test("G14: messageâ†’content", "SELECT count(*) FROM Log WHERE message LIKE '%error%'", [V(), code_has('content')])
    test("G14: levelâ†’loglevel", "SELECT count(*) FROM Log WHERE level = 'ERROR'", [V(), code_has('loglevel')])
    test("G14: traceIdâ†’trace_id", "SELECT count(*) FROM Transaction FACET traceId", [V(), code_has('trace_id')])
    test("G14: parentIdâ†’span.parent_id", "SELECT count(*) FROM Span FACET parentId", [V(), code_has('span.parent_id')])
    test("G14: clusterNameâ†’k8s.cluster.name", "SELECT count(*) FROM K8sContainerSample WHERE clusterName = 'test'", [V(), code_has('k8s.cluster.name')])
    test("G14: podNameâ†’k8s.pod.name", "SELECT count(*) FROM K8sContainerSample FACET podName", [V(), code_has('k8s.pod.name')])
    test("G14: containerNameâ†’k8s.container.name", "SELECT count(*) FROM K8sContainerSample FACET containerName", [V(), code_has('k8s.container.name')])
    test("G14: nodeNameâ†’k8s.node.name", "SELECT count(*) FROM K8sNodeSample FACET nodeName", [V(), code_has('k8s.node.name')])
    test("G14: namespaceNameâ†’k8s.namespace.name", "SELECT count(*) FROM K8sContainerSample FACET namespaceName", [V(), code_has('k8s.namespace.name')])
    test("G14: deploymentNameâ†’k8s.deployment.name", "SELECT count(*) FROM Transaction FACET deploymentName", [V(), code_has('k8s.deployment.name'), code_not_has('deploymentName')])
    test("G14: pageUrlâ†’page.url", "SELECT count(*) FROM PageView FACET pageUrl", [V(), code_has('page.url')])
    test("G14: userAgentNameâ†’browser.name", "SELECT count(*) FROM PageView FACET userAgentName", [V(), code_has('browser.name')])
    test("G14: databaseCallCountâ†’db.call_count", "SELECT sum(databaseCallCount) FROM Transaction", [V(), code_has('db.call_count'), code_not_has('databaseCallCount')])
    test("G14: externalCallCountâ†’http.call_count", "SELECT sum(externalCallCount) FROM Transaction", [V(), code_has('http.call_count'), code_not_has('externalCallCount')])

    # â”€â”€ 14f: Every operator/condition type â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n    14f: Every operator/condition type")

    test("G14: = â†’ ==", "SELECT count(*) FROM Transaction WHERE appName = 'test'", [V(), code_has('== "test"')])
    test("G14: != preserved", "SELECT count(*) FROM Transaction WHERE appName != 'test'", [V(), code_has('!= "test"')])
    test("G14: > preserved", "SELECT count(*) FROM Transaction WHERE duration > 1", [V(), code_has('> 1')])
    test("G14: >= preserved", "SELECT count(*) FROM Transaction WHERE duration >= 0.5", [V(), code_has('>= 500us')])
    test("G14: < preserved", "SELECT count(*) FROM Transaction WHERE duration < 2", [V(), code_has('< 2')])
    test("G14: <= preserved", "SELECT count(*) FROM Transaction WHERE duration <= 10", [V(), code_has('<= 10')])
    test("G14: IS NULLâ†’isNull", "SELECT count(*) FROM Transaction WHERE error IS NULL", [V(), code_has('isNull(')])
    test("G14: IS NOT NULLâ†’isNotNull", "SELECT count(*) FROM Transaction WHERE error IS NOT NULL", [V(), code_has('isNotNull(')])
    test("G14: INâ†’in()", "SELECT count(*) FROM Transaction WHERE appName IN ('a', 'b', 'c')", [V(), code_has('in(service.name, {"a", "b", "c"})')])
    test("G14: NOT INâ†’not in()", "SELECT count(*) FROM Transaction WHERE appName NOT IN ('x', 'y')", [V(), code_has('not in(service.name, {"x", "y"})')])
    test("G14: LIKE %x%â†’contains", "SELECT count(*) FROM Transaction WHERE name LIKE '%payment%'", [V(), code_has('contains(')])
    test("G14: LIKE x%â†’startsWith", "SELECT count(*) FROM Transaction WHERE name LIKE 'api/%'", [V(), code_has('startsWith(')])
    test("G14: LIKE %xâ†’endsWith", "SELECT count(*) FROM Transaction WHERE name LIKE '%/health'", [V(), code_has('endsWith(')])
    test("G14: NOT LIKEâ†’not(contains)", "SELECT count(*) FROM Transaction WHERE name NOT LIKE '%test%'", [V(), code_has('not(contains(')])
    test("G14: RLIKEâ†’no RLIKE", "SELECT count(*) FROM Transaction WHERE name RLIKE '.*api.*'", [V(), code_not_has('RLIKE')])
    test("G14: IS trueâ†’== true", "SELECT count(*) FROM Transaction WHERE error IS true", [V(), code_has('== true')])
    test("G14: IS falseâ†’== false", "SELECT count(*) FROM Transaction WHERE error IS false", [V(), code_has('== false')])
    test("G14: AND preserved", "SELECT count(*) FROM Transaction WHERE appName = 'a' AND duration > 1", [V(), code_has(' and ')])
    test("G14: OR preserved", "SELECT count(*) FROM Transaction WHERE appName = 'a' OR appName = 'b'", [V(), code_has(' or ')])
    test("G14: nested (AND/OR)", "SELECT count(*) FROM Transaction WHERE (appName = 'a' OR appName = 'b') AND duration > 1", [V(), code_has(' or '), code_has(' and ')])

    # â”€â”€ 14g: Every alias edge case â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n    14g: Every alias edge case")

    test("G14: alias 'duration'â†’bt", "SELECT average(duration) AS 'duration' FROM Transaction", [V(), code_has('`duration`=')])
    test("G14: alias 'timestamp'â†’bt", "SELECT max(timestamp) AS 'timestamp' FROM Transaction", [V(), code_has('`timestamp`=')])
    test("G14: alias 'from'â†’bt", "SELECT count(*) AS 'from' FROM Transaction", [V(), code_has('`from`=')])
    test("G14: alias 'to'â†’bt", "SELECT count(*) AS 'to' FROM Transaction", [V(), code_has('`to`=')])
    test("G14: alias 'in'â†’bt", "SELECT count(*) AS 'in' FROM Transaction", [V(), code_has('`in`=')])
    test("G14: alias 'filter'â†’bt", "SELECT count(*) AS 'filter' FROM Transaction", [V(), code_has('`filter`=')])
    test("G14: alias 'fetch'â†’bt", "SELECT count(*) AS 'fetch' FROM Transaction", [V(), code_has('`fetch`=')])
    test("G14: alias 'sort'â†’bt", "SELECT count(*) AS 'sort' FROM Transaction", [V(), code_has('`sort`=')])
    test("G14: alias 'not'â†’bt", "SELECT count(*) AS 'not' FROM Transaction", [V(), code_has('`not`=')])
    test("G14: alias 'true'â†’bt", "SELECT count(*) AS 'true' FROM Transaction", [V(), code_has('`true`=')])
    test("G14: alias 'null'â†’bt", "SELECT count(*) AS 'null' FROM Transaction", [V(), code_has('`null`=')])
    test("G14: alias '2XX'â†’bt digit", "SELECT percentage(count(*), WHERE http.statusCode >= 200 AND http.statusCode < 300) AS '2XX' FROM Transaction", [V(), code_has('`2XX`')])
    test("G14: alias '4XX'â†’bt digit", "SELECT percentage(count(*), WHERE http.statusCode >= 400 AND http.statusCode < 500) AS '4XX' FROM Transaction", [V(), code_has('`4XX`')])
    test("G14: alias '5XX'â†’bt digit", "SELECT percentage(count(*), WHERE http.statusCode >= 500) AS '5XX' FROM Transaction", [V(), code_has('`5XX`')])
    test("G14: alias '$/Month'â†’bt special", "SELECT count(*) / 1000 AS '$/Month' FROM Transaction", [V(), code_has('`$/Month`')])
    test("G14: alias 'Requests thousands'â†’bt space", "SELECT count(*) / 1000 AS 'Requests thousands' FROM Transaction", [V(), code_has('`Requests thousands`')])
    test("G14: alias 'Avg.Duration'â†’bt dot", "SELECT average(duration) AS 'Avg.Duration' FROM Transaction", [V(), code_has('`Avg.Duration`')])
    test("G14: alias 'Count (total)'â†’bt parens", "SELECT count(*) AS 'Count (total)' FROM Transaction", [V()])
    test("G14: alias 'P&L'â†’bt ampersand", "SELECT count(*) AS 'P&L' FROM Transaction", [V()])

    # â”€â”€ 14h: Timeseries, Compare, Slide â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n    14h: Timeseries, Compare With, Slide By")

    test("G14: TIMESERIESâ†’makeTimeseries", "SELECT count(*) FROM Transaction TIMESERIES", [V(), code_has('makeTimeseries')])
    test("G14: TIMESERIES 5mâ†’interval:5m", "SELECT count(*) FROM Transaction TIMESERIES 5 minutes", [V(), code_has('interval: 5m')])
    test("G14: TIMESERIES 1hâ†’interval:1h", "SELECT count(*) FROM Transaction TIMESERIES 1 hour", [V(), code_has('interval: 1h')])
    test("G14: TIMESERIES AUTOâ†’no interval", "SELECT count(*) FROM Transaction TIMESERIES AUTO", [V(), code_has('makeTimeseries'), code_not_has('interval:')])
    test("G14: SINCE/UNTIL stripped", "SELECT count(*) FROM Transaction SINCE 1 hour ago UNTIL 30 minutes ago", [V(), code_not_has('SINCE'), code_not_has('UNTIL')])
    test("G14: EXTRAPOLATE stripped", "SELECT count(*) FROM Transaction EXTRAPOLATE", [V(), code_not_has('EXTRAPOLATE')])
    test("G14: COMPARE WITH metricâ†’shift:", "SELECT average(cpuPercent) FROM SystemSample TIMESERIES COMPARE WITH 1 week ago", [V(), code_has('shift:-7d')])
    test("G14: COMPARE WITH span (comment)", "SELECT count(*) FROM Transaction TIMESERIES COMPARE WITH 1 day ago", [V()])
    test("G14: SLIDE BYâ†’rolling", "SELECT average(duration) FROM Transaction TIMESERIES 5 minutes SLIDE BY 1 minute", [V(), code_has('rolling(')])
    test("G14: SLIDE BY AUTOâ†’rolling(f,3)", "SELECT average(duration) FROM Transaction TIMESERIES 10 minutes SLIDE BY AUTO", [V(), code_has('rolling(')])
    test("G14: LIMIT N", "SELECT count(*) FROM Transaction FACET appName LIMIT 25", [V(), code_has('limit 25')])

    # â”€â”€ 14i: Complex real-world patterns â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n    14i: Complex real-world patterns (US Foods)")

    test("G14: Error rate filter/filter*100",
         "SELECT filter(count(*), WHERE error IS true) / filter(count(*), WHERE duration > 0) * 100 "
         "AS 'Error Rate' FROM Transaction WHERE appName = 'prod-usf-order-api' TIMESERIES",
         [V(), code_has('countIf(')])
    test("G14: Multi-percentage status codes",
         "SELECT percentage(count(http.statusCode), WHERE http.statusCode >= 200 AND http.statusCode < 300) AS '2XX', "
         "percentage(count(http.statusCode), WHERE http.statusCode >= 400 AND http.statusCode < 500) AS '4XX', "
         "percentage(count(http.statusCode), WHERE http.statusCode >= 500) AS '5XX' "
         "FROM Transaction WHERE appName = 'prod-usf-auth-api' TIMESERIES",
         [V(), code_has('countIf(')])
    test("G14: K8s memory util multi-metric",
         "SELECT latest(memoryUsedBytes) / latest(memoryLimitBytes) * 100 "
         "FROM K8sContainerSample WHERE clusterName = 'usf-app-prod' FACET podName TIMESERIES",
         [V()])
    test("G14: Log error by service+level",
         "FROM Log SELECT count(*) WHERE level IN ('ERROR', 'FATAL') FACET service.name, level TIMESERIES",
         [V(), code_has('fetch logs')])
    test("G14: Throughput multi-app",
         "SELECT rate(count(*), 1 minute) FROM Transaction "
         "WHERE appName IN ('api-1', 'api-2', 'api-3') FACET appName TIMESERIES",
         [V(), code_has('in(service.name')])
    test("G14: Subquery trace correlation",
         "SELECT count(*) FROM Transaction WHERE appName = 'order-api' "
         "AND trace.id IN (FROM Span SELECT trace.id WHERE appName = 'auth-api' "
         "AND name = 'authenticate') FACET httpResponseCode TIMESERIES",
         [V(), code_has('lookup')])
    test("G14: Funnel analysis",
         "SELECT funnel(session, WHERE page = '/home' AS 'Home', "
         "WHERE page = '/cart' AS 'Cart', WHERE page = '/checkout' AS 'Checkout') FROM PageView",
         [V(), code_has('countIf(')])
    test("G14: count+avg+p95+filter combined",
         "SELECT count(*) AS 'Total', average(duration) AS 'Avg', "
         "percentile(duration, 95) AS 'P95', "
         "filter(count(*), WHERE error IS true) AS 'Errors' "
         "FROM Transaction WHERE appName = 'prod-api' TIMESERIES",
         [V(), code_has('countIf(')])
    test("G14: Infra CPU with hostname filter",
         "SELECT average(cpuPercent) FROM SystemSample WHERE hostname LIKE 'prod-usf-%' FACET hostname TIMESERIES",
         [V(), code_has('timeseries')])
    test("G14: clamp_max+clamp_min combined",
         "SELECT clamp_max(average(duration), 10), clamp_min(count(*), 0) FROM Transaction",
         [V(), code_has('if(')])
    test("G14: FROM prefix (non-standard order)",
         "FROM Transaction SELECT count(*), average(duration) WHERE appName = 'test' FACET appName TIMESERIES AUTO",
         [V(), code_has('fetch spans'), code_has('service.name')])
    test("G14: Custom event FACET+LIMIT",
         "SELECT count(*) FROM NrCustomAppEvent WHERE eventType = 'OrderPlaced' FACET customerSegment LIMIT 20",
         [V(), code_has('limit 20')])

    # Session 69 regression tests
    print("\n    14j: Session 69 â€” CASES/matchesPhrase, multi-line comment, apdex t:N")
    test("S69: matchesPhrase in CASES",
         "SELECT count(*) FROM BrowserInteraction FACET CASES (matchesPhrase(targetUrl, \"/search2\") as 'Coveo', matchesPhrase(targetUrl, \"/search\") as 'Legacy')",
         [V(), code_has('contains(targetUrl'), code_has('"Coveo"'), code_has('"Legacy"')])
    test("S69: NRQL comment single-line",
         "SELECT\n  count(*)\nFROM\n  Transaction",
         [V(), lambda r: '\n' not in r.dql.split('\n')[0] or r.dql.split('\n')[0].startswith('//')])
    test("S69: apdex t:3 threshold",
         "SELECT apdex(duration, t:3) FROM BrowserInteraction",
         [V(), code_has('countIf(duration < 3.0'), code_has('countIf(duration >= 3.0')])
    test("S69: apdex t:0.5 threshold",
         "SELECT apdex(duration, t:0.5) FROM BrowserInteraction",
         [V(), code_has('countIf(duration < 0.5'), code_has('countIf(duration >= 0.5')])
    test("S69: K8s isReady â†’ entity fetch",
         "SELECT latest(isReady) FROM K8sPodSample WHERE clusterName = 'prod'",
         [V(), code_has('entity'), code_not_has('timeseries')])

    # 14k: AUDIT FIXES - Context-aware mapping, nested agg detection
    print("\n    14k: Audit Fixes - Context-aware mapping, nested aggregation detection")

    test("AUDIT: metric context preserves id dimension",
         "SELECT latest(consumer_lag) FROM Metric WHERE id = 'lkc_123' FACET topic",
         [V(), code_not_has('span.id')])

    test("AUDIT: metric context preserves target dimension",
         "SELECT average(kafka.consumer.lag) FROM Metric WHERE target = 'my-cluster'",
         [V(), code_not_has('http.route')])

    test("AUDIT: span context maps entity.name to dt.entity.name",
         "SELECT count(*) FROM Transaction WHERE entity.name = 'my-svc'",
         [V(), code_has('dt.entity.name')])

    test("AUDIT: percentage simple no nested agg",
         "SELECT percentage(count(*), WHERE error IS TRUE) FROM Transaction",
         [V(), code_has('countIf'), code_has('count()')])

    test("AUDIT: apdex produces warning",
         "SELECT apdex(duration, t:0.5) FROM Transaction",
         [V(), code_has('countIf'), lambda r: any('apdex' in w for w in r.warnings)])

    test("AUDIT: multi-metric gets braces",
         "SELECT average(cpuPercent), average(memoryUsedPercent) FROM SystemSample FACET hostname TIMESERIES",
         [V(), code_has('timeseries {')])

    test("AUDIT: metric filter uses braces",
         "SELECT average(cpuPercent) FROM SystemSample WHERE hostname = 'web-1' TIMESERIES",
         [V(), code_has('filter:{')])

    # â”€â”€ Summary â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    print("\n" + "=" * 80)
    print(f"  RESULTS: {passed} passed, {failed} failed, {total} total")
    if failed == 0:
        print("  ALL TESTS PASS âœ…")
    else:
        print(f"  {failed} TESTS FAILED âŒ")
    print("=" * 80)
    return failed == 0


if __name__ == '__main__':
    run_tests()